<?php
/**
 * Plugin Name: MP Courses Inspector (MemberPress)
 * Description: Inspect MemberPress Courses: ordered curriculum (sections + lessons) + user progress with dateStarted/dateCompleted. Shortcode: [mpc_course_inspect id="123"]. JSON: /wp-json/mpc/v1/courses/<id>/full and /scan.
 * Version: 0.6.0
 * Author: ChatGPT (Sean’s helper)
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

if (!defined('ABSPATH')) exit;

/* ------------------------- Utilities ------------------------- */
function mpc_i($v){
  return '<pre style="white-space:pre-wrap;overflow:auto;max-height:520px;background:#0b1020;color:#e6f1ff;padding:12px;border-radius:8px;">'
    . esc_html(is_string($v) ? $v : wp_json_encode($v, JSON_PRETTY_PRINT))
    . '</pre>';
}
function mpc_url($path){ return esc_url_raw(home_url($path)); }
function mpc_link($url,$text=null){
  $t = $text ?: $url;
  return '<a href="'.esc_url($url).'" target="_blank" rel="noopener noreferrer">'.esc_html($t).'</a>';
}
function mpc_min_date(?string $a, ?string $b){ if(!$a) return $b; if(!$b) return $a; return (strtotime($a) <= strtotime($b)) ? $a : $b; }
function mpc_max_date(?string $a, ?string $b){ if(!$a) return $b; if(!$b) return $a; return (strtotime($a) >= strtotime($b)) ? $a : $b; }

/* -------- Post type & taxonomy registry snapshots (debug) ----- */
function mpc_list_post_types(){
  $pts = get_post_types([], 'objects');
  $out = [];
  foreach($pts as $name=>$obj){
    $out[$name] = [
      'label'        => $obj->label ?? $name,
      'public'       => (bool)($obj->public ?? false),
      'show_in_rest' => (bool)($obj->show_in_rest ?? false),
      'rest_base'    => $obj->rest_base ?? '',
      'hierarchical' => (bool)($obj->hierarchical ?? false),
      'supports'     => array_values(array_filter((array)($obj->supports ?? []))),
    ];
  }
  ksort($out);
  return $out;
}
function mpc_list_taxonomies_for($types){
  $txs = get_object_taxonomies($types, 'objects');
  $out = [];
  foreach($txs as $name=>$obj){
    $out[$name] = [
      'label'        => $obj->label ?? $name,
      'object_type'  => (array)($obj->object_type ?? []),
      'hierarchical' => (bool)($obj->hierarchical ?? false),
      'show_in_rest' => (bool)($obj->show_in_rest ?? false),
      'rest_base'    => $obj->rest_base ?? '',
    ];
  }
  ksort($out);
  return $out;
}

/* ----------------------- DB helpers -------------------------- */
function mpc_db_get_sections_for_course($course_id){
  global $wpdb;
  $table = $wpdb->prefix . 'mpcs_sections';
  $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
  if (!$exists) return [];
  // phpcs:ignore WordPress.DB.PreparedSQLPlaceholders.UnquotedComplexPlaceholder
  $rows = $wpdb->get_results($wpdb->prepare("
    SELECT id, title, description, course_id, section_order, uuid, created_at
    FROM `$table`
    WHERE course_id = %d
    ORDER BY CAST(section_order AS UNSIGNED), id
  ", $course_id), ARRAY_A);
  return $rows ?: [];
}

function mpc_db_get_progress_rows($user_id, $course_id){
  global $wpdb;
  $table = $wpdb->prefix . 'mpcs_user_progress';
  $exists = $wpdb->get_var($wpdb->prepare("SHOW TABLES LIKE %s", $table));
  if (!$exists) return ['table'=>'missing','rows'=>[]];
  $sql = $wpdb->prepare("SELECT * FROM `$table` WHERE user_id = %d AND course_id = %d LIMIT 200", $user_id, $course_id);
  // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
  $rows = $wpdb->get_results($sql, ARRAY_A);
  return ['table'=>$table, 'rows'=>$rows ?: []];
}

/* ----------------------- Progress discovery ------------------ */
/**
 * Collect per-lesson progress from:
 *  A) usermeta keys (mpcs_lesson_started_{ID}, mpcs_lesson_completed_{ID})
 *  B) mpcs_user_progress table (heuristic: lesson_id|item_id|object_id; dates started_at|created_at, completed_at|updated_at; status/progress)
 * Returns: ['lessons' => [lessonId => ['dateStarted'=>str|null, 'dateCompleted'=>str|null, 'isCompleted'=>bool]], 'course'=>['dateStarted','dateCompleted']]
 */
function mpc_collect_user_progress($user_id, $course_id){
  $res = ['lessons'=>[], 'course'=>['dateStarted'=>null, 'dateCompleted'=>null]];

  // A) usermeta
  if ($user_id){
    $um = get_user_meta($user_id);
    foreach($um as $key=>$vals){
      $val = count($vals) ? $vals[0] : null;
      if (preg_match('/^mpcs_lesson_started_(\d+)$/i', $key, $m)){
        $lid = (int)$m[1];
        $res['lessons'][$lid]['dateStarted'] = $val ?: ($res['lessons'][$lid]['dateStarted'] ?? null);
      }
      if (preg_match('/^mpcs_lesson_completed_(\d+)$/i', $key, $m)){
        $lid = (int)$m[1];
        $res['lessons'][$lid]['dateCompleted'] = $val ?: ($res['lessons'][$lid]['dateCompleted'] ?? null);
      }
      if ($key === "mpcs_course_started_{$course_id}"){
        $res['course']['dateStarted'] = $val;
      }
      if ($key === "mpcs_course_completed_{$course_id}"){
        $res['course']['dateCompleted'] = $val;
      }
    }
  }

  // B) DB table (best-effort schema sniff)
  $db = mpc_db_get_progress_rows($user_id, $course_id);
  foreach($db['rows'] as $row){
    $lesson_id = null;
    foreach(['lesson_id','item_id','object_id'] as $k){
      if (isset($row[$k]) && is_numeric($row[$k])) { $lesson_id = (int)$row[$k]; break; }
    }
    $section_id = null;
    foreach(['section_id'] as $k){
      if (isset($row[$k]) && is_numeric($row[$k])) { $section_id = (int)$row[$k]; break; }
    }
    $started = null;
    foreach(['started_at','created_at','start_time','created'] as $k){
      if (!empty($row[$k])) { $started = $row[$k]; break; }
    }
    $completed = null;
    foreach(['completed_at','updated_at','complete_time','finished_at'] as $k){
      if (!empty($row[$k])) { $completed = $row[$k]; break; }
    }
    $status = null;
    foreach(['status'] as $k){
      if (!empty($row[$k])) { $status = strtolower((string)$row[$k]); break; }
    }
    if ($lesson_id){
      if (!isset($res['lessons'][$lesson_id])) $res['lessons'][$lesson_id] = ['dateStarted'=>null,'dateCompleted'=>null];
      if ($started)   $res['lessons'][$lesson_id]['dateStarted']   = mpc_min_date($res['lessons'][$lesson_id]['dateStarted'] ?? null, $started);
      if ($completed) $res['lessons'][$lesson_id]['dateCompleted'] = mpc_max_date($res['lessons'][$lesson_id]['dateCompleted'] ?? null, $completed);
      if (!$completed && $status === 'completed'){ $res['lessons'][$lesson_id]['dateCompleted'] = $res['lessons'][$lesson_id]['dateCompleted'] ?? $started ?? current_time('mysql'); }
      // optionally keep section_id in case needed
      if ($section_id) $res['lessons'][$lesson_id]['sectionId'] = $section_id;
    }
  }

  // final isCompleted flag
  foreach($res['lessons'] as $lid=>&$L){
    $L['isCompleted'] = !empty($L['dateCompleted']);
  }
  unset($L);

  // make sure course dates exist (aggregate if not explicitly present)
  if (!$res['course']['dateStarted'] || !$res['course']['dateCompleted']){
    $minStart = null; $maxComplete = null;
    foreach($res['lessons'] as $L){
      $minStart   = mpc_min_date($minStart, $L['dateStarted']   ?? null);
      $maxComplete= mpc_max_date($maxComplete, $L['dateCompleted'] ?? null);
    }
    if (!$res['course']['dateStarted'])   $res['course']['dateStarted']   = $minStart;
    if (!$res['course']['dateCompleted']) $res['course']['dateCompleted'] = $maxComplete;
  }

  $res['db_source'] = $db['table'];
  return $res;
}

/* ----------------------- Lessons for sections ---------------- */
function mpc_get_lessons_for_section_ids(array $section_ids){
  if (!$section_ids) return [];

  $q = new WP_Query([
    'post_type'      => ['mpcs-lesson'],
    'posts_per_page' => -1,
    'post_status'    => ['publish','draft','pending','future','private'],
    'meta_query'     => [[
      'key'     => '_mpcs_lesson_section_id',
      'value'   => array_map('strval', $section_ids),
      'compare' => 'IN',
    ]],
    'no_found_rows'  => true,
  ]);

  $by_section = [];
  foreach($q->posts as $p){
    $sid   = (string) get_post_meta($p->ID, '_mpcs_lesson_section_id', true);
    $order = get_post_meta($p->ID, '_mpcs_lesson_lesson_order', true);
    $by_section[$sid][] = [
      'id'         => $p->ID,
      'title'      => get_the_title($p),
      'status'     => $p->post_status,
      'slug'       => $p->post_name,
      'order'      => is_numeric($order) ? intval($order) : 0,
      'rest'       => mpc_url('/wp-json/wp/v2/mpcs-lesson/'.$p->ID),
      'permalink'  => get_permalink($p->ID),
    ];
  }
  wp_reset_postdata();

  foreach($by_section as $sid => $items){
    usort($items, function($a,$b){
      if ($a['order'] === $b['order']) return $a['id'] <=> $b['id'];
      return $a['order'] <=> $b['order'];
    });
    $by_section[$sid] = array_values($items);
  }

  return $by_section;
}

/* ----------------------- Curriculum builder ------------------ */
/**
 * Returns:
 * [
 *   'course': {dateStarted,dateCompleted,progress,percent,completedCount,totalCount},
 *   'sections':[ { id,title,order,dateStarted,dateCompleted,progress,percent,completedCount,totalCount,
 *                  lessons:[ {id,title,order,dateStarted,dateCompleted,isCompleted,permalink,rest} ] } ],
 *   'unsectioned_lessons': [...]
 * ]
 */
function mpc_build_ordered_curriculum_with_progress($course_id, $user_id){
  // Sections
  $sections = mpc_db_get_sections_for_course($course_id);
  $section_ids = array_map(fn($r)=>(string)$r['id'], $sections);
  $lessons_by_section = mpc_get_lessons_for_section_ids($section_ids);

  // Progress map (per-lesson + course dates)
  $prog = mpc_collect_user_progress($user_id, $course_id);
  $lessonProg = $prog['lessons'];

  // Build sections with lesson progress
  $out_sections = [];
  $totalLessons = 0; $totalCompleted = 0;
  $courseDateStart = $prog['course']['dateStarted'] ?? null;
  $courseDateDone  = $prog['course']['dateCompleted'] ?? null;

  foreach($sections as $s){
    $sid = (string)$s['id'];
    $lessons = [];
    $secStarted = null; $secCompleted = null;
    $secTotal = 0; $secDone = 0;

    foreach(($lessons_by_section[$sid] ?? []) as $L){
      $secTotal++;
      $lp = $lessonProg[$L['id']] ?? ['dateStarted'=>null,'dateCompleted'=>null,'isCompleted'=>false];
      $row = [
        'id'           => $L['id'],
        'title'        => $L['title'],
        'order'        => $L['order'],
        'permalink'    => $L['permalink'],
        'rest'         => $L['rest'],
        'dateStarted'  => $lp['dateStarted'] ?? null,
        'dateCompleted'=> $lp['dateCompleted'] ?? null,
        'isCompleted'  => (bool)($lp['isCompleted'] ?? false),
      ];
      if ($row['isCompleted']) $secDone++;
      $secStarted  = mpc_min_date($secStarted,   $row['dateStarted']);
      $secCompleted= mpc_max_date($secCompleted, $row['dateCompleted']);
      $lessons[] = $row;
    }

    $percent = ($secTotal > 0) ? round(($secDone / $secTotal) * 100, 2) : 0.0;

    $out_sections[] = [
      'id'          => intval($s['id']),
      'uuid'        => $s['uuid'],
      'title'       => $s['title'],
      'description' => $s['description'],
      'order'       => intval($s['section_order']),
      'dateStarted' => $secStarted,
      'dateCompleted' => ($secTotal > 0 && $secDone === $secTotal) ? $secCompleted : null,
      'progress'    => ($secTotal > 0) ? ($secDone / $secTotal) : 0.0,
      'percent'     => $percent,
      'completedCount' => $secDone,
      'totalCount'  => $secTotal,
      'lessons'     => $lessons,
    ];

    $totalLessons += $secTotal;
    $totalCompleted += $secDone;
    $courseDateStart = mpc_min_date($courseDateStart, $secStarted);
    // Only consider a section's completion for courseCompleted if that section is fully done
    if ($secTotal > 0 && $secDone === $secTotal){
      $courseDateDone = mpc_max_date($courseDateDone, $secCompleted);
    }
  }

  // Unsectioned lessons (if any exist)
  $unsectioned = [];
  // (Optional scan omitted for brevity — most installs won’t need it once sections are in DB)

  // Course progress
  $coursePercent = ($totalLessons > 0) ? round(($totalCompleted / $totalLessons) * 100, 2) : 0.0;
  $courseProgress = ($totalLessons > 0) ? ($totalCompleted / $totalLessons) : 0.0;
  $courseObj = [
    'dateStarted'    => $courseDateStart,
    'dateCompleted'  => ($totalLessons > 0 && $totalCompleted === $totalLessons) ? $courseDateDone : null,
    'progress'       => $courseProgress,
    'percent'        => $coursePercent,
    'completedCount' => $totalCompleted,
    'totalCount'     => $totalLessons,
  ];

  // Sort sections by order then id
  usort($out_sections, function($a,$b){
    if ($a['order'] === $b['order']) return $a['id'] <=> $b['id'];
    return $a['order'] <=> $b['order'];
  });

  return [
    'course'              => $courseObj,
    'sections'            => $out_sections,
    'unsectioned_lessons' => $unsectioned,
    'raw'                 => ['db_source'=>$prog['db_source']], // helpful debug
  ];
}

/* ----------------------- Deep debug (optional) ---------------- */
function mpc_reverse_meta_scan($course_id, $limit=800){
  global $wpdb;
  $course_id = absint($course_id);
  $results = ['hits'=>[]];

  $rows1 = $wpdb->get_results($wpdb->prepare("
    SELECT pm.post_id, pm.meta_key, pm.meta_value
    FROM {$wpdb->postmeta} pm
    WHERE pm.meta_value = %d
    LIMIT %d
  ", $course_id, $limit));

  $needle = '%' . $wpdb->esc_like((string)$course_id) . '%';
  $rows2 = $wpdb->get_results($wpdb->prepare("
    SELECT pm.post_id, pm.meta_key, pm.meta_value
    FROM {$wpdb->postmeta} pm
    WHERE pm.meta_value LIKE %s
    LIMIT %d
  ", $needle, $limit));

  $rows = array_merge($rows1 ?: [], $rows2 ?: []);
  $agg  = [];
  foreach($rows as $r){
    $pid = (int)$r->post_id;
    if (!isset($agg[$pid])) $agg[$pid] = [];
    $val = maybe_unserialize($r->meta_value);
    $agg[$pid][] = ['key'=>$r->meta_key, 'value'=>$val];
  }

  foreach($agg as $pid=>$metas){
    $p = get_post($pid);
    $results['hits'][] = [
      'post_id'    => $pid,
      'post_type'  => $p ? $p->post_type : null,
      'title'      => $p ? get_the_title($p) : null,
      'status'     => $p ? $p->post_status : null,
      'permalink'  => $p ? get_permalink($p) : null,
      'meta_refs'  => $metas,
      'rest'       => $p ? mpc_url('/wp-json/wp/v2/' . $p->post_type . '/' . $pid) : null,
      'post_parent'=> $p ? (int)$p->post_parent : null,
    ];
  }
  return $results;
}
function mpc_probe_custom_tables($course_id){
  global $wpdb;
  $course = get_post($course_id);
  $slug   = $course ? $course->post_name : '';
  $like_patterns = ['%mpcs%','%memberpress%','%mepr%','%courses%'];

  $tables = [];
  $all = $wpdb->get_col("SHOW TABLES");
  foreach($all as $t){
    $lt = strtolower($t);
    foreach($like_patterns as $pat){
      if (fnmatch(str_replace('%','*',$pat), $lt)){
        $tables[] = $t; break;
      }
    }
  }
  $tables = array_values(array_unique($tables));

  $rows = [];
  foreach($tables as $t){
    $cols = $wpdb->get_results("SHOW COLUMNS FROM `$t`", ARRAY_A);
    if (!$cols) continue;
    $colnames = array_map(fn($c)=>$c['Field'], $cols);

    $where = [];
    foreach($colnames as $c){
      $where[] = $wpdb->prepare("`$c` = %d", $course_id);
      $where[] = $wpdb->prepare("`$c` LIKE %s", '%' . $wpdb->esc_like((string)$course_id) . '%');
      if ($slug) $where[] = $wpdb->prepare("`$c` LIKE %s", '%' . $wpdb->esc_like($slug) . '%');
    }
    $where_sql = $where ? ('WHERE ' . implode(' OR ', $where)) : '';
    // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
    $peek = $wpdb->get_results("SELECT * FROM `$t` $where_sql LIMIT 10", ARRAY_A);
    if ($peek) $rows[] = ['table'=>$t, 'matches'=>$peek];
  }

  return ['tables'=>$tables, 'hits'=>$rows];
}
function mpc_recent_curriculum_posts($limit=20){
  $types = ['mpcs-lesson','mpcs-quiz','mpcs-assignment'];
  $q = new WP_Query([
    'post_type'      => $types,
    'posts_per_page' => $limit,
    'post_status'    => ['publish','draft','pending','future','private'],
    'orderby'        => 'date',
    'order'          => 'DESC',
    'no_found_rows'  => true,
  ]);
  $out = [];
  foreach($q->posts as $p){
    $meta = get_post_meta($p->ID);
    $out[] = [
      'id'         => $p->ID,
      'title'      => get_the_title($p),
      'type'       => $p->post_type,
      'status'     => $p->post_status,
      'parent'     => (int)$p->post_parent,
      'menu_order' => (int)$p->menu_order,
      'rest'       => mpc_url('/wp-json/wp/v2/'.$p->post_type.'/'.$p->ID),
      'permalink'  => get_permalink($p->ID),
      'linkish_meta_keys' => array_values(array_filter(array_keys($meta), function($k){
        return (stripos($k,'_mpcs_lesson_section_id') !== false) || (stripos($k,'_mpcs_lesson_lesson_order') !== false);
      })),
    ];
  }
  wp_reset_postdata();
  return $out;
}

/* ----------------------- Shortcode UI ------------------------ */
add_shortcode('mpc_course_inspect', function($atts){
  $a = shortcode_atts(['id'=>0], $atts, 'mpc_course_inspect');
  $course_id = absint($a['id']);
  if (!$course_id) return '<p><em>Please provide a course ID: [mpc_course_inspect id="123"]</em></p>';

  $course = get_post($course_id);
  if (!$course || $course->post_type !== 'mpcs-course'){
    return '<p><strong>Course not found</strong> or not an <code>mpcs-course</code>. ID: '.esc_html($course_id).'</p>';
  }

  $user_id = get_current_user_id();

  $data = [];
  $data['course_info'] = [
    'ID'         => $course->ID,
    'title'      => get_the_title($course),
    'status'     => $course->post_status,
    'slug'       => $course->post_name,
    'type'       => $course->post_type,
    'permalink'  => get_permalink($course),
    'rest_link'  => mpc_url('/wp-json/wp/v2/mpcs-course/'.$course->ID),
    'meta'       => get_post_meta($course->ID),
    'post_types' => mpc_list_post_types(),
    'taxonomies' => mpc_list_taxonomies_for(['mpcs-course','mpcs-lesson','mpcs-quiz','mpcs-assignment']),
  ];

  // Ordered curriculum + progress aggregation
  $data['curriculum'] = mpc_build_ordered_curriculum_with_progress($course->ID, $user_id);

  // Debug extras
  $data['recent_curriculum_posts'] = mpc_recent_curriculum_posts(20);
  $data['deep_scan_postmeta']      = mpc_reverse_meta_scan($course->ID, 1200);
  $data['custom_table_probe']      = mpc_probe_custom_tables($course->ID);

  // Render
  $out  = '<div class="mpc-inspector">';
  $out .= '<h3>MP Courses Inspector</h3>';
  $out .= '<p>Course: <strong>'.esc_html(get_the_title($course)).'</strong> (ID '.$course->ID.')</p>';
  $out .= '<p>Permalink: '.mpc_link(get_permalink($course)).'</p>';
  $out .= '<p>WP REST (Course): '.mpc_link(mpc_url('/wp-json/wp/v2/mpcs-course/'.$course->ID)).'</p>';

  $out .= '<h4>Course Object, Post Types & Meta</h4>'.mpc_i($data['course_info']);
  $out .= '<h4>Curriculum (Ordered with Progress)</h4>'.mpc_i($data['curriculum']);

  $out .= '<h4>Recent curriculum posts</h4>'.mpc_i($data['recent_curriculum_posts']);
  $out .= '<h4>Deep Scan: postmeta that references this Course ID</h4>'.mpc_i($data['deep_scan_postmeta']);
  $out .= '<h4>Custom table probe</h4>'.mpc_i($data['custom_table_probe']);

  $out .= '<p style="margin-top:16px"><small>Progress is merged from usermeta and '.$data['curriculum']['raw']['db_source'].' (if present).</small></p>';
  $out .= '</div>';

  return $out;
});

/* ------------------------ Admin page ------------------------- */
add_action('admin_menu', function(){
  add_management_page(
    'MP Courses Inspector',
    'MP Courses Inspector',
    'manage_options',
    'mp-courses-inspector',
    'mpc_admin_page_render'
  );
});
function mpc_admin_page_render(){
  if (!current_user_can('manage_options')) return;
  $course_id = isset($_GET['course_id']) ? absint($_GET['course_id']) : 0;
  echo '<div class="wrap"><h1>MP Courses Inspector</h1>';
  echo '<form method="get" action=""><input type="hidden" name="page" value="mp-courses-inspector" />';
  echo '<p><label for="course_id">Course ID: </label> <input type="number" id="course_id" name="course_id" value="'.esc_attr($course_id).'" min="1" style="width:160px" /> ';
  submit_button('Inspect', 'primary', '', false);
  echo '</p></form>';
  if ($course_id){
    echo do_shortcode('[mpc_course_inspect id="'.$course_id.'"]');
  } else {
    echo '<p>Enter a Course ID and click Inspect, or use the shortcode on a page:</p>';
    echo '<code>[mpc_course_inspect id="31106"]</code>';
  }
  echo '</div>';
}

/* ------------------- JSON: /courses/<id>/full ---------------- */
add_action('rest_api_init', function(){
  register_rest_route('mpc/v1', '/courses/(?P<id>\d+)/full', [
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    /* 'permission_callback' => function(){ return is_user_logged_in(); }, // adjust if you want public */
    'callback' => function(\WP_REST_Request $req){
      $course_id = (int)$req->get_param('id');
      $course = get_post($course_id);
      if (!$course || $course->post_type !== 'mpcs-course'){
        return new \WP_Error('mpc_not_found', 'Course not found or wrong type', ['status'=>404]);
      }
      $user_id    = get_current_user_id();
      $curr       = mpc_build_ordered_curriculum_with_progress($course->ID, $user_id);

      return [
        'course' => [
          'id'        => $course->ID,
          'title'     => get_the_title($course),
          'status'    => $course->post_status,
          'slug'      => $course->post_name,
          'type'      => $course->post_type,
          'permalink' => get_permalink($course->ID),
          'meta'      => get_post_meta($course->ID),
          'post_types'=> mpc_list_post_types(),
        ],
        // Aggregated course progress lives inside curriculum['course']
        'curriculum' => $curr,
      ];
    }
  ]);

  /* -------- JSON: /courses/<id>/scan (debug) ----------------- */
  register_rest_route('mpc/v1', '/courses/(?P<id>\d+)/scan', [
    'methods'  => 'GET',
    'permission_callback' => '__return_true',
    /* 'permission_callback' => function(){ return current_user_can('manage_options'); }, */
    'callback' => function(\WP_REST_Request $req){
      $course_id = (int)$req->get_param('id');
      $course = get_post($course_id);
      if (!$course || $course->post_type !== 'mpcs-course'){
        return new \WP_Error('mpc_not_found', 'Course not found or wrong type', ['status'=>404]);
      }
      $user_id = get_current_user_id();
      return [
        'course'                => ['id'=>$course->ID,'title'=>get_the_title($course)],
        'post_types'            => mpc_list_post_types(),
        'curriculum'            => mpc_build_ordered_curriculum_with_progress($course->ID, $user_id),
        'recent_curriculum'     => mpc_recent_curriculum_posts(30),
        'custom_table_probe'    => mpc_probe_custom_tables($course->ID),
        'deep_scan_postmeta'    => mpc_reverse_meta_scan($course->ID, 1200),
      ];
    }
  ]);
});
