<?php
/**
 * Plugin Name: Scene Credits Meta Box
 * Description: Adds custom fields for Model, Rigger, and Photographer, and Location to CAS (Scene) posts
 * Version: 1.0.0
 * Author: TheDuchy Mobile App
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

class SceneCreditsMetaBox {
    
    public function __construct() {
        add_action('add_meta_boxes', array($this, 'add_scene_credits_meta_box'));
        add_action('save_post', array($this, 'save_scene_credits_meta'));
    }
    
    /**
     * Add meta box to CAS post edit screen
     */
    public function add_scene_credits_meta_box() {
        add_meta_box(
            'scene_credits_meta_box',
            'Scene Credits',
            array($this, 'scene_credits_meta_box_callback'),
            'cas',
            'normal',
            'high'
        );
    }
    
    /**
     * Meta box callback function
     */
    public function scene_credits_meta_box_callback($post) {
        // Add nonce for security
        wp_nonce_field('scene_credits_meta_box', 'scene_credits_meta_box_nonce');
        
        // Get current values
        $model = get_post_meta($post->ID, '_cas_model', true);
        $rigger = get_post_meta($post->ID, '_cas_rigger', true);
        $photographer = get_post_meta($post->ID, '_cas_photographer', true);
        $location = get_post_meta($post->ID, '_cas_location', true);
        
        // Get custom values if "Other" is selected
        $model_custom = get_post_meta($post->ID, '_cas_model_custom', true);
        $rigger_custom = get_post_meta($post->ID, '_cas_rigger_custom', true);
        $photographer_custom = get_post_meta($post->ID, '_cas_photographer_custom', true);
        $location_custom = get_post_meta($post->ID, '_cas_location_custom', true);
        
        ?>
        <style>
            .scene-credits-field {
                margin-bottom: 20px;
            }
            .scene-credits-field label {
                display: block;
                font-weight: bold;
                margin-bottom: 5px;
            }
            .scene-credits-field select,
            .scene-credits-field input[type="text"] {
                width: 100%;
                max-width: 400px;
                padding: 8px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }
            .scene-credits-custom {
                margin-top: 10px;
                display: none;
            }
            .scene-credits-custom.show {
                display: block;
            }
        </style>
        
        <div class="scene-credits-field">
            <label for="cas_model">Model:</label>
            <select name="cas_model" id="cas_model" onchange="toggleCustomField('model', this.value)">
                <option value="">Select Model...</option>
                <option value="Lazarus Redmayne" <?php selected($model, 'Lazarus Redmayne'); ?>>Lazarus Redmayne</option>
                <option value="Kajira Blue" <?php selected($model, 'Kajira Blue'); ?>>Kajira Blue</option>
                <option value="Other" <?php selected($model, 'Other'); ?>>Other</option>
            </select>
            <div id="model_custom" class="scene-credits-custom <?php echo ($model === 'Other') ? 'show' : ''; ?>">
                <input type="text" name="cas_model_custom" value="<?php echo esc_attr($model_custom); ?>" placeholder="Enter model name..." />
            </div>
        </div>
        
        <div class="scene-credits-field">
            <label for="cas_rigger">Rigger:</label>
            <select name="cas_rigger" id="cas_rigger" onchange="toggleCustomField('rigger', this.value)">
                <option value="">Select Rigger...</option>
                <option value="Lazarus Redmayne" <?php selected($rigger, 'Lazarus Redmayne'); ?>>Lazarus Redmayne</option>
                <option value="Kajira Blue" <?php selected($rigger, 'Kajira Blue'); ?>>Kajira Blue</option>
                <option value="Other" <?php selected($rigger, 'Other'); ?>>Other</option>
            </select>
            <div id="rigger_custom" class="scene-credits-custom <?php echo ($rigger === 'Other') ? 'show' : ''; ?>">
                <input type="text" name="cas_rigger_custom" value="<?php echo esc_attr($rigger_custom); ?>" placeholder="Enter rigger name..." />
            </div>
        </div>
        
        <div class="scene-credits-field">
            <label for="cas_photographer">Photographer:</label>
            <select name="cas_photographer" id="cas_photographer" onchange="toggleCustomField('photographer', this.value)">
                <option value="">Select Photographer...</option>
                <option value="Lazarus Redmayne" <?php selected($photographer, 'Lazarus Redmayne'); ?>>Lazarus Redmayne</option>
                <option value="Kajira Blue" <?php selected($photographer, 'Kajira Blue'); ?>>Kajira Blue</option>
                <option value="Other" <?php selected($photographer, 'Other'); ?>>Other</option>
            </select>
            <div id="photographer_custom" class="scene-credits-custom <?php echo ($photographer === 'Other') ? 'show' : ''; ?>">
                <input type="text" name="cas_photographer_custom" value="<?php echo esc_attr($photographer_custom); ?>" placeholder="Enter photographer name..." />
            </div>
        </div>
        
        <div class="scene-credits-field">
            <label for="cas_location">Location:</label>
            <select name="cas_location" id="cas_location" onchange="toggleCustomField('location', this.value)">
                <option value="">Select Location...</option>
                <option value="Nashville, TN" <?php selected($location, 'Nashville, TN'); ?>>Nashville, TN</option>
                <option value="Chicago, IL" <?php selected($location, 'Chicago, IL'); ?>>Chicago, IL</option>
                <option value="Other" <?php selected($location, 'Other'); ?>>Other</option>
            </select>
            <div id="location_custom" class="scene-credits-custom <?php echo ($location === 'Other') ? 'show' : ''; ?>">
                <input type="text" name="cas_location_custom" value="<?php echo esc_attr($location_custom); ?>" placeholder="Enter location name..." />
            </div>
        </div>
        
        <script>
        function toggleCustomField(field, value) {
            const customDiv = document.getElementById(field + '_custom');
            if (value === 'Other') {
                customDiv.classList.add('show');
            } else {
                customDiv.classList.remove('show');
            }
        }
        </script>
        
        <p><em>Note: If "Other" is selected, enter the custom name in the text field that appears. These credits will be displayed on the mobile app.</em></p>
        <?php
    }
    
    /**
     * Save meta box data
     */
    public function save_scene_credits_meta($post_id) {
        // Check if nonce is valid
        if (!isset($_POST['scene_credits_meta_box_nonce']) || 
            !wp_verify_nonce($_POST['scene_credits_meta_box_nonce'], 'scene_credits_meta_box')) {
            return;
        }
        
        // Check if user has permission to edit the post
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        
        // Check if this is an autosave
        if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        
        // Save model
        if (isset($_POST['cas_model'])) {
            $model = sanitize_text_field($_POST['cas_model']);
            if ($model === 'Other' && isset($_POST['cas_model_custom'])) {
                $model = sanitize_text_field($_POST['cas_model_custom']);
            }
            update_post_meta($post_id, '_cas_model', $model);
        }
        
        // Save rigger
        if (isset($_POST['cas_rigger'])) {
            $rigger = sanitize_text_field($_POST['cas_rigger']);
            if ($rigger === 'Other' && isset($_POST['cas_rigger_custom'])) {
                $rigger = sanitize_text_field($_POST['cas_rigger_custom']);
            }
            update_post_meta($post_id, '_cas_rigger', $rigger);
        }
        
        // Save photographer
        if (isset($_POST['cas_photographer'])) {
            $photographer = sanitize_text_field($_POST['cas_photographer']);
            if ($photographer === 'Other' && isset($_POST['cas_photographer_custom'])) {
                $photographer = sanitize_text_field($_POST['cas_photographer_custom']);
            }
            update_post_meta($post_id, '_cas_photographer', $photographer);
        }
        
        // Save location
        if (isset($_POST['cas_location'])) {
            $location = sanitize_text_field($_POST['cas_location']);
            if ($location === 'Other' && isset($_POST['cas_location_custom'])) {
                $location = sanitize_text_field($_POST['cas_location_custom']);
            }
            update_post_meta($post_id, '_cas_location', $location);
        }
    }
}

// Initialize the meta box
new SceneCreditsMetaBox();
