# MemberSync WordPress Plugin

Sync subscriptions and transactions from Authorize.Net (and other payment gateways) to MemberPress.

## Features

- **Authorize.Net Integration**: Sync active subscriptions and transactions from Authorize.Net ARB
- **Dual Sync Modes**: 
  - CSV Export: Export data to CSV files for manual import
  - Direct Import: Import directly into MemberPress database
- **License Management**: WPMods store license activation and validation
- **Real-time Progress**: Live progress tracking and logs during sync
- **Product Mapping**: Configurable mapping of subscription names to MemberPress product IDs
- **Duplicate Handling**: Choose to skip or update existing records

## Requirements

- WordPress 5.0+
- PHP 7.4+
- MemberPress plugin (must be installed and activated)

## Installation

1. Upload the plugin files to `/wp-content/plugins/wpmods-membersync/`
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Navigate to MemberPress > Sync Tools to configure

## Configuration

### Authorize.Net Credentials

1. Go to MemberPress > Sync Tools > Settings
2. Enter your Authorize.Net API Login ID and Transaction Key
3. Enable sandbox mode if testing

### Product Mapping

Map Authorize.Net subscription names to MemberPress product IDs in the Settings tab.

### Sync Options

- **Sync Mode**: Choose CSV Export or Direct Import
- **Duplicate Handling**: Skip duplicates or update existing records
- **Transaction Start Date**: Set the start date for fetching transactions

## Usage

1. Configure your Authorize.Net credentials in Settings
2. Set up product mapping if needed
3. Choose your sync mode (CSV Export or Direct Import)
4. Go to the Authorize.Net tab
5. Click "Start Sync" to begin the sync process
6. Monitor progress and logs in real-time

## License

This plugin requires a valid license from WPMods Store. Activate your license in the License tab.

## Support

For support, visit https://wpmods.store
