<?php
/**
 * MemberPress Integration
 *
 * Handles direct database operations for MemberPress subscriptions and transactions
 *
 * @package MemberSync
 */

if (!defined('ABSPATH')) {
    exit;
}

class MemberSync_MemberPress_Integration {
    
    /**
     * WordPress database instance
     */
    private $wpdb;
    
    /**
     * Table prefix
     */
    private $prefix;
    
    /**
     * Subscriptions table
     */
    private $subscriptions_table;
    
    /**
     * Transactions table
     */
    private $transactions_table;
    
    /**
     * Constructor
     */
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->prefix = $wpdb->prefix;
        $this->subscriptions_table = $this->prefix . 'mp_subscriptions';
        $this->transactions_table = $this->prefix . 'mp_transactions';
    }
    
    /**
     * Find WordPress user by email
     */
    public function find_user_by_email($email) {
        if (empty($email)) {
            return null;
        }
        
        $user = get_user_by('email', $email);
        return $user ? $user->ID : null;
    }
    
    /**
     * Find WordPress user by subscription ID (from existing MemberPress subscription)
     */
    public function find_user_by_subscription_id($subscription_id) {
        if (empty($subscription_id)) {
            return null;
        }
        
        $query = $this->wpdb->prepare(
            "SELECT user_id FROM {$this->subscriptions_table} WHERE subscr_id = %s ORDER BY id DESC LIMIT 1",
            $subscription_id
        );
        
        $user_id = $this->wpdb->get_var($query);
        return $user_id ? intval($user_id) : null;
    }
    
    /**
     * Resolve username from email and subscription ID
     */
    public function resolve_username($email, $subscription_id) {
        // Try by email first
        $user_id = $this->find_user_by_email($email);
        if ($user_id) {
            $user = get_user_by('id', $user_id);
            return $user ? $user->user_login : '';
        }
        
        // Try by subscription ID
        $user_id = $this->find_user_by_subscription_id($subscription_id);
        if ($user_id) {
            $user = get_user_by('id', $user_id);
            return $user ? $user->user_login : '';
        }
        
        return '';
    }
    
    /**
     * Check if subscription exists
     */
    public function subscription_exists($sub_num) {
        $query = $this->wpdb->prepare(
            "SELECT id FROM {$this->subscriptions_table} WHERE subscr_id = %s LIMIT 1",
            $sub_num
        );
        
        return $this->wpdb->get_var($query) ? true : false;
    }
    
    /**
     * Get existing subscription
     */
    public function get_subscription($sub_num) {
        $query = $this->wpdb->prepare(
            "SELECT * FROM {$this->subscriptions_table} WHERE subscr_id = %s LIMIT 1",
            $sub_num
        );
        
        return $this->wpdb->get_row($query, ARRAY_A);
    }
    
    /**
     * Create or update subscription
     */
    public function create_or_update_subscription($data) {
        $duplicate_handling = get_option('membersync_duplicate_handling', 'skip');
        
        // Check if exists
        $existing = $this->get_subscription($data['sub_num']);
        
        if ($existing) {
            if ($duplicate_handling === 'skip') {
                return array(
                    'success' => true,
                    'action' => 'skipped',
                    'id' => $existing['id'],
                );
            } else {
                // Update existing
                $update_data = $this->prepare_subscription_data($data);
                $this->wpdb->update(
                    $this->subscriptions_table,
                    $update_data,
                    array('id' => $existing['id']),
                    null,
                    array('%d')
                );
                
                return array(
                    'success' => true,
                    'action' => 'updated',
                    'id' => $existing['id'],
                );
            }
        }
        
        // Create new
        $insert_data = $this->prepare_subscription_data($data);
        $result = $this->wpdb->insert($this->subscriptions_table, $insert_data);
        
        if ($result === false) {
            return array(
                'success' => false,
                'error' => $this->wpdb->last_error,
            );
        }
        
        return array(
            'success' => true,
            'action' => 'created',
            'id' => $this->wpdb->insert_id,
        );
    }
    
    /**
     * Prepare subscription data for database
     */
    private function prepare_subscription_data($data) {
        $user_id = $this->find_user_by_email($data['email']);
        if (!$user_id) {
            $user_id = $this->find_user_by_subscription_id($data['sub_num']);
        }
        
        if (!$user_id) {
            // Try to create user if email provided
            if (!empty($data['email'])) {
                $user_id = $this->create_user_from_email($data['email'], $data['username']);
            }
        }
        
        if (!$user_id) {
            return false; // Can't create subscription without user
        }
        
        // Map status
        $status = $this->map_subscription_status($data['status']);
        
        // Calculate period
        $period = isset($data['period']) ? intval($data['period']) : 1;
        $period_type = isset($data['period_type']) ? $data['period_type'] : 'months';
        
        // Calculate next billing date
        $created_at = !empty($data['created_at']) ? $data['created_at'] : current_time('mysql');
        $next_billing = $this->calculate_next_billing($created_at, $period, $period_type);
        
        return array(
            'user_id' => $user_id,
            'product_id' => intval($data['product_id']),
            'subscr_id' => sanitize_text_field($data['sub_num']),
            'gateway' => sanitize_text_field($data['payment_method']),
            'price' => floatval($data['price']),
            'total' => floatval($data['total']),
            'period' => $period,
            'period_type' => $period_type,
            'status' => $status,
            'created_at' => $this->format_datetime($data['created_at']),
            'expires_at' => $this->format_datetime($next_billing),
        );
    }
    
    /**
     * Check if transaction exists
     */
    public function transaction_exists($trans_num) {
        $query = $this->wpdb->prepare(
            "SELECT id FROM {$this->transactions_table} WHERE trans_num = %s LIMIT 1",
            $trans_num
        );
        
        return $this->wpdb->get_var($query) ? true : false;
    }
    
    /**
     * Get existing transaction
     */
    public function get_transaction($trans_num) {
        $query = $this->wpdb->prepare(
            "SELECT * FROM {$this->transactions_table} WHERE trans_num = %s LIMIT 1",
            $trans_num
        );
        
        return $this->wpdb->get_row($query, ARRAY_A);
    }
    
    /**
     * Create or update transaction
     */
    public function create_or_update_transaction($data) {
        $duplicate_handling = get_option('membersync_duplicate_handling', 'skip');
        
        // Check if exists
        $existing = $this->get_transaction($data['trans_num']);
        
        if ($existing) {
            if ($duplicate_handling === 'skip') {
                return array(
                    'success' => true,
                    'action' => 'skipped',
                    'id' => $existing['id'],
                );
            } else {
                // Update existing
                $update_data = $this->prepare_transaction_data($data);
                $this->wpdb->update(
                    $this->transactions_table,
                    $update_data,
                    array('id' => $existing['id']),
                    null,
                    array('%d')
                );
                
                return array(
                    'success' => true,
                    'action' => 'updated',
                    'id' => $existing['id'],
                );
            }
        }
        
        // Create new
        $insert_data = $this->prepare_transaction_data($data);
        if ($insert_data === false) {
            return array(
                'success' => false,
                'error' => 'Failed to prepare transaction data',
            );
        }
        
        $result = $this->wpdb->insert($this->transactions_table, $insert_data);
        
        if ($result === false) {
            return array(
                'success' => false,
                'error' => $this->wpdb->last_error,
            );
        }
        
        return array(
            'success' => true,
            'action' => 'created',
            'id' => $this->wpdb->insert_id,
        );
    }
    
    /**
     * Prepare transaction data for database
     */
    private function prepare_transaction_data($data) {
        // Find user
        $user_id = $this->find_user_by_email($data['email']);
        if (!$user_id) {
            $user_id = $this->find_user_by_subscription_id($data['sub_num']);
        }
        
        if (!$user_id) {
            return false; // Can't create transaction without user
        }
        
        // Find subscription
        $subscription = $this->get_subscription($data['sub_num']);
        $subscription_id = $subscription ? $subscription['id'] : null;
        
        // Map status
        $status = $this->map_transaction_status($data['status']);
        
        return array(
            'user_id' => $user_id,
            'product_id' => intval($data['product_id']),
            'subscription_id' => $subscription_id,
            'trans_num' => sanitize_text_field($data['trans_num']),
            'gateway' => sanitize_text_field($data['payment_method']),
            'amount' => floatval($data['amount']),
            'total' => floatval($data['total']),
            'status' => $status,
            'created_at' => $this->format_datetime($data['created_at']),
            'expires_at' => $this->format_datetime($data['expires_at']),
        );
    }
    
    /**
     * Create user from email
     */
    private function create_user_from_email($email, $username = '') {
        if (empty($email)) {
            return null;
        }
        
        // Check if user already exists
        $existing = get_user_by('email', $email);
        if ($existing) {
            return $existing->ID;
        }
        
        // Generate username if not provided
        if (empty($username)) {
            $username = sanitize_user(substr($email, 0, strpos($email, '@')));
            $base_username = $username;
            $counter = 1;
            
            while (username_exists($username)) {
                $username = $base_username . $counter;
                $counter++;
            }
        }
        
        // Create user
        $user_id = wp_create_user($username, wp_generate_password(), $email);
        
        if (is_wp_error($user_id)) {
            return null;
        }
        
        return $user_id;
    }
    
    /**
     * Map subscription status
     */
    private function map_subscription_status($status) {
        $status = strtolower(trim($status));
        
        $mapping = array(
            'active' => 'active',
            'suspended' => 'suspended',
            'cancelled' => 'cancelled',
            'expired' => 'expired',
        );
        
        return isset($mapping[$status]) ? $mapping[$status] : 'active';
    }
    
    /**
     * Map transaction status
     */
    private function map_transaction_status($status) {
        $status = strtolower(trim($status));
        
        $mapping = array(
            'complete' => 'complete',
            'pending' => 'pending',
            'failed' => 'failed',
            'refunded' => 'refunded',
        );
        
        return isset($mapping[$status]) ? $mapping[$status] : 'complete';
    }
    
    /**
     * Calculate next billing date
     */
    private function calculate_next_billing($start_date, $period, $period_type) {
        if (empty($start_date)) {
            $start_date = current_time('mysql');
        }
        
        try {
            $dt = new DateTime($start_date);
            
            switch ($period_type) {
                case 'days':
                    $dt->modify("+{$period} days");
                    break;
                case 'weeks':
                    $dt->modify("+{$period} weeks");
                    break;
                case 'months':
                    $dt->modify("+{$period} months");
                    break;
                case 'years':
                    $dt->modify("+{$period} years");
                    break;
                default:
                    $dt->modify("+{$period} months");
            }
            
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return current_time('mysql');
        }
    }
    
    /**
     * Format datetime for database
     */
    private function format_datetime($datetime) {
        if (empty($datetime)) {
            return current_time('mysql');
        }
        
        try {
            $dt = new DateTime($datetime);
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return current_time('mysql');
        }
    }
}

