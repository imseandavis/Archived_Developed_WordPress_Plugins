<?php
/**
 * Admin Interface
 *
 * Handles admin menu, tabs, and UI
 *
 * @package MemberSync
 */

if (!defined('ABSPATH')) {
    exit;
}

class MemberSync_Admin {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Current tab
     */
    private $current_tab = 'authorize-net';
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_init', array($this, 'handle_settings_save'));
        add_action('wp_ajax_membersync_start_sync', array($this, 'ajax_start_sync'));
        add_action('wp_ajax_membersync_get_progress', array($this, 'ajax_get_progress'));
        add_action('wp_ajax_membersync_get_logs', array($this, 'ajax_get_logs'));
    }
    
    /**
     * Add admin menu
     */
    public function add_admin_menu() {
        add_submenu_page(
            'memberpress',
            __('Sync Tools', 'memberpress'),
            __('Sync Tools', 'memberpress'),
            'manage_options',
            'membersync-sync-tools',
            array($this, 'render_page')
        );
    }
    
    /**
     * Enqueue scripts and styles
     */
    public function enqueue_scripts($hook) {
        if ($hook !== 'memberpress_page_membersync-sync-tools') {
            return;
        }
        
        wp_enqueue_style(
            'membersync-admin',
            MEMBERSYNC_PLUGIN_URL . 'assets/css/admin.css',
            array(),
            MEMBERSYNC_VERSION
        );
        
        wp_enqueue_script(
            'membersync-admin',
            MEMBERSYNC_PLUGIN_URL . 'assets/js/admin.js',
            array('jquery'),
            MEMBERSYNC_VERSION,
            true
        );
        
        wp_localize_script('membersync-admin', 'membersyncAdmin', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('membersync_admin'),
        ));
    }
    
    /**
     * Handle settings save
     */
    public function handle_settings_save() {
        if (!isset($_POST['membersync_save_settings']) || !check_admin_referer('membersync_save_settings')) {
            return;
        }
        
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Save Authorize.Net settings
        if (isset($_POST['membersync_anet_api_login_id'])) {
            update_option('membersync_anet_api_login_id', sanitize_text_field($_POST['membersync_anet_api_login_id']));
        }
        
        if (isset($_POST['membersync_anet_transaction_key'])) {
            update_option('membersync_anet_transaction_key', sanitize_text_field($_POST['membersync_anet_transaction_key']));
        }
        
        update_option('membersync_anet_use_sandbox', isset($_POST['membersync_anet_use_sandbox']));
        
        // Save sync settings
        if (isset($_POST['membersync_sync_mode'])) {
            update_option('membersync_sync_mode', sanitize_text_field($_POST['membersync_sync_mode']));
        }
        
        if (isset($_POST['membersync_duplicate_handling'])) {
            update_option('membersync_duplicate_handling', sanitize_text_field($_POST['membersync_duplicate_handling']));
        }
        
        if (isset($_POST['membersync_txn_start_date'])) {
            update_option('membersync_txn_start_date', sanitize_text_field($_POST['membersync_txn_start_date']));
        }
        
        if (isset($_POST['membersync_payment_method'])) {
            update_option('membersync_payment_method', sanitize_text_field($_POST['membersync_payment_method']));
        }
        
        // Save product mapping
        if (isset($_POST['membersync_product_mapping'])) {
            $mapping = array();
            foreach ($_POST['membersync_product_mapping'] as $name => $product_id) {
                $name = sanitize_text_field($name);
                $product_id = sanitize_text_field($product_id);
                if (!empty($name) && !empty($product_id)) {
                    $mapping[$name] = $product_id;
                }
            }
            update_option('membersync_product_mapping', $mapping);
        }
        
        add_settings_error('membersync_settings', 'settings_saved', __('Settings saved successfully.', 'membersync'), 'success');
    }
    
    /**
     * Render admin page
     */
    public function render_page() {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'membersync'));
        }
        
        // Get current tab
        $this->current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'authorize-net';
        
        ?>
        <div class="wrap membersync-wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php settings_errors('membersync_settings'); ?>
            <?php settings_errors('membersync_license'); ?>
            
            <nav class="nav-tab-wrapper">
                <a href="?page=membersync-sync-tools&tab=authorize-net" class="nav-tab <?php echo $this->current_tab === 'authorize-net' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Authorize.Net', 'membersync'); ?>
                </a>
                <a href="?page=membersync-sync-tools&tab=license" class="nav-tab <?php echo $this->current_tab === 'license' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('License', 'membersync'); ?>
                </a>
                <a href="?page=membersync-sync-tools&tab=settings" class="nav-tab <?php echo $this->current_tab === 'settings' ? 'nav-tab-active' : ''; ?>">
                    <?php esc_html_e('Settings', 'membersync'); ?>
                </a>
            </nav>
            
            <div class="membersync-tab-content">
                <?php
                switch ($this->current_tab) {
                    case 'license':
                        $this->render_license_tab();
                        break;
                    case 'settings':
                        $this->render_settings_tab();
                        break;
                    case 'authorize-net':
                    default:
                        $this->render_authorize_net_tab();
                        break;
                }
                ?>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render Authorize.Net tab
     */
    private function render_authorize_net_tab() {
        ?>
        <div class="membersync-sync-section">
            <h2><?php esc_html_e('Sync from Authorize.Net', 'membersync'); ?></h2>
            <p><?php esc_html_e('Click the button below to start syncing subscriptions and transactions from Authorize.Net to MemberPress.', 'membersync'); ?></p>
            
            <p>
                <button type="button" id="membersync-start-sync" class="button button-primary button-large">
                    <?php esc_html_e('Start Sync', 'membersync'); ?>
                </button>
            </p>
            
            <div id="membersync-progress" style="display: none;">
                <div class="membersync-progress-bar">
                    <div class="membersync-progress-fill" id="membersync-progress-fill"></div>
                </div>
                <p class="membersync-progress-text" id="membersync-progress-text"></p>
            </div>
            
            <div id="membersync-logs" class="membersync-logs" style="display: none;">
                <h3><?php esc_html_e('Sync Logs', 'membersync'); ?></h3>
                <div class="membersync-logs-content" id="membersync-logs-content"></div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Render License tab
     */
    private function render_license_tab() {
        if (!class_exists('MemberSync_License_Manager')) {
            echo '<p>' . esc_html__('License manager not available.', 'membersync') . '</p>';
            return;
        }
        
        $license_manager = MemberSync_License_Manager::get_instance();
        $license_key = $license_manager->get_license_key();
        $license_status = $license_manager->get_license_status();
        $activation_data = get_option('membersync_activation_data', array());
        ?>
        <div class="membersync-license-section">
            <h2><?php esc_html_e('License Settings', 'membersync'); ?></h2>
            
            <form method="post" action="">
                <?php wp_nonce_field('membersync_activate_license', '_wpnonce_license'); ?>
                
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="membersync_license_key"><?php esc_html_e('License Key', 'membersync'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="membersync_license_key" 
                                name="membersync_license_key" 
                                value="<?php echo esc_attr($license_key); ?>" 
                                class="regular-text"
                                placeholder="<?php esc_attr_e('Enter your license key', 'membersync'); ?>"
                            />
                            <p class="description">
                                <?php esc_html_e('Enter your license key from your WPMods account.', 'membersync'); ?>
                                <a href="https://wpmods.store/my-plugins" target="_blank">
                                    <?php esc_html_e('Get your license key', 'membersync'); ?>
                                </a>
                            </p>
                        </td>
                    </tr>
                    
                    <?php if ($license_key): ?>
                    <tr>
                        <th scope="row"><?php esc_html_e('License Status', 'membersync'); ?></th>
                        <td>
                            <span class="membersync-license-status membersync-license-status-<?php echo esc_attr($license_status); ?>">
                                <?php echo esc_html(ucfirst($license_status)); ?>
                            </span>
                            <?php if (isset($activation_data['license'])): ?>
                                <p class="description">
                                    <?php 
                                    printf(
                                        esc_html__('License Type: %s', 'membersync'),
                                        esc_html($activation_data['license']['license_type'])
                                    ); 
                                    ?>
                                </p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endif; ?>
                </table>
                
                <p class="submit">
                    <?php if ($license_status === 'active'): ?>
                        <input 
                            type="submit" 
                            name="membersync_deactivate_license" 
                            class="button button-secondary" 
                            value="<?php esc_attr_e('Deactivate License', 'membersync'); ?>"
                        />
                        <?php wp_nonce_field('membersync_deactivate_license', '_wpnonce_deactivate'); ?>
                    <?php else: ?>
                        <input 
                            type="submit" 
                            name="membersync_activate_license" 
                            class="button button-primary" 
                            value="<?php esc_attr_e('Activate License', 'membersync'); ?>"
                        />
                    <?php endif; ?>
                    
                    <button 
                        type="button" 
                        class="button" 
                        id="membersync-check-license"
                        data-nonce="<?php echo esc_attr(wp_create_nonce('membersync_license_check')); ?>"
                    >
                        <?php esc_html_e('Check License Status', 'membersync'); ?>
                    </button>
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * Render Settings tab
     */
    private function render_settings_tab() {
        $api_login_id = get_option('membersync_anet_api_login_id', '');
        $transaction_key = get_option('membersync_anet_transaction_key', '');
        $use_sandbox = get_option('membersync_anet_use_sandbox', false);
        $sync_mode = get_option('membersync_sync_mode', 'csv');
        $duplicate_handling = get_option('membersync_duplicate_handling', 'skip');
        $txn_start_date = get_option('membersync_txn_start_date', '2020-01-01');
        $payment_method = get_option('membersync_payment_method', 't39zk3-3bx');
        $product_mapping = get_option('membersync_product_mapping', array());
        
        if (is_string($product_mapping)) {
            $product_mapping = json_decode($product_mapping, true);
        }
        if (!is_array($product_mapping)) {
            $product_mapping = array();
        }
        ?>
        <div class="membersync-settings-section">
            <h2><?php esc_html_e('Settings', 'membersync'); ?></h2>
            
            <form method="post" action="">
                <?php wp_nonce_field('membersync_save_settings'); ?>
                
                <h3><?php esc_html_e('Authorize.Net Credentials', 'membersync'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="membersync_anet_api_login_id"><?php esc_html_e('API Login ID', 'membersync'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="membersync_anet_api_login_id" 
                                name="membersync_anet_api_login_id" 
                                value="<?php echo esc_attr($api_login_id); ?>" 
                                class="regular-text"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="membersync_anet_transaction_key"><?php esc_html_e('Transaction Key', 'membersync'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="password" 
                                id="membersync_anet_transaction_key" 
                                name="membersync_anet_transaction_key" 
                                value="<?php echo esc_attr($transaction_key); ?>" 
                                class="regular-text"
                            />
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="membersync_anet_use_sandbox"><?php esc_html_e('Use Sandbox', 'membersync'); ?></label>
                        </th>
                        <td>
                            <label>
                                <input 
                                    type="checkbox" 
                                    id="membersync_anet_use_sandbox" 
                                    name="membersync_anet_use_sandbox" 
                                    value="1"
                                    <?php checked($use_sandbox); ?>
                                />
                                <?php esc_html_e('Enable sandbox mode for testing', 'membersync'); ?>
                            </label>
                        </td>
                    </tr>
                </table>
                
                <h3><?php esc_html_e('Sync Options', 'membersync'); ?></h3>
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="membersync_sync_mode"><?php esc_html_e('Sync Mode', 'membersync'); ?></label>
                        </th>
                        <td>
                            <select id="membersync_sync_mode" name="membersync_sync_mode">
                                <option value="csv" <?php selected($sync_mode, 'csv'); ?>><?php esc_html_e('CSV Export', 'membersync'); ?></option>
                                <option value="import" <?php selected($sync_mode, 'import'); ?>><?php esc_html_e('Direct Import', 'membersync'); ?></option>
                            </select>
                            <p class="description">
                                <?php esc_html_e('CSV Export: Export data to CSV files. Direct Import: Import directly into MemberPress database.', 'membersync'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="membersync_duplicate_handling"><?php esc_html_e('Duplicate Handling', 'membersync'); ?></label>
                        </th>
                        <td>
                            <select id="membersync_duplicate_handling" name="membersync_duplicate_handling">
                                <option value="skip" <?php selected($duplicate_handling, 'skip'); ?>><?php esc_html_e('Skip Duplicates', 'membersync'); ?></option>
                                <option value="update" <?php selected($duplicate_handling, 'update'); ?>><?php esc_html_e('Update Existing', 'membersync'); ?></option>
                            </select>
                            <p class="description">
                                <?php esc_html_e('How to handle records that already exist in MemberPress.', 'membersync'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="membersync_txn_start_date"><?php esc_html_e('Transaction Start Date', 'membersync'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="date" 
                                id="membersync_txn_start_date" 
                                name="membersync_txn_start_date" 
                                value="<?php echo esc_attr($txn_start_date); ?>" 
                                class="regular-text"
                            />
                            <p class="description">
                                <?php esc_html_e('Start date for fetching transactions (YYYY-MM-DD).', 'membersync'); ?>
                            </p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="membersync_payment_method"><?php esc_html_e('Payment Method ID', 'membersync'); ?></label>
                        </th>
                        <td>
                            <input 
                                type="text" 
                                id="membersync_payment_method" 
                                name="membersync_payment_method" 
                                value="<?php echo esc_attr($payment_method); ?>" 
                                class="regular-text"
                            />
                            <p class="description">
                                <?php esc_html_e('MemberPress payment method ID to use for imported records.', 'membersync'); ?>
                            </p>
                        </td>
                    </tr>
                </table>
                
                <h3><?php esc_html_e('Product Mapping', 'membersync'); ?></h3>
                <p class="description">
                    <?php esc_html_e('Map Authorize.Net subscription names to MemberPress product IDs.', 'membersync'); ?>
                </p>
                <table class="form-table" id="membersync-product-mapping">
                    <thead>
                        <tr>
                            <th><?php esc_html_e('Subscription Name', 'membersync'); ?></th>
                            <th><?php esc_html_e('Product ID', 'membersync'); ?></th>
                            <th></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($product_mapping)): ?>
                            <?php foreach ($product_mapping as $name => $product_id): ?>
                                <tr>
                                    <td>
                                        <input 
                                            type="text" 
                                            name="membersync_product_mapping[<?php echo esc_attr($name); ?>]" 
                                            value="<?php echo esc_attr($name); ?>" 
                                            class="regular-text membersync-mapping-name"
                                        />
                                    </td>
                                    <td>
                                        <input 
                                            type="text" 
                                            name="membersync_product_mapping[<?php echo esc_attr($name); ?>]" 
                                            value="<?php echo esc_attr($product_id); ?>" 
                                            class="regular-text membersync-mapping-product"
                                        />
                                    </td>
                                    <td>
                                        <button type="button" class="button membersync-remove-mapping"><?php esc_html_e('Remove', 'membersync'); ?></button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>
                        <tr class="membersync-new-mapping-row">
                            <td>
                                <input type="text" class="regular-text membersync-mapping-name" placeholder="<?php esc_attr_e('Subscription name', 'membersync'); ?>" />
                            </td>
                            <td>
                                <input type="text" class="regular-text membersync-mapping-product" placeholder="<?php esc_attr_e('Product ID', 'membersync'); ?>" />
                            </td>
                            <td>
                                <button type="button" class="button membersync-add-mapping"><?php esc_html_e('Add', 'membersync'); ?></button>
                            </td>
                        </tr>
                    </tbody>
                </table>
                
                <p class="submit">
                    <input type="submit" name="membersync_save_settings" class="button button-primary" value="<?php esc_attr_e('Save Settings', 'membersync'); ?>" />
                </p>
            </form>
        </div>
        <?php
    }
    
    /**
     * AJAX: Start sync
     */
    public function ajax_start_sync() {
        check_ajax_referer('membersync_admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'membersync')));
        }
        
        // Increase execution time and memory limit for long-running sync
        @set_time_limit(0);
        @ini_set('memory_limit', '512M');
        
        // Run sync in background (for now, synchronous - can be improved with WP Cron)
        $processor = new MemberSync_Sync_Processor();
        
        // Start sync in a way that doesn't block
        // For production, consider using WP Cron or Action Scheduler
        try {
            // Initialize progress and logs before starting
            $processor->start_sync();
            wp_send_json_success(array('message' => __('Sync started.', 'membersync')));
        } catch (Exception $e) {
            error_log('MemberSync Error: ' . $e->getMessage());
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }
    
    /**
     * AJAX: Get progress
     */
    public function ajax_get_progress() {
        check_ajax_referer('membersync_admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'membersync')));
        }
        
        $progress = MemberSync_Sync_Processor::get_progress();
        wp_send_json_success($progress ? $progress : array('status' => 'idle'));
    }
    
    /**
     * AJAX: Get logs
     */
    public function ajax_get_logs() {
        check_ajax_referer('membersync_admin', 'nonce');
        
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => __('Permission denied.', 'membersync')));
        }
        
        $logs = MemberSync_Sync_Processor::get_logs();
        wp_send_json_success($logs ? $logs : array());
    }
}

