<?php
/**
 * Authorize.Net API Integration
 *
 * @package MemberSync
 */

if (!defined('ABSPATH')) {
    exit;
}

class MemberSync_Authorize_Net {
    
    /**
     * API endpoint
     */
    private $endpoint;
    
    /**
     * API login ID
     */
    private $api_login_id;
    
    /**
     * Transaction key
     */
    private $transaction_key;
    
    /**
     * Use sandbox
     */
    private $use_sandbox;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->api_login_id = get_option('membersync_anet_api_login_id', '');
        $this->transaction_key = get_option('membersync_anet_transaction_key', '');
        $this->use_sandbox = get_option('membersync_anet_use_sandbox', false);
        
        $this->endpoint = $this->use_sandbox 
            ? 'https://apitest.authorize.net/xml/v1/request.api'
            : 'https://api.authorize.net/xml/v1/request.api';
    }
    
    /**
     * Make API request
     */
    private function api_request($payload) {
        $args = array(
            'method' => 'POST',
            'timeout' => 60,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Accept' => 'application/json',
            ),
            'body' => json_encode($payload),
        );
        
        $response = wp_remote_request($this->endpoint, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message(),
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $status_code = wp_remote_retrieve_response_code($response);
        
        // Strip BOM character if present
        $body = $this->remove_bom($body);
        
        // Try to parse as JSON first
        $data = json_decode($body, true);
        
        // If JSON parsing failed, try XML
        if (json_last_error() !== JSON_ERROR_NONE) {
            $data = $this->parse_xml_response($body);
        }
        
        return array(
            'success' => ($status_code >= 200 && $status_code < 300),
            'data' => $data,
            'status_code' => $status_code,
        );
    }
    
    /**
     * Remove BOM character from string
     */
    private function remove_bom($text) {
        // Remove UTF-8 BOM (\xEF\xBB\xBF)
        if (substr($text, 0, 3) === "\xEF\xBB\xBF") {
            $text = substr($text, 3);
        }
        return $text;
    }
    
    /**
     * Parse XML response to array
     */
    private function parse_xml_response($xml_text) {
        if (empty($xml_text) || !function_exists('simplexml_load_string')) {
            return array('raw' => $xml_text);
        }
        
        libxml_use_internal_errors(true);
        $xml = simplexml_load_string($xml_text);
        
        if ($xml === false) {
            return array('raw' => $xml_text);
        }
        
        return $this->xml_to_array($xml);
    }
    
    /**
     * Convert SimpleXMLElement to array
     */
    private function xml_to_array($xml) {
        $array = array();
        
        foreach ($xml->children() as $key => $value) {
            if (count($value->children()) > 0) {
                $array[$key] = $this->xml_to_array($value);
            } else {
                $array[$key] = (string) $value;
            }
        }
        
        return $array;
    }
    
    /**
     * Check if response is OK
     */
    public function is_response_ok($body) {
        // Check for standard Authorize.Net response format
        $messages = isset($body['messages']) ? $body['messages'] : array();
        $result_code = isset($messages['resultCode']) ? strtolower($messages['resultCode']) : '';
        
        if ($result_code === 'ok') {
            return true;
        }
        
        // Check for direct response format (has subscriptionDetails or totalNumInResultSet)
        if (isset($body['subscriptionDetails']) || isset($body['totalNumInResultSet'])) {
            return true;
        }
        
        // Check for wrapped response
        if (isset($body['ARBGetSubscriptionListResponse'])) {
            $wrapped = $body['ARBGetSubscriptionListResponse'];
            if (isset($wrapped['subscriptionDetails']) || isset($wrapped['totalNumInResultSet'])) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Get error text from response
     */
    public function get_error_text($body) {
        $messages = isset($body['messages']) ? $body['messages'] : array();
        $message_list = isset($messages['message']) ? $messages['message'] : array();
        
        if (!is_array($message_list)) {
            $message_list = array($message_list);
        }
        
        if (!empty($message_list) && is_array($message_list[0])) {
            $m = $message_list[0];
            $code = isset($m['code']) ? $m['code'] : '';
            $text = isset($m['text']) ? $m['text'] : '';
            return trim($code . ': ' . $text);
        }
        
        return substr(json_encode($body), 0, 400);
    }
    
    /**
     * Get subscription list
     */
    public function get_subscription_list($limit = 1000, $page = 1, $search_type = 'subscriptionActive') {
        $payload = array(
            'ARBGetSubscriptionListRequest' => array(
                'merchantAuthentication' => array(
                    'name' => $this->api_login_id,
                    'transactionKey' => $this->transaction_key,
                ),
                'searchType' => $search_type,
                'sorting' => array(
                    'orderBy' => 'id',
                    'orderDescending' => 'false',
                ),
                'paging' => array(
                    'limit' => intval($limit),
                    'offset' => intval($page),
                ),
            ),
        );
        
        return $this->api_request($payload);
    }
    
    /**
     * Get subscription detail
     */
    public function get_subscription_detail($subscription_id, $include_transactions = false) {
        $payload = array(
            'ARBGetSubscriptionRequest' => array(
                'merchantAuthentication' => array(
                    'name' => $this->api_login_id,
                    'transactionKey' => $this->transaction_key,
                ),
                'subscriptionId' => strval($subscription_id),
                'includeTransactions' => $include_transactions ? 'true' : 'false',
            ),
        );
        
        return $this->api_request($payload);
    }
    
    /**
     * Get settled batch list
     */
    public function get_settled_batch_list($first_date, $last_date) {
        $payload = array(
            'getSettledBatchListRequest' => array(
                'merchantAuthentication' => array(
                    'name' => $this->api_login_id,
                    'transactionKey' => $this->transaction_key,
                ),
                'includeStatistics' => 'false',
                'firstSettlementDate' => $first_date,
                'lastSettlementDate' => $last_date,
            ),
        );
        
        return $this->api_request($payload);
    }
    
    /**
     * Get transaction list for batch
     */
    public function get_transaction_list_for_batch($batch_id) {
        $payload = array(
            'getTransactionListRequest' => array(
                'merchantAuthentication' => array(
                    'name' => $this->api_login_id,
                    'transactionKey' => $this->transaction_key,
                ),
                'batchId' => strval($batch_id),
            ),
        );
        
        return $this->api_request($payload);
    }
    
    /**
     * Get unsettled transaction list
     */
    public function get_unsettled_transaction_list() {
        $payload = array(
            'getUnsettledTransactionListRequest' => array(
                'merchantAuthentication' => array(
                    'name' => $this->api_login_id,
                    'transactionKey' => $this->transaction_key,
                ),
            ),
        );
        
        return $this->api_request($payload);
    }
    
    /**
     * Normalize name (remove HTML entities, extra spaces)
     */
    public function normalize_name($name) {
        if (empty($name)) {
            return '';
        }
        $name = html_entity_decode($name, ENT_QUOTES, 'UTF-8');
        $name = trim($name);
        $name = preg_replace('/\s+/', ' ', $name);
        return $name;
    }
    
    /**
     * Format amount to string
     */
    public function format_amount($value) {
        if (empty($value) && $value !== '0' && $value !== 0) {
            return '';
        }
        return number_format(floatval($value), 2, '.', '');
    }
    
    /**
     * Format timestamp
     */
    public function format_timestamp($timestamp) {
        if (empty($timestamp)) {
            return '';
        }
        
        // Normalize ISO format
        $timestamp = str_replace(array('T', 'Z'), array(' ', ''), $timestamp);
        $timestamp = explode('.', $timestamp)[0];
        $timestamp = trim($timestamp);
        
        // Add time if only date
        if (strlen($timestamp) === 10) {
            $timestamp .= ' 00:00:00';
        }
        
        // Try to parse and format
        try {
            $dt = new DateTime($timestamp);
            return $dt->format('Y-m-d H:i:s');
        } catch (Exception $e) {
            return $timestamp;
        }
    }
    
    /**
     * Parse datetime string
     */
    public function parse_datetime($timestamp) {
        if (empty($timestamp)) {
            return null;
        }
        
        $timestamp = str_replace(array('T', 'Z'), array(' ', ''), $timestamp);
        $timestamp = explode('.', $timestamp)[0];
        $timestamp = trim($timestamp);
        
        if (strlen($timestamp) === 10) {
            $timestamp .= ' 00:00:00';
        }
        
        try {
            return new DateTime($timestamp);
        } catch (Exception $e) {
            return null;
        }
    }
    
    /**
     * Extract email from subscription data
     */
    public function extract_email($subscription) {
        $profile = isset($subscription['profile']) ? $subscription['profile'] : array();
        $customer = isset($subscription['customer']) ? $subscription['customer'] : array();
        
        $email = '';
        if (!empty($profile['email'])) {
            $email = trim($profile['email']);
        } elseif (!empty($customer['email'])) {
            $email = trim($customer['email']);
        }
        
        return $email;
    }
    
    /**
     * Choose transaction timestamp from various fields
     */
    public function choose_txn_timestamp($transaction) {
        $fields = array(
            'submitTimeUTC',
            'transactionTimeUTC',
            'settlementTimeUTC',
            'submitTimeLocal',
            'submitTime',
            'transactionTime',
        );
        
        foreach ($fields as $field) {
            if (!empty($transaction[$field])) {
                return $transaction[$field];
            }
        }
        
        return '';
    }
}

