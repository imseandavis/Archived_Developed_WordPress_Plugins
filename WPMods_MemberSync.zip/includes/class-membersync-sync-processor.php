<?php
/**
 * Sync Processor
 *
 * Main sync orchestration class
 *
 * @package MemberSync
 */

if (!defined('ABSPATH')) {
    exit;
}

class MemberSync_Sync_Processor {
    
    /**
     * Authorize.Net API instance
     */
    private $anet;
    
    /**
     * MemberPress integration instance
     */
    private $mp;
    
    /**
     * Sync mode: 'csv' or 'import'
     */
    private $sync_mode;
    
    /**
     * Progress data
     */
    private $progress;
    
    /**
     * Logs
     */
    private $logs;
    
    /**
     * CSV file handles
     */
    private $subs_csv_handle = null;
    private $txns_csv_handle = null;
    
    /**
     * Constructor
     */
    public function __construct() {
        $this->anet = new MemberSync_Authorize_Net();
        $this->mp = new MemberSync_MemberPress_Integration();
        $this->sync_mode = get_option('membersync_sync_mode', 'csv');
    }
    
    /**
     * Start sync process
     */
    public function start_sync() {
        // Initialize progress
        $this->progress = array(
            'status' => 'running',
            'step' => 'initializing',
            'subscriptions_processed' => 0,
            'subscriptions_total' => 0,
            'transactions_processed' => 0,
            'transactions_total' => 0,
            'errors' => 0,
        );
        
        $this->logs = array();
        $this->update_progress();
        $this->update_logs(); // Initialize empty logs
        
        $this->log('Starting sync process...');
        $this->log('Sync mode: ' . ($this->sync_mode === 'csv' ? 'CSV Export' : 'Direct Import'));
        
        try {
            // Initialize CSV files if needed
            if ($this->sync_mode === 'csv') {
                $this->init_csv_files();
            }
            // Step 1: Fetch subscriptions
            $this->log('Fetching active subscriptions from Authorize.Net...');
            $subscriptions = $this->fetch_subscriptions();
            
            if (empty($subscriptions)) {
                $this->log('No subscriptions found.', 'warning');
                $this->progress['status'] = 'completed';
                $this->update_progress();
                return;
            }
            
            $this->progress['subscriptions_total'] = count($subscriptions);
            $this->log(sprintf('Found %d subscriptions', count($subscriptions)));
            
            // Step 2: Process subscriptions
            $this->log('Processing subscriptions...');
            $active_sub_ids = array();
            $sub_meta = array();
            
            foreach ($subscriptions as $sub_data) {
                $this->process_subscription($sub_data, $active_sub_ids, $sub_meta);
                $this->progress['subscriptions_processed']++;
                $this->update_progress();
            }
            
            $this->log(sprintf('Processed %d subscriptions', count($subscriptions)));
            $this->log(sprintf('Found %d active subscriptions', count($active_sub_ids)));
            
            // Step 3: Fetch transactions
            $this->log('Fetching transactions...');
            $transactions = $this->fetch_transactions($active_sub_ids, $sub_meta);
            
            $this->progress['transactions_total'] = count($transactions);
            $this->log(sprintf('Found %d transactions', count($transactions)));
            
            // Step 4: Process transactions
            $this->log('Processing transactions...');
            foreach ($transactions as $txn_data) {
                $this->process_transaction($txn_data);
                $this->progress['transactions_processed']++;
                $this->update_progress();
            }
            
            $this->log(sprintf('Processed %d transactions', count($transactions)));
            
            // Complete
            $this->progress['status'] = 'completed';
            $this->log('Sync completed successfully!');
            
            // Close CSV files if needed
            if ($this->sync_mode === 'csv') {
                $this->close_csv_files();
            }
            
        } catch (Exception $e) {
            $this->progress['status'] = 'error';
            $this->progress['error_message'] = $e->getMessage();
            $this->log('Error: ' . $e->getMessage(), 'error');
            $this->log('Stack trace: ' . $e->getTraceAsString(), 'error');
            $this->progress['errors']++;
            
            // Close CSV files on error
            if ($this->sync_mode === 'csv') {
                $this->close_csv_files();
            }
        } catch (Error $e) {
            // Catch fatal errors too
            $this->progress['status'] = 'error';
            $this->progress['error_message'] = $e->getMessage();
            $this->log('Fatal Error: ' . $e->getMessage(), 'error');
            $this->progress['errors']++;
            
            // Close CSV files on error
            if ($this->sync_mode === 'csv') {
                $this->close_csv_files();
            }
        }
        
        $this->update_progress();
        $this->update_logs(); // Final log update
    }
    
    /**
     * Initialize CSV files
     */
    private function init_csv_files() {
        $upload_dir = wp_upload_dir();
        $csv_dir = $upload_dir['basedir'] . '/membersync';
        
        // Create directory if it doesn't exist
        if (!file_exists($csv_dir)) {
            wp_mkdir_p($csv_dir);
        }
        
        $subs_file = $csv_dir . '/Final_Memberpress_Subscriptions.csv';
        $txns_file = $csv_dir . '/Final_Memberpress_Transactions.csv';
        
        // Open files for writing
        $this->subs_csv_handle = fopen($subs_file, 'w');
        $this->txns_csv_handle = fopen($txns_file, 'w');
        
        if (!$this->subs_csv_handle || !$this->txns_csv_handle) {
            throw new Exception('Failed to create CSV files. Please check upload directory permissions.');
        }
        
        // Write headers
        $subs_headers = array('email', 'username', 'product_id', 'price', 'total', 'period', 'period_type', 'status', 'payment_method', 'sub_num', 'created_at');
        $txns_headers = array('email', 'username', 'product_id', 'amount', 'total', 'payment_method', 'trans_num', 'sub_num', 'created_at', 'expires_at', 'status');
        
        fputcsv($this->subs_csv_handle, $subs_headers);
        fputcsv($this->txns_csv_handle, $txns_headers);
        
        $this->log('CSV files initialized: ' . $subs_file . ' and ' . $txns_file);
    }
    
    /**
     * Close CSV files
     */
    private function close_csv_files() {
        if ($this->subs_csv_handle) {
            fclose($this->subs_csv_handle);
            $this->subs_csv_handle = null;
        }
        
        if ($this->txns_csv_handle) {
            fclose($this->txns_csv_handle);
            $this->txns_csv_handle = null;
        }
        
        $this->log('CSV files closed');
    }
    
    /**
     * Fetch subscriptions from Authorize.Net
     */
    private function fetch_subscriptions() {
        $subscriptions = array();
        $page = 1;
        $limit = 1000;
        $total_reported = null;
        
        while (true) {
            $this->log(sprintf('Fetching subscriptions page %d...', $page));
            
            $response = $this->anet->get_subscription_list($limit, $page, 'subscriptionActive');
            $body = isset($response['data']['ARBGetSubscriptionListResponse']) 
                ? $response['data']['ARBGetSubscriptionListResponse'] 
                : $response['data'];
            
            if (!$this->anet->is_response_ok($body)) {
                $error = $this->anet->get_error_text($body);
                $this->log('Error fetching subscriptions: ' . $error, 'error');
                break;
            }
            
            if ($total_reported === null) {
                $total_reported = isset($body['totalNumInResultSet']) ? intval($body['totalNumInResultSet']) : 0;
                if ($total_reported > 0) {
                    $this->log(sprintf('Total subscriptions reported: %d', $total_reported));
                }
            }
            
            $details = isset($body['subscriptionDetails']) ? $body['subscriptionDetails'] : array();
            if (!is_array($details)) {
                $details = array($details);
            }
            
            if (empty($details)) {
                break;
            }
            
            // Fetch detail for each subscription
            foreach ($details as $detail) {
                $sub_id = isset($detail['id']) ? trim($detail['id']) : '';
                if (empty($sub_id)) {
                    continue;
                }
                
                $detail_response = $this->anet->get_subscription_detail($sub_id, false);
                $detail_body = isset($detail_response['data']['ARBGetSubscriptionResponse'])
                    ? $detail_response['data']['ARBGetSubscriptionResponse']
                    : $detail_response['data'];
                
                if (!$this->anet->is_response_ok($detail_body)) {
                    $this->log(sprintf('Error fetching subscription %s details', $sub_id), 'warning');
                    continue;
                }
                
                $subscription = isset($detail_body['subscription']) ? $detail_body['subscription'] : array();
                if (empty($subscription)) {
                    continue;
                }
                
                // Process subscription data
                $sub_data = $this->process_subscription_data($subscription, $detail);
                if ($sub_data) {
                    $subscriptions[] = $sub_data;
                }
                
                // Rate limiting
                usleep(10000); // 0.01 seconds
            }
            
            if (count($details) < $limit) {
                break;
            }
            
            $page++;
            usleep(200000); // 0.2 seconds between pages
        }
        
        return $subscriptions;
    }
    
    /**
     * Process subscription data
     */
    private function process_subscription_data($subscription, $detail) {
        $sub_id = isset($detail['id']) ? trim($detail['id']) : '';
        if (empty($sub_id)) {
            return null;
        }
        
        $email = $this->anet->extract_email($subscription);
        $name = isset($subscription['name']) ? $subscription['name'] : '';
        $product_id = $this->map_product_id($name);
        $amount = isset($subscription['amount']) ? $this->anet->format_amount($subscription['amount']) : '0.00';
        $status = isset($subscription['status']) ? trim($subscription['status']) : '';
        
        $username = $this->mp->resolve_username($email, $sub_id);
        
        $created_raw = isset($detail['createTimeStampUTC']) ? $detail['createTimeStampUTC'] : '';
        $created_at = $this->anet->format_timestamp($created_raw);
        
        $payment_schedule = isset($subscription['paymentSchedule']) ? $subscription['paymentSchedule'] : array();
        $interval = isset($payment_schedule['interval']) ? $payment_schedule['interval'] : array();
        $interval_len = isset($interval['length']) ? intval($interval['length']) : 1;
        $interval_unit = isset($interval['unit']) ? $interval['unit'] : 'months';
        
        $next_payment = isset($subscription['nextPaymentDate']) ? trim($subscription['nextPaymentDate']) : '';
        
        return array(
            'email' => $email,
            'username' => $username,
            'product_id' => $product_id,
            'price' => $amount,
            'total' => $amount,
            'period' => '1',
            'period_type' => 'months',
            'status' => $status,
            'payment_method' => get_option('membersync_payment_method', 't39zk3-3bx'),
            'sub_num' => $sub_id,
            'created_at' => $created_at,
            'interval_len' => $interval_len,
            'interval_unit' => $interval_unit,
            'next_payment' => $next_payment,
        );
    }
    
    /**
     * Process subscription (save to CSV or import)
     */
    private function process_subscription($sub_data, &$active_sub_ids, &$sub_meta) {
        if (strtolower($sub_data['status']) === 'active') {
            $active_sub_ids[] = $sub_data['sub_num'];
        }
        
        $sub_meta[$sub_data['sub_num']] = $sub_data;
        
        if ($this->sync_mode === 'import') {
            $result = $this->mp->create_or_update_subscription($sub_data);
            if (!$result['success']) {
                $this->log(sprintf('Error processing subscription %s: %s', $sub_data['sub_num'], $result['error']), 'error');
                $this->progress['errors']++;
            } else {
                $this->log(sprintf('Subscription %s: %s', $sub_data['sub_num'], $result['action']));
            }
        } elseif ($this->sync_mode === 'csv' && $this->subs_csv_handle) {
            // Write to CSV
            $row = array(
                $sub_data['email'],
                $sub_data['username'],
                $sub_data['product_id'],
                $sub_data['price'],
                $sub_data['total'],
                $sub_data['period'],
                $sub_data['period_type'],
                $sub_data['status'],
                $sub_data['payment_method'],
                $sub_data['sub_num'],
                $sub_data['created_at'],
            );
            fputcsv($this->subs_csv_handle, $row);
        }
    }
    
    /**
     * Fetch transactions from Authorize.Net
     */
    private function fetch_transactions($active_sub_ids, $sub_meta) {
        if (empty($active_sub_ids)) {
            return array();
        }
        
        $transactions = array();
        $start_date = get_option('membersync_txn_start_date', '2020-01-01');
        $window_days = 31;
        
        // Parse start date
        try {
            $current = new DateTime($start_date);
        } catch (Exception $e) {
            $current = new DateTime('2020-01-01');
        }
        
        $now = new DateTime();
        $hard_clamped = false;
        
        // Fetch settled batches
        while ($current < $now) {
            $window_end = clone $current;
            $window_end->modify("+{$window_days} days");
            if ($window_end > $now) {
                $window_end = $now;
            }
            
            $first_str = $current->format('Y-m-d\T00:00:00\Z');
            $last_str = $window_end->format('Y-m-d\T00:00:00\Z');
            
            $this->log(sprintf('Fetching settled batches: %s to %s', $current->format('Y-m-d'), $window_end->format('Y-m-d')));
            
            $response = $this->anet->get_settled_batch_list($first_str, $last_str);
            $body = isset($response['data']['getSettledBatchListResponse'])
                ? $response['data']['getSettledBatchListResponse']
                : $response['data'];
            
            if (!$this->anet->is_response_ok($body)) {
                $error = $this->anet->get_error_text($body);
                
                // Handle date clamping
                if (strpos($error, 'E00013') !== false && strpos(strtolower($error), '2023') !== false && !$hard_clamped) {
                    $this->log('Gateway requires dates from 2023+, clamping start date', 'warning');
                    $current = new DateTime('2023-01-01');
                    $hard_clamped = true;
                    continue;
                }
                
                $this->log('Error fetching batches: ' . $error, 'warning');
                $current = $window_end;
                continue;
            }
            
            $batches = isset($body['batchList']) ? $body['batchList'] : array();
            if (isset($batches['batch'])) {
                $batches = is_array($batches['batch']) ? $batches['batch'] : array($batches['batch']);
            }
            if (!is_array($batches)) {
                $batches = array();
            }
            
            // Process each batch
            foreach ($batches as $batch) {
                $batch_id = isset($batch['batchId']) ? trim($batch['batchId']) : (isset($batch['id']) ? trim($batch['id']) : '');
                if (empty($batch_id)) {
                    continue;
                }
                
                $txn_response = $this->anet->get_transaction_list_for_batch($batch_id);
                $txn_body = isset($txn_response['data']['getTransactionListResponse'])
                    ? $txn_response['data']['getTransactionListResponse']
                    : $txn_response['data'];
                
                if (!$this->anet->is_response_ok($txn_body)) {
                    continue;
                }
                
                $txn_list = isset($txn_body['transactions']) ? $txn_body['transactions'] : array();
                if (isset($txn_list['transaction'])) {
                    $txn_list = is_array($txn_list['transaction']) ? $txn_list['transaction'] : array($txn_list['transaction']);
                }
                if (!is_array($txn_list)) {
                    $txn_list = array();
                }
                
                // Process transactions
                foreach ($txn_list as $txn) {
                    $sub_info = isset($txn['subscription']) ? $txn['subscription'] : array();
                    $sub_id = isset($sub_info['id']) ? trim($sub_info['id']) : (isset($sub_info['subscriptionId']) ? trim($sub_info['subscriptionId']) : '');
                    
                    if (empty($sub_id) || !in_array($sub_id, $active_sub_ids)) {
                        continue;
                    }
                    
                    $txn_data = $this->process_transaction_data($txn, $sub_meta[$sub_id]);
                    if ($txn_data) {
                        $transactions[] = $txn_data;
                    }
                }
            }
            
            $current = $window_end;
        }
        
        // Fetch unsettled transactions
        $this->log('Fetching unsettled transactions...');
        $unsettled_response = $this->anet->get_unsettled_transaction_list();
        $unsettled_body = isset($unsettled_response['data']['getUnsettledTransactionListResponse'])
            ? $unsettled_response['data']['getUnsettledTransactionListResponse']
            : $unsettled_response['data'];
        
        if ($this->anet->is_response_ok($unsettled_body)) {
            $unsettled_list = isset($unsettled_body['transactions']) ? $unsettled_body['transactions'] : array();
            if (isset($unsettled_list['transaction'])) {
                $unsettled_list = is_array($unsettled_list['transaction']) ? $unsettled_list['transaction'] : array($unsettled_list['transaction']);
            }
            if (!is_array($unsettled_list)) {
                $unsettled_list = array();
            }
            
            foreach ($unsettled_list as $txn) {
                $sub_info = isset($txn['subscription']) ? $txn['subscription'] : array();
                $sub_id = isset($sub_info['id']) ? trim($sub_info['id']) : (isset($sub_info['subscriptionId']) ? trim($sub_info['subscriptionId']) : '');
                
                if (empty($sub_id) || !in_array($sub_id, $active_sub_ids)) {
                    continue;
                }
                
                $txn_data = $this->process_transaction_data($txn, $sub_meta[$sub_id]);
                if ($txn_data) {
                    $transactions[] = $txn_data;
                }
            }
        }
        
        return $transactions;
    }
    
    /**
     * Process transaction data
     */
    private function process_transaction_data($transaction, $sub_meta) {
        $trans_id = isset($transaction['transId']) ? trim($transaction['transId']) : (isset($transaction['transactionId']) ? trim($transaction['transactionId']) : '');
        if (empty($trans_id)) {
            return null;
        }
        
        $sub_id = isset($sub_meta['sub_num']) ? $sub_meta['sub_num'] : '';
        $email = isset($sub_meta['email']) ? $sub_meta['email'] : '';
        $username = isset($sub_meta['username']) ? $sub_meta['username'] : '';
        $product_id = isset($sub_meta['product_id']) ? $sub_meta['product_id'] : '';
        $default_amount = isset($sub_meta['amount']) ? $sub_meta['amount'] : '0.00';
        
        $amount = isset($transaction['settleAmount']) ? $transaction['settleAmount'] : (isset($transaction['authAmount']) ? $transaction['authAmount'] : (isset($transaction['amount']) ? $transaction['amount'] : $default_amount));
        $amount = $this->anet->format_amount($amount);
        
        $created_raw = $this->anet->choose_txn_timestamp($transaction);
        $created_at = $this->anet->format_timestamp($created_raw);
        
        $created_dt = $this->anet->parse_datetime($created_raw);
        $interval_len = isset($sub_meta['interval_len']) ? $sub_meta['interval_len'] : 1;
        $interval_unit = isset($sub_meta['interval_unit']) ? $sub_meta['interval_unit'] : 'months';
        
        // Calculate expires_at
        $next_payment = isset($sub_meta['next_payment']) ? trim($sub_meta['next_payment']) : '';
        if ($next_payment) {
            $expires_at = $this->anet->format_timestamp($next_payment);
        } elseif ($created_dt) {
            $expires_dt = clone $created_dt;
            switch ($interval_unit) {
                case 'days':
                    $expires_dt->modify("+{$interval_len} days");
                    break;
                case 'weeks':
                    $expires_dt->modify("+{$interval_len} weeks");
                    break;
                case 'months':
                    $expires_dt->modify("+{$interval_len} months");
                    break;
                case 'years':
                    $expires_dt->modify("+{$interval_len} years");
                    break;
            }
            $expires_at = $expires_dt->format('Y-m-d H:i:s');
        } else {
            $expires_at = '';
        }
        
        return array(
            'email' => $email,
            'username' => $username,
            'product_id' => $product_id,
            'amount' => $amount,
            'total' => $amount,
            'payment_method' => get_option('membersync_payment_method', 't39zk3-3bx'),
            'trans_num' => $trans_id,
            'sub_num' => $sub_id,
            'created_at' => $created_at,
            'expires_at' => $expires_at,
            'status' => 'complete',
        );
    }
    
    /**
     * Process transaction (save to CSV or import)
     */
    private function process_transaction($txn_data) {
        if ($this->sync_mode === 'import') {
            $result = $this->mp->create_or_update_transaction($txn_data);
            if (!$result['success']) {
                $this->log(sprintf('Error processing transaction %s: %s', $txn_data['trans_num'], $result['error']), 'error');
                $this->progress['errors']++;
            }
        } elseif ($this->sync_mode === 'csv' && $this->txns_csv_handle) {
            // Write to CSV
            $row = array(
                $txn_data['email'],
                $txn_data['username'],
                $txn_data['product_id'],
                $txn_data['amount'],
                $txn_data['total'],
                $txn_data['payment_method'],
                $txn_data['trans_num'],
                $txn_data['sub_num'],
                $txn_data['created_at'],
                $txn_data['expires_at'],
                $txn_data['status'],
            );
            fputcsv($this->txns_csv_handle, $row);
        }
    }
    
    /**
     * Map product ID from subscription name
     */
    private function map_product_id($name) {
        $name = $this->anet->normalize_name($name);
        $mapping = get_option('membersync_product_mapping', array());
        
        if (is_string($mapping)) {
            $mapping = json_decode($mapping, true);
        }
        
        if (!is_array($mapping)) {
            $mapping = array();
        }
        
        // Default mapping (from Python script)
        $default_mapping = array(
            '' => '30986',
            'Basic Member' => '30985',
            'BTS' => '30986',
            'BTS & Events' => '30986',
            'BTS &amp; Events' => '30986',
            'BTS &amp;amp; Events' => '30986',
            'Full Member' => '30986',
            'Introductory Member' => '30985',
            'Premium Member' => '30987',
            'Regular Member' => '30986',
            'Tutorials' => '30984',
            'Video Downloads' => '30987',
            'Videos' => '30987',
            'Voting Only' => '30988',
        );
        
        $mapping = array_merge($default_mapping, $mapping);
        
        return isset($mapping[$name]) ? $mapping[$name] : $mapping[''];
    }
    
    /**
     * Log message
     */
    private function log($message, $level = 'info') {
        $timestamp = current_time('mysql');
        $this->logs[] = array(
            'timestamp' => $timestamp,
            'level' => $level,
            'message' => $message,
        );
        
        // Keep only last 1000 logs
        if (count($this->logs) > 1000) {
            $this->logs = array_slice($this->logs, -1000);
        }
        
        // Update logs immediately so they're available for polling
        $this->update_logs();
        
        // Also flush output buffer if possible (for debugging)
        if (function_exists('fastcgi_finish_request')) {
            fastcgi_finish_request();
        }
    }
    
    /**
     * Update progress transient
     */
    private function update_progress() {
        set_transient('membersync_sync_progress', $this->progress, HOUR_IN_SECONDS);
    }
    
    /**
     * Update logs transient
     */
    private function update_logs() {
        set_transient('membersync_sync_logs', $this->logs, HOUR_IN_SECONDS);
    }
    
    /**
     * Get progress
     */
    public static function get_progress() {
        return get_transient('membersync_sync_progress');
    }
    
    /**
     * Get logs
     */
    public static function get_logs() {
        return get_transient('membersync_sync_logs');
    }
}

