<?php
/**
 * WPMods License Manager
 * 
 * Handles license activation, validation, and deactivation
 *
 * @package MemberSync
 */

if (!defined('ABSPATH')) {
    exit;
}

class MemberSync_License_Manager {
    
    /**
     * API base URL
     */
    private $api_url = 'https://wpmods.store/api';
    
    /**
     * Option name for storing license key
     */
    private $license_key_option = 'membersync_license_key';
    
    /**
     * Option name for storing license status
     */
    private $license_status_option = 'membersync_license_status';
    
    /**
     * Option name for storing activation data
     */
    private $activation_data_option = 'membersync_activation_data';
    
    /**
     * Option name for storing last successful validation timestamp
     */
    private $last_validated_option = 'membersync_last_validated';
    
    /**
     * Grace period in days - plugin stays active if validation fails
     * Set to 0 to disable grace period (not recommended)
     */
    private $grace_period_days = 7;
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        add_action('admin_init', array($this, 'handle_license_activation'));
        add_action('admin_init', array($this, 'handle_license_deactivation'));
        add_action('wp_ajax_membersync_check_license', array($this, 'ajax_check_license'));
        
        // Schedule license check - runs daily by default
        // You can change 'daily' to 'twicedaily' or 'hourly' for more frequent checks
        $this->ensure_cron_scheduled();
        add_action('membersync_daily_license_check', array($this, 'check_license_status'));
        
        // Also check license status on admin page load (fallback if cron fails)
        add_action('admin_init', array($this, 'maybe_check_license_on_admin_load'));
        
        // Re-schedule cron if missing (safety net)
        add_action('admin_init', array($this, 'ensure_cron_scheduled'));
    }
    
    /**
     * Check license on admin page load (throttled to once per hour)
     * This provides faster updates when admin revokes a license
     * Also serves as a fallback if cron job is deleted or doesn't run
     */
    public function maybe_check_license_on_admin_load() {
        $last_check = get_transient('membersync_last_license_check');
        $last_check_time = $last_check ? (int) $last_check : 0;
        $time_since_check = time() - $last_check_time;
        
        // Check if it's been more than 1 hour since last check
        // OR if it's been more than 24 hours (fallback for missing cron)
        if ($time_since_check > HOUR_IN_SECONDS || $time_since_check > DAY_IN_SECONDS) {
            $this->check_license_status();
            set_transient('membersync_last_license_check', time(), HOUR_IN_SECONDS);
        }
    }
    
    /**
     * Check license when premium features are accessed
     * This ensures license is validated even if cron fails
     */
    public function check_license_before_feature() {
        $last_check = get_transient('membersync_last_license_check');
        $last_check_time = $last_check ? (int) $last_check : 0;
        $time_since_check = time() - $last_check_time;
        
        // If it's been more than 6 hours since last check, verify license
        if ($time_since_check > (6 * HOUR_IN_SECONDS)) {
            $this->check_license_status();
        }
        
        // Return current license status
        return $this->is_license_active();
    }
    
    /**
     * Re-schedule cron job if it's missing
     * Call this on plugin activation or admin init
     */
    public function ensure_cron_scheduled() {
        if (!wp_next_scheduled('membersync_daily_license_check')) {
            wp_schedule_event(time(), 'daily', 'membersync_daily_license_check');
        }
    }
    
    /**
     * Get current site URL
     */
    private function get_site_url() {
        return home_url();
    }
    
    /**
     * Get current site name
     */
    private function get_site_name() {
        return get_bloginfo('name');
    }
    
    /**
     * Make API request
     */
    private function api_request($endpoint, $data = array()) {
        $url = trailingslashit($this->api_url) . $endpoint;
        
        $args = array(
            'method' => 'POST',
            'timeout' => 30,
            'headers' => array(
                'Content-Type' => 'application/json',
            ),
            'body' => json_encode($data),
        );
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'error' => $response->get_error_message(),
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        $status_code = wp_remote_retrieve_response_code($response);
        
        return array(
            'success' => ($status_code >= 200 && $status_code < 300),
            'data' => $data,
            'status_code' => $status_code,
        );
    }
    
    /**
     * Activate license
     */
    public function activate_license($license_key) {
        $result = $this->api_request('validate-license', array(
            'license_key' => sanitize_text_field($license_key),
            'site_url' => $this->get_site_url(),
            'site_name' => $this->get_site_name(),
        ));
        
        if (!$result['success'] || !isset($result['data']['valid']) || !$result['data']['valid']) {
            $error = isset($result['data']['error']) ? $result['data']['error'] : 'Failed to activate license';
            
            // Check for duplicate key error (activation already exists but inactive)
            if (isset($result['data']['code']) && $result['data']['code'] === 'DUPLICATE_KEY') {
                $error = __('This license is already activated for this site. If you recently deactivated it, please wait a moment and try again, or contact support if the issue persists.', 'membersync');
            } elseif (isset($result['status_code']) && $result['status_code'] === 409) {
                // 409 Conflict usually means duplicate
                $error = __('This license is already activated for this site. Please deactivate it first if you want to reactivate.', 'membersync');
            }
            
            return array(
                'success' => false,
                'error' => $error,
            );
        }
        
        // Store license data
        update_option($this->license_key_option, $license_key);
        update_option($this->license_status_option, 'active');
        update_option($this->activation_data_option, $result['data']);
        update_option($this->last_validated_option, time()); // Record successful validation
        
        return array(
            'success' => true,
            'data' => $result['data'],
        );
    }
    
    /**
     * Deactivate license
     */
    public function deactivate_license() {
        $license_key = get_option($this->license_key_option);
        
        if (!$license_key) {
            return array(
                'success' => false,
                'error' => 'No license key found',
            );
        }
        
        $result = $this->api_request('deactivate-license', array(
            'license_key' => $license_key,
            'site_url' => $this->get_site_url(),
        ));
        
        if ($result['success']) {
            // Clear local license data
            delete_option($this->license_key_option);
            delete_option($this->license_status_option);
            delete_option($this->activation_data_option);
            delete_option($this->last_validated_option);
        }
        
        return $result;
    }
    
    /**
     * Check license status
     * 
     * Important: This method distinguishes between:
     * 1. Network/API errors (grace period applies)
     * 2. License actually invalid/revoked (immediate deactivation)
     */
    public function check_license_status() {
        $license_key = get_option($this->license_key_option);
        
        if (!$license_key) {
            return array(
                'valid' => false,
                'active' => false,
            );
        }
        
        $result = $this->api_request('check-license', array(
            'license_key' => $license_key,
            'site_url' => $this->get_site_url(),
        ));
        
        // Successfully reached API and got a response
        if ($result['success'] && isset($result['data'])) {
            $api_data = $result['data'];
            
            // License is valid and active
            if (isset($api_data['valid']) && $api_data['valid'] && isset($api_data['active']) && $api_data['active']) {
                update_option($this->license_status_option, 'active');
                update_option($this->last_validated_option, time());
                return $api_data;
            }
            
            // License is explicitly invalid (revoked, expired, etc.)
            // API returned valid:false or active:false - deactivate immediately
            update_option($this->license_status_option, 'inactive');
            return array(
                'valid' => false,
                'active' => false,
            );
        }
        
        // API request failed (network error, timeout, server down, etc.)
        // Check if we're still within grace period
        $last_validated = get_option($this->last_validated_option, 0);
        $days_since_validation = (time() - $last_validated) / DAY_IN_SECONDS;
        
        if ($days_since_validation < $this->grace_period_days) {
            // Still within grace period - keep plugin active
            // Don't update status, just return current status
            $current_status = get_option($this->license_status_option, 'active');
            return array(
                'valid' => true, // Assume valid during grace period
                'active' => ($current_status === 'active'),
                'grace_period' => true,
                'days_remaining' => $this->grace_period_days - $days_since_validation,
            );
        }
        
        // Grace period expired - deactivate
        update_option($this->license_status_option, 'inactive');
        return array(
            'valid' => false,
            'active' => false,
            'error' => 'License validation failed and grace period expired',
        );
    }
    
    /**
     * Get license key
     */
    public function get_license_key() {
        return get_option($this->license_key_option, '');
    }
    
    /**
     * Get license status
     */
    public function get_license_status() {
        return get_option($this->license_status_option, 'inactive');
    }
    
    /**
     * Check if license is active
     * 
     * This method respects the grace period - if validation fails but we're
     * still within grace period, it returns true
     */
    public function is_license_active() {
        $status = $this->get_license_status();
        
        // If status is active, return true
        if ($status === 'active') {
            return true;
        }
        
        // If status is inactive, check if we're in grace period
        $last_validated = get_option($this->last_validated_option, 0);
        if ($last_validated > 0) {
            $days_since_validation = (time() - $last_validated) / DAY_IN_SECONDS;
            if ($days_since_validation < $this->grace_period_days) {
                // Still in grace period - allow access
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Handle license activation form submission
     */
    public function handle_license_activation() {
        if (!isset($_POST['membersync_activate_license']) || !check_admin_referer('membersync_activate_license', '_wpnonce_license')) {
            return;
        }
        
        $license_key = isset($_POST['membersync_license_key']) ? sanitize_text_field($_POST['membersync_license_key']) : '';
        
        if (empty($license_key)) {
            add_settings_error('membersync_license', 'empty_key', __('Please enter a license key.', 'membersync'));
            return;
        }
        
        $result = $this->activate_license($license_key);
        
        if ($result['success']) {
            add_settings_error('membersync_license', 'activation_success', __('License activated successfully!', 'membersync'), 'success');
        } else {
            add_settings_error('membersync_license', 'activation_error', $result['error']);
        }
    }
    
    /**
     * Handle license deactivation form submission
     */
    public function handle_license_deactivation() {
        if (!isset($_POST['membersync_deactivate_license']) || !check_admin_referer('membersync_deactivate_license', '_wpnonce_deactivate')) {
            return;
        }
        
        $result = $this->deactivate_license();
        
        if ($result['success']) {
            add_settings_error('membersync_license', 'deactivation_success', __('License deactivated successfully.', 'membersync'), 'success');
        } else {
            $error = isset($result['data']['error']) ? $result['data']['error'] : __('Failed to deactivate license.', 'membersync');
            add_settings_error('membersync_license', 'deactivation_error', $error);
        }
    }
    
    /**
     * AJAX handler for license check
     */
    public function ajax_check_license() {
        check_ajax_referer('membersync_license_check', 'nonce');
        
        $result = $this->check_license_status();
        wp_send_json($result);
    }
}

