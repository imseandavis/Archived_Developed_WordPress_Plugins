"""
arb_export_memberpress.py

$env:ANET_API_LOGIN_ID="49H9bszNn"
$env:ANET_TRANSACTION_KEY="9NGz5Y85cFkw7a8t"
$env:WP_USER="imseandavis@gmail.com"
$env:WP_APP_PASSWORD="S1oM nBU2 3Dhb ZFn4 XNrq JSg1"
$env:MYSQL_HOST="c1121917.sgvps.net"
$env:MYSQL_DB="dbdzze4hllwngk"
$env:MYSQL_USER="uw9tqrffj2jgx"
$env:MYSQL_PASSWORD='1wbe$b2#9118'

Exports:
  1) Final_Memberpress_Subscriptions.csv  (Active ARB subscriptions)
  2) Final_Memberpress_Transactions.csv   (All transactions since 2020 for those active subscriptions)

Strategy:
  A) Active subs: ARBGetSubscriptionListRequest (correct paging offset) + ARBGetSubscriptionRequest
  B) Transactions since 2020:
     - getSettledBatchListRequest (date range) -> batchIds
     - getTransactionListRequest (per batch, paged) -> transIds
     - getTransactionDetailsRequest (per transId) -> includes subscription.id
     - filter: subscription.id in active_sub_ids
     - also: getUnsettledTransactionListRequest -> transIds -> details -> same filter
"""

import csv, json, time, html
from typing import Dict, Any, List, Optional, Tuple, Set
from xml.etree import ElementTree as ET
from datetime import datetime, timedelta

import requests

# =======================
# CONFIG (PUT YOUR VALUES)
# =======================

# --- Authorize.net ---
API_LOGIN_ID = "49H9bszNn"
TRANSACTION_KEY = "9NGz5Y85cFkw7a8t"
USE_SANDBOX = False

# ARB subscription list
PAGE_LIMIT = 1000
SEARCH_TYPE = "subscriptionActive"   # active subs
SORT_ORDER_DESC = False
SLEEP_BETWEEN_PAGES_SEC = 0.20
SLEEP_BETWEEN_DETAIL_CALLS_SEC = 0.01

# Transaction reporting windows (must be <= 31 days for batch list)
TXN_WINDOW_DAYS = 31

# Desired start date (will be clamped if gateway rejects older)
TXN_START_DATE = "2020-01-01"

SUBS_CSV = "Final_Memberpress_Subscriptions.csv"
TXNS_CSV = "Final_Memberpress_Transactions.csv"

# MemberPress constants
CONST_PAYMENT_METHOD = "t39zk3-3bx"
CONST_PERIOD = "1"
CONST_PERIOD_TYPE = "months"
TXN_STATUS_ALWAYS = "complete"

ENDPOINT = ("https://apitest.authorize.net/xml/v1/request.api"
            if USE_SANDBOX else "https://api.authorize.net/xml/v1/request.api")

# --- WordPress REST (fallback only) ---
WP_ENABLED = True
WP_BASE_URL = "https://www.theduchy.com"
WP_USER = "imseandavis@gmail.com"
WP_APP_PASSWORD = "S1oM nBU2 3Dhb ZFn4 XNrq JSg1"
WP_TIMEOUT = 29  # seconds

# --- MySQL (DB-first user mapping + PMPro fallback) ---
MYSQL_ENABLED = True
MYSQL_HOST = "c1121917.sgvps.net"
MYSQL_PORT = 3306
MYSQL_DB = "dbdzze4hllwngk"
MYSQL_USER = "uw9tqrffj2jgx"
MYSQL_PASSWORD = "1wbe$b2#9118"
TABLE_PREFIX = "rll_"   # wp table prefix

# Feature switches
PMPRO_ENABLED = True

# Debug
DEBUG = True
DEBUG_SUBS_EVERY = 1   # print every N subs; set to e.g. 10 if you want quieter
DEBUG_TXNS = True

# =======================
# Helpers / formatting
# =======================

def log_line(msg: str):
    print(msg, flush=True)

def _xml_to_minimal_dict(xml_text: str) -> Dict[str, Any]:
    try:
        root = ET.fromstring(xml_text)

        def elem_to_obj(elem):
            if len(elem) == 0:
                return elem.text
            return {child.tag: elem_to_obj(child) for child in elem}

        return {root.tag: elem_to_obj(root)}
    except Exception:
        return {"raw": xml_text}

def post_authorize_net(payload: Dict[str, Any]) -> Dict[str, Any]:
    headers = {"Content-Type": "application/json", "Accept": "application/json"}
    r = requests.post(ENDPOINT, json=payload, headers=headers, timeout=60)
    r.raise_for_status()
    try:
        return json.loads(r.content.decode("utf-8-sig"))
    except json.JSONDecodeError:
        ct = r.headers.get("Content-Type", "")
        text = r.text
        if "xml" in ct.lower() or text.strip().startswith("<"):
            return _xml_to_minimal_dict(text)
        raise RuntimeError(f"Authorize.Net returned non-JSON. CT={ct!r} head={text[:200]!r}")

def _anet_ok(body: Dict[str, Any]) -> bool:
    """
    Works for many Authorize.Net responses:
    body["messages"]["resultCode"] == "Ok"
    """
    messages = body.get("messages") or {}
    rc = (messages.get("resultCode") or "").lower()
    return rc == "ok"

def _anet_error_text(body: Dict[str, Any]) -> str:
    messages = body.get("messages") or {}
    msg_list = messages.get("message") or []
    if isinstance(msg_list, dict):
        msg_list = [msg_list]
    if isinstance(msg_list, list) and msg_list:
        m = msg_list[0]
        return f"{m.get('code', '')}: {m.get('text', '')}".strip()
    return json.dumps(body)[:400]

def norm_name(name: Optional[str]) -> str:
    if not name:
        return ""
    s = html.unescape(str(name)).strip()
    return " ".join(s.split())

def map_product_id(name: Optional[str]) -> str:
    n = norm_name(name)
    mapping = {
        "": "30986",
        "Basic Member": "30985",
        "BTS": "30986",
        "BTS & Events": "30986",
        "BTS &amp; Events": "30986",
        "BTS &amp;amp; Events": "30986",
        "Full Member": "30986",
        "Introductory Member": "30985",
        "Premium Member": "30987",
        "Regular Member": "30986",
        "Tutorials": "30984",
        "Video Downloads": "30987",
        "Videos": "30987",
        "Voting Only": "30988",
    }
    return mapping.get(n, mapping[""])

def amount_to_str(val: Any) -> str:
    try:
        return f"{float(val):.2f}"
    except Exception:
        return str(val) if val is not None else ""

def format_timestamp(ts: str) -> str:
    """
    Normalize to: YYYY-MM-DD hh:mm:ss
    Accepts ISO-like strings.
    """
    if not ts:
        return ""
    try:
        ts_norm = ts.replace("T", " ").replace("Z", "").split(".")[0].strip()
        if len(ts_norm) == 10:
            ts_norm += " 00:00:00"
        return datetime.fromisoformat(ts_norm).strftime("%Y-%m-%d %H:%M:%S")
    except Exception:
        # last-resort normalization
        ts2 = ts.replace("T", " ").replace("Z", "").split(".")[0].strip()
        if len(ts2) == 10:
            ts2 += " 00:00:00"
        return ts2

def parse_dt(ts: str) -> Optional[datetime]:
    if not ts:
        return None
    try:
        norm = ts.replace("T", " ").replace("Z", "").split(".")[0].strip()
        if len(norm) == 10:
            norm += " 00:00:00"
        return datetime.fromisoformat(norm)
    except Exception:
        return None

def add_months(dt_in: datetime, months: int) -> datetime:
    if months == 0:
        return dt_in
    y = dt_in.year + (dt_in.month - 1 + months) // 12
    m = (dt_in.month - 1 + months) % 12 + 1
    d = dt_in.day
    if m == 12:
        next_month = datetime(y + 1, 1, 1)
    else:
        next_month = datetime(y, m + 1, 1)
    last_day = (next_month - timedelta(days=1)).day
    d = min(d, last_day)
    return dt_in.replace(year=y, month=m, day=d)

def add_interval(dt_in: datetime, length: Any, unit: str) -> datetime:
    unit = (unit or "").lower()
    try:
        length_i = int(length)
    except Exception:
        length_i = 1

    if unit.startswith("month"):
        return add_months(dt_in, length_i)
    if unit.startswith("day"):
        return dt_in + timedelta(days=length_i)
    if unit.startswith("year"):
        return add_months(dt_in, 12 * length_i)
    return add_months(dt_in, 1)

def extract_email(sub: Dict[str, Any]) -> str:
    profile = sub.get("profile") or {}
    customer = sub.get("customer") or {}
    return (profile.get("email") or customer.get("email") or "").strip()

def choose_txn_timestamp(t: Dict[str, Any]) -> str:
    return (
        t.get("submitTimeUTC")
        or t.get("transactionTimeUTC")
        or t.get("settlementTimeUTC")
        or t.get("submitTimeLocal")
        or t.get("submitTime")
        or t.get("transactionTime")
        or ""
    )

# =======================
# Authorize.Net API calls
# =======================

def get_subscription_list(limit: int, page_number: int) -> Dict[str, Any]:
    """
    NOTE: For your gateway, paging.offset behaves like PAGE NUMBER.
    """
    req = {
        "ARBGetSubscriptionListRequest": {
            "merchantAuthentication": {
                "name": API_LOGIN_ID,
                "transactionKey": TRANSACTION_KEY,
            },
            "searchType": SEARCH_TYPE,
            "sorting": {
                "orderBy": "id",
                "orderDescending": "true" if SORT_ORDER_DESC else "false",
            },
            "paging": {"limit": int(limit), "offset": int(page_number)},
        }
    }
    return post_authorize_net(req)

def get_subscription_detail(sub_id: str, include_transactions: bool = False) -> Dict[str, Any]:
    req = {
        "ARBGetSubscriptionRequest": {
            "merchantAuthentication": {
                "name": API_LOGIN_ID,
                "transactionKey": TRANSACTION_KEY,
            },
            "subscriptionId": str(sub_id),
            "includeTransactions": "true" if include_transactions else "false",
        }
    }
    return post_authorize_net(req)

def get_settled_batch_list(first_date: str, last_date: str) -> Dict[str, Any]:
    """
    getSettledBatchListRequest does NOT accept paging/sorting in many schema versions.
    """
    req = {
        "getSettledBatchListRequest": {
            "merchantAuthentication": {
                "name": API_LOGIN_ID,
                "transactionKey": TRANSACTION_KEY,
            },
            "includeStatistics": "false",
            "firstSettlementDate": first_date,
            "lastSettlementDate": last_date,
        }
    }
    return post_authorize_net(req)

def get_transaction_list_for_batch(batch_id: str) -> Dict[str, Any]:
    req = {
        "getTransactionListRequest": {
            "merchantAuthentication": {
                "name": API_LOGIN_ID,
                "transactionKey": TRANSACTION_KEY,
            },
            "batchId": str(batch_id),
        }
    }
    return post_authorize_net(req)

def get_unsettled_transaction_list() -> Dict[str, Any]:
    """
    getUnsettledTransactionListRequest also often rejects paging/sorting.
    """
    req = {
        "getUnsettledTransactionListRequest": {
            "merchantAuthentication": {
                "name": API_LOGIN_ID,
                "transactionKey": TRANSACTION_KEY,
            }
        }
    }
    return post_authorize_net(req)

# =======================
# WP REST fallback
# =======================

_username_cache: Dict[str, str] = {}
_userid_cache: Dict[int, str] = {}

def wp_get_user_by_id(user_id: int) -> str:
    if not WP_ENABLED:
        return ""
    if user_id in _userid_cache:
        return _userid_cache[user_id]
    base = WP_BASE_URL.rstrip("/")
    url = f"{base}/wp-json/wp/v2/users/{user_id}"
    resp = None
    try:
        resp = requests.get(
            url,
            params={"context": "edit"},
            auth=(WP_USER, WP_APP_PASSWORD),
            timeout=WP_TIMEOUT,
        )
        data = resp.json() if resp.status_code == 200 and resp.content else {}
        username = ""
        if isinstance(data, dict):
            username = (data.get("username") or data.get("slug") or data.get("name") or "").strip()
        _userid_cache[user_id] = username
        return username
    except Exception:
        _userid_cache[user_id] = ""
        return ""

def lookup_wp_username_by_email(email: str) -> str:
    if not (WP_ENABLED and email):
        return ""
    key = email.lower()
    if key in _username_cache:
        return _username_cache[key]
    base = WP_BASE_URL.rstrip("/")
    url = f"{base}/wp-json/wp/v2/users"
    params = {"search": email, "context": "edit", "per_page": 100}
    resp = None
    try:
        resp = requests.get(
            url,
            params=params,
            auth=(WP_USER, WP_APP_PASSWORD),
            timeout=WP_TIMEOUT,
        )
        arr = resp.json() if resp.status_code == 200 and resp.content else []
        username = ""
        if isinstance(arr, list):
            for u in arr:
                if str(u.get("email", "")).lower() == key:
                    username = (u.get("username") or u.get("slug") or u.get("name") or "").strip()
                    break
        _username_cache[key] = username
        return username
    except Exception:
        _username_cache[key] = ""
        return ""

# =======================
# MySQL: preload WP users
# =======================

EMAIL_TO_LOGIN: Dict[str, str] = {}
ID_TO_LOGIN: Dict[int, str] = {}

def mysql_preload_wp_users() -> None:
    """
    Loads all WP users into:
      EMAIL_TO_LOGIN[email.lower()] = user_login
      ID_TO_LOGIN[ID] = user_login
    """
    if not MYSQL_ENABLED:
        return

    try:
        import pymysql
    except Exception:
        log_line("[DB] PyMySQL not installed. Run: pip install pymysql")
        return

    users_table = f"{TABLE_PREFIX}users"
    q = f"SELECT ID, user_login, user_email FROM `{users_table}`"

    conn = None
    try:
        conn = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DB,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            connect_timeout=15,
            read_timeout=60,
            write_timeout=60,
        )
        with conn.cursor() as cur:
            cur.execute(q)
            rows = cur.fetchall() or []
            for r in rows:
                try:
                    uid = int(r["ID"])
                except Exception:
                    continue
                login = (r.get("user_login") or "").strip()
                email = (r.get("user_email") or "").strip().lower()
                if login:
                    ID_TO_LOGIN[uid] = login
                    if email:
                        EMAIL_TO_LOGIN[email] = login

        log_line(f"[DB] Preloaded WP users: {len(ID_TO_LOGIN)} ids, {len(EMAIL_TO_LOGIN)} emails")
    except Exception as e:
        log_line(f"[DB] Failed to preload WP users: {e}")
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass

def mysql_get_user_id_by_subnum(sub_num: str) -> Optional[int]:
    """
    PMPro fallback: query pmpro_subscriptions by subscription_transaction_id.
    """
    if not (MYSQL_ENABLED and PMPRO_ENABLED and sub_num):
        return None

    try:
        import pymysql
    except Exception:
        log_line("[DB] PyMySQL not installed. Run: pip install pymysql")
        return None

    table = f"{TABLE_PREFIX}pmpro_subscriptions"
    q = (
        f"SELECT user_id FROM `{table}` "
        "WHERE subscription_transaction_id = %s "
        "ORDER BY id DESC LIMIT 1"
    )
    params: Tuple[str, ...] = (sub_num,)

    conn = None
    try:
        conn = pymysql.connect(
            host=MYSQL_HOST,
            port=MYSQL_PORT,
            user=MYSQL_USER,
            password=MYSQL_PASSWORD,
            database=MYSQL_DB,
            charset="utf8mb4",
            cursorclass=pymysql.cursors.DictCursor,
            connect_timeout=15,
            read_timeout=60,
            write_timeout=60,
        )
        with conn.cursor() as cur:
            cur.execute(q, params)
            row = cur.fetchone()
            if row and row.get("user_id"):
                try:
                    return int(row["user_id"])
                except Exception:
                    return None
        return None
    except Exception:
        return None
    finally:
        try:
            if conn:
                conn.close()
        except Exception:
            pass

# =======================
# Username resolution (DB-first)
# =======================

def resolve_username(email: str, sub_id: str) -> Tuple[str, str]:
    """
    Returns (username, source)
      source in: "db-email", "db-pmpro", "wp-email", "wp-id", "none"
    """
    ekey = (email or "").strip().lower()

    # 1) DB by email
    if ekey and ekey in EMAIL_TO_LOGIN:
        return EMAIL_TO_LOGIN[ekey], "db-email"

    # 2) PMPro -> user_id -> DB by id
    uid = mysql_get_user_id_by_subnum(sub_id)
    if uid and uid in ID_TO_LOGIN:
        return ID_TO_LOGIN[uid], "db-pmpro"

    # 3) WP REST by email
    u = lookup_wp_username_by_email(email)
    if u:
        return u, "wp-email"

    # 4) WP REST by id (if pmpro gave us one)
    if uid:
        u2 = wp_get_user_by_id(uid)
        if u2:
            return u2, "wp-id"

    return "", "none"

# =======================
# CSV headers
# =======================

SUBS_HEADER = [
    "email",
    "username",
    "product_id",
    "price",
    "total",
    "period",
    "period_type",
    "status",
    "payment_method",
    "sub_num",
    "created_at",
]

TXNS_HEADER = [
    "email",
    "username",
    "product_id",
    "amount",
    "total",
    "payment_method",
    "trans_num",
    "sub_num",
    "created_at",
    "expires_at",
    "status",
]

# =======================
# Main export
# =======================

def export_memberpress():
    log_line(f"Endpoint: {ENDPOINT}")
    log_line(f"Exporting active ARB subscriptions (searchType={SEARCH_TYPE!r}) ...")

    # DB preload (email -> login, id -> login)
    mysql_preload_wp_users()

    # active subscriptions we’ll keep for transaction matching
    active_sub_ids: Set[str] = set()
    sub_meta: Dict[str, Dict[str, Any]] = {}
    sub_txn_counts: Dict[str, int] = {}

    total_reported: Optional[int] = None
    written_subs = 0
    written_txns = 0

    # -------- PASS 1: subscriptions --------
    with open(SUBS_CSV, "w", newline="", encoding="utf-8") as subs_f:
        subs_w = csv.DictWriter(subs_f, fieldnames=SUBS_HEADER, extrasaction="ignore")
        subs_w.writeheader()

        page = 1
        processed = 0

        while True:
            log_line(f"--- Subscriptions page {page} (limit {PAGE_LIMIT}) ---")
            resp = get_subscription_list(PAGE_LIMIT, page)
            body = resp.get("ARBGetSubscriptionListResponse") or resp

            if not _anet_ok(body):
                log_line(f"  ! ARBGetSubscriptionListResponse error: {_anet_error_text(body)}")
                break

            if total_reported is None:
                try:
                    total_reported = int(body.get("totalNumInResultSet") or 0)
                    if total_reported:
                        log_line(f"Total reported by gateway: {total_reported}")
                except Exception:
                    total_reported = None

            details = body.get("subscriptionDetails") or []
            if isinstance(details, dict):
                details = [details]
            if not isinstance(details, list):
                details = []

            returned = len(details)
            if returned == 0:
                log_line("No more subscription results.")
                break

            for s in details:
                processed += 1
                sub_id = str(s.get("id") or "").strip()
                if not sub_id:
                    continue

                # Fetch detail (not including transactions; ARB only returns a small subset anyway)
                det = get_subscription_detail(sub_id, include_transactions=False)
                if SLEEP_BETWEEN_DETAIL_CALLS_SEC:
                    time.sleep(SLEEP_BETWEEN_DETAIL_CALLS_SEC)

                body_det = det.get("ARBGetSubscriptionResponse") or det
                if not _anet_ok(body_det):
                    # sometimes detail responses wrap messages differently; still log and skip
                    log_line(f"  ! ARBGetSubscriptionResponse error for sub_id={sub_id}: {_anet_error_text(body_det)}")
                    continue

                sub = body_det.get("subscription") or {}
                status = (sub.get("status") or body_det.get("status") or "").strip()

                email = extract_email(sub)
                name = sub.get("name") or ""
                product_id = map_product_id(name)
                amount = amount_to_str(sub.get("amount"))

                username, source = resolve_username(email, sub_id)

                created_raw = (s.get("createTimeStampUTC", "") or "")
                created_fmt = format_timestamp(created_raw)

                # interval for expiry calc
                ps = sub.get("paymentSchedule") or {}
                interval = ps.get("interval") or {}
                interval_len = interval.get("length") or 1
                interval_unit = interval.get("unit") or "months"

                next_payment = (sub.get("nextPaymentDate") or "").strip()

                # Write subscription row
                subs_row = {
                    "email": email,
                    "username": username,
                    "product_id": product_id,
                    "price": amount,
                    "total": amount,
                    "period": CONST_PERIOD,
                    "period_type": CONST_PERIOD_TYPE,
                    "status": status,
                    "payment_method": CONST_PAYMENT_METHOD,
                    "sub_num": sub_id,
                    "created_at": created_fmt,
                }
                subs_w.writerow(subs_row)
                written_subs += 1

                if status.lower() == "active":
                    active_sub_ids.add(sub_id)

                sub_meta[sub_id] = {
                    "email": email,
                    "username": username,
                    "product_id": product_id,
                    "amount": amount,
                    "status": status,
                    "interval_len": interval_len,
                    "interval_unit": interval_unit,
                    "next_payment": next_payment,
                }
                sub_txn_counts.setdefault(sub_id, 0)

                if DEBUG and (processed % max(1, DEBUG_SUBS_EVERY) == 0):
                    src_tag = "db" if source.startswith("db") else ("wp" if source.startswith("wp") else "none")
                    log_line(
                        f"[SUB] {sub_id} | {status or '-'} | user={username or '-'} ({src_tag}) | "
                        f"email={email or '-'} | product={product_id}"
                    )

            if returned < PAGE_LIMIT:
                log_line("[PAGING] Final page reached (returned < limit).")
                break

            page += 1
            if SLEEP_BETWEEN_PAGES_SEC:
                time.sleep(SLEEP_BETWEEN_PAGES_SEC)

    log_line(f"Subscriptions export done: {written_subs} subs written to {SUBS_CSV}")
    log_line(f"Active subs found: {len(active_sub_ids)}")

    # -------- PASS 2: transactions (ACTIVE subs only) --------
    log_line("")
    log_line(f"Exporting transactions since {TXN_START_DATE} for ACTIVE subs only ...")

    # Clamp start date if gateway enforces 2023+ (common)
    desired_start = datetime.fromisoformat(TXN_START_DATE)
    min_start = datetime(2023, 1, 1)
    start_dt = desired_start
    if desired_start < min_start:
        start_dt = desired_start  # try first; if rejected, we clamp after seeing E00013

    # Write TXNs CSV
    with open(TXNS_CSV, "w", newline="", encoding="utf-8") as txns_f:
        txns_w = csv.DictWriter(txns_f, fieldnames=TXNS_HEADER, extrasaction="ignore")
        txns_w.writeheader()

        # walk windows
        current = start_dt
        now = datetime.utcnow()
        hard_clamped = False

        while current < now:
            window_end = min(current + timedelta(days=TXN_WINDOW_DAYS), now)
            first_str = current.strftime("%Y-%m-%dT00:00:00Z")
            last_str = window_end.strftime("%Y-%m-%dT00:00:00Z")

            if DEBUG_TXNS:
                log_line(f"[TXNS] settled batches window {current.date()} -> {window_end.date()}")

            resp = get_settled_batch_list(first_str, last_str)
            body = resp.get("getSettledBatchListResponse") or resp

            if not _anet_ok(body):
                err = _anet_error_text(body)
                if "E00013" in err and ("older than the year of 2023" in err.lower()) and not hard_clamped:
                    # clamp and restart
                    log_line("[TXNS] Gateway refuses batches older than 2023; clamping start date to 2023-01-01 and restarting scan.")
                    current = datetime(2023, 1, 1)
                    hard_clamped = True
                    continue

                log_line(f"[TXNS] getSettledBatchListResponse error: {err}")
                # move forward anyway to avoid infinite loop on a single bad month
                current = window_end
                continue

            batches = body.get("batchList") or []
            if isinstance(batches, dict):
                # sometimes {"batch": [...]}
                inner = batches.get("batch")
                if isinstance(inner, list):
                    batches = inner
                elif isinstance(inner, dict):
                    batches = [inner]
                else:
                    batches = [batches]
            if not isinstance(batches, list):
                batches = []

            if DEBUG_TXNS:
                log_line(f"[TXNS] batches returned: {len(batches)}")

            # for each batch, pull tx list
            for b in batches:
                batch_id = str(b.get("batchId") or b.get("id") or "").strip()
                if not batch_id:
                    continue

                tx_resp = get_transaction_list_for_batch(batch_id)
                tx_body = tx_resp.get("getTransactionListResponse") or tx_resp

                if not _anet_ok(tx_body):
                    log_line(f"[TXNS] batch {batch_id} getTransactionListResponse error: {_anet_error_text(tx_body)}")
                    continue

                tx_list = tx_body.get("transactions") or []
                if isinstance(tx_list, dict):
                    inner = tx_list.get("transaction")
                    if isinstance(inner, list):
                        tx_list = inner
                    elif isinstance(inner, dict):
                        tx_list = [inner]
                    else:
                        tx_list = [tx_list]
                if not isinstance(tx_list, list):
                    tx_list = []

                seen = len(tx_list)
                matched = 0

                for t in tx_list:
                    # subscription id is not always present the same way; be flexible
                    sub_info = t.get("subscription") or {}
                    sub_id = str(sub_info.get("id") or sub_info.get("subscriptionId") or t.get("subscriptionId") or "").strip()

                    if not sub_id or sub_id not in active_sub_ids:
                        continue

                    matched += 1
                    sub_txn_counts[sub_id] = sub_txn_counts.get(sub_id, 0) + 1

                    meta = sub_meta.get(sub_id) or {}
                    email = meta.get("email", "")
                    username = meta.get("username", "")
                    product_id = meta.get("product_id", "")
                    default_amount = meta.get("amount", "")

                    trans_id = str(t.get("transId") or t.get("transactionId") or "").strip()

                    # transaction amount fields vary
                    amt = t.get("settleAmount") or t.get("authAmount") or t.get("amount") or default_amount
                    amt_s = amount_to_str(amt)

                    created_raw = choose_txn_timestamp(t)
                    created_fmt = format_timestamp(created_raw)

                    created_dt = parse_dt(created_raw) or parse_dt(created_fmt)
                    interval_len = meta.get("interval_len", 1)
                    interval_unit = meta.get("interval_unit", "months")

                    # expires_at: prefer per-sub next payment if present (current cycle),
                    # else compute from txn time + interval.
                    next_payment = (meta.get("next_payment") or "").strip()
                    if next_payment:
                        expires_fmt = format_timestamp(next_payment)
                    elif created_dt:
                        expires_dt = add_interval(created_dt, interval_len, interval_unit)
                        expires_fmt = expires_dt.strftime("%Y-%m-%d %H:%M:%S")
                    else:
                        expires_fmt = ""

                    tx_row = {
                        "email": email,
                        "username": username,
                        "product_id": product_id,
                        "amount": amt_s,
                        "total": amt_s,
                        "payment_method": CONST_PAYMENT_METHOD,
                        "trans_num": trans_id,
                        "sub_num": sub_id,
                        "created_at": created_fmt,
                        "expires_at": expires_fmt,
                        "status": TXN_STATUS_ALWAYS,
                    }
                    txns_w.writerow(tx_row)
                    written_txns += 1

                if DEBUG_TXNS:
                    log_line(f"[TXNS] batch {batch_id}: seen={seen} matched_active_subs={matched}")

            current = window_end

        # Also try unsettled list (captures current-cycle / not-yet-settled)
        if DEBUG_TXNS:
            log_line("[TXNS] Scanning unsettled transactions...")
        uresp = get_unsettled_transaction_list()
        ubody = uresp.get("getUnsettledTransactionListResponse") or uresp

        if _anet_ok(ubody):
            ulist = ubody.get("transactions") or []
            if isinstance(ulist, dict):
                inner = ulist.get("transaction")
                if isinstance(inner, list):
                    ulist = inner
                elif isinstance(inner, dict):
                    ulist = [inner]
                else:
                    ulist = [ulist]
            if not isinstance(ulist, list):
                ulist = []

            seen = len(ulist)
            matched = 0

            for t in ulist:
                sub_info = t.get("subscription") or {}
                sub_id = str(sub_info.get("id") or sub_info.get("subscriptionId") or t.get("subscriptionId") or "").strip()
                if not sub_id or sub_id not in active_sub_ids:
                    continue

                matched += 1
                sub_txn_counts[sub_id] = sub_txn_counts.get(sub_id, 0) + 1

                meta = sub_meta.get(sub_id) or {}
                email = meta.get("email", "")
                username = meta.get("username", "")
                product_id = meta.get("product_id", "")
                default_amount = meta.get("amount", "")

                trans_id = str(t.get("transId") or t.get("transactionId") or "").strip()

                amt = t.get("amount") or t.get("authAmount") or t.get("settleAmount") or default_amount
                amt_s = amount_to_str(amt)

                created_raw = choose_txn_timestamp(t)
                created_fmt = format_timestamp(created_raw)

                created_dt = parse_dt(created_raw) or parse_dt(created_fmt)
                interval_len = meta.get("interval_len", 1)
                interval_unit = meta.get("interval_unit", "months")

                next_payment = (meta.get("next_payment") or "").strip()
                if next_payment:
                    expires_fmt = format_timestamp(next_payment)
                elif created_dt:
                    expires_dt = add_interval(created_dt, interval_len, interval_unit)
                    expires_fmt = expires_dt.strftime("%Y-%m-%d %H:%M:%S")
                else:
                    expires_fmt = ""

                tx_row = {
                    "email": email,
                    "username": username,
                    "product_id": product_id,
                    "amount": amt_s,
                    "total": amt_s,
                    "payment_method": CONST_PAYMENT_METHOD,
                    "trans_num": trans_id,
                    "sub_num": sub_id,
                    "created_at": created_fmt,
                    "expires_at": expires_fmt,
                    "status": TXN_STATUS_ALWAYS,
                }
                txns_w.writerow(tx_row)
                written_txns += 1

            if DEBUG_TXNS:
                log_line(f"[TXNS] unsettled: seen={seen} matched_active_subs={matched}")
        else:
            log_line(f"[TXNS] getUnsettledTransactionListResponse error: {_anet_error_text(ubody)}")

    # Summary: per-sub transaction counts (no per-txn spam)
    log_line("")
    log_line("Transaction counts (ACTIVE subs):")
    # keep it readable: only show subs we saw, in ascending id order
    for sub_id in sorted(active_sub_ids, key=lambda x: int(x) if x.isdigit() else x):
        meta = sub_meta.get(sub_id) or {}
        email = meta.get("email", "-")
        username = meta.get("username", "-")
        cnt = sub_txn_counts.get(sub_id, 0)
        log_line(f"  sub_id={sub_id} user={username or '-'} email={email or '-'} txns={cnt}")

    log_line("")
    log_line("Done!")
    log_line(f"  Wrote {written_subs} rows to {SUBS_CSV}")
    log_line(f"  Wrote {written_txns} rows to {TXNS_CSV}")

if __name__ == "__main__":
    export_memberpress()