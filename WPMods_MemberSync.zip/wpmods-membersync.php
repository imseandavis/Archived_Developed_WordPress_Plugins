<?php
/**
 * Plugin Name: MemberSync
 * Plugin URI: https://wpmods.store
 * Description: Sync subscriptions and transactions from Authorize.Net (and other payment gateways) to MemberPress.
 * Version: 1.0.0
 * Author: WPMods
 * Author URI: https://wpmods.store
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: membersync
 * Domain Path: /languages
 * Requires at least: 5.0
 * Requires PHP: 7.4
 *
 * @package MemberSync
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MEMBERSYNC_VERSION', '1.0.0');
define('MEMBERSYNC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MEMBERSYNC_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MEMBERSYNC_PLUGIN_FILE', __FILE__);
define('MEMBERSYNC_PLUGIN_BASENAME', plugin_basename(__FILE__));

/**
 * Main plugin class
 */
class MemberSync {
    
    /**
     * Single instance
     */
    private static $instance = null;
    
    /**
     * Get instance
     */
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    /**
     * Constructor
     */
    private function __construct() {
        $this->check_dependencies();
        $this->load_dependencies();
        $this->init_hooks();
    }
    
    /**
     * Check if required dependencies are available
     */
    private function check_dependencies() {
        // Check if MemberPress is active
        if (!class_exists( 'MeprAppController' ) && did_action( 'mepr_loaded' )) {
            add_action('admin_notices', array($this, 'memberpress_missing_notice'));
            return;
        }
    }
    
    /**
     * Load plugin dependencies
     */
    private function load_dependencies() {
        // Load license manager
        require_once MEMBERSYNC_PLUGIN_DIR . 'includes/class-wpmods-license-manager.php';
        
        // Load admin interface
        require_once MEMBERSYNC_PLUGIN_DIR . 'includes/class-membersync-admin.php';
        
        // Load Authorize.Net integration
        require_once MEMBERSYNC_PLUGIN_DIR . 'includes/class-membersync-authorize-net.php';
        
        // Load MemberPress integration
        require_once MEMBERSYNC_PLUGIN_DIR . 'includes/class-membersync-memberpress-integration.php';
        
        // Load sync processor
        require_once MEMBERSYNC_PLUGIN_DIR . 'includes/class-membersync-sync-processor.php';
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        // Initialize admin
        if (is_admin()) {
            add_action('plugins_loaded', array($this, 'init_admin'), 20);
        }
        
        // Register activation/deactivation hooks
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    /**
     * Initialize admin interface
     */
    public function init_admin() {
        if (class_exists('MemberSync_Admin')) {
            MemberSync_Admin::get_instance();
        }
        
        // Initialize license manager
        if (class_exists('MemberSync_License_Manager')) {
            MemberSync_License_Manager::get_instance();
        }
    }
    
    /**
     * Plugin activation
     */
    public function activate() {
        // Check for MemberPress
        if (!class_exists('MeprAppCtrl')) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(
                __('MemberSync requires MemberPress to be installed and activated.', 'membersync'),
                __('Plugin Activation Error', 'membersync'),
                array('back_link' => true)
            );
        }
        
        // Schedule license check cron
        $license_manager = MemberSync_License_Manager::get_instance();
        if (method_exists($license_manager, 'ensure_cron_scheduled')) {
            $license_manager->ensure_cron_scheduled();
        }
    }
    
    /**
     * Plugin deactivation
     */
    public function deactivate() {
        // Clear any scheduled events
        wp_clear_scheduled_hook('membersync_daily_license_check');
    }
    
    /**
     * Notice when MemberPress is missing
     */
    public function memberpress_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p>
                <?php
                printf(
                    __('MemberSync requires %s to be installed and activated.', 'membersync'),
                    '<strong>MemberPress</strong>'
                );
                ?>
            </p>
        </div>
        <?php
    }
}

/**
 * Initialize the plugin
 */
function membersync_init() {
    return MemberSync::get_instance();
}

// Start the plugin
membersync_init();

