/**
 * MemberSync Admin JavaScript
 */

(function($) {
    'use strict';
    
    var syncInProgress = false;
    var progressInterval = null;
    var logsInterval = null;
    
    $(document).ready(function() {
        // Start sync button
        $('#membersync-start-sync').on('click', function() {
            if (syncInProgress) {
                return;
            }
            
            if (!confirm('Are you sure you want to start the sync? This may take a while.')) {
                return;
            }
            
            startSync();
        });
        
        // Check license button
        $('#membersync-check-license').on('click', function() {
            var $button = $(this);
            var nonce = $button.data('nonce');
            
            $button.prop('disabled', true).text('Checking...');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'membersync_check_license',
                    nonce: nonce
                },
                success: function(response) {
                    if (response && response.success && response.data && response.data.valid && response.data.active) {
                        alert('License is active and valid.');
                    } else {
                        alert('License is not active or invalid.');
                    }
                },
                error: function() {
                    alert('Error checking license status.');
                },
                complete: function() {
                    $button.prop('disabled', false).text('Check License Status');
                }
            });
        });
        
        // Product mapping add/remove
        $('.membersync-add-mapping').on('click', function() {
            var $row = $(this).closest('tr');
            var name = $row.find('.membersync-mapping-name').val();
            var productId = $row.find('.membersync-mapping-product').val();
            
            if (!name || !productId) {
                alert('Please enter both subscription name and product ID.');
                return;
            }
            
            // Create new row with proper name attributes
            var newRow = $('<tr></tr>');
            newRow.append('<td><input type="text" name="membersync_product_mapping[' + escapeHtml(name) + ']" value="' + escapeHtml(name) + '" class="regular-text membersync-mapping-name" /></td>');
            newRow.append('<td><input type="text" name="membersync_product_mapping[' + escapeHtml(name) + ']" value="' + escapeHtml(productId) + '" class="regular-text membersync-mapping-product" /></td>');
            newRow.append('<td><button type="button" class="button membersync-remove-mapping">Remove</button></td>');
            
            $row.before(newRow);
            $row.find('.membersync-mapping-name, .membersync-mapping-product').val('');
            
            // Bind remove handler
            newRow.find('.membersync-remove-mapping').on('click', function() {
                $(this).closest('tr').remove();
            });
        });
        
        $(document).on('click', '.membersync-remove-mapping', function() {
            $(this).closest('tr').remove();
        });
    });
    
    /**
     * Start sync process
     */
    function startSync() {
        syncInProgress = true;
        $('#membersync-start-sync').prop('disabled', true).text('Syncing...');
        $('#membersync-progress').show();
        $('#membersync-logs').show();
        
        // Clear logs container and show initial message
        $('#membersync-logs-content').html('<div class="membersync-log-entry membersync-log-info"><span class="membersync-log-time">[Starting...]</span> <span class="membersync-log-message">Initializing sync process...</span></div>');
        
        // Start polling immediately (before sync starts)
        startProgressPolling();
        startLogsPolling();
        
        // Start sync
        $.ajax({
            url: membersyncAdmin.ajaxUrl,
            type: 'POST',
            data: {
                action: 'membersync_start_sync',
                nonce: membersyncAdmin.nonce
            },
            timeout: 300000, // 5 minute timeout
            success: function(response) {
                if (response && response.success) {
                    // Polling already started above
                    console.log('Sync started successfully');
                } else {
                    var errorMsg = 'Unknown error';
                    if (response && response.data) {
                        if (typeof response.data === 'string') {
                            errorMsg = response.data;
                        } else if (response.data.message) {
                            errorMsg = response.data.message;
                        }
                    }
                    alert('Error starting sync: ' + errorMsg);
                    stopSync();
                }
            },
            error: function(xhr, status, error) {
                console.error('Sync error:', status, error, xhr);
                var errorMsg = error || 'Unknown error';
                if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
                    errorMsg = xhr.responseJSON.data.message;
                }
                alert('Error starting sync: ' + errorMsg);
                stopSync();
            }
        });
    }
    
    /**
     * Stop sync
     */
    function stopSync() {
        syncInProgress = false;
        $('#membersync-start-sync').prop('disabled', false).text('Start Sync');
        
        if (progressInterval) {
            clearInterval(progressInterval);
            progressInterval = null;
        }
        
        if (logsInterval) {
            clearInterval(logsInterval);
            logsInterval = null;
        }
    }
    
    /**
     * Start polling for progress
     */
    function startProgressPolling() {
        if (progressInterval) {
            clearInterval(progressInterval);
        }
        
        progressInterval = setInterval(function() {
            $.ajax({
                url: membersyncAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'membersync_get_progress',
                    nonce: membersyncAdmin.nonce
                },
                success: function(response) {
                    if (response && response.success && response.data) {
                        updateProgress(response.data);
                        
                        // Check if completed or error
                        if (response.data.status === 'completed' || response.data.status === 'error') {
                            stopSync();
                            
                            if (response.data.status === 'error') {
                                alert('Sync failed: ' + (response.data.error_message || 'Unknown error'));
                            } else {
                                alert('Sync completed successfully!');
                            }
                        }
                    } else {
                        console.log('Progress response:', response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching progress:', status, error);
                }
            });
        }, 2000); // Poll every 2 seconds
    }
    
    /**
     * Start polling for logs
     */
    function startLogsPolling() {
        if (logsInterval) {
            clearInterval(logsInterval);
        }
        
        logsInterval = setInterval(function() {
            $.ajax({
                url: membersyncAdmin.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'membersync_get_logs',
                    nonce: membersyncAdmin.nonce
                },
                success: function(response) {
                    if (response && response.success && response.data) {
                        updateLogs(response.data);
                    } else {
                        console.log('Logs response:', response);
                    }
                },
                error: function(xhr, status, error) {
                    console.error('Error fetching logs:', status, error);
                }
            });
        }, 1000); // Poll every second
    }
    
    /**
     * Update progress display
     */
    function updateProgress(progress) {
        var total = progress.subscriptions_total + progress.transactions_total;
        var processed = progress.subscriptions_processed + progress.transactions_processed;
        var percentage = total > 0 ? Math.round((processed / total) * 100) : 0;
        
        $('#membersync-progress-fill').css('width', percentage + '%');
        
        var text = '';
        if (progress.status === 'running') {
            text = 'Processing... ' + processed + ' / ' + total + ' items';
            if (progress.subscriptions_total > 0) {
                text += ' (Subscriptions: ' + progress.subscriptions_processed + ' / ' + progress.subscriptions_total + ')';
            }
            if (progress.transactions_total > 0) {
                text += ' (Transactions: ' + progress.transactions_processed + ' / ' + progress.transactions_total + ')';
            }
        } else if (progress.status === 'completed') {
            text = 'Sync completed!';
        } else if (progress.status === 'error') {
            text = 'Sync failed: ' + (progress.error_message || 'Unknown error');
        }
        
        $('#membersync-progress-text').text(text);
    }
    
    /**
     * Update logs display
     */
    function updateLogs(logs) {
        var $container = $('#membersync-logs-content');
        
        if (!logs || logs.length === 0) {
            // Show waiting message if no logs yet
            if ($container.children().length === 0 || $container.text().indexOf('Initializing') !== -1) {
                $container.html('<div class="membersync-log-entry membersync-log-info"><span class="membersync-log-time">[Waiting...]</span> <span class="membersync-log-message">Waiting for sync to start...</span></div>');
            }
            return;
        }
        
        $container.empty();
        
        // Show last 50 logs
        var recentLogs = logs.slice(-50);
        
        recentLogs.forEach(function(log) {
            if (!log || !log.message) {
                return;
            }
            
            var $log = $('<div class="membersync-log-entry membersync-log-' + (log.level || 'info') + '"></div>');
            $log.append('<span class="membersync-log-time">[' + (log.timestamp || '') + ']</span> ');
            $log.append('<span class="membersync-log-message">' + escapeHtml(log.message) + '</span>');
            $container.append($log);
        });
        
        // Scroll to bottom
        if ($container[0]) {
            $container.scrollTop($container[0].scrollHeight);
        }
    }
    
    /**
     * Escape HTML
     */
    function escapeHtml(text) {
        var map = {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#039;'
        };
        return text.replace(/[&<>"']/g, function(m) { return map[m]; });
    }
    
})(jQuery);

