<?php
/**
 * Alerting system — sends email and/or Slack notifications when
 * thresholds are breached.
 *
 * Integrates with the anomaly detection in WPPI_Monitor.  When an
 * event of severity "critical" or "warning" is logged, this class
 * checks user preferences and dispatches notifications.
 *
 * Cooldown logic prevents notification storms.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Alerting {

    /** @var WPPI_Logger */
    private $logger;

    public function __construct( WPPI_Logger $logger ) {
        $this->logger = $logger;

        // Hook into the event logging flow.
        add_action( 'wppi_event_logged', [ $this, 'maybe_send_alert' ], 10, 3 );
    }

    /* ------------------------------------------------------------------
     * Alert dispatcher
     * ----------------------------------------------------------------*/

    /**
     * Evaluate whether a newly logged event warrants an alert.
     *
     * @param string $type     Event type (cpu, memory, disk, http, frontend).
     * @param string $severity Event severity (critical, warning, error, info).
     * @param string $message  Human-readable event description.
     */
    public function maybe_send_alert( string $type, string $severity, string $message ): void {
        $settings = $this->get_alert_settings();

        // Only alert on configured severities.
        if ( ! in_array( $severity, $settings['severities'], true ) ) {
            return;
        }

        // Cooldown — don't spam.  One alert per type per cooldown period.
        $cooldown_key = 'wppi_alert_cooldown_' . $type . '_' . $severity;
        if ( get_transient( $cooldown_key ) ) {
            return;
        }
        set_transient( $cooldown_key, true, $settings['cooldown_minutes'] * 60 );

        $subject = sprintf(
            '[%s] WP Performance Inspector: %s alert on %s',
            strtoupper( $severity ),
            $type,
            wp_parse_url( get_site_url(), PHP_URL_HOST )
        );

        $body = $this->build_alert_body( $type, $severity, $message );

        // Email.
        if ( $settings['email_enabled'] && ! empty( $settings['email_recipients'] ) ) {
            $this->send_email( $settings['email_recipients'], $subject, $body );
        }

        // Slack.
        if ( $settings['slack_enabled'] && ! empty( $settings['slack_webhook'] ) ) {
            $this->send_slack( $settings['slack_webhook'], $subject, $message, $severity );
        }
    }

    /* ------------------------------------------------------------------
     * Email
     * ----------------------------------------------------------------*/

    private function send_email( array $recipients, string $subject, string $body ): void {
        $headers = [ 'Content-Type: text/html; charset=UTF-8' ];

        wp_mail( $recipients, $subject, $body, $headers );
    }

    /* ------------------------------------------------------------------
     * Slack
     * ----------------------------------------------------------------*/

    private function send_slack( string $webhook_url, string $subject, string $message, string $severity ): void {
        $color_map = [
            'critical' => '#ef4444',
            'warning'  => '#f59e0b',
            'error'    => '#ef4444',
            'info'     => '#3b82f6',
        ];

        $payload = [
            'attachments' => [
                [
                    'fallback'   => $subject . ': ' . $message,
                    'color'      => $color_map[ $severity ] ?? '#6366f1',
                    'title'      => $subject,
                    'text'       => $message,
                    'footer'     => 'WP Performance Inspector Pro',
                    'footer_icon' => '',
                    'ts'         => time(),
                    'fields'     => [
                        [
                            'title' => 'Site',
                            'value' => get_site_url(),
                            'short' => true,
                        ],
                        [
                            'title' => 'Severity',
                            'value' => strtoupper( $severity ),
                            'short' => true,
                        ],
                    ],
                ],
            ],
        ];

        wp_remote_post( $webhook_url, [
            'body'    => wp_json_encode( $payload ),
            'headers' => [ 'Content-Type' => 'application/json' ],
            'timeout' => 10,
        ] );
    }

    /* ------------------------------------------------------------------
     * HTML email body
     * ----------------------------------------------------------------*/

    private function build_alert_body( string $type, string $severity, string $message ): string {
        $bg_map = [
            'critical' => '#fef2f2',
            'warning'  => '#fffbeb',
            'error'    => '#fef2f2',
            'info'     => '#eff6ff',
        ];
        $border_map = [
            'critical' => '#ef4444',
            'warning'  => '#f59e0b',
            'error'    => '#ef4444',
            'info'     => '#3b82f6',
        ];

        $bg     = $bg_map[ $severity ] ?? '#f8fafc';
        $border = $border_map[ $severity ] ?? '#6366f1';
        $site   = esc_html( get_site_url() );
        $time   = esc_html( current_time( 'Y-m-d H:i:s' ) );
        $sev    = esc_html( strtoupper( $severity ) );
        $typE   = esc_html( ucfirst( $type ) );
        $msg    = esc_html( $message );

        return <<<HTML
<!DOCTYPE html>
<html>
<head><meta charset="UTF-8"></head>
<body style="margin:0;padding:0;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,sans-serif;background:#f8fafc;">
<table width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;margin:24px auto;">
<tr><td style="padding:24px;background:#fff;border-radius:12px;box-shadow:0 1px 3px rgba(0,0,0,.1);">

<h2 style="margin:0 0 16px;color:#1e293b;">Performance Inspector Alert</h2>

<div style="padding:16px;border-radius:8px;background:{$bg};border-left:4px solid {$border};margin-bottom:16px;">
  <strong style="font-size:14px;color:#1e293b;">{$sev}: {$typE}</strong>
  <p style="margin:8px 0 0;font-size:14px;color:#334155;">{$msg}</p>
</div>

<table style="width:100%;font-size:13px;color:#64748b;border-collapse:collapse;">
  <tr><td style="padding:6px 0;"><strong>Site:</strong></td><td>{$site}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Time:</strong></td><td>{$time}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Type:</strong></td><td>{$typE}</td></tr>
  <tr><td style="padding:6px 0;"><strong>Severity:</strong></td><td>{$sev}</td></tr>
</table>

<p style="margin:20px 0 0;font-size:12px;color:#94a3b8;">
  This alert was sent by WP Performance Inspector Pro.
  Manage alert settings in Tools &rarr; Performance Inspector &rarr; Settings.
</p>

</td></tr>
</table>
</body>
</html>
HTML;
    }

    /* ------------------------------------------------------------------
     * Settings
     * ----------------------------------------------------------------*/

    public function get_alert_settings(): array {
        return wp_parse_args(
            get_option( 'wppi_alert_settings', [] ),
            [
                'email_enabled'    => false,
                'email_recipients' => [ get_option( 'admin_email' ) ],
                'slack_enabled'    => false,
                'slack_webhook'    => '',
                'severities'       => [ 'critical' ],
                'cooldown_minutes' => 30,
            ]
        );
    }

    /**
     * Save alert settings (called from AJAX or REST).
     */
    public static function save_settings( array $input ): void {
        $sanitized = [
            'email_enabled'    => ! empty( $input['email_enabled'] ),
            'email_recipients' => array_filter( array_map( 'sanitize_email', (array) ( $input['email_recipients'] ?? [] ) ) ),
            'slack_enabled'    => ! empty( $input['slack_enabled'] ),
            'slack_webhook'    => esc_url_raw( $input['slack_webhook'] ?? '' ),
            'severities'       => array_intersect( (array) ( $input['severities'] ?? [] ), [ 'critical', 'warning', 'error', 'info' ] ),
            'cooldown_minutes' => max( 5, absint( $input['cooldown_minutes'] ?? 30 ) ),
        ];

        update_option( 'wppi_alert_settings', $sanitized );
    }
}
