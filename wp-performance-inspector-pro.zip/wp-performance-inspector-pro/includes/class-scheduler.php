<?php
/**
 * Cron scheduler — manages periodic metric collection and data purging.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Scheduler {

    /** @var WPPI_Monitor */
    private $monitor;

    /** @var WPPI_Analyzer */
    private $analyzer;

    public function __construct( WPPI_Monitor $monitor, WPPI_Analyzer $analyzer ) {
        $this->monitor  = $monitor;
        $this->analyzer = $analyzer;

        // Register custom cron intervals.
        add_filter( 'cron_schedules', [ $this, 'add_intervals' ] );

        // Hook the collection action.
        add_action( 'wppi_collect_metrics', [ $this, 'collect' ] );

        // Purge old data once daily.
        add_action( 'wppi_purge_old_data', [ $this, 'purge' ] );

        if ( ! wp_next_scheduled( 'wppi_purge_old_data' ) ) {
            wp_schedule_event( time(), 'daily', 'wppi_purge_old_data' );
        }
    }

    /* ------------------------------------------------------------------
     * Custom intervals
     * ----------------------------------------------------------------*/

    public function add_intervals( array $schedules ): array {
        $schedules['wppi_one_minute'] = [
            'interval' => 60,
            'display'  => __( 'Every Minute', 'wp-performance-inspector-pro' ),
        ];
        $schedules['wppi_five_minutes'] = [
            'interval' => 300,
            'display'  => __( 'Every 5 Minutes', 'wp-performance-inspector-pro' ),
        ];
        $schedules['wppi_fifteen_minutes'] = [
            'interval' => 900,
            'display'  => __( 'Every 15 Minutes', 'wp-performance-inspector-pro' ),
        ];
        $schedules['wppi_thirty_minutes'] = [
            'interval' => 1800,
            'display'  => __( 'Every 30 Minutes', 'wp-performance-inspector-pro' ),
        ];
        return $schedules;
    }

    /* ------------------------------------------------------------------
     * Collect metrics (runs via WP-Cron)
     * ----------------------------------------------------------------*/

    public function collect(): void {
        $this->monitor->collect_all();
    }

    /* ------------------------------------------------------------------
     * Purge old data (runs daily)
     * ----------------------------------------------------------------*/

    public function purge(): void {
        $retention_days = (int) get_option( 'wppi_retention_days', 30 );
        $db = new WPPI_Database();
        $db->purge_old_data( $retention_days );
    }

    /* ------------------------------------------------------------------
     * Schedule management
     * ----------------------------------------------------------------*/

    /**
     * Update the collection frequency.
     */
    public static function update_schedule( string $interval ): void {
        $allowed = [
            'wppi_one_minute',
            'wppi_five_minutes',
            'wppi_fifteen_minutes',
            'wppi_thirty_minutes',
            'hourly',
        ];

        if ( ! in_array( $interval, $allowed, true ) ) {
            return;
        }

        // Remove existing schedule and set new one.
        wp_clear_scheduled_hook( 'wppi_collect_metrics' );
        wp_schedule_event( time(), $interval, 'wppi_collect_metrics' );
        update_option( 'wppi_collection_interval', $interval );
    }
}
