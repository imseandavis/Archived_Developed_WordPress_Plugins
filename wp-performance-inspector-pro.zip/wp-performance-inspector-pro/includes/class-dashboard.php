<?php
/**
 * Admin dashboard — registers the menu page, enqueues assets,
 * and renders the dashboard shell (the heavy lifting is in JS).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Dashboard {

    /** @var WP_Performance_Inspector_Pro */
    private $plugin;

    public function __construct( WP_Performance_Inspector_Pro $plugin ) {
        $this->plugin = $plugin;

        add_action( 'admin_menu', [ $this, 'register_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );

        // AJAX handlers for inline actions.
        add_action( 'wp_ajax_wppi_run_scan', [ $this, 'ajax_run_scan' ] );
        add_action( 'wp_ajax_wppi_export', [ $this, 'ajax_export' ] );
        add_action( 'wp_ajax_wppi_save_settings', [ $this, 'ajax_save_settings' ] );
    }

    /* ------------------------------------------------------------------
     * Menu
     * ----------------------------------------------------------------*/

    public function register_menu(): void {
        add_management_page(
            __( 'Performance Inspector Pro', 'wp-performance-inspector-pro' ),
            __( 'Performance Inspector', 'wp-performance-inspector-pro' ),
            'manage_options',
            'wppi-dashboard',
            [ $this, 'render_page' ]
        );
    }

    /* ------------------------------------------------------------------
     * Assets
     * ----------------------------------------------------------------*/

    public function enqueue_assets( string $hook ): void {
        if ( 'tools_page_wppi-dashboard' !== $hook ) {
            return;
        }

        // Chart.js — local copy, no CDN dependency.
        wp_enqueue_script(
            'chartjs',
            WPPI_PLUGIN_URL . 'assets/js/chart.min.js',
            [],
            '4.4.4',
            true
        );

        // Plugin CSS.
        wp_enqueue_style(
            'wppi-dashboard-css',
            WPPI_PLUGIN_URL . 'assets/css/dashboard.css',
            [],
            WPPI_VERSION
        );

        // Plugin JS.
        wp_enqueue_script(
            'wppi-dashboard-js',
            WPPI_PLUGIN_URL . 'assets/js/dashboard.js',
            [ 'jquery', 'chartjs' ],
            WPPI_VERSION,
            true
        );

        // Pass data to JS — includes SSE nonce for live streaming.
        wp_localize_script( 'wppi-dashboard-js', 'wppiData', [
            'restBase'  => esc_url_raw( rest_url( 'wppi/v1/' ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'ajaxNonce' => wp_create_nonce( 'wppi_ajax' ),
            'sseNonce'  => wp_create_nonce( 'wppi_sse' ),
            'sseEnabled' => (bool) get_option( 'wppi_sse_enabled', true ),
            'i18n'      => [
                'healthy'  => __( 'Healthy', 'wp-performance-inspector-pro' ),
                'warning'  => __( 'Warning', 'wp-performance-inspector-pro' ),
                'critical' => __( 'Critical', 'wp-performance-inspector-pro' ),
            ],
        ] );
    }

    /* ------------------------------------------------------------------
     * Page render
     * ----------------------------------------------------------------*/

    public function render_page(): void {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'wp-performance-inspector-pro' ) );
        }

        $settings = $this->get_settings();
        ?>
        <div class="wrap wppi-wrap">
            <div class="wppi-header">
                <h1 class="wppi-title">
                    <span class="wppi-logo">&#9889;</span>
                    <?php esc_html_e( 'Performance Inspector Pro', 'wp-performance-inspector-pro' ); ?>
                </h1>
                <div class="wppi-header-actions">
                    <button id="wppi-run-scan" class="button button-primary">
                        <?php esc_html_e( 'Run Full Scan', 'wp-performance-inspector-pro' ); ?>
                    </button>
                    <button id="wppi-export-json" class="button" data-format="json">
                        <?php esc_html_e( 'Export JSON', 'wp-performance-inspector-pro' ); ?>
                    </button>
                    <button id="wppi-export-csv" class="button" data-format="csv">
                        <?php esc_html_e( 'Export CSV', 'wp-performance-inspector-pro' ); ?>
                    </button>
                </div>
            </div>

            <!-- Tab navigation -->
            <nav class="wppi-tabs">
                <a href="#" class="wppi-tab active" data-tab="overview"><?php esc_html_e( 'Overview', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="system"><?php esc_html_e( 'System Resources', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="wordpress"><?php esc_html_e( 'WordPress', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="network"><?php esc_html_e( 'Network', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="frontend"><?php esc_html_e( 'Frontend RUM', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="queries"><?php esc_html_e( 'DB Queries', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="events"><?php esc_html_e( 'Events', 'wp-performance-inspector-pro' ); ?></a>
                <a href="#" class="wppi-tab" data-tab="settings"><?php esc_html_e( 'Settings', 'wp-performance-inspector-pro' ); ?></a>
            </nav>

            <!-- Tab panels -->
            <div class="wppi-panels">

                <!-- OVERVIEW -->
                <div class="wppi-panel active" id="wppi-panel-overview">
                    <!-- Score card -->
                    <div class="wppi-score-card">
                        <div class="wppi-score-ring" id="wppi-score-ring">
                            <svg viewBox="0 0 120 120">
                                <circle class="wppi-score-bg" cx="60" cy="60" r="54" />
                                <circle class="wppi-score-fg" id="wppi-score-circle" cx="60" cy="60" r="54" />
                            </svg>
                            <div class="wppi-score-value" id="wppi-score-value">--</div>
                        </div>
                        <div class="wppi-score-label"><?php esc_html_e( 'Performance Score', 'wp-performance-inspector-pro' ); ?></div>
                    </div>

                    <!-- Live gauges row -->
                    <div class="wppi-gauges-row">
                        <div class="wppi-gauge-card" id="wppi-gauge-cpu">
                            <h3><?php esc_html_e( 'CPU', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-cpu-fill"></div></div>
                            <span class="wppi-gauge-val" id="wppi-cpu-val">--</span>
                        </div>
                        <div class="wppi-gauge-card" id="wppi-gauge-memory">
                            <h3><?php esc_html_e( 'Memory', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-mem-fill"></div></div>
                            <span class="wppi-gauge-val" id="wppi-mem-val">--</span>
                        </div>
                        <div class="wppi-gauge-card" id="wppi-gauge-disk">
                            <h3><?php esc_html_e( 'Disk', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-disk-fill"></div></div>
                            <span class="wppi-gauge-val" id="wppi-disk-val">--</span>
                        </div>
                        <div class="wppi-gauge-card" id="wppi-gauge-http">
                            <h3><?php esc_html_e( 'HTTP Requests', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-http-fill"></div></div>
                            <span class="wppi-gauge-val" id="wppi-http-val">--</span>
                        </div>
                    </div>

                    <!-- Charts row -->
                    <div class="wppi-charts-row">
                        <div class="wppi-chart-card">
                            <h3><?php esc_html_e( 'CPU Usage Over Time', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-chart-wrap"><canvas id="wppi-chart-cpu"></canvas></div>
                        </div>
                        <div class="wppi-chart-card">
                            <h3><?php esc_html_e( 'Memory Usage Over Time', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-chart-wrap"><canvas id="wppi-chart-memory"></canvas></div>
                        </div>
                    </div>

                    <!-- Issues summary -->
                    <div class="wppi-issues-card">
                        <h3><?php esc_html_e( 'Top Issues', 'wp-performance-inspector-pro' ); ?></h3>
                        <div id="wppi-issues-list" class="wppi-issues-list">
                            <p class="wppi-muted"><?php esc_html_e( 'Run a scan to discover issues.', 'wp-performance-inspector-pro' ); ?></p>
                        </div>
                    </div>
                </div>

                <!-- SYSTEM RESOURCES -->
                <div class="wppi-panel" id="wppi-panel-system">
                    <div class="wppi-grid-2">
                        <div class="wppi-card" id="wppi-sys-cpu">
                            <h3><?php esc_html_e( 'CPU Details', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-sys-cpu-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card" id="wppi-sys-memory">
                            <h3><?php esc_html_e( 'Memory Details', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-sys-mem-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card" id="wppi-sys-disk">
                            <h3><?php esc_html_e( 'Disk Details', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-sys-disk-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card" id="wppi-sys-php">
                            <h3><?php esc_html_e( 'PHP Environment', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-sys-php-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                    </div>
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'System Capabilities', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body" id="wppi-capabilities-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                    </div>
                </div>

                <!-- WORDPRESS -->
                <div class="wppi-panel" id="wppi-panel-wordpress">
                    <div class="wppi-grid-2">
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'WordPress Core', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-core-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'Database', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-db-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'Plugins', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-plugins-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'Caching', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-cache-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'Themes', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-themes-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                        <div class="wppi-card">
                            <h3><?php esc_html_e( 'Security', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-card-body" id="wppi-wp-security-body"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                        </div>
                    </div>
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'All Recommendations', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body" id="wppi-wp-recommendations"><p class="wppi-muted"><?php esc_html_e( 'Run a scan first.', 'wp-performance-inspector-pro' ); ?></p></div>
                    </div>
                </div>

                <!-- NETWORK -->
                <div class="wppi-panel" id="wppi-panel-network">
                    <div class="wppi-gauges-row">
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Total Requests', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-net-total">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg Response', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-net-avg">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Failed', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number wppi-text-danger" id="wppi-net-failed">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Slow Requests', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number wppi-text-warning" id="wppi-net-slow">--</span>
                        </div>
                    </div>

                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Top Domains', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body" id="wppi-net-domains"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                    </div>

                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Recent HTTP Requests', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body wppi-table-wrap" id="wppi-net-log"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                    </div>

                    <div class="wppi-charts-row">
                        <div class="wppi-chart-card">
                            <h3><?php esc_html_e( 'Response Time Trend', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-chart-wrap"><canvas id="wppi-chart-http"></canvas></div>
                        </div>
                    </div>
                </div>

                <!-- FRONTEND RUM -->
                <div class="wppi-panel" id="wppi-panel-frontend">
                    <div class="wppi-gauges-row">
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg Page Load', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-load">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg TTFB', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-ttfb">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg FCP', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-fcp">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg LCP', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-lcp">--</span>
                        </div>
                    </div>
                    <div class="wppi-gauges-row">
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg CLS', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-cls">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg FID', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-fid">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Samples', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-rum-samples">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Slow Pages', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number wppi-text-warning" id="wppi-rum-slow">--</span>
                        </div>
                    </div>
                    <div class="wppi-charts-row">
                        <div class="wppi-chart-card">
                            <h3><?php esc_html_e( 'Page Load Time Trend', 'wp-performance-inspector-pro' ); ?></h3>
                            <div class="wppi-chart-wrap"><canvas id="wppi-chart-rum"></canvas></div>
                        </div>
                    </div>
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Recent Page Loads', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body wppi-table-wrap" id="wppi-rum-table">
                            <p class="wppi-muted"><?php esc_html_e( 'Beacon data appears as visitors browse your site.', 'wp-performance-inspector-pro' ); ?></p>
                        </div>
                    </div>
                </div>

                <!-- DB QUERIES -->
                <div class="wppi-panel" id="wppi-panel-queries">
                    <div class="wppi-gauges-row">
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg Queries/Request', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-db-avg-count">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg Total Time', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-db-avg-time">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Avg Per Query', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number" id="wppi-db-avg-per">--</span>
                        </div>
                        <div class="wppi-gauge-card">
                            <h3><?php esc_html_e( 'Total Slow Queries', 'wp-performance-inspector-pro' ); ?></h3>
                            <span class="wppi-big-number wppi-text-warning" id="wppi-db-slow-total">--</span>
                        </div>
                    </div>
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Recent Slow Queries', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body wppi-table-wrap" id="wppi-db-slow-table">
                            <?php if ( get_option( 'wppi_query_monitor_enabled', false ) ) : ?>
                                <p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p>
                            <?php else : ?>
                                <p class="wppi-muted"><?php esc_html_e( 'Query Monitor is disabled. Enable it in Settings to track slow queries.', 'wp-performance-inspector-pro' ); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>

                <!-- EVENTS -->
                <div class="wppi-panel" id="wppi-panel-events">
                    <div class="wppi-card">
                        <div class="wppi-card-header-row">
                            <h3><?php esc_html_e( 'Event Log', 'wp-performance-inspector-pro' ); ?></h3>
                            <select id="wppi-events-filter" class="wppi-select">
                                <option value=""><?php esc_html_e( 'All Severities', 'wp-performance-inspector-pro' ); ?></option>
                                <option value="critical"><?php esc_html_e( 'Critical', 'wp-performance-inspector-pro' ); ?></option>
                                <option value="warning"><?php esc_html_e( 'Warning', 'wp-performance-inspector-pro' ); ?></option>
                                <option value="error"><?php esc_html_e( 'Error', 'wp-performance-inspector-pro' ); ?></option>
                                <option value="info"><?php esc_html_e( 'Info', 'wp-performance-inspector-pro' ); ?></option>
                            </select>
                        </div>
                        <div class="wppi-card-body wppi-table-wrap" id="wppi-events-body"><p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p></div>
                    </div>
                </div>

                <!-- SETTINGS -->
                <div class="wppi-panel" id="wppi-panel-settings">
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Collection Settings', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body">
                            <table class="form-table wppi-settings-table">
                                <tr>
                                    <th><?php esc_html_e( 'Collection Interval', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <select id="wppi-setting-interval" class="wppi-select">
                                            <option value="wppi_one_minute" <?php selected( $settings['interval'], 'wppi_one_minute' ); ?>><?php esc_html_e( 'Every Minute', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="wppi_five_minutes" <?php selected( $settings['interval'], 'wppi_five_minutes' ); ?>><?php esc_html_e( 'Every 5 Minutes', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="wppi_fifteen_minutes" <?php selected( $settings['interval'], 'wppi_fifteen_minutes' ); ?>><?php esc_html_e( 'Every 15 Minutes', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="wppi_thirty_minutes" <?php selected( $settings['interval'], 'wppi_thirty_minutes' ); ?>><?php esc_html_e( 'Every 30 Minutes', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="hourly" <?php selected( $settings['interval'], 'hourly' ); ?>><?php esc_html_e( 'Hourly', 'wp-performance-inspector-pro' ); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Data Retention', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <select id="wppi-setting-retention" class="wppi-select">
                                            <option value="7" <?php selected( $settings['retention'], 7 ); ?>><?php esc_html_e( '7 Days', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="14" <?php selected( $settings['retention'], 14 ); ?>><?php esc_html_e( '14 Days', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="30" <?php selected( $settings['retention'], 30 ); ?>><?php esc_html_e( '30 Days', 'wp-performance-inspector-pro' ); ?></option>
                                            <option value="90" <?php selected( $settings['retention'], 90 ); ?>><?php esc_html_e( '90 Days', 'wp-performance-inspector-pro' ); ?></option>
                                        </select>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Slow HTTP Threshold (seconds)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="number" id="wppi-setting-slow-http" class="small-text" value="<?php echo esc_attr( $settings['slow_http'] ); ?>" min="0.5" max="30" step="0.5" />
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Alert Thresholds', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label>CPU Warning: <input type="number" id="wppi-thresh-cpu-warn" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['cpu_warn'] ); ?>" min="1" max="100" />%</label><br>
                                        <label>CPU Critical: <input type="number" id="wppi-thresh-cpu-crit" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['cpu_crit'] ); ?>" min="1" max="100" />%</label><br>
                                        <label>Memory Warning: <input type="number" id="wppi-thresh-mem-warn" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['mem_warn'] ); ?>" min="1" max="100" />%</label><br>
                                        <label>Memory Critical: <input type="number" id="wppi-thresh-mem-crit" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['mem_crit'] ); ?>" min="1" max="100" />%</label><br>
                                        <label>Disk Warning: <input type="number" id="wppi-thresh-disk-warn" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['disk_warn'] ); ?>" min="1" max="100" />%</label><br>
                                        <label>Disk Critical: <input type="number" id="wppi-thresh-disk-crit" class="small-text" value="<?php echo esc_attr( $settings['thresholds']['disk_crit'] ); ?>" min="1" max="100" />%</label>
                                    </td>
                                </tr>
                            </table>
                            <p>
                                <button id="wppi-save-settings" class="button button-primary"><?php esc_html_e( 'Save Settings', 'wp-performance-inspector-pro' ); ?></button>
                                <span id="wppi-settings-status" class="wppi-muted"></span>
                            </p>
                        </div>
                    </div>

                    <!-- Feature Toggles -->
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Feature Toggles', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body">
                            <table class="form-table wppi-settings-table">
                                <tr>
                                    <th><?php esc_html_e( 'Frontend Beacon (RUM)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" id="wppi-setting-beacon" <?php checked( get_option( 'wppi_beacon_enabled', true ) ); ?> /> <?php esc_html_e( 'Inject performance beacon on frontend pages', 'wp-performance-inspector-pro' ); ?></label>
                                        <p class="description"><?php esc_html_e( 'Collects real-user metrics (TTFB, FCP, LCP, CLS, FID) via the Performance API.', 'wp-performance-inspector-pro' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Slow Page Threshold (ms)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="number" id="wppi-setting-slow-page" class="small-text" value="<?php echo esc_attr( get_option( 'wppi_slow_page_threshold', 3000 ) ); ?>" min="500" max="30000" step="100" />
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Query Monitor', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" id="wppi-setting-query-monitor" <?php checked( get_option( 'wppi_query_monitor_enabled', false ) ); ?> /> <?php esc_html_e( 'Track and log slow database queries', 'wp-performance-inspector-pro' ); ?></label>
                                        <p class="description"><?php esc_html_e( 'Adds a small overhead per query. Recommended for debugging, not permanent production use.', 'wp-performance-inspector-pro' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Slow Query Threshold (seconds)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="number" id="wppi-setting-slow-query" class="small-text" value="<?php echo esc_attr( get_option( 'wppi_slow_query_threshold', 0.05 ) ); ?>" min="0.01" max="5" step="0.01" />
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Real-Time SSE Updates', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" id="wppi-setting-sse" <?php checked( get_option( 'wppi_sse_enabled', true ) ); ?> /> <?php esc_html_e( 'Enable Server-Sent Events for live dashboard updates', 'wp-performance-inspector-pro' ); ?></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'SSE Push Interval (seconds)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="number" id="wppi-setting-sse-interval" class="small-text" value="<?php echo esc_attr( get_option( 'wppi_sse_interval', 10 ) ); ?>" min="5" max="60" step="1" />
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>

                    <!-- Alert Settings -->
                    <?php $alert_settings = ( new WPPI_Alerting( wppi()->logger ) )->get_alert_settings(); ?>
                    <div class="wppi-card">
                        <h3><?php esc_html_e( 'Alert Notifications', 'wp-performance-inspector-pro' ); ?></h3>
                        <div class="wppi-card-body">
                            <table class="form-table wppi-settings-table">
                                <tr>
                                    <th><?php esc_html_e( 'Email Alerts', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" id="wppi-alert-email-enabled" <?php checked( $alert_settings['email_enabled'] ); ?> /> <?php esc_html_e( 'Send email alerts when thresholds are breached', 'wp-performance-inspector-pro' ); ?></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Email Recipients', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="text" id="wppi-alert-email-recipients" class="regular-text" value="<?php echo esc_attr( implode( ', ', $alert_settings['email_recipients'] ) ); ?>" />
                                        <p class="description"><?php esc_html_e( 'Comma-separated email addresses.', 'wp-performance-inspector-pro' ); ?></p>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Slack Alerts', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" id="wppi-alert-slack-enabled" <?php checked( $alert_settings['slack_enabled'] ); ?> /> <?php esc_html_e( 'Send Slack notifications', 'wp-performance-inspector-pro' ); ?></label>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Slack Webhook URL', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="url" id="wppi-alert-slack-webhook" class="regular-text" value="<?php echo esc_attr( $alert_settings['slack_webhook'] ); ?>" placeholder="https://hooks.slack.com/services/..." />
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Alert Severities', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <label><input type="checkbox" class="wppi-alert-severity" value="critical" <?php checked( in_array( 'critical', $alert_settings['severities'], true ) ); ?> /> Critical</label>
                                        <label><input type="checkbox" class="wppi-alert-severity" value="warning" <?php checked( in_array( 'warning', $alert_settings['severities'], true ) ); ?> /> Warning</label>
                                        <label><input type="checkbox" class="wppi-alert-severity" value="error" <?php checked( in_array( 'error', $alert_settings['severities'], true ) ); ?> /> Error</label>
                                        <label><input type="checkbox" class="wppi-alert-severity" value="info" <?php checked( in_array( 'info', $alert_settings['severities'], true ) ); ?> /> Info</label>
                                    </td>
                                </tr>
                                <tr>
                                    <th><?php esc_html_e( 'Cooldown (minutes)', 'wp-performance-inspector-pro' ); ?></th>
                                    <td>
                                        <input type="number" id="wppi-alert-cooldown" class="small-text" value="<?php echo esc_attr( $alert_settings['cooldown_minutes'] ); ?>" min="5" max="1440" />
                                        <p class="description"><?php esc_html_e( 'Minimum minutes between repeated alerts of the same type.', 'wp-performance-inspector-pro' ); ?></p>
                                    </td>
                                </tr>
                            </table>
                        </div>
                    </div>
                </div>

            </div><!-- .wppi-panels -->

            <!-- Loading overlay -->
            <div id="wppi-loading" class="wppi-loading" style="display:none;">
                <div class="wppi-spinner"></div>
                <p><?php esc_html_e( 'Collecting metrics...', 'wp-performance-inspector-pro' ); ?></p>
            </div>
        </div><!-- .wppi-wrap -->
        <?php
    }

    /* ------------------------------------------------------------------
     * AJAX: Run scan
     * ----------------------------------------------------------------*/

    public function ajax_run_scan(): void {
        check_ajax_referer( 'wppi_ajax', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $monitor_data  = $this->plugin->monitor->collect_all();
        $analysis_data = $this->plugin->analyzer->run_full_analysis();

        wp_send_json_success( [
            'system'   => $monitor_data,
            'analysis' => $analysis_data,
        ] );
    }

    /* ------------------------------------------------------------------
     * AJAX: Export
     * ----------------------------------------------------------------*/

    public function ajax_export(): void {
        check_ajax_referer( 'wppi_ajax', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $format = sanitize_text_field( $_POST['format'] ?? 'json' );

        $exporter = $this->plugin->exporter;
        $data     = $exporter->generate_report();

        if ( 'csv' === $format ) {
            wp_send_json_success( [
                'format'   => 'csv',
                'filename' => 'wppi-report-' . gmdate( 'Y-m-d-His' ) . '.csv',
                'content'  => $exporter->to_csv( $data ),
            ] );
        }

        wp_send_json_success( [
            'format'   => 'json',
            'filename' => 'wppi-report-' . gmdate( 'Y-m-d-His' ) . '.json',
            'content'  => wp_json_encode( $data, JSON_PRETTY_PRINT ),
        ] );
    }

    /* ------------------------------------------------------------------
     * AJAX: Save settings
     * ----------------------------------------------------------------*/

    public function ajax_save_settings(): void {
        check_ajax_referer( 'wppi_ajax', 'nonce' );

        if ( ! current_user_can( 'manage_options' ) ) {
            wp_send_json_error( 'Unauthorized', 403 );
        }

        $interval  = sanitize_text_field( $_POST['interval'] ?? 'wppi_five_minutes' );
        $retention = absint( $_POST['retention'] ?? 30 );
        $slow_http = floatval( $_POST['slow_http'] ?? 3.0 );

        $thresholds = [
            'cpu_warn'  => absint( $_POST['cpu_warn'] ?? 70 ),
            'cpu_crit'  => absint( $_POST['cpu_crit'] ?? 90 ),
            'mem_warn'  => absint( $_POST['mem_warn'] ?? 80 ),
            'mem_crit'  => absint( $_POST['mem_crit'] ?? 95 ),
            'disk_warn' => absint( $_POST['disk_warn'] ?? 80 ),
            'disk_crit' => absint( $_POST['disk_crit'] ?? 95 ),
        ];

        WPPI_Scheduler::update_schedule( $interval );
        update_option( 'wppi_retention_days', $retention );
        update_option( 'wppi_slow_http_threshold', $slow_http );
        update_option( 'wppi_thresholds', $thresholds );

        // Feature toggles.
        update_option( 'wppi_beacon_enabled', ! empty( $_POST['beacon_enabled'] ) );
        update_option( 'wppi_slow_page_threshold', floatval( $_POST['slow_page_threshold'] ?? 3000 ) );
        update_option( 'wppi_query_monitor_enabled', ! empty( $_POST['query_monitor_enabled'] ) );
        update_option( 'wppi_slow_query_threshold', floatval( $_POST['slow_query_threshold'] ?? 0.05 ) );
        update_option( 'wppi_sse_enabled', ! empty( $_POST['sse_enabled'] ) );
        update_option( 'wppi_sse_interval', max( 5, absint( $_POST['sse_interval'] ?? 10 ) ) );

        // Alert settings.
        $recipients_raw = sanitize_text_field( $_POST['alert_email_recipients'] ?? '' );
        $recipients     = array_filter( array_map( 'trim', explode( ',', $recipients_raw ) ) );

        $severities = [];
        if ( ! empty( $_POST['alert_severities'] ) && is_array( $_POST['alert_severities'] ) ) {
            $sanitized_sevs = array_map( 'sanitize_text_field', $_POST['alert_severities'] );
            $severities     = array_values( array_intersect( $sanitized_sevs, [ 'critical', 'warning', 'error', 'info' ] ) );
        }

        WPPI_Alerting::save_settings( [
            'email_enabled'    => ! empty( $_POST['alert_email_enabled'] ),
            'email_recipients' => $recipients,
            'slack_enabled'    => ! empty( $_POST['alert_slack_enabled'] ),
            'slack_webhook'    => esc_url_raw( $_POST['alert_slack_webhook'] ?? '' ),
            'severities'       => $severities,
            'cooldown_minutes' => absint( $_POST['alert_cooldown'] ?? 30 ),
        ] );

        wp_send_json_success( 'Settings saved.' );
    }

    /* ------------------------------------------------------------------
     * Helpers
     * ----------------------------------------------------------------*/

    private function get_settings(): array {
        $thresholds = get_option( 'wppi_thresholds', [
            'cpu_warn'  => 70,
            'cpu_crit'  => 90,
            'mem_warn'  => 80,
            'mem_crit'  => 95,
            'disk_warn' => 80,
            'disk_crit' => 95,
        ] );

        return [
            'interval'   => get_option( 'wppi_collection_interval', 'wppi_five_minutes' ),
            'retention'  => (int) get_option( 'wppi_retention_days', 30 ),
            'slow_http'  => (float) get_option( 'wppi_slow_http_threshold', 3.0 ),
            'thresholds' => $thresholds,
        ];
    }
}
