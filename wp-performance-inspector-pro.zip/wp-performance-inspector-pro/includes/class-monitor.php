<?php
/**
 * System resource monitor — collects CPU, RAM, disk, and network metrics.
 *
 * Every method is wrapped in a try/catch so that restricted hosting
 * environments never cause a fatal error.  When a metric is unavailable
 * the method returns null or a sensible fallback.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Monitor {

    /** @var WPPI_Logger */
    private $logger;

    /** @var array Cached capability flags so we only probe once per request. */
    private $capabilities = [];

    public function __construct( WPPI_Logger $logger ) {
        $this->logger = $logger;
    }

    /* ==================================================================
     * PUBLIC: Collect all system metrics at once
     * ================================================================*/

    /**
     * Run a full collection cycle and persist to the database.
     *
     * Called by WP-Cron (see WPPI_Scheduler) or manually from the dashboard.
     */
    public function collect_all(): array {
        $snapshot = [
            'cpu'    => $this->get_cpu_metrics(),
            'memory' => $this->get_memory_metrics(),
            'disk'   => $this->get_disk_metrics(),
            'php'    => $this->get_php_metrics(),
        ];

        // Persist each metric group.
        foreach ( $snapshot as $type => $data ) {
            if ( empty( $data ) ) {
                continue;
            }
            foreach ( $data as $key => $value ) {
                if ( is_array( $value ) ) {
                    $this->logger->log_metric( $type, $key, 0, $value );
                } else {
                    $this->logger->log_metric( $type, $key, (float) $value );
                }
            }
        }

        // Detect anomalies and fire events.
        $this->detect_anomalies( $snapshot );

        return $snapshot;
    }

    /**
     * Get a live snapshot (no persistence).
     */
    public function get_live_snapshot(): array {
        return [
            'cpu'    => $this->get_cpu_metrics(),
            'memory' => $this->get_memory_metrics(),
            'disk'   => $this->get_disk_metrics(),
            'php'    => $this->get_php_metrics(),
            'server' => $this->get_server_info(),
        ];
    }

    /* ==================================================================
     * CPU
     * ================================================================*/

    public function get_cpu_metrics(): array {
        $metrics = [];

        // Load averages (Linux / macOS).
        if ( function_exists( 'sys_getloadavg' ) ) {
            $load = @sys_getloadavg();
            if ( false !== $load ) {
                $metrics['load_1']  = round( $load[0], 2 );
                $metrics['load_5']  = round( $load[1], 2 );
                $metrics['load_15'] = round( $load[2], 2 );
            }
        }

        // Try to get CPU usage % via /proc/stat (Linux).
        $cpu_pct = $this->read_cpu_usage_linux();
        if ( null !== $cpu_pct ) {
            $metrics['cpu_usage_pct'] = $cpu_pct;
        }

        // Number of CPU cores — needed to interpret load averages.
        $cores = $this->get_cpu_core_count();
        if ( $cores ) {
            $metrics['cpu_cores'] = $cores;
        }

        // Normalised load (load / cores * 100).
        if ( isset( $metrics['load_1'], $metrics['cpu_cores'] ) && $metrics['cpu_cores'] > 0 ) {
            $metrics['normalized_load'] = round( ( $metrics['load_1'] / $metrics['cpu_cores'] ) * 100, 1 );
        }

        return $metrics;
    }

    /* ==================================================================
     * MEMORY / RAM
     * ================================================================*/

    public function get_memory_metrics(): array {
        $metrics = [];

        // PHP process memory.
        $metrics['php_memory_used']   = memory_get_usage( true );
        $metrics['php_memory_peak']   = memory_get_peak_usage( true );
        $metrics['php_memory_limit']  = $this->parse_php_size( ini_get( 'memory_limit' ) );
        $metrics['php_memory_pct']    = ( $metrics['php_memory_limit'] > 0 )
            ? round( ( $metrics['php_memory_used'] / $metrics['php_memory_limit'] ) * 100, 1 )
            : 0;

        // System memory via /proc/meminfo (Linux).
        $sys = $this->read_meminfo();
        if ( $sys ) {
            $metrics['system_total']     = $sys['total'];
            $metrics['system_used']      = $sys['used'];
            $metrics['system_free']      = $sys['free'];
            $metrics['system_available'] = $sys['available'];
            $metrics['system_pct']       = $sys['pct'];
            $metrics['swap_total']       = $sys['swap_total'];
            $metrics['swap_used']        = $sys['swap_used'];
        }

        return $metrics;
    }

    /* ==================================================================
     * DISK
     * ================================================================*/

    public function get_disk_metrics(): array {
        $metrics = [];

        $path = ABSPATH;

        if ( function_exists( 'disk_free_space' ) ) {
            $free = @disk_free_space( $path );
            if ( false !== $free ) {
                $metrics['disk_free'] = (float) $free;
            }
        }

        if ( function_exists( 'disk_total_space' ) ) {
            $total = @disk_total_space( $path );
            if ( false !== $total ) {
                $metrics['disk_total'] = (float) $total;
                $metrics['disk_used']  = $total - ( $metrics['disk_free'] ?? 0 );
                $metrics['disk_pct']   = ( $total > 0 )
                    ? round( ( $metrics['disk_used'] / $total ) * 100, 1 )
                    : 0;
            }
        }

        // WordPress-specific directory sizes.
        $metrics['uploads_size'] = $this->directory_size( wp_upload_dir()['basedir'] );
        $metrics['plugins_size'] = $this->directory_size( WP_PLUGIN_DIR );
        $metrics['themes_size']  = $this->directory_size( get_theme_root() );

        // Disk I/O from /proc/diskstats (Linux, best effort).
        $io = $this->read_disk_io();
        if ( $io ) {
            $metrics['disk_reads']  = $io['reads'];
            $metrics['disk_writes'] = $io['writes'];
        }

        return $metrics;
    }

    /* ==================================================================
     * PHP Runtime
     * ================================================================*/

    public function get_php_metrics(): array {
        return [
            'php_version'        => PHP_VERSION,
            'php_sapi'           => PHP_SAPI,
            'max_execution_time' => (int) ini_get( 'max_execution_time' ),
            'upload_max'         => $this->parse_php_size( ini_get( 'upload_max_filesize' ) ),
            'post_max'           => $this->parse_php_size( ini_get( 'post_max_size' ) ),
            'opcache_enabled'    => function_exists( 'opcache_get_status' ) && ! empty( @opcache_get_status( false )['opcache_enabled'] ),
            'extensions'         => get_loaded_extensions(),
        ];
    }

    /* ==================================================================
     * Server Environment
     * ================================================================*/

    public function get_server_info(): array {
        return [
            'software'   => sanitize_text_field( $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown' ),
            'hostname'   => php_uname( 'n' ),
            'os'         => php_uname( 's' ) . ' ' . php_uname( 'r' ),
            'arch'       => php_uname( 'm' ),
            'php_sapi'   => PHP_SAPI,
            'is_64bit'   => PHP_INT_SIZE === 8,
        ];
    }

    /* ==================================================================
     * Capability detection
     * ================================================================*/

    /**
     * Report which monitoring features are available on this host.
     */
    public function get_capabilities(): array {
        if ( ! empty( $this->capabilities ) ) {
            return $this->capabilities;
        }

        $this->capabilities = [
            'load_avg'        => function_exists( 'sys_getloadavg' ),
            'disk_space'      => function_exists( 'disk_free_space' ),
            'proc_stat'       => is_readable( '/proc/stat' ),
            'proc_meminfo'    => is_readable( '/proc/meminfo' ),
            'proc_diskstats'  => is_readable( '/proc/diskstats' ),
            'shell_exec'      => $this->can_shell_exec(),
            'opcache'         => function_exists( 'opcache_get_status' ),
        ];

        return $this->capabilities;
    }

    /* ==================================================================
     * ANOMALY DETECTION
     * ================================================================*/

    private function detect_anomalies( array $snapshot ): void {
        $thresholds = get_option( 'wppi_thresholds', [
            'cpu_warn'    => 70,
            'cpu_crit'    => 90,
            'mem_warn'    => 80,
            'mem_crit'    => 95,
            'disk_warn'   => 80,
            'disk_crit'   => 95,
        ] );

        // CPU.
        $cpu_val = $snapshot['cpu']['normalized_load'] ?? $snapshot['cpu']['cpu_usage_pct'] ?? null;
        if ( null !== $cpu_val ) {
            if ( $cpu_val >= $thresholds['cpu_crit'] ) {
                $this->logger->log_event( 'cpu', 'critical', sprintf( 'CPU usage is critically high: %.1f%%', $cpu_val ) );
            } elseif ( $cpu_val >= $thresholds['cpu_warn'] ) {
                $this->logger->log_event( 'cpu', 'warning', sprintf( 'CPU usage is elevated: %.1f%%', $cpu_val ) );
            }
        }

        // Memory.
        $mem_pct = $snapshot['memory']['system_pct'] ?? $snapshot['memory']['php_memory_pct'] ?? null;
        if ( null !== $mem_pct ) {
            if ( $mem_pct >= $thresholds['mem_crit'] ) {
                $this->logger->log_event( 'memory', 'critical', sprintf( 'Memory usage is critically high: %.1f%%', $mem_pct ) );
            } elseif ( $mem_pct >= $thresholds['mem_warn'] ) {
                $this->logger->log_event( 'memory', 'warning', sprintf( 'Memory usage is elevated: %.1f%%', $mem_pct ) );
            }
        }

        // Disk.
        $disk_pct = $snapshot['disk']['disk_pct'] ?? null;
        if ( null !== $disk_pct ) {
            if ( $disk_pct >= $thresholds['disk_crit'] ) {
                $this->logger->log_event( 'disk', 'critical', sprintf( 'Disk usage is critically high: %.1f%%', $disk_pct ) );
            } elseif ( $disk_pct >= $thresholds['disk_warn'] ) {
                $this->logger->log_event( 'disk', 'warning', sprintf( 'Disk usage is elevated: %.1f%%', $disk_pct ) );
            }
        }
    }

    /* ==================================================================
     * INTERNAL HELPERS
     * ================================================================*/

    /**
     * Attempt to read current CPU usage from /proc/stat.
     * Returns a usage percentage or null.
     */
    private function read_cpu_usage_linux(): ?float {
        if ( ! is_readable( '/proc/stat' ) ) {
            return null;
        }

        $stat1 = @file_get_contents( '/proc/stat' );
        if ( ! $stat1 ) {
            return null;
        }

        // We need two readings to compute a delta.  Sleep 200 ms.
        usleep( 200000 );

        $stat2 = @file_get_contents( '/proc/stat' );
        if ( ! $stat2 ) {
            return null;
        }

        $parse = static function ( string $raw ): ?array {
            if ( preg_match( '/^cpu\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)\s+(\d+)/m', $raw, $m ) ) {
                $total = array_sum( array_slice( $m, 1 ) );
                $idle  = (int) $m[4];
                return [ 'total' => $total, 'idle' => $idle ];
            }
            return null;
        };

        $a = $parse( $stat1 );
        $b = $parse( $stat2 );

        if ( ! $a || ! $b ) {
            return null;
        }

        $total_diff = $b['total'] - $a['total'];
        $idle_diff  = $b['idle']  - $a['idle'];

        if ( $total_diff <= 0 ) {
            return null;
        }

        return round( ( 1 - ( $idle_diff / $total_diff ) ) * 100, 1 );
    }

    /**
     * Parse /proc/meminfo into an associative array.
     */
    private function read_meminfo(): ?array {
        if ( ! is_readable( '/proc/meminfo' ) ) {
            return null;
        }

        $raw = @file_get_contents( '/proc/meminfo' );
        if ( ! $raw ) {
            return null;
        }

        $values = [];
        if ( preg_match_all( '/^(\w+):\s+(\d+)\s+kB$/m', $raw, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $m ) {
                $values[ $m[1] ] = (int) $m[2] * 1024; // Convert kB → bytes.
            }
        }

        if ( empty( $values['MemTotal'] ) ) {
            return null;
        }

        $total     = $values['MemTotal'];
        $free      = $values['MemFree'] ?? 0;
        $available = $values['MemAvailable'] ?? $free;
        $used      = $total - $available;

        return [
            'total'      => $total,
            'used'       => $used,
            'free'       => $free,
            'available'  => $available,
            'pct'        => round( ( $used / $total ) * 100, 1 ),
            'swap_total' => $values['SwapTotal'] ?? 0,
            'swap_used'  => ( $values['SwapTotal'] ?? 0 ) - ( $values['SwapFree'] ?? 0 ),
        ];
    }

    /**
     * Best-effort disk I/O from /proc/diskstats.
     */
    private function read_disk_io(): ?array {
        if ( ! is_readable( '/proc/diskstats' ) ) {
            return null;
        }

        $raw = @file_get_contents( '/proc/diskstats' );
        if ( ! $raw ) {
            return null;
        }

        $reads  = 0;
        $writes = 0;
        foreach ( explode( "\n", $raw ) as $line ) {
            $parts = preg_split( '/\s+/', trim( $line ) );
            if ( count( $parts ) >= 14 ) {
                // Column indices: 3 = reads completed, 7 = writes completed.
                $reads  += (int) ( $parts[3] ?? 0 );
                $writes += (int) ( $parts[7] ?? 0 );
            }
        }

        return [ 'reads' => $reads, 'writes' => $writes ];
    }

    /**
     * Count CPU cores.
     */
    private function get_cpu_core_count(): int {
        // /proc/cpuinfo (Linux).
        if ( is_readable( '/proc/cpuinfo' ) ) {
            $cpuinfo = @file_get_contents( '/proc/cpuinfo' );
            if ( $cpuinfo ) {
                return max( 1, substr_count( $cpuinfo, 'processor' ) );
            }
        }

        // macOS / BSD via sysctl.
        if ( $this->can_shell_exec() ) {
            $cores = @shell_exec( 'sysctl -n hw.ncpu 2>/dev/null' );
            if ( is_numeric( trim( (string) $cores ) ) ) {
                return (int) trim( $cores );
            }
            $cores = @shell_exec( 'nproc 2>/dev/null' );
            if ( is_numeric( trim( (string) $cores ) ) ) {
                return (int) trim( $cores );
            }
        }

        return 1;
    }

    /**
     * Calculate directory size (recursively).
     * Returns bytes.  Returns 0 on failure.
     */
    private function directory_size( string $path ): int {
        if ( ! is_dir( $path ) ) {
            return 0;
        }

        $size = 0;

        try {
            $iterator = new RecursiveIteratorIterator(
                new RecursiveDirectoryIterator( $path, RecursiveDirectoryIterator::SKIP_DOTS ),
                RecursiveIteratorIterator::LEAVES_ONLY
            );

            $limit = 50000; // Safety cap for very large directories.
            $count = 0;

            foreach ( $iterator as $file ) {
                if ( $file->isFile() ) {
                    $size += $file->getSize();
                }
                if ( ++$count >= $limit ) {
                    break;
                }
            }
        } catch ( \Exception $e ) {
            // Inaccessible directory — return what we have.
        }

        return $size;
    }

    /**
     * Test whether shell_exec() is callable.
     */
    private function can_shell_exec(): bool {
        if ( ! function_exists( 'shell_exec' ) ) {
            return false;
        }

        $disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
        return ! in_array( 'shell_exec', $disabled, true );
    }

    /**
     * Convert a PHP size string (e.g. "256M") to bytes.
     */
    private function parse_php_size( string $size ): int {
        $size = trim( $size );

        if ( '-1' === $size ) {
            // Unlimited.
            return PHP_INT_MAX;
        }

        $value = (int) $size;
        $unit  = strtoupper( substr( $size, -1 ) );

        switch ( $unit ) {
            case 'G':
                $value *= 1024 * 1024 * 1024;
                break;
            case 'M':
                $value *= 1024 * 1024;
                break;
            case 'K':
                $value *= 1024;
                break;
        }

        return $value;
    }
}
