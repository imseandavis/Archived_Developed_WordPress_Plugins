<?php
/**
 * REST API endpoints for the dashboard and external consumers.
 *
 * Namespace: wppi/v1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_REST_API {

    /** @var WP_Performance_Inspector_Pro */
    private $plugin;

    public function __construct( WP_Performance_Inspector_Pro $plugin ) {
        $this->plugin = $plugin;
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    /* ------------------------------------------------------------------
     * Route registration
     * ----------------------------------------------------------------*/

    public function register_routes(): void {
        $ns = 'wppi/v1';

        // Live system snapshot.
        register_rest_route( $ns, '/snapshot', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_snapshot' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ] );

        // Historical metrics.
        register_rest_route( $ns, '/metrics/(?P<type>[a-z]+)', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_metrics' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'type'  => [ 'required' => true, 'sanitize_callback' => 'sanitize_key' ],
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // HTTP log.
        register_rest_route( $ns, '/http-log', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_http_log' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // Network summary.
        register_rest_route( $ns, '/network-summary', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_network_summary' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // Events.
        register_rest_route( $ns, '/events', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_events' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range'    => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
                'severity' => [ 'default' => '',    'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // Run full analysis.
        register_rest_route( $ns, '/analyze', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_analysis' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ] );

        // Latest analysis.
        register_rest_route( $ns, '/analysis', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_analysis' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ] );

        // Capabilities.
        register_rest_route( $ns, '/capabilities', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_capabilities' ],
            'permission_callback' => [ $this, 'check_permission' ],
        ] );

        // Frontend RUM metrics.
        register_rest_route( $ns, '/frontend-metrics', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_frontend_metrics' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // Database query summary.
        register_rest_route( $ns, '/db-summary', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_db_summary' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );

        // Slow queries detail.
        register_rest_route( $ns, '/slow-queries', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_slow_queries' ],
            'permission_callback' => [ $this, 'check_permission' ],
            'args'                => [
                'range' => [ 'default' => '24h', 'sanitize_callback' => 'sanitize_key' ],
            ],
        ] );
    }

    /* ------------------------------------------------------------------
     * Permission check
     * ----------------------------------------------------------------*/

    public function check_permission(): bool {
        return current_user_can( 'manage_options' );
    }

    /* ------------------------------------------------------------------
     * Callbacks
     * ----------------------------------------------------------------*/

    public function get_snapshot( WP_REST_Request $request ): WP_REST_Response {
        $data = $this->plugin->monitor->get_live_snapshot();
        return new WP_REST_Response( $data, 200 );
    }

    public function get_metrics( WP_REST_Request $request ): WP_REST_Response {
        $type  = $request->get_param( 'type' );
        $range = $request->get_param( 'range' );

        $data = $this->plugin->logger->get_metrics( $type, $range );

        return new WP_REST_Response( $data, 200 );
    }

    public function get_http_log( WP_REST_Request $request ): WP_REST_Response {
        $range = $request->get_param( 'range' );
        $data  = $this->plugin->logger->get_http_logs( $range );

        return new WP_REST_Response( $data, 200 );
    }

    public function get_network_summary( WP_REST_Request $request ): WP_REST_Response {
        $range = $request->get_param( 'range' );
        $data  = $this->plugin->network_monitor->get_summary( $range );

        return new WP_REST_Response( $data, 200 );
    }

    public function get_events( WP_REST_Request $request ): WP_REST_Response {
        $range    = $request->get_param( 'range' );
        $severity = $request->get_param( 'severity' );
        $data     = $this->plugin->logger->get_events( $range, $severity );

        return new WP_REST_Response( $data, 200 );
    }

    public function run_analysis( WP_REST_Request $request ): WP_REST_Response {
        $system   = $this->plugin->monitor->collect_all();
        $analysis = $this->plugin->analyzer->run_full_analysis();

        return new WP_REST_Response( [
            'system'   => $system,
            'analysis' => $analysis,
        ], 200 );
    }

    public function get_analysis( WP_REST_Request $request ): WP_REST_Response {
        $data = $this->plugin->logger->get_latest_analysis( 'full' );

        if ( ! $data ) {
            return new WP_REST_Response( [ 'message' => 'No analysis available. Run a scan first.' ], 404 );
        }

        $data['analysis_data'] = json_decode( $data['analysis_data'], true );

        return new WP_REST_Response( $data, 200 );
    }

    public function get_capabilities( WP_REST_Request $request ): WP_REST_Response {
        return new WP_REST_Response( $this->plugin->monitor->get_capabilities(), 200 );
    }

    public function get_frontend_metrics( WP_REST_Request $request ): WP_REST_Response {
        $range   = $request->get_param( 'range' );
        $metrics = $this->plugin->logger->get_metrics( 'frontend', $range, 500 );

        // Compute averages.
        $totals = [ 'page_load' => [], 'ttfb' => [], 'fcp' => [], 'lcp' => [], 'cls' => [], 'fid' => [] ];
        $rows   = [];

        foreach ( $metrics as $m ) {
            $key = $m['metric_key'];
            if ( isset( $totals[ $key ] ) ) {
                $totals[ $key ][] = (float) $m['metric_value'];
            }
            if ( 'page_load' === $key ) {
                $extra = json_decode( $m['extra_data'] ?? '{}', true );
                $rows[] = [
                    'recorded_at' => $m['recorded_at'],
                    'url'         => $extra['url'] ?? '',
                    'load_time'   => (float) $m['metric_value'],
                    'ttfb'        => $extra['ttfb'] ?? 0,
                    'fcp'         => $extra['fcp'] ?? 0,
                    'lcp'         => $extra['lcp'] ?? 0,
                    'cls'         => $extra['cls'] ?? 0,
                    'fid'         => $extra['fid'] ?? 0,
                ];
            }
        }

        $avg = static function ( array $arr ): float {
            return count( $arr ) > 0 ? round( array_sum( $arr ) / count( $arr ), 1 ) : 0;
        };

        $slow_threshold = (float) get_option( 'wppi_slow_page_threshold', 3000 );
        $slow_count     = count( array_filter( $totals['page_load'], function ( $v ) use ( $slow_threshold ) { return $v >= $slow_threshold; } ) );

        return new WP_REST_Response( [
            'samples'       => count( $totals['page_load'] ),
            'avg_load_time' => $avg( $totals['page_load'] ),
            'avg_ttfb'      => $avg( $totals['ttfb'] ),
            'avg_fcp'       => $avg( $totals['fcp'] ),
            'avg_lcp'       => $avg( $totals['lcp'] ),
            'avg_cls'       => count( $totals['cls'] ) > 0 ? round( array_sum( $totals['cls'] ) / count( $totals['cls'] ), 3 ) : 0,
            'avg_fid'       => $avg( $totals['fid'] ),
            'slow_pages'    => $slow_count,
            'recent'        => array_slice( array_reverse( $rows ), 0, 50 ),
        ], 200 );
    }

    public function get_db_summary( WP_REST_Request $request ): WP_REST_Response {
        $range = $request->get_param( 'range' );

        if ( ! $this->plugin->query_monitor ) {
            return new WP_REST_Response( [ 'message' => 'Query monitor not available.' ], 404 );
        }

        return new WP_REST_Response( $this->plugin->query_monitor->get_db_summary( $range ), 200 );
    }

    public function get_slow_queries( WP_REST_Request $request ): WP_REST_Response {
        $range = $request->get_param( 'range' );

        if ( ! $this->plugin->query_monitor ) {
            return new WP_REST_Response( [], 200 );
        }

        $raw = $this->plugin->query_monitor->get_slow_queries( $range, 20 );

        // Decode the extra_data for each row.
        $results = [];
        foreach ( $raw as $row ) {
            $decoded = json_decode( $row['extra_data'] ?? '[]', true );
            $results[] = [
                'recorded_at' => $row['recorded_at'],
                'queries'     => is_array( $decoded ) ? $decoded : [],
            ];
        }

        return new WP_REST_Response( $results, 200 );
    }
}
