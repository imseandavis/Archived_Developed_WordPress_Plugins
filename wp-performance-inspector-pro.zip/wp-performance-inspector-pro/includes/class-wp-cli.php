<?php
/**
 * WP-CLI integration — headless scanning, metric collection,
 * and report generation from the command line.
 *
 * Usage:
 *   wp perf-inspector scan            Run a full performance scan
 *   wp perf-inspector snapshot        Collect a live system snapshot
 *   wp perf-inspector score           Show the latest performance score
 *   wp perf-inspector report [--format=json|csv] [--file=path]
 *   wp perf-inspector events [--severity=critical] [--range=24h]
 *   wp perf-inspector http-log [--range=24h] [--limit=50]
 *   wp perf-inspector db-summary      Show database query stats
 *   wp perf-inspector purge [--days=30]
 *   wp perf-inspector status          Show scheduler and capability info
 */

if ( ! defined( 'ABSPATH' ) || ! defined( 'WP_CLI' ) ) {
    return;
}

class WPPI_CLI_Command extends WP_CLI_Command {

    /**
     * Run a full performance scan (system + analysis).
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector scan
     *
     * @subcommand scan
     */
    public function scan( $args, $assoc_args ) {
        WP_CLI::log( 'Collecting system metrics...' );
        $system = wppi()->monitor->collect_all();

        WP_CLI::log( 'Running WordPress analysis...' );
        $analysis = wppi()->analyzer->run_full_analysis();

        $score = $analysis['overall_score'] ?? 0;

        // Score color.
        if ( $score >= 80 ) {
            WP_CLI::success( sprintf( 'Performance Score: %d/100', $score ) );
        } elseif ( $score >= 50 ) {
            WP_CLI::warning( sprintf( 'Performance Score: %d/100', $score ) );
        } else {
            WP_CLI::error( sprintf( 'Performance Score: %d/100', $score ), false );
        }

        // Print section scores.
        $sections = $analysis['sections'] ?? [];
        $table    = [];
        foreach ( $sections as $name => $section ) {
            $table[] = [
                'Section' => ucfirst( $name ),
                'Score'   => $section['score'] ?? '-',
                'Issues'  => count( $section['issues'] ?? [] ),
            ];
        }
        WP_CLI\Utils\format_items( 'table', $table, [ 'Section', 'Score', 'Issues' ] );

        // Print all issues.
        $all_issues = [];
        foreach ( $sections as $name => $section ) {
            foreach ( $section['issues'] ?? [] as $issue ) {
                $all_issues[] = [
                    'Section'  => ucfirst( $name ),
                    'Severity' => strtoupper( $issue['severity'] ?? '' ),
                    'Message'  => $issue['message'] ?? '',
                    'Fix'      => $issue['fix'] ?? '',
                ];
            }
        }

        if ( $all_issues ) {
            WP_CLI::log( '' );
            WP_CLI::log( '--- Issues Found ---' );
            WP_CLI\Utils\format_items( 'table', $all_issues, [ 'Section', 'Severity', 'Message', 'Fix' ] );
        } else {
            WP_CLI::success( 'No issues found!' );
        }

        // Print system highlights.
        WP_CLI::log( '' );
        WP_CLI::log( '--- System Snapshot ---' );
        $this->print_system_summary( $system );
    }

    /**
     * Collect and display a live system snapshot.
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector snapshot
     *
     * @subcommand snapshot
     */
    public function snapshot( $args, $assoc_args ) {
        WP_CLI::log( 'Collecting live snapshot...' );
        $data = wppi()->monitor->get_live_snapshot();

        $this->print_system_summary( $data );
    }

    /**
     * Show the latest performance score.
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector score
     *
     * @subcommand score
     */
    public function score( $args, $assoc_args ) {
        $raw = wppi()->logger->get_latest_analysis( 'full' );

        if ( ! $raw ) {
            WP_CLI::warning( 'No analysis data available. Run: wp perf-inspector scan' );
            return;
        }

        $data  = json_decode( $raw['analysis_data'], true );
        $score = $data['overall_score'] ?? 0;

        WP_CLI::log( sprintf( 'Performance Score: %d/100  (scanned %s)', $score, $raw['recorded_at'] ) );
    }

    /**
     * Generate and output a performance report.
     *
     * ## OPTIONS
     *
     * [--format=<format>]
     * : Output format. json or csv.
     * ---
     * default: json
     * ---
     *
     * [--file=<path>]
     * : Write output to a file instead of stdout.
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector report
     *     wp perf-inspector report --format=csv --file=report.csv
     *
     * @subcommand report
     */
    public function report( $args, $assoc_args ) {
        $format = $assoc_args['format'] ?? 'json';
        $file   = $assoc_args['file'] ?? '';

        $exporter = wppi()->exporter;
        $data     = $exporter->generate_report();

        if ( 'csv' === $format ) {
            $output = $exporter->to_csv( $data );
        } else {
            $output = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        }

        if ( $file ) {
            $written = file_put_contents( $file, $output );
            if ( false === $written ) {
                WP_CLI::error( sprintf( 'Failed to write report to %s — check permissions.', $file ) );
                return;
            }
            WP_CLI::success( sprintf( 'Report written to %s', $file ) );
        } else {
            WP_CLI::log( $output );
        }
    }

    /**
     * Show recent events.
     *
     * ## OPTIONS
     *
     * [--severity=<severity>]
     * : Filter by severity (critical, warning, error, info).
     *
     * [--range=<range>]
     * : Time range (1h, 6h, 24h, 7d, 30d).
     * ---
     * default: 24h
     * ---
     *
     * [--limit=<limit>]
     * : Maximum rows.
     * ---
     * default: 50
     * ---
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector events --severity=critical --range=7d
     *
     * @subcommand events
     */
    public function events( $args, $assoc_args ) {
        $range    = $assoc_args['range'] ?? '24h';
        $severity = $assoc_args['severity'] ?? '';
        $limit    = (int) ( $assoc_args['limit'] ?? 50 );

        $events = wppi()->logger->get_events( $range, $severity, $limit );

        if ( empty( $events ) ) {
            WP_CLI::log( 'No events found.' );
            return;
        }

        $rows = [];
        foreach ( $events as $ev ) {
            $rows[] = [
                'Time'     => $ev['recorded_at'],
                'Type'     => $ev['event_type'],
                'Severity' => strtoupper( $ev['severity'] ),
                'Message'  => $ev['message'],
            ];
        }

        WP_CLI\Utils\format_items( 'table', $rows, [ 'Time', 'Type', 'Severity', 'Message' ] );
    }

    /**
     * Show recent outbound HTTP requests.
     *
     * ## OPTIONS
     *
     * [--range=<range>]
     * : Time range (1h, 6h, 24h, 7d).
     * ---
     * default: 24h
     * ---
     *
     * [--limit=<limit>]
     * : Maximum rows.
     * ---
     * default: 50
     * ---
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector http-log --range=1h --limit=20
     *
     * @subcommand http-log
     */
    public function http_log( $args, $assoc_args ) {
        $range = $assoc_args['range'] ?? '24h';
        $limit = (int) ( $assoc_args['limit'] ?? 50 );

        $logs = wppi()->logger->get_http_logs( $range, $limit );

        if ( empty( $logs ) ) {
            WP_CLI::log( 'No HTTP requests logged.' );
            return;
        }

        $rows = [];
        foreach ( $logs as $log ) {
            $rows[] = [
                'Time'   => $log['recorded_at'],
                'Method' => $log['method'],
                'URL'    => strlen( $log['url'] ) > 60 ? substr( $log['url'], 0, 57 ) . '...' : $log['url'],
                'Status' => $log['response_code'],
                'ms'     => round( (float) $log['response_time'] * 1000 ),
                'Error'  => $log['error_message'] ?? '',
            ];
        }

        WP_CLI\Utils\format_items( 'table', $rows, [ 'Time', 'Method', 'URL', 'Status', 'ms', 'Error' ] );
    }

    /**
     * Show database query statistics.
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector db-summary
     *
     * @subcommand db-summary
     */
    public function db_summary( $args, $assoc_args ) {
        if ( ! isset( wppi()->query_monitor ) ) {
            WP_CLI::warning( 'Query monitor is not enabled. Enable it in Settings.' );
            return;
        }

        $summary = wppi()->query_monitor->get_db_summary( '24h' );

        $rows = [];
        foreach ( $summary as $key => $value ) {
            $rows[] = [
                'Metric' => str_replace( '_', ' ', ucfirst( $key ) ),
                'Value'  => $value,
            ];
        }

        WP_CLI\Utils\format_items( 'table', $rows, [ 'Metric', 'Value' ] );
    }

    /**
     * Purge old data from the database.
     *
     * ## OPTIONS
     *
     * [--days=<days>]
     * : Delete data older than this many days.
     * ---
     * default: 30
     * ---
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector purge --days=7
     *
     * @subcommand purge
     */
    public function purge( $args, $assoc_args ) {
        $days = (int) ( $assoc_args['days'] ?? 30 );

        WP_CLI::log( sprintf( 'Purging data older than %d days...', $days ) );
        $db = new WPPI_Database();
        $db->purge_old_data( $days );

        WP_CLI::success( 'Purge complete.' );
    }

    /**
     * Show scheduler status and system capabilities.
     *
     * ## EXAMPLES
     *
     *     wp perf-inspector status
     *
     * @subcommand status
     */
    public function status( $args, $assoc_args ) {
        // Scheduler.
        $next = wp_next_scheduled( 'wppi_collect_metrics' );
        $interval = get_option( 'wppi_collection_interval', 'wppi_five_minutes' );
        WP_CLI::log( sprintf( 'Collection interval: %s', $interval ) );
        WP_CLI::log( sprintf( 'Next collection: %s', $next ? gmdate( 'Y-m-d H:i:s', $next ) . ' UTC' : 'Not scheduled' ) );
        WP_CLI::log( sprintf( 'Retention: %d days', get_option( 'wppi_retention_days', 30 ) ) );
        WP_CLI::log( '' );

        // Capabilities.
        $caps = wppi()->monitor->get_capabilities();
        WP_CLI::log( '--- Monitoring Capabilities ---' );
        $rows = [];
        foreach ( $caps as $cap => $available ) {
            $rows[] = [
                'Capability' => str_replace( '_', ' ', $cap ),
                'Available'  => $available ? 'Yes' : 'No',
            ];
        }
        WP_CLI\Utils\format_items( 'table', $rows, [ 'Capability', 'Available' ] );

        // Feature flags.
        WP_CLI::log( '' );
        WP_CLI::log( '--- Feature Flags ---' );
        $flags = [
            [ 'Feature' => 'Frontend Beacon', 'Enabled' => get_option( 'wppi_beacon_enabled', true ) ? 'Yes' : 'No' ],
            [ 'Feature' => 'Query Monitor',   'Enabled' => get_option( 'wppi_query_monitor_enabled', false ) ? 'Yes' : 'No' ],
            [ 'Feature' => 'Email Alerts',    'Enabled' => ! empty( get_option( 'wppi_alert_settings', [] )['email_enabled'] ) ? 'Yes' : 'No' ],
            [ 'Feature' => 'Slack Alerts',    'Enabled' => ! empty( get_option( 'wppi_alert_settings', [] )['slack_enabled'] ) ? 'Yes' : 'No' ],
        ];
        WP_CLI\Utils\format_items( 'table', $flags, [ 'Feature', 'Enabled' ] );
    }

    /* ------------------------------------------------------------------
     * Internal helpers
     * ----------------------------------------------------------------*/

    private function print_system_summary( array $data ): void {
        $rows = [];

        // CPU.
        if ( ! empty( $data['cpu'] ) ) {
            if ( isset( $data['cpu']['cpu_usage_pct'] ) ) {
                $rows[] = [ 'Metric' => 'CPU Usage', 'Value' => $data['cpu']['cpu_usage_pct'] . '%' ];
            }
            if ( isset( $data['cpu']['load_1'] ) ) {
                $rows[] = [ 'Metric' => 'Load Avg (1/5/15)',
                    'Value' => sprintf( '%.2f / %.2f / %.2f',
                        $data['cpu']['load_1'], $data['cpu']['load_5'] ?? 0, $data['cpu']['load_15'] ?? 0 ) ];
            }
            if ( isset( $data['cpu']['cpu_cores'] ) ) {
                $rows[] = [ 'Metric' => 'CPU Cores', 'Value' => $data['cpu']['cpu_cores'] ];
            }
        }

        // Memory.
        if ( ! empty( $data['memory'] ) ) {
            $rows[] = [ 'Metric' => 'PHP Memory Used', 'Value' => size_format( $data['memory']['php_memory_used'] ) ];
            $rows[] = [ 'Metric' => 'PHP Memory Limit', 'Value' => size_format( $data['memory']['php_memory_limit'] ) ];
            if ( isset( $data['memory']['system_total'] ) ) {
                $rows[] = [ 'Metric' => 'System RAM Used', 'Value' => size_format( $data['memory']['system_used'] ) . ' / ' . size_format( $data['memory']['system_total'] ) ];
            }
        }

        // Disk.
        if ( ! empty( $data['disk'] ) ) {
            if ( isset( $data['disk']['disk_total'] ) ) {
                $rows[] = [ 'Metric' => 'Disk Usage', 'Value' => size_format( $data['disk']['disk_used'] ) . ' / ' . size_format( $data['disk']['disk_total'] ) . ' (' . $data['disk']['disk_pct'] . '%)' ];
            }
        }

        if ( $rows ) {
            WP_CLI\Utils\format_items( 'table', $rows, [ 'Metric', 'Value' ] );
        }
    }
}
