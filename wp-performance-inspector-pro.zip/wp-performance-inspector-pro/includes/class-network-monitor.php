<?php
/**
 * Network / HTTP monitor.
 *
 * Hooks into WordPress HTTP API to transparently track every outbound
 * request — URL, method, status code, response time, and errors.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Network_Monitor {

    /** @var WPPI_Logger */
    private $logger;

    /** @var array In-flight request timings keyed by URL. */
    private $timings = [];

    public function __construct( WPPI_Logger $logger ) {
        $this->logger = $logger;
        $this->register_hooks();
    }

    /* ------------------------------------------------------------------
     * Hook registration
     * ----------------------------------------------------------------*/

    private function register_hooks(): void {
        // Fires just before WP sends an HTTP request.
        add_filter( 'pre_http_request', [ $this, 'on_pre_request' ], 10, 3 );

        // Fires after a successful HTTP request.
        add_action( 'http_api_debug', [ $this, 'on_post_request' ], 10, 5 );
    }

    /* ------------------------------------------------------------------
     * Callbacks
     * ----------------------------------------------------------------*/

    /**
     * Record the start time before an outgoing HTTP request.
     *
     * Returning false (the default) lets WordPress proceed normally.
     *
     * @param false|array|WP_Error $preempt
     * @param array                $args
     * @param string               $url
     * @return false|array|WP_Error
     */
    public function on_pre_request( $preempt, array $args, string $url ) {
        $this->timings[ $url ] = [
            'start'  => microtime( true ),
            'method' => strtoupper( $args['method'] ?? 'GET' ),
            'body'   => $args['body'] ?? '',
        ];

        return $preempt; // Don't short-circuit.
    }

    /**
     * Record result after the HTTP response arrives.
     *
     * @param array|WP_Error $response
     * @param string         $context  ('response' on success)
     * @param string         $class    Transport class.
     * @param array          $args     Original request args.
     * @param string         $url      Request URL.
     */
    public function on_post_request( $response, string $context, string $class, array $args, string $url ): void {
        $start = $this->timings[ $url ]['start'] ?? microtime( true );
        $elapsed = microtime( true ) - $start;
        $method  = $this->timings[ $url ]['method'] ?? 'GET';
        $body    = $this->timings[ $url ]['body'] ?? '';

        unset( $this->timings[ $url ] );

        $log_data = [
            'url'           => $url,
            'method'        => $method,
            'response_time' => round( $elapsed, 4 ),
            'request_size'  => is_string( $body ) ? strlen( $body ) : 0,
        ];

        if ( is_wp_error( $response ) ) {
            $log_data['response_code']  = 0;
            $log_data['response_size']  = 0;
            $log_data['error_message']  = $response->get_error_message();
        } else {
            $log_data['response_code']  = (int) wp_remote_retrieve_response_code( $response );
            $resp_body                  = wp_remote_retrieve_body( $response );
            $log_data['response_size']  = is_string( $resp_body ) ? strlen( $resp_body ) : 0;
            $log_data['error_message']  = null;
        }

        // Persist.
        $this->logger->log_http_request( $log_data );

        // Log slow requests as events.
        $slow_threshold = (float) get_option( 'wppi_slow_http_threshold', 3.0 );
        if ( $elapsed >= $slow_threshold ) {
            $this->logger->log_event(
                'http',
                'warning',
                sprintf( 'Slow HTTP request: %.2fs to %s', $elapsed, $url ),
                $log_data
            );
        }

        // Log failures.
        if ( is_wp_error( $response ) || $log_data['response_code'] >= 400 ) {
            $this->logger->log_event(
                'http',
                'error',
                sprintf( 'HTTP error %s for %s: %s',
                    $log_data['response_code'],
                    $url,
                    $log_data['error_message'] ?? 'HTTP ' . $log_data['response_code']
                ),
                $log_data
            );
        }
    }

    /* ------------------------------------------------------------------
     * Summaries (for the dashboard)
     * ----------------------------------------------------------------*/

    /**
     * Aggregate HTTP stats for a given range.
     */
    public function get_summary( string $range = '24h' ): array {
        $logs = $this->logger->get_http_logs( $range, 5000 );

        if ( empty( $logs ) ) {
            return [
                'total_requests'   => 0,
                'avg_response_ms'  => 0,
                'failed_requests'  => 0,
                'slow_requests'    => 0,
                'top_domains'      => [],
                'error_rate'       => 0,
            ];
        }

        $total    = count( $logs );
        $failed   = 0;
        $slow     = 0;
        $time_sum = 0.0;
        $domains  = [];

        $slow_threshold = (float) get_option( 'wppi_slow_http_threshold', 3.0 );

        foreach ( $logs as $log ) {
            $time_sum += (float) $log['response_time'];

            if ( (int) $log['response_code'] >= 400 || ! empty( $log['error_message'] ) ) {
                $failed++;
            }

            if ( (float) $log['response_time'] >= $slow_threshold ) {
                $slow++;
            }

            $parsed = wp_parse_url( $log['url'] );
            $host   = $parsed['host'] ?? 'unknown';
            if ( ! isset( $domains[ $host ] ) ) {
                $domains[ $host ] = 0;
            }
            $domains[ $host ]++;
        }

        arsort( $domains );

        return [
            'total_requests'  => $total,
            'avg_response_ms' => round( ( $time_sum / $total ) * 1000, 1 ),
            'failed_requests' => $failed,
            'slow_requests'   => $slow,
            'error_rate'      => round( ( $failed / $total ) * 100, 1 ),
            'top_domains'     => array_slice( $domains, 0, 10, true ),
        ];
    }
}
