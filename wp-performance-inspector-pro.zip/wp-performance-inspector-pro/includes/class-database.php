<?php
/**
 * Database layer — creates and manages custom tables for metric storage.
 *
 * Tables:
 *   {prefix}wppi_metrics        — time-series system metrics (CPU, RAM, disk, network).
 *   {prefix}wppi_http_log       — outbound HTTP request log.
 *   {prefix}wppi_analysis_cache — cached analysis results.
 *   {prefix}wppi_events         — notable events / alerts.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Database {

    /** @var string */
    private $metrics_table;

    /** @var string */
    private $http_log_table;

    /** @var string */
    private $analysis_table;

    /** @var string */
    private $events_table;

    public function __construct() {
        global $wpdb;
        $this->metrics_table  = $wpdb->prefix . 'wppi_metrics';
        $this->http_log_table = $wpdb->prefix . 'wppi_http_log';
        $this->analysis_table = $wpdb->prefix . 'wppi_analysis_cache';
        $this->events_table   = $wpdb->prefix . 'wppi_events';
    }

    /* ------------------------------------------------------------------
     * Table accessors
     * ----------------------------------------------------------------*/

    public function metrics_table(): string {
        return $this->metrics_table;
    }

    public function http_log_table(): string {
        return $this->http_log_table;
    }

    public function analysis_table(): string {
        return $this->analysis_table;
    }

    public function events_table(): string {
        return $this->events_table;
    }

    /* ------------------------------------------------------------------
     * Schema creation (runs on activation)
     * ----------------------------------------------------------------*/

    public function create_tables(): void {
        global $wpdb;

        $charset = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Time-series metrics.
        $sql = "CREATE TABLE {$this->metrics_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            metric_type varchar(50) NOT NULL,
            metric_key varchar(100) NOT NULL,
            metric_value double NOT NULL DEFAULT 0,
            extra_data longtext DEFAULT NULL,
            recorded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_type_recorded (metric_type, recorded_at),
            KEY idx_recorded (recorded_at)
        ) {$charset};";
        dbDelta( $sql );

        // Outbound HTTP request log.
        $sql = "CREATE TABLE {$this->http_log_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            url text NOT NULL,
            method varchar(10) NOT NULL DEFAULT 'GET',
            response_code int(5) DEFAULT NULL,
            response_time float DEFAULT NULL,
            request_size int(11) DEFAULT 0,
            response_size int(11) DEFAULT 0,
            error_message text DEFAULT NULL,
            recorded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_recorded (recorded_at),
            KEY idx_response_code (response_code)
        ) {$charset};";
        dbDelta( $sql );

        // Cached full-analysis snapshots.
        $sql = "CREATE TABLE {$this->analysis_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            analysis_type varchar(50) NOT NULL,
            analysis_data longtext NOT NULL,
            score int(3) DEFAULT NULL,
            recorded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_type_recorded (analysis_type, recorded_at)
        ) {$charset};";
        dbDelta( $sql );

        // Events / alerts.
        $sql = "CREATE TABLE {$this->events_table} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            event_type varchar(50) NOT NULL,
            severity varchar(20) NOT NULL DEFAULT 'info',
            message text NOT NULL,
            context longtext DEFAULT NULL,
            recorded_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY idx_type (event_type),
            KEY idx_severity (severity),
            KEY idx_recorded (recorded_at)
        ) {$charset};";
        dbDelta( $sql );
    }

    /* ------------------------------------------------------------------
     * Generic CRUD helpers
     * ----------------------------------------------------------------*/

    /**
     * Insert a metric row.
     */
    public function insert_metric( string $type, string $key, float $value, array $extra = [] ): int {
        global $wpdb;

        $wpdb->insert(
            $this->metrics_table,
            [
                'metric_type'  => $type,
                'metric_key'   => $key,
                'metric_value' => $value,
                'extra_data'   => ! empty( $extra ) ? wp_json_encode( $extra ) : null,
                'recorded_at'  => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%f', '%s', '%s' ]
        );

        return (int) $wpdb->insert_id;
    }

    /**
     * Insert an HTTP log row.
     */
    public function insert_http_log( array $data ): int {
        global $wpdb;

        $wpdb->insert(
            $this->http_log_table,
            [
                'url'           => $data['url'] ?? '',
                'method'        => $data['method'] ?? 'GET',
                'response_code' => $data['response_code'] ?? null,
                'response_time' => $data['response_time'] ?? null,
                'request_size'  => $data['request_size'] ?? 0,
                'response_size' => $data['response_size'] ?? 0,
                'error_message' => $data['error_message'] ?? null,
                'recorded_at'   => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%d', '%f', '%d', '%d', '%s', '%s' ]
        );

        return (int) $wpdb->insert_id;
    }

    /**
     * Insert an event.
     */
    public function insert_event( string $type, string $severity, string $message, array $context = [] ): int {
        global $wpdb;

        $wpdb->insert(
            $this->events_table,
            [
                'event_type'  => $type,
                'severity'    => $severity,
                'message'     => $message,
                'context'     => ! empty( $context ) ? wp_json_encode( $context ) : null,
                'recorded_at' => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s' ]
        );

        return (int) $wpdb->insert_id;
    }

    /**
     * Save an analysis snapshot.
     */
    public function save_analysis( string $type, array $data, int $score = 0 ): int {
        global $wpdb;

        $wpdb->insert(
            $this->analysis_table,
            [
                'analysis_type' => $type,
                'analysis_data' => wp_json_encode( $data ),
                'score'         => $score,
                'recorded_at'   => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%d', '%s' ]
        );

        return (int) $wpdb->insert_id;
    }

    /* ------------------------------------------------------------------
     * Query helpers
     * ----------------------------------------------------------------*/

    /**
     * Get metrics for a given type within a date range.
     */
    public function get_metrics( string $type, string $range = '24h', int $limit = 500 ): array {
        global $wpdb;

        $since = $this->range_to_datetime( $range );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->metrics_table}
                 WHERE metric_type = %s AND recorded_at >= %s
                 ORDER BY recorded_at ASC
                 LIMIT %d",
                $type,
                $since,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get the most recent metric value for a key.
     */
    public function get_latest_metric( string $type, string $key ): ?array {
        global $wpdb;

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->metrics_table}
                 WHERE metric_type = %s AND metric_key = %s
                 ORDER BY recorded_at DESC
                 LIMIT 1",
                $type,
                $key
            ),
            ARRAY_A
        );

        return $row ?: null;
    }

    /**
     * Get HTTP log entries.
     */
    public function get_http_logs( string $range = '24h', int $limit = 200 ): array {
        global $wpdb;

        $since = $this->range_to_datetime( $range );

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->http_log_table}
                 WHERE recorded_at >= %s
                 ORDER BY recorded_at DESC
                 LIMIT %d",
                $since,
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get events.
     */
    public function get_events( string $range = '24h', string $severity = '', int $limit = 100 ): array {
        global $wpdb;

        $since = $this->range_to_datetime( $range );

        $limit = absint( $limit );

        $where = $wpdb->prepare( 'recorded_at >= %s', $since );
        if ( $severity ) {
            $where .= $wpdb->prepare( ' AND severity = %s', $severity );
        }

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$this->events_table}
                 WHERE {$where}
                 ORDER BY recorded_at DESC
                 LIMIT %d",
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get the latest analysis snapshot.
     */
    public function get_latest_analysis( string $type ): ?array {
        global $wpdb;

        // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$this->analysis_table}
                 WHERE analysis_type = %s
                 ORDER BY recorded_at DESC
                 LIMIT 1",
                $type
            ),
            ARRAY_A
        );

        return $row ?: null;
    }

    /* ------------------------------------------------------------------
     * Maintenance
     * ----------------------------------------------------------------*/

    /**
     * Purge data older than the given number of days.
     */
    public function purge_old_data( int $days = 30 ): void {
        global $wpdb;

        $cutoff = gmdate( 'Y-m-d H:i:s', time() - ( $days * DAY_IN_SECONDS ) );

        foreach ( [ $this->metrics_table, $this->http_log_table, $this->analysis_table, $this->events_table ] as $table ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE recorded_at < %s", $cutoff ) );
        }
    }

    /**
     * Drop all plugin tables (used on uninstall).
     */
    public function drop_tables(): void {
        global $wpdb;

        foreach ( [ $this->metrics_table, $this->http_log_table, $this->analysis_table, $this->events_table ] as $table ) {
            // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $wpdb->query( "DROP TABLE IF EXISTS {$table}" );
        }
    }

    /* ------------------------------------------------------------------
     * Utilities
     * ----------------------------------------------------------------*/

    /**
     * Convert a shorthand range string to a MySQL datetime.
     */
    private function range_to_datetime( string $range ): string {
        $map = [
            '1h'  => HOUR_IN_SECONDS,
            '6h'  => 6 * HOUR_IN_SECONDS,
            '24h' => DAY_IN_SECONDS,
            '7d'  => 7 * DAY_IN_SECONDS,
            '30d' => 30 * DAY_IN_SECONDS,
        ];

        $seconds = $map[ $range ] ?? DAY_IN_SECONDS;

        return gmdate( 'Y-m-d H:i:s', time() - $seconds );
    }
}
