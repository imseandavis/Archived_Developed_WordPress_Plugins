<?php
/**
 * WordPress application-level analyzer.
 *
 * Inspects the WP environment, database, plugins, themes, caching,
 * and frontend assets.  Produces scored recommendations.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Analyzer {

    /** @var WPPI_Logger */
    private $logger;

    public function __construct( WPPI_Logger $logger ) {
        $this->logger = $logger;
    }

    /* ==================================================================
     * PUBLIC: Run all analyses and return a unified report.
     * ================================================================*/

    public function run_full_analysis(): array {
        $sections = [
            'wordpress'  => $this->analyze_wordpress(),
            'database'   => $this->analyze_database(),
            'plugins'    => $this->analyze_plugins(),
            'themes'     => $this->analyze_themes(),
            'caching'    => $this->analyze_caching(),
            'frontend'   => $this->analyze_frontend(),
            'security'   => $this->analyze_security(),
        ];

        // Compute overall score (0-100).
        $total  = 0;
        $count  = 0;
        foreach ( $sections as $section ) {
            if ( isset( $section['score'] ) ) {
                $total += $section['score'];
                $count++;
            }
        }

        $overall_score = $count > 0 ? (int) round( $total / $count ) : 0;

        $report = [
            'overall_score' => $overall_score,
            'sections'      => $sections,
            'timestamp'     => current_time( 'mysql' ),
        ];

        // Persist.
        $this->logger->save_analysis( 'full', $report, $overall_score );

        return $report;
    }

    /* ==================================================================
     * WordPress Core
     * ================================================================*/

    public function analyze_wordpress(): array {
        global $wp_version;

        $issues = [];
        $score  = 100;

        // Version check.
        $latest = $this->get_latest_wp_version();
        if ( $latest && version_compare( $wp_version, $latest, '<' ) ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( 'WordPress %s is available (you have %s).', $latest, $wp_version ),
                'fix'      => 'Update WordPress to the latest version.',
            ];
            $score -= 10;
        }

        // WP_DEBUG.
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => 'WP_DEBUG is enabled in production.',
                'fix'      => 'Set WP_DEBUG to false in wp-config.php for production sites.',
            ];
            $score -= 5;
        }

        // WP-Cron.
        if ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => 'WP-Cron is disabled — ensure a real cron job is configured.',
                'fix'      => 'Add a system cron entry: */5 * * * * curl -s {site_url}/wp-cron.php',
            ];
        }

        // Heartbeat.
        $heartbeat_settings = apply_filters( 'heartbeat_settings', [ 'interval' => 60 ] );
        $heartbeat_interval = (int) ( $heartbeat_settings['interval'] ?? 60 );
        if ( $heartbeat_interval < 30 ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => sprintf( 'Heartbeat interval is %ds — may cause high admin-ajax load.', $heartbeat_interval ),
                'fix'      => 'Increase the Heartbeat interval or disable it on non-essential pages.',
            ];
            $score -= 5;
        }

        // Multisite.
        $is_multisite = is_multisite();

        return [
            'score'   => max( 0, $score ),
            'data'    => [
                'wp_version'       => $wp_version,
                'php_version'      => PHP_VERSION,
                'is_multisite'     => $is_multisite,
                'wp_debug'         => defined( 'WP_DEBUG' ) && WP_DEBUG,
                'wp_cron_disabled' => defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON,
                'heartbeat'        => $heartbeat_interval,
                'site_url'         => get_site_url(),
                'home_url'         => get_home_url(),
                'timezone'         => wp_timezone_string(),
            ],
            'issues'  => $issues,
        ];
    }

    /* ==================================================================
     * Database
     * ================================================================*/

    public function analyze_database(): array {
        global $wpdb;

        $issues = [];
        $score  = 100;

        // Autoloaded options size.
        $autoload_size = (int) $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value))
             FROM {$wpdb->options}
             WHERE autoload = 'yes'"
        );

        if ( $autoload_size > 1048576 ) { // > 1 MB
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( 'Autoloaded options total %.2f MB — this slows every page load.', $autoload_size / 1048576 ),
                'fix'      => 'Audit autoloaded options and set heavy ones to autoload=no.',
            ];
            $score -= 15;
        } elseif ( $autoload_size > 524288 ) { // > 500 KB
            $issues[] = [
                'severity' => 'info',
                'message'  => sprintf( 'Autoloaded options total %.2f KB.', $autoload_size / 1024 ),
                'fix'      => 'Review autoloaded options for cleanup opportunities.',
            ];
            $score -= 5;
        }

        // Post revisions.
        $revision_count = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} WHERE post_type = 'revision'"
        );
        if ( $revision_count > 5000 ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( '%s post revisions detected.', number_format( $revision_count ) ),
                'fix'      => 'Limit revisions via WP_POST_REVISIONS or clean up with WP-CLI.',
            ];
            $score -= 10;
        }

        // Transients (expired).
        $expired_transients = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_timeout_%'
             AND option_value < UNIX_TIMESTAMP()"
        );
        if ( $expired_transients > 100 ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => sprintf( '%d expired transients in the database.', $expired_transients ),
                'fix'      => 'Clean expired transients with wp transient delete --expired.',
            ];
            $score -= 5;
        }

        // Orphaned post meta.
        $orphan_meta = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->postmeta} pm
             LEFT JOIN {$wpdb->posts} p ON pm.post_id = p.ID
             WHERE p.ID IS NULL"
        );

        // Table sizes.
        $table_sizes = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT table_name AS `table`,
                        ROUND((data_length + index_length) / 1024 / 1024, 2) AS size_mb
                 FROM information_schema.TABLES
                 WHERE table_schema = %s
                 ORDER BY (data_length + index_length) DESC
                 LIMIT 20",
                DB_NAME
            ),
            ARRAY_A
        );

        // Total database size.
        $db_size_mb = 0;
        foreach ( $table_sizes as $t ) {
            $db_size_mb += (float) $t['size_mb'];
        }

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'autoload_size_bytes' => $autoload_size,
                'revision_count'      => $revision_count,
                'expired_transients'  => $expired_transients,
                'orphan_postmeta'     => $orphan_meta,
                'db_size_mb'          => round( $db_size_mb, 2 ),
                'table_sizes'         => $table_sizes,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Plugins
     * ================================================================*/

    public function analyze_plugins(): array {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins    = get_plugins();
        $active_plugins = get_option( 'active_plugins', [] );
        $issues         = [];
        $score          = 100;

        $inactive = [];
        foreach ( $all_plugins as $file => $meta ) {
            if ( ! in_array( $file, $active_plugins, true ) ) {
                $inactive[] = $meta['Name'];
            }
        }

        if ( count( $inactive ) > 3 ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => sprintf( '%d inactive plugins installed.', count( $inactive ) ),
                'fix'      => 'Delete inactive plugins to reduce attack surface and disk usage.',
            ];
            $score -= 5;
        }

        if ( count( $active_plugins ) > 30 ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( '%d active plugins may degrade performance.', count( $active_plugins ) ),
                'fix'      => 'Audit active plugins and deactivate any that are unnecessary.',
            ];
            $score -= 10;
        }

        // Check for known heavy patterns (update checks, etc.).
        $update_check = get_site_transient( 'update_plugins' );
        $outdated     = [];
        if ( $update_check && ! empty( $update_check->response ) ) {
            foreach ( $update_check->response as $file => $info ) {
                $name = $all_plugins[ $file ]['Name'] ?? $file;
                $outdated[] = $name;
            }
            if ( count( $outdated ) > 0 ) {
                $issues[] = [
                    'severity' => 'warning',
                    'message'  => sprintf( '%d plugin(s) have updates available.', count( $outdated ) ),
                    'fix'      => 'Update plugins to get performance improvements and security fixes.',
                ];
                $score -= 5;
            }
        }

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'total_plugins'    => count( $all_plugins ),
                'active_count'     => count( $active_plugins ),
                'inactive_count'   => count( $inactive ),
                'inactive_plugins' => $inactive,
                'outdated_plugins' => $outdated,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Themes
     * ================================================================*/

    public function analyze_themes(): array {
        $issues = [];
        $score  = 100;

        $active_theme  = wp_get_theme();
        $all_themes    = wp_get_themes();
        $inactive      = count( $all_themes ) - 1; // All minus the active one.

        if ( $inactive > 2 ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => sprintf( '%d inactive themes installed.', $inactive ),
                'fix'      => 'Keep only the active theme and one default theme as a fallback.',
            ];
            $score -= 5;
        }

        // Parent theme (child theme check).
        $parent = $active_theme->parent();

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'active_theme'  => $active_theme->get( 'Name' ),
                'theme_version' => $active_theme->get( 'Version' ),
                'is_child'      => (bool) $parent,
                'parent_theme'  => $parent ? $parent->get( 'Name' ) : null,
                'total_themes'  => count( $all_themes ),
                'inactive'      => $inactive,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Caching
     * ================================================================*/

    public function analyze_caching(): array {
        $issues = [];
        $score  = 100;

        // Object cache.
        $object_cache = wp_using_ext_object_cache();
        $object_cache_type = 'None';

        if ( $object_cache ) {
            if ( class_exists( 'Redis' ) || class_exists( 'Predis\Client' ) ) {
                $object_cache_type = 'Redis';
            } elseif ( class_exists( 'Memcached' ) || class_exists( 'Memcache' ) ) {
                $object_cache_type = 'Memcached';
            } else {
                $object_cache_type = 'External (unknown type)';
            }
        } else {
            $issues[] = [
                'severity' => 'warning',
                'message'  => 'No persistent object cache detected.',
                'fix'      => 'Install Redis or Memcached for a persistent object cache.',
            ];
            $score -= 15;
        }

        // Page cache (heuristic: check for known page-cache drop-ins or headers).
        $page_cache = file_exists( WP_CONTENT_DIR . '/advanced-cache.php' )
                      && defined( 'WP_CACHE' ) && WP_CACHE;

        if ( ! $page_cache ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => 'No page cache detected.',
                'fix'      => 'Install a page-caching plugin (WP Super Cache, W3 Total Cache, etc.).',
            ];
            $score -= 15;
        }

        // OPcache.
        $opcache = false;
        if ( function_exists( 'opcache_get_status' ) ) {
            $status  = @opcache_get_status( false );
            $opcache = ! empty( $status['opcache_enabled'] );
        }
        if ( ! $opcache ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => 'PHP OPcache is not enabled.',
                'fix'      => 'Enable OPcache in php.ini for significant PHP performance gains.',
            ];
            $score -= 10;
        }

        // GZIP / Brotli.
        $gzip   = in_array( 'zlib', get_loaded_extensions(), true );
        $brotli = extension_loaded( 'brotli' );
        if ( ! $gzip && ! $brotli ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => 'Neither GZIP nor Brotli compression is available.',
                'fix'      => 'Enable mod_deflate / zlib for GZIP compression.',
            ];
            $score -= 10;
        }

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'object_cache'      => $object_cache,
                'object_cache_type' => $object_cache_type,
                'page_cache'        => $page_cache,
                'opcache'           => $opcache,
                'gzip'              => $gzip,
                'brotli'            => $brotli,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Frontend Assets
     * ================================================================*/

    public function analyze_frontend(): array {
        global $wp_scripts, $wp_styles;

        $issues = [];
        $score  = 100;

        $registered_scripts = $wp_scripts instanceof WP_Scripts ? count( $wp_scripts->registered ) : 0;
        $registered_styles  = $wp_styles instanceof WP_Styles ? count( $wp_styles->registered ) : 0;

        if ( $registered_scripts > 40 ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( '%d JavaScript files registered — too many HTTP requests.', $registered_scripts ),
                'fix'      => 'Concatenate, defer, or lazy-load scripts.',
            ];
            $score -= 10;
        }

        if ( $registered_styles > 30 ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => sprintf( '%d CSS files registered — may cause render blocking.', $registered_styles ),
                'fix'      => 'Concatenate stylesheets or load them asynchronously.',
            ];
            $score -= 10;
        }

        // Lazy loading support (WP 5.5+).
        $lazy_loading = function_exists( 'wp_lazy_loading_enabled' ) && wp_lazy_loading_enabled( 'img', 'the_content' );

        if ( ! $lazy_loading ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => 'Native lazy loading for images is disabled.',
                'fix'      => 'Ensure add_filter("wp_lazy_loading_enabled", "__return_true") is active.',
            ];
            $score -= 5;
        }

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'registered_scripts' => $registered_scripts,
                'registered_styles'  => $registered_styles,
                'lazy_loading'       => $lazy_loading,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Security (lightweight checks)
     * ================================================================*/

    public function analyze_security(): array {
        $issues = [];
        $score  = 100;

        // File editing.
        if ( ! defined( 'DISALLOW_FILE_EDIT' ) || ! DISALLOW_FILE_EDIT ) {
            $issues[] = [
                'severity' => 'warning',
                'message'  => 'File editing is enabled in the admin.',
                'fix'      => "Add define('DISALLOW_FILE_EDIT', true); to wp-config.php.",
            ];
            $score -= 10;
        }

        // SSL.
        if ( ! is_ssl() ) {
            $issues[] = [
                'severity' => 'critical',
                'message'  => 'Site is not using HTTPS.',
                'fix'      => 'Install an SSL certificate and force HTTPS.',
            ];
            $score -= 20;
        }

        // DB table prefix.
        global $wpdb;
        if ( 'wp_' === $wpdb->prefix ) {
            $issues[] = [
                'severity' => 'info',
                'message'  => 'Default database table prefix (wp_) is in use.',
                'fix'      => 'Use a custom table prefix for better security.',
            ];
            $score -= 5;
        }

        // Debug log exposed.
        if ( defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
            $log_path = WP_DEBUG_LOG === true
                ? WP_CONTENT_DIR . '/debug.log'
                : WP_DEBUG_LOG;
            if ( file_exists( $log_path ) ) {
                $issues[] = [
                    'severity' => 'warning',
                    'message'  => 'Debug log file exists and may be publicly accessible.',
                    'fix'      => 'Move the debug log outside the webroot or restrict access via .htaccess.',
                ];
                $score -= 10;
            }
        }

        return [
            'score'  => max( 0, $score ),
            'data'   => [
                'ssl'                => is_ssl(),
                'file_edit_disabled' => defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT,
                'db_prefix_default'  => 'wp_' === $wpdb->prefix,
            ],
            'issues' => $issues,
        ];
    }

    /* ==================================================================
     * Helpers
     * ================================================================*/

    /**
     * Fetch the latest WP version from the API (cached for 12 hours).
     */
    private function get_latest_wp_version(): ?string {
        $cached = get_transient( 'wppi_latest_wp_version' );
        if ( $cached ) {
            return $cached;
        }

        $response = wp_remote_get( 'https://api.wordpress.org/core/version-check/1.7/', [
            'timeout' => 5,
        ] );

        if ( is_wp_error( $response ) ) {
            return null;
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) ) {
            return null;
        }
        $ver = $body['offers'][0]['version'] ?? null;

        if ( $ver ) {
            set_transient( 'wppi_latest_wp_version', $ver, 12 * HOUR_IN_SECONDS );
        }

        return $ver;
    }
}
