<?php
/**
 * Query monitor — intercepts and logs slow database queries.
 *
 * WordPress provides the SAVEQUERIES constant and the $wpdb->queries
 * array, but those are debug-only and not designed for production.
 * This class uses the 'log_query_custom_data' filter (WP 6.1+)
 * or falls back to the 'query' filter to time every SQL statement
 * and flag the slow ones.
 *
 * Only active when WPPI_QUERY_MONITOR is truthy (set via Settings).
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Query_Monitor {

    /** @var WPPI_Logger */
    private $logger;

    /** @var array In-flight query timers. */
    private $timers = [];

    /** @var array Collected query stats for the current request. */
    private $queries = [];

    /** @var int Maximum queries to track per request (memory safety). */
    private $max_queries = 500;

    /** @var float Threshold in seconds to flag a query as slow. */
    private $slow_threshold;

    public function __construct( WPPI_Logger $logger ) {
        $this->logger         = $logger;
        $this->slow_threshold = (float) get_option( 'wppi_slow_query_threshold', 0.05 ); // 50 ms

        if ( ! $this->is_enabled() ) {
            return;
        }

        $this->register_hooks();
    }

    /* ------------------------------------------------------------------
     * Hook registration
     * ----------------------------------------------------------------*/

    private function register_hooks(): void {
        // The 'query' filter lets us time every SQL query.
        add_filter( 'query', [ $this, 'on_query_start' ], 1 );

        // After the query has executed, we measure elapsed time via
        // the 'log_query_custom_data' filter (WP 6.1+).
        if ( has_filter( 'log_query_custom_data' ) !== false || version_compare( get_bloginfo( 'version' ), '6.1', '>=' ) ) {
            add_filter( 'log_query_custom_data', [ $this, 'on_query_logged' ], 10, 5 );
        }

        // Save summary at shutdown.
        add_action( 'shutdown', [ $this, 'on_shutdown' ], 9999 );
    }

    /* ------------------------------------------------------------------
     * Query hooks
     * ----------------------------------------------------------------*/

    /**
     * Record the start time of a query (fires before execution).
     *
     * @param string $query SQL string.
     * @return string Unmodified query.
     */
    public function on_query_start( string $query ): string {
        if ( count( $this->timers ) < $this->max_queries ) {
            $hash = md5( $query . microtime( true ) );
            $this->timers[ $hash ] = [
                'sql'   => $query,
                'start' => microtime( true ),
            ];
        }
        return $query;
    }

    /**
     * WP 6.1+ hook — fires after wpdb logs a query.
     *
     * @param array  $query_data   Custom data to append.
     * @param string $query        SQL.
     * @param float  $query_time   Execution time (seconds).
     * @param string $query_callstack Caller trace.
     * @param float  $query_start  Start timestamp.
     * @return array
     */
    public function on_query_logged( array $query_data, string $query, float $query_time, string $query_callstack, float $query_start ): array {
        $this->record_query( $query, $query_time, $query_callstack );

        // Remove matching timer entry to avoid double-counting.
        foreach ( $this->timers as $hash => $timer ) {
            if ( $timer['sql'] === $query ) {
                unset( $this->timers[ $hash ] );
                break;
            }
        }

        return $query_data;
    }

    /**
     * Record a query with its duration.
     */
    private function record_query( string $sql, float $duration, string $caller = '' ): void {
        $entry = [
            'sql'      => $this->truncate_sql( $sql ),
            'duration' => round( $duration * 1000, 2 ), // Store as ms.
            'caller'   => $caller ? $this->simplify_caller( $caller ) : '',
            'is_slow'  => $duration >= $this->slow_threshold,
        ];

        $this->queries[] = $entry;

        // Immediately log critically slow queries as events.
        if ( $duration >= $this->slow_threshold * 5 ) {
            $this->logger->log_event(
                'database',
                'warning',
                sprintf( 'Very slow query: %.1fms — %s', $entry['duration'], $entry['sql'] ),
                $entry
            );
        }
    }

    /* ------------------------------------------------------------------
     * Shutdown — persist aggregated stats
     * ----------------------------------------------------------------*/

    public function on_shutdown(): void {
        // If log_query_custom_data didn't fire (WP < 6.1), fall back
        // to measuring elapsed time from our own timers.
        if ( ! empty( $this->timers ) && empty( $this->queries ) ) {
            $now = microtime( true );
            foreach ( $this->timers as $timer ) {
                $duration = $now - $timer['start'];
                $this->record_query( $timer['sql'], $duration );
            }
        }

        if ( empty( $this->queries ) ) {
            return;
        }

        // Compute request-level summary.
        $total_queries = count( $this->queries );
        $total_time    = 0;
        $slow_queries  = 0;
        $slowest       = null;

        foreach ( $this->queries as $q ) {
            $total_time += $q['duration'];
            if ( $q['is_slow'] ) {
                $slow_queries++;
            }
            if ( ! $slowest || $q['duration'] > $slowest['duration'] ) {
                $slowest = $q;
            }
        }

        $avg_time = $total_queries > 0 ? round( $total_time / $total_queries, 2 ) : 0;

        // Store summary metrics.
        $this->logger->log_metric( 'database', 'query_count', $total_queries );
        $this->logger->log_metric( 'database', 'total_query_time', round( $total_time, 2 ) );
        $this->logger->log_metric( 'database', 'avg_query_time', $avg_time );
        $this->logger->log_metric( 'database', 'slow_query_count', $slow_queries );

        if ( $slowest ) {
            $this->logger->log_metric( 'database', 'slowest_query', $slowest['duration'], [
                'sql'    => $slowest['sql'],
                'caller' => $slowest['caller'],
            ] );
        }

        // Store the N slowest queries for drill-down.
        $slow_list = array_filter( $this->queries, function ( $q ) { return $q['is_slow']; } );
        usort( $slow_list, function ( $a, $b ) { return $b['duration'] <=> $a['duration']; } );
        $slow_list = array_slice( $slow_list, 0, 20 );

        if ( $slow_list ) {
            $this->logger->log_metric( 'database', 'slow_queries_detail', count( $slow_list ), $slow_list );
        }
    }

    /* ------------------------------------------------------------------
     * Public accessors for the REST API / dashboard
     * ----------------------------------------------------------------*/

    /**
     * Get recent slow query events from the database.
     */
    public function get_slow_queries( string $range = '24h', int $limit = 50 ): array {
        global $wpdb;
        $db = new WPPI_Database();

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$db->metrics_table()}
                 WHERE metric_type = 'database' AND metric_key = 'slow_queries_detail'
                 AND recorded_at >= %s
                 ORDER BY recorded_at DESC
                 LIMIT %d",
                gmdate( 'Y-m-d H:i:s', time() - $this->range_seconds( $range ) ),
                $limit
            ),
            ARRAY_A
        );
    }

    /**
     * Get database performance summary.
     */
    public function get_db_summary( string $range = '24h' ): array {
        $db = new WPPI_Database();

        $metrics = $db->get_metrics( 'database', $range, 500 );

        $summary = [
            'total_samples'     => 0,
            'avg_query_count'   => 0,
            'avg_total_time_ms' => 0,
            'avg_per_query_ms'  => 0,
            'total_slow'        => 0,
        ];

        $counts = [];
        $times  = [];
        $avgs   = [];
        $slows  = [];

        foreach ( $metrics as $m ) {
            switch ( $m['metric_key'] ) {
                case 'query_count':
                    $counts[] = (float) $m['metric_value'];
                    break;
                case 'total_query_time':
                    $times[] = (float) $m['metric_value'];
                    break;
                case 'avg_query_time':
                    $avgs[] = (float) $m['metric_value'];
                    break;
                case 'slow_query_count':
                    $slows[] = (float) $m['metric_value'];
                    break;
            }
        }

        $n = count( $counts );
        if ( $n > 0 ) {
            $summary['total_samples']     = $n;
            $summary['avg_query_count']   = round( array_sum( $counts ) / $n, 1 );
            $summary['avg_total_time_ms'] = round( array_sum( $times ) / $n, 1 );
            $summary['avg_per_query_ms']  = round( array_sum( $avgs ) / $n, 2 );
            $summary['total_slow']        = (int) array_sum( $slows );
        }

        return $summary;
    }

    /* ------------------------------------------------------------------
     * Helpers
     * ----------------------------------------------------------------*/

    private function is_enabled(): bool {
        return (bool) get_option( 'wppi_query_monitor_enabled', false );
    }

    private function truncate_sql( string $sql ): string {
        $sql = preg_replace( '/\s+/', ' ', trim( $sql ) );
        if ( strlen( $sql ) > 500 ) {
            return substr( $sql, 0, 497 ) . '...';
        }
        return $sql;
    }

    private function simplify_caller( string $trace ): string {
        // Return only the last meaningful caller.
        $parts = explode( ', ', $trace );
        return end( $parts ) ?: $trace;
    }

    private function range_seconds( string $range ): int {
        $map = [
            '1h'  => HOUR_IN_SECONDS,
            '6h'  => 6 * HOUR_IN_SECONDS,
            '24h' => DAY_IN_SECONDS,
            '7d'  => 7 * DAY_IN_SECONDS,
            '30d' => 30 * DAY_IN_SECONDS,
        ];
        return $map[ $range ] ?? DAY_IN_SECONDS;
    }
}
