<?php
/**
 * Server-Sent Events (SSE) handler for real-time dashboard updates.
 *
 * SSE is a simpler, unidirectional alternative to WebSockets that works
 * natively in all modern browsers via EventSource.  The server holds the
 * connection open and pushes JSON payloads at a configured interval.
 *
 * Endpoint: admin-ajax.php?action=wppi_sse_stream
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_SSE_Handler {

    /** @var WP_Performance_Inspector_Pro */
    private $plugin;

    public function __construct( WP_Performance_Inspector_Pro $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wppi_sse_stream', [ $this, 'stream' ] );
    }

    /**
     * Open an SSE connection and push live metrics every N seconds.
     *
     * The browser calls:
     *   new EventSource(ajaxUrl + '?action=wppi_sse_stream&nonce=...')
     *
     * We flush a JSON payload as an SSE "data:" line, then sleep.
     * The connection stays alive until the browser closes EventSource
     * or the PHP max_execution_time is reached.
     */
    public function stream(): void {
        // Nonce + capability check.  Verify nonce manually instead of
        // check_ajax_referer() to avoid wp_die() outputting HTML into
        // the SSE stream on failure.
        $nonce = sanitize_text_field( $_GET['nonce'] ?? '' );
        if ( ! wp_verify_nonce( $nonce, 'wppi_sse' ) || ! current_user_can( 'manage_options' ) ) {
            status_header( 403 );
            exit;
        }

        // Prevent output buffering from delaying flushes.
        // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        @ini_set( 'output_buffering', 'Off' );
        @ini_set( 'zlib.output_compression', 'Off' );

        // Turn off any WP / server-level buffering we can reach.
        while ( ob_get_level() ) {
            ob_end_clean();
        }

        // SSE headers.
        header( 'Content-Type: text/event-stream' );
        header( 'Cache-Control: no-cache' );
        header( 'Connection: keep-alive' );
        header( 'X-Accel-Buffering: no' ); // Nginx proxy buffering off.

        $interval   = max( 5, (int) get_option( 'wppi_sse_interval', 10 ) );
        $max_pushes = 60; // Safety cap — reconnect after ~10 min at 10 s interval.
        $push_count = 0;

        while ( $push_count < $max_pushes ) {
            if ( connection_aborted() ) {
                break;
            }

            $payload = $this->build_payload();

            echo "data: " . wp_json_encode( $payload ) . "\n\n";

            // Flush to the browser immediately.
            if ( function_exists( 'fastcgi_finish_request' ) ) {
                // Don't call fastcgi_finish_request — it would end the stream.
            }
            flush();

            $push_count++;
            sleep( $interval );
        }

        // Final "done" event so the browser knows to reconnect.
        echo "event: done\ndata: {}\n\n";
        flush();

        exit;
    }

    /**
     * Build the payload pushed on every tick.
     */
    private function build_payload(): array {
        $snapshot = $this->plugin->monitor->get_live_snapshot();
        $net      = $this->plugin->network_monitor->get_summary( '1h' );

        return [
            'timestamp' => current_time( 'mysql' ),
            'cpu'       => $snapshot['cpu'] ?? [],
            'memory'    => $snapshot['memory'] ?? [],
            'disk'      => $snapshot['disk'] ?? [],
            'network'   => $net,
        ];
    }
}
