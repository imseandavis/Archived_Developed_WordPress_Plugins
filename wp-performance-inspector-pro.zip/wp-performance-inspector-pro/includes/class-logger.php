<?php
/**
 * Centralised logging facade.
 *
 * All writes to the database go through here so that other classes
 * are decoupled from the schema.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Logger {

    /** @var WPPI_Database */
    private $db;

    public function __construct( WPPI_Database $db ) {
        $this->db = $db;
    }

    /* ------------------------------------------------------------------
     * Metrics
     * ----------------------------------------------------------------*/

    public function log_metric( string $type, string $key, float $value, array $extra = [] ): int {
        return $this->db->insert_metric( $type, $key, $value, $extra );
    }

    /* ------------------------------------------------------------------
     * HTTP requests
     * ----------------------------------------------------------------*/

    public function log_http_request( array $data ): int {
        return $this->db->insert_http_log( $data );
    }

    /* ------------------------------------------------------------------
     * Events / alerts
     * ----------------------------------------------------------------*/

    public function log_event( string $type, string $severity, string $message, array $context = [] ): int {
        $id = $this->db->insert_event( $type, $severity, $message, $context );

        // Fire action so the alerting system can dispatch notifications.
        do_action( 'wppi_event_logged', $type, $severity, $message );

        return $id;
    }

    /* ------------------------------------------------------------------
     * Analysis snapshots
     * ----------------------------------------------------------------*/

    public function save_analysis( string $type, array $data, int $score = 0 ): int {
        return $this->db->save_analysis( $type, $data, $score );
    }

    /* ------------------------------------------------------------------
     * Accessors (delegate reads to Database)
     * ----------------------------------------------------------------*/

    public function get_metrics( string $type, string $range = '24h', int $limit = 500 ): array {
        return $this->db->get_metrics( $type, $range, $limit );
    }

    public function get_http_logs( string $range = '24h', int $limit = 200 ): array {
        return $this->db->get_http_logs( $range, $limit );
    }

    public function get_events( string $range = '24h', string $severity = '', int $limit = 100 ): array {
        return $this->db->get_events( $range, $severity, $limit );
    }

    public function get_latest_analysis( string $type ): ?array {
        return $this->db->get_latest_analysis( $type );
    }
}
