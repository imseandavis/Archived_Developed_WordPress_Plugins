<?php
/**
 * Multisite support — adds a network-wide dashboard and aggregates
 * metrics across all sites in the network.
 *
 * Only active when is_multisite() returns true.
 *
 * Adds a Network Admin menu page that shows per-site scores and
 * a roll-up overview of system resources.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Multisite {

    /** @var WP_Performance_Inspector_Pro */
    private $plugin;

    public function __construct( WP_Performance_Inspector_Pro $plugin ) {
        $this->plugin = $plugin;

        if ( ! is_multisite() ) {
            return;
        }

        add_action( 'network_admin_menu', [ $this, 'register_network_menu' ] );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_network_assets' ] );

        // REST route for network overview.
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    /* ------------------------------------------------------------------
     * Network admin menu
     * ----------------------------------------------------------------*/

    public function register_network_menu(): void {
        add_menu_page(
            __( 'Performance Inspector', 'wp-performance-inspector-pro' ),
            __( 'Perf Inspector', 'wp-performance-inspector-pro' ),
            'manage_network_options',
            'wppi-network',
            [ $this, 'render_network_page' ],
            'dashicons-performance',
            80
        );
    }

    public function enqueue_network_assets( string $hook ): void {
        if ( 'toplevel_page_wppi-network' !== $hook ) {
            return;
        }

        wp_enqueue_script(
            'chartjs',
            WPPI_PLUGIN_URL . 'assets/js/chart.min.js',
            [],
            '4.4.4',
            true
        );

        wp_enqueue_style(
            'wppi-dashboard-css',
            WPPI_PLUGIN_URL . 'assets/css/dashboard.css',
            [],
            WPPI_VERSION
        );

        wp_enqueue_script(
            'wppi-network-js',
            WPPI_PLUGIN_URL . 'assets/js/network-dashboard.js',
            [ 'jquery', 'chartjs' ],
            WPPI_VERSION,
            true
        );

        wp_localize_script( 'wppi-network-js', 'wppiNetData', [
            'restBase' => esc_url_raw( rest_url( 'wppi/v1/' ) ),
            'nonce'    => wp_create_nonce( 'wp_rest' ),
            'sites'    => $this->get_site_list(),
        ] );
    }

    /* ------------------------------------------------------------------
     * Network dashboard page
     * ----------------------------------------------------------------*/

    public function render_network_page(): void {
        if ( ! current_user_can( 'manage_network_options' ) ) {
            wp_die( esc_html__( 'Unauthorized.', 'wp-performance-inspector-pro' ) );
        }
        ?>
        <div class="wrap wppi-wrap">
            <div class="wppi-header">
                <h1 class="wppi-title">
                    <span class="wppi-logo">&#9889;</span>
                    <?php esc_html_e( 'Network Performance Overview', 'wp-performance-inspector-pro' ); ?>
                </h1>
            </div>

            <!-- Shared system resources (one server) -->
            <div class="wppi-gauges-row" id="wppi-net-gauges">
                <div class="wppi-gauge-card">
                    <h3><?php esc_html_e( 'CPU', 'wp-performance-inspector-pro' ); ?></h3>
                    <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-net-cpu-fill"></div></div>
                    <span class="wppi-gauge-val" id="wppi-net-cpu-val">--</span>
                </div>
                <div class="wppi-gauge-card">
                    <h3><?php esc_html_e( 'Memory', 'wp-performance-inspector-pro' ); ?></h3>
                    <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-net-mem-fill"></div></div>
                    <span class="wppi-gauge-val" id="wppi-net-mem-val">--</span>
                </div>
                <div class="wppi-gauge-card">
                    <h3><?php esc_html_e( 'Disk', 'wp-performance-inspector-pro' ); ?></h3>
                    <div class="wppi-gauge-bar"><div class="wppi-gauge-fill" id="wppi-net-disk-fill"></div></div>
                    <span class="wppi-gauge-val" id="wppi-net-disk-val">--</span>
                </div>
                <div class="wppi-gauge-card">
                    <h3><?php esc_html_e( 'Sites', 'wp-performance-inspector-pro' ); ?></h3>
                    <span class="wppi-big-number" id="wppi-net-site-count"><?php echo esc_html( get_blog_count() ); ?></span>
                </div>
            </div>

            <!-- Per-site scores table -->
            <div class="wppi-card">
                <h3><?php esc_html_e( 'Per-Site Performance Scores', 'wp-performance-inspector-pro' ); ?></h3>
                <div class="wppi-card-body wppi-table-wrap" id="wppi-net-sites-body">
                    <p class="wppi-muted"><?php esc_html_e( 'Loading site data...', 'wp-performance-inspector-pro' ); ?></p>
                </div>
            </div>

            <!-- Aggregated events -->
            <div class="wppi-card">
                <h3><?php esc_html_e( 'Recent Network Events', 'wp-performance-inspector-pro' ); ?></h3>
                <div class="wppi-card-body wppi-table-wrap" id="wppi-net-events-body">
                    <p class="wppi-muted"><?php esc_html_e( 'Loading...', 'wp-performance-inspector-pro' ); ?></p>
                </div>
            </div>
        </div>
        <?php
    }

    /* ------------------------------------------------------------------
     * REST routes
     * ----------------------------------------------------------------*/

    public function register_routes(): void {
        register_rest_route( 'wppi/v1', '/network-overview', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'rest_network_overview' ],
            'permission_callback' => function () {
                return current_user_can( 'manage_network_options' );
            },
        ] );
    }

    public function rest_network_overview( WP_REST_Request $request ): WP_REST_Response {
        $sites_data = [];

        $sites = get_sites( [
            'number' => 100,
            'fields' => 'ids',
        ] );

        foreach ( $sites as $site_id ) {
            switch_to_blog( $site_id );

            $db = new WPPI_Database();
            $latest = $db->get_latest_analysis( 'full' );

            $score = null;
            if ( $latest ) {
                $parsed = json_decode( $latest['analysis_data'], true );
                $score  = $parsed['overall_score'] ?? null;
            }

            $sites_data[] = [
                'site_id'   => $site_id,
                'blog_name' => get_bloginfo( 'name' ),
                'site_url'  => get_site_url(),
                'score'     => $score,
                'last_scan' => $latest['recorded_at'] ?? null,
            ];

            restore_current_blog();
        }

        // System snapshot is shared (same server).
        $snapshot = $this->plugin->monitor->get_live_snapshot();

        return new WP_REST_Response( [
            'system' => $snapshot,
            'sites'  => $sites_data,
        ], 200 );
    }

    /* ------------------------------------------------------------------
     * Helpers
     * ----------------------------------------------------------------*/

    private function get_site_list(): array {
        $sites = get_sites( [
            'number' => 100,
            'fields' => 'ids',
        ] );

        $list = [];
        foreach ( $sites as $site_id ) {
            switch_to_blog( $site_id );
            $list[] = [
                'id'   => $site_id,
                'name' => get_bloginfo( 'name' ),
                'url'  => get_site_url(),
            ];
            restore_current_blog();
        }
        return $list;
    }
}
