<?php
/**
 * Report exporter — generates JSON and CSV reports.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Exporter {

    /** @var WPPI_Database */
    private $db;

    public function __construct( WPPI_Database $db ) {
        $this->db = $db;
    }

    /**
     * Generate a full report suitable for export.
     */
    public function generate_report(): array {
        // Latest analysis.
        $analysis_raw = $this->db->get_latest_analysis( 'full' );
        $analysis     = $analysis_raw
            ? json_decode( $analysis_raw['analysis_data'], true )
            : [];

        // Recent metrics.
        $cpu_metrics    = $this->db->get_metrics( 'cpu', '24h', 200 );
        $memory_metrics = $this->db->get_metrics( 'memory', '24h', 200 );
        $disk_metrics   = $this->db->get_metrics( 'disk', '24h', 200 );

        // HTTP logs.
        $http_logs = $this->db->get_http_logs( '24h', 200 );

        // Events.
        $events = $this->db->get_events( '24h', '', 200 );

        return [
            'report_generated' => current_time( 'mysql' ),
            'site_url'         => get_site_url(),
            'overall_score'    => $analysis['overall_score'] ?? null,
            'analysis'         => $analysis,
            'metrics'          => [
                'cpu'    => $cpu_metrics,
                'memory' => $memory_metrics,
                'disk'   => $disk_metrics,
            ],
            'http_log' => $http_logs,
            'events'   => $events,
        ];
    }

    /**
     * Convert report data to CSV.
     */
    public function to_csv( array $report ): string {
        $lines = [];

        // Header.
        $lines[] = 'WP Performance Inspector Pro Report';
        $lines[] = 'Generated: ' . ( $report['report_generated'] ?? '' );
        $lines[] = 'Site: ' . ( $report['site_url'] ?? '' );
        $lines[] = 'Overall Score: ' . ( $report['overall_score'] ?? 'N/A' );
        $lines[] = '';

        // Issues.
        $lines[] = '--- ISSUES ---';
        $lines[] = implode( ',', [ 'Section', 'Severity', 'Message', 'Fix' ] );

        $sections = $report['analysis']['sections'] ?? [];
        foreach ( $sections as $section_name => $section ) {
            $issues = $section['issues'] ?? [];
            foreach ( $issues as $issue ) {
                $lines[] = implode( ',', [
                    $this->csv_escape( $section_name ),
                    $this->csv_escape( $issue['severity'] ?? '' ),
                    $this->csv_escape( $issue['message'] ?? '' ),
                    $this->csv_escape( $issue['fix'] ?? '' ),
                ] );
            }
        }

        $lines[] = '';

        // HTTP log.
        $lines[] = '--- HTTP LOG ---';
        $lines[] = implode( ',', [ 'Time', 'Method', 'URL', 'Status', 'Response Time (s)', 'Error' ] );

        foreach ( $report['http_log'] ?? [] as $entry ) {
            $lines[] = implode( ',', [
                $this->csv_escape( $entry['recorded_at'] ?? '' ),
                $this->csv_escape( $entry['method'] ?? '' ),
                $this->csv_escape( $entry['url'] ?? '' ),
                $entry['response_code'] ?? '',
                $entry['response_time'] ?? '',
                $this->csv_escape( $entry['error_message'] ?? '' ),
            ] );
        }

        $lines[] = '';

        // Events.
        $lines[] = '--- EVENTS ---';
        $lines[] = implode( ',', [ 'Time', 'Type', 'Severity', 'Message' ] );

        foreach ( $report['events'] ?? [] as $event ) {
            $lines[] = implode( ',', [
                $this->csv_escape( $event['recorded_at'] ?? '' ),
                $this->csv_escape( $event['event_type'] ?? '' ),
                $this->csv_escape( $event['severity'] ?? '' ),
                $this->csv_escape( $event['message'] ?? '' ),
            ] );
        }

        return implode( "\n", $lines );
    }

    /**
     * Escape a value for CSV output.
     */
    private function csv_escape( string $value ): string {
        // Wrap in quotes if it contains commas, quotes, or newlines.
        if ( preg_match( '/[,"\n\r]/', $value ) ) {
            return '"' . str_replace( '"', '""', $value ) . '"';
        }
        return $value;
    }
}
