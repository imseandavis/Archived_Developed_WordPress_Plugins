<?php
/**
 * Frontend performance beacon — injects a lightweight JavaScript snippet
 * on every front-end page load to capture real-user metrics (RUM) via the
 * Navigation Timing / Performance API and beacon them back to the site.
 *
 * Collected metrics:
 *   - TTFB (Time to First Byte)
 *   - DOM Content Loaded
 *   - Full page load time
 *   - First Contentful Paint (FCP)
 *   - Largest Contentful Paint (LCP)
 *   - Cumulative Layout Shift (CLS)
 *   - First Input Delay (FID)
 *   - Page URL / referrer
 *
 * Data is sent via navigator.sendBeacon() (or XHR fallback) to a
 * lightweight admin-ajax endpoint, then stored in the metrics table.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class WPPI_Frontend_Beacon {

    /** @var WPPI_Logger */
    private $logger;

    public function __construct( WPPI_Logger $logger ) {
        $this->logger = $logger;

        // Only inject on the front-end, not admin.
        if ( ! is_admin() ) {
            add_action( 'wp_footer', [ $this, 'inject_beacon' ], 9999 );
        }

        // AJAX receiver — works for logged-in AND logged-out users.
        add_action( 'wp_ajax_wppi_beacon',        [ $this, 'receive_beacon' ] );
        add_action( 'wp_ajax_nopriv_wppi_beacon',  [ $this, 'receive_beacon' ] );
    }

    /* ------------------------------------------------------------------
     * Inject the beacon script into <footer>
     * ----------------------------------------------------------------*/

    public function inject_beacon(): void {
        if ( ! (bool) get_option( 'wppi_beacon_enabled', true ) ) {
            return;
        }

        $ajax_url = admin_url( 'admin-ajax.php' );
        $nonce    = wp_create_nonce( 'wppi_beacon' );
        ?>
        <script data-no-optimize="1">
        (function(){
            if (!window.performance || !window.performance.getEntriesByType) return;

            function sendBeacon(){
                var nav = performance.getEntriesByType('navigation')[0] || performance.timing;
                var isNew = !!nav.startTime !== undefined;

                var data = {
                    action: 'wppi_beacon',
                    nonce: '<?php echo esc_js( $nonce ); ?>',
                    url: location.href,
                    referrer: document.referrer || '',
                    ttfb: 0,
                    dom_ready: 0,
                    load_time: 0,
                    fcp: 0,
                    lcp: 0,
                    cls: 0,
                    fid: 0
                };

                /* Navigation Timing (Level 2 preferred) */
                if (nav.responseStart !== undefined) {
                    if (isNew) {
                        data.ttfb      = Math.round(nav.responseStart);
                        data.dom_ready = Math.round(nav.domContentLoadedEventEnd);
                        data.load_time = Math.round(nav.loadEventEnd || nav.duration);
                    } else {
                        var t = nav;
                        data.ttfb      = t.responseStart - t.navigationStart;
                        data.dom_ready = t.domContentLoadedEventEnd - t.navigationStart;
                        data.load_time = t.loadEventEnd - t.navigationStart;
                    }
                }

                /* Paint entries */
                var paints = performance.getEntriesByType('paint');
                for (var i = 0; i < paints.length; i++) {
                    if (paints[i].name === 'first-contentful-paint') {
                        data.fcp = Math.round(paints[i].startTime);
                    }
                }

                /* LCP via PerformanceObserver */
                if (window.__wppi_lcp) data.lcp = Math.round(window.__wppi_lcp);

                /* CLS via PerformanceObserver */
                if (window.__wppi_cls !== undefined) data.cls = Math.round(window.__wppi_cls * 1000); /* x1000 for precision */

                /* FID via PerformanceObserver */
                if (window.__wppi_fid) data.fid = Math.round(window.__wppi_fid);

                /* Send */
                var payload = '';
                for (var k in data) { payload += (payload ? '&' : '') + k + '=' + encodeURIComponent(data[k]); }

                if (navigator.sendBeacon) {
                    navigator.sendBeacon('<?php echo esc_js( $ajax_url ); ?>', payload);
                } else {
                    var xhr = new XMLHttpRequest();
                    xhr.open('POST', '<?php echo esc_js( $ajax_url ); ?>', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.send(payload);
                }
            }

            /* Observe LCP */
            try {
                new PerformanceObserver(function(list){
                    var entries = list.getEntries();
                    if (entries.length) window.__wppi_lcp = entries[entries.length - 1].startTime;
                }).observe({type: 'largest-contentful-paint', buffered: true});
            } catch(e){}

            /* Observe CLS */
            try {
                window.__wppi_cls = 0;
                new PerformanceObserver(function(list){
                    list.getEntries().forEach(function(e){
                        if (!e.hadRecentInput) window.__wppi_cls += e.value;
                    });
                }).observe({type: 'layout-shift', buffered: true});
            } catch(e){}

            /* Observe FID */
            try {
                new PerformanceObserver(function(list){
                    var entries = list.getEntries();
                    if (entries.length) window.__wppi_fid = entries[0].processingStart - entries[0].startTime;
                }).observe({type: 'first-input', buffered: true});
            } catch(e){}

            /* Fire after load event settles */
            if (document.readyState === 'complete') {
                setTimeout(sendBeacon, 500);
            } else {
                window.addEventListener('load', function(){ setTimeout(sendBeacon, 500); });
            }
        })();
        </script>
        <?php
    }

    /* ------------------------------------------------------------------
     * Receive beacon POST from the frontend
     * ----------------------------------------------------------------*/

    public function receive_beacon(): void {
        // Lightweight nonce check — rate-limit by IP so public beacons
        // can't flood the DB.
        if ( ! wp_verify_nonce( $_POST['nonce'] ?? '', 'wppi_beacon' ) ) {
            wp_send_json_error( 'Bad nonce', 403 );
        }

        $url       = esc_url_raw( $_POST['url'] ?? '' );
        $referrer  = esc_url_raw( $_POST['referrer'] ?? '' );
        $ttfb      = floatval( $_POST['ttfb'] ?? 0 );
        $dom_ready = floatval( $_POST['dom_ready'] ?? 0 );
        $load_time = floatval( $_POST['load_time'] ?? 0 );
        $fcp       = floatval( $_POST['fcp'] ?? 0 );
        $lcp       = floatval( $_POST['lcp'] ?? 0 );
        $cls       = floatval( $_POST['cls'] ?? 0 ) / 1000; // Undo the x1000.
        $fid       = floatval( $_POST['fid'] ?? 0 );

        // Basic rate limiting: max 10 beacons per IP per minute.
        $ip  = sanitize_text_field( $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0' );
        $key = 'wppi_beacon_' . md5( $ip );
        $count = (int) get_transient( $key );
        if ( $count >= 10 ) {
            wp_send_json_error( 'Rate limited', 429 );
        }
        set_transient( $key, $count + 1, 60 );

        // Store metrics.
        $extra = [
            'url'       => $url,
            'referrer'  => $referrer,
            'ttfb'      => $ttfb,
            'dom_ready' => $dom_ready,
            'fcp'       => $fcp,
            'lcp'       => $lcp,
            'cls'       => $cls,
            'fid'       => $fid,
        ];

        $this->logger->log_metric( 'frontend', 'page_load', $load_time, $extra );

        if ( $ttfb > 0 ) {
            $this->logger->log_metric( 'frontend', 'ttfb', $ttfb, [ 'url' => $url ] );
        }
        if ( $lcp > 0 ) {
            $this->logger->log_metric( 'frontend', 'lcp', $lcp, [ 'url' => $url ] );
        }
        if ( $fcp > 0 ) {
            $this->logger->log_metric( 'frontend', 'fcp', $fcp, [ 'url' => $url ] );
        }
        if ( $cls > 0 ) {
            $this->logger->log_metric( 'frontend', 'cls', $cls, [ 'url' => $url ] );
        }
        if ( $fid > 0 ) {
            $this->logger->log_metric( 'frontend', 'fid', $fid, [ 'url' => $url ] );
        }

        // Flag slow pages.
        $slow_threshold = (float) get_option( 'wppi_slow_page_threshold', 3000 ); // ms
        if ( $load_time >= $slow_threshold ) {
            $this->logger->log_event(
                'frontend',
                'warning',
                sprintf( 'Slow page load: %dms on %s', (int) $load_time, $url ),
                $extra
            );
        }

        wp_send_json_success();
    }
}
