/**
 * WP Performance Inspector Pro — Dashboard JavaScript v1.1
 *
 * Handles tab navigation, SSE live streaming (with AJAX fallback),
 * chart rendering, scan triggering, export, frontend RUM tab,
 * DB queries tab, and full settings management.
 */
(function ($) {
    'use strict';

    /* ================================================================
     * Config
     * ================================================================*/
    const API     = wppiData.restBase;
    const NONCE   = wppiData.nonce;
    const AJAX    = wppiData.ajaxUrl;
    const AJNONCE = wppiData.ajaxNonce;

    let pollTimer    = null;
    const POLL_INTERVAL = 30000;

    // Chart instances.
    let cpuChart    = null;
    let memoryChart = null;
    let httpChart   = null;
    let rumChart    = null;

    // SSE connection.
    let sseSource = null;

    /* ================================================================
     * Initialization
     * ================================================================*/
    $(document).ready(function () {
        initTabs();
        initButtons();
        loadInitialData();
        initSSE();
    });

    /* ================================================================
     * Server-Sent Events (SSE) — real-time live updates
     * Falls back to AJAX polling if SSE is disabled or fails.
     * ================================================================*/
    function initSSE() {
        if (!wppiData.sseEnabled || typeof EventSource === 'undefined') {
            startPolling();
            return;
        }

        var sseUrl = AJAX + '?action=wppi_sse_stream&nonce=' + encodeURIComponent(wppiData.sseNonce);

        try {
            sseSource = new EventSource(sseUrl);

            sseSource.onmessage = function (event) {
                try {
                    var data = JSON.parse(event.data);
                    updateGaugesFromSSE(data);
                } catch (e) { /* ignore parse errors */ }
            };

            sseSource.addEventListener('done', function () {
                // Server closed the stream — reconnect after a short delay.
                sseSource.close();
                setTimeout(initSSE, 5000);
            });

            sseSource.onerror = function () {
                // SSE failed — fall back to AJAX polling.
                sseSource.close();
                sseSource = null;
                startPolling();
            };
        } catch (e) {
            startPolling();
        }
    }

    function updateGaugesFromSSE(data) {
        // CPU
        var cpuVal = data.cpu.normalized_load ?? data.cpu.cpu_usage_pct ?? data.cpu.load_1 ?? null;
        setGauge('cpu', cpuVal, cpuVal !== null ? cpuVal.toFixed(1) + '%' : 'N/A');

        // Memory
        var memPct = data.memory.system_pct ?? data.memory.php_memory_pct ?? 0;
        setGauge('memory', memPct, memPct.toFixed(1) + '%');

        // Disk
        var diskPct = data.disk.disk_pct ?? 0;
        setGauge('disk', diskPct, diskPct.toFixed(1) + '%');

        // Network
        if (data.network) {
            var errRate = data.network.error_rate ?? 0;
            setGauge('http', errRate, (data.network.total_requests || 0) + ' req');
            $('#wppi-http-fill').css('background', errRate > 10 ? '#ef4444' : errRate > 5 ? '#f59e0b' : '#22c55e');
        }

        // Update the SSE status indicator.
        $('#wppi-sse-status').remove();
        $('.wppi-header-actions').prepend('<span id="wppi-sse-status" class="wppi-badge wppi-badge-success" style="line-height:32px;margin-right:8px;">LIVE</span>');
    }

    /* ================================================================
     * Tabs
     * ================================================================*/
    function initTabs() {
        $('.wppi-tab').on('click', function (e) {
            e.preventDefault();
            var tab = $(this).data('tab');

            $('.wppi-tab').removeClass('active');
            $(this).addClass('active');

            $('.wppi-panel').removeClass('active');
            $('#wppi-panel-' + tab).addClass('active');

            // Lazy-load tab content.
            if (tab === 'events')   loadEvents();
            if (tab === 'network')  loadNetworkData();
            if (tab === 'frontend') loadFrontendRUM();
            if (tab === 'queries')  loadDBQueries();
        });
    }

    /* ================================================================
     * Button handlers
     * ================================================================*/
    function initButtons() {
        $('#wppi-run-scan').on('click', runScan);
        $('#wppi-export-json').on('click', function () { exportReport('json'); });
        $('#wppi-export-csv').on('click', function () { exportReport('csv'); });
        $('#wppi-save-settings').on('click', saveSettings);
        $('#wppi-events-filter').on('change', loadEvents);
    }

    /* ================================================================
     * Initial data load
     * ================================================================*/
    function loadInitialData() {
        fetchSnapshot();
        fetchMetrics('cpu', '24h', renderCpuChart);
        fetchMetrics('memory', '24h', renderMemoryChart);
        loadNetworkData();
        loadLatestAnalysis();
    }

    /* ================================================================
     * AJAX fallback polling (used when SSE is unavailable)
     * ================================================================*/
    function startPolling() {
        if (pollTimer) return; // Don't double-start.
        pollTimer = setInterval(function () {
            fetchSnapshot();
        }, POLL_INTERVAL);
    }

    /* ================================================================
     * REST helpers
     * ================================================================*/
    function apiFetch(endpoint, method, data) {
        var opts = {
            url: API + endpoint,
            method: method || 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', NONCE);
            },
        };
        if (data) opts.data = data;
        return $.ajax(opts);
    }

    /* ================================================================
     * Snapshot (live gauges — AJAX path)
     * ================================================================*/
    function fetchSnapshot() {
        apiFetch('snapshot').done(function (data) {
            updateGauges(data);
            updateSystemPanel(data);
        });
    }

    function updateGauges(data) {
        var cpuVal = data.cpu.normalized_load ?? data.cpu.cpu_usage_pct ?? data.cpu.load_1 ?? null;
        setGauge('cpu', cpuVal, cpuVal !== null ? cpuVal.toFixed(1) + '%' : 'N/A');

        var memPct = data.memory.system_pct ?? data.memory.php_memory_pct ?? 0;
        setGauge('memory', memPct, memPct.toFixed(1) + '%');

        var diskPct = data.disk.disk_pct ?? 0;
        setGauge('disk', diskPct, diskPct.toFixed(1) + '%');

        apiFetch('network-summary?range=24h').done(function (ns) {
            var errRate = ns.error_rate ?? 0;
            setGauge('http', errRate, ns.total_requests + ' req');
            $('#wppi-http-fill').css('background', errRate > 10 ? '#ef4444' : errRate > 5 ? '#f59e0b' : '#22c55e');
        });
    }

    function setGauge(id, pct, label) {
        var fill = $('#wppi-' + id + '-fill');
        var val  = $('#wppi-' + id + '-val');
        var clamped = Math.min(100, Math.max(0, pct || 0));

        fill.css('width', clamped + '%');
        fill.css('background', gaugeColor(clamped));
        val.text(label);
    }

    function gaugeColor(pct) {
        if (pct >= 90) return '#ef4444';
        if (pct >= 70) return '#f59e0b';
        return '#22c55e';
    }

    /* ================================================================
     * System panel
     * ================================================================*/
    function updateSystemPanel(data) {
        var cpuHtml = '<table class="wppi-data-table">';
        if (data.cpu.cpu_usage_pct !== undefined) cpuHtml += row('CPU Usage', data.cpu.cpu_usage_pct + '%');
        if (data.cpu.load_1 !== undefined)        cpuHtml += row('Load Avg (1m)', data.cpu.load_1);
        if (data.cpu.load_5 !== undefined)        cpuHtml += row('Load Avg (5m)', data.cpu.load_5);
        if (data.cpu.load_15 !== undefined)       cpuHtml += row('Load Avg (15m)', data.cpu.load_15);
        if (data.cpu.cpu_cores !== undefined)      cpuHtml += row('CPU Cores', data.cpu.cpu_cores);
        if (data.cpu.normalized_load !== undefined) cpuHtml += row('Normalized Load', data.cpu.normalized_load + '%');
        cpuHtml += '</table>';
        $('#wppi-sys-cpu-body').html(cpuHtml);

        var memHtml = '<table class="wppi-data-table">';
        memHtml += row('PHP Memory Used', formatBytes(data.memory.php_memory_used));
        memHtml += row('PHP Memory Peak', formatBytes(data.memory.php_memory_peak));
        memHtml += row('PHP Memory Limit', formatBytes(data.memory.php_memory_limit));
        memHtml += row('PHP Memory Usage', (data.memory.php_memory_pct || 0) + '%');
        if (data.memory.system_total) {
            memHtml += row('System Total', formatBytes(data.memory.system_total));
            memHtml += row('System Used', formatBytes(data.memory.system_used));
            memHtml += row('System Available', formatBytes(data.memory.system_available));
            memHtml += row('System Usage', data.memory.system_pct + '%');
        }
        memHtml += '</table>';
        $('#wppi-sys-mem-body').html(memHtml);

        var diskHtml = '<table class="wppi-data-table">';
        if (data.disk.disk_total) diskHtml += row('Total', formatBytes(data.disk.disk_total));
        if (data.disk.disk_used)  diskHtml += row('Used', formatBytes(data.disk.disk_used));
        if (data.disk.disk_free)  diskHtml += row('Free', formatBytes(data.disk.disk_free));
        if (data.disk.disk_pct !== undefined) diskHtml += row('Usage', data.disk.disk_pct + '%');
        if (data.disk.uploads_size) diskHtml += row('Uploads Dir', formatBytes(data.disk.uploads_size));
        if (data.disk.plugins_size) diskHtml += row('Plugins Dir', formatBytes(data.disk.plugins_size));
        if (data.disk.themes_size)  diskHtml += row('Themes Dir', formatBytes(data.disk.themes_size));
        diskHtml += '</table>';
        $('#wppi-sys-disk-body').html(diskHtml);

        if (data.php) {
            var phpHtml = '<table class="wppi-data-table">';
            phpHtml += row('PHP Version', data.php.php_version);
            phpHtml += row('SAPI', data.php.php_sapi);
            phpHtml += row('Max Execution Time', data.php.max_execution_time + 's');
            phpHtml += row('Upload Max', formatBytes(data.php.upload_max));
            phpHtml += row('Post Max', formatBytes(data.php.post_max));
            phpHtml += row('OPcache', data.php.opcache_enabled ? '<span class="wppi-badge wppi-badge-success">Enabled</span>' : '<span class="wppi-badge wppi-badge-danger">Disabled</span>');
            phpHtml += '</table>';
            $('#wppi-sys-php-body').html(phpHtml);
        }

        if (data.server) {
            var capHtml = '<table class="wppi-data-table">';
            capHtml += row('Server Software', data.server.software);
            capHtml += row('Hostname', data.server.hostname);
            capHtml += row('OS', data.server.os);
            capHtml += row('Architecture', data.server.arch);
            capHtml += row('64-bit', data.server.is_64bit ? 'Yes' : 'No');
            capHtml += '</table>';

            apiFetch('capabilities').done(function (caps) {
                capHtml += '<h4 style="margin-top:16px;">Monitoring Capabilities</h4><table class="wppi-data-table">';
                for (var k in caps) {
                    capHtml += row(k.replace(/_/g, ' '), caps[k] ? '<span class="wppi-badge wppi-badge-success">Available</span>' : '<span class="wppi-badge wppi-badge-warning">Unavailable</span>');
                }
                capHtml += '</table>';
                $('#wppi-capabilities-body').html(capHtml);
            });
        }
    }

    /* ================================================================
     * Charts
     * ================================================================*/
    function fetchMetrics(type, range, callback) {
        apiFetch('metrics/' + type + '?range=' + range).done(callback);
    }

    function renderCpuChart(data) {
        var ctx = document.getElementById('wppi-chart-cpu');
        if (!ctx) return;
        var labels = [], values = [];
        data.forEach(function (m) {
            if (m.metric_key === 'normalized_load' || m.metric_key === 'cpu_usage_pct' || m.metric_key === 'load_1') {
                labels.push(formatTime(m.recorded_at));
                values.push(parseFloat(m.metric_value));
            }
        });
        if (cpuChart) cpuChart.destroy();
        cpuChart = createLineChart(ctx, 'CPU Usage %', labels, values, '#6366f1');
    }

    function renderMemoryChart(data) {
        var ctx = document.getElementById('wppi-chart-memory');
        if (!ctx) return;
        var labels = [], values = [];
        data.forEach(function (m) {
            if (m.metric_key === 'php_memory_pct' || m.metric_key === 'system_pct') {
                labels.push(formatTime(m.recorded_at));
                values.push(parseFloat(m.metric_value));
            }
        });
        if (memoryChart) memoryChart.destroy();
        memoryChart = createLineChart(ctx, 'Memory Usage %', labels, values, '#8b5cf6');
    }

    function renderHttpChart(data) {
        var ctx = document.getElementById('wppi-chart-http');
        if (!ctx) return;
        var labels = [], values = [];
        data.slice(0, 100).reverse().forEach(function (entry) {
            labels.push(formatTime(entry.recorded_at));
            values.push(parseFloat(entry.response_time) * 1000);
        });
        if (httpChart) httpChart.destroy();
        httpChart = createLineChart(ctx, 'Response Time (ms)', labels, values, '#f59e0b');
    }

    function createLineChart(ctx, label, labels, data, color) {
        return new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: label, data: data,
                    borderColor: color, backgroundColor: color + '20',
                    fill: true, tension: 0.3, pointRadius: 2,
                    pointHoverRadius: 5, borderWidth: 2,
                }],
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                interaction: { intersect: false, mode: 'index' },
                plugins: {
                    legend: { display: false },
                    tooltip: { backgroundColor: '#1e293b', titleColor: '#e2e8f0', bodyColor: '#e2e8f0', cornerRadius: 8, padding: 12 },
                },
                scales: {
                    x: { display: true, ticks: { maxTicksLimit: 10, color: '#94a3b8', font: { size: 11 } }, grid: { color: '#1e293b22' } },
                    y: { display: true, beginAtZero: true, ticks: { color: '#94a3b8', font: { size: 11 } }, grid: { color: '#1e293b22' } },
                },
            },
        });
    }

    /* ================================================================
     * Network tab
     * ================================================================*/
    function loadNetworkData() {
        apiFetch('network-summary?range=24h').done(function (data) {
            $('#wppi-net-total').text(data.total_requests);
            $('#wppi-net-avg').text(data.avg_response_ms + ' ms');
            $('#wppi-net-failed').text(data.failed_requests);
            $('#wppi-net-slow').text(data.slow_requests);

            if (data.top_domains && Object.keys(data.top_domains).length) {
                var html = '<table class="wppi-data-table"><tr><th>Domain</th><th>Requests</th></tr>';
                for (var domain in data.top_domains) {
                    html += '<tr><td>' + escHtml(domain) + '</td><td>' + data.top_domains[domain] + '</td></tr>';
                }
                html += '</table>';
                $('#wppi-net-domains').html(html);
            } else {
                $('#wppi-net-domains').html('<p class="wppi-muted">No data yet.</p>');
            }
        });

        apiFetch('http-log?range=24h').done(function (data) {
            if (!data.length) {
                $('#wppi-net-log').html('<p class="wppi-muted">No HTTP requests logged yet.</p>');
                return;
            }
            var html = '<table class="wppi-data-table"><tr><th>Time</th><th>Method</th><th>URL</th><th>Status</th><th>Time</th><th>Error</th></tr>';
            data.slice(0, 50).forEach(function (entry) {
                var statusClass = entry.response_code >= 400 ? 'wppi-text-danger' : (entry.response_code >= 300 ? 'wppi-text-warning' : '');
                html += '<tr>';
                html += '<td class="wppi-nowrap">' + formatTime(entry.recorded_at) + '</td>';
                html += '<td>' + escHtml(entry.method) + '</td>';
                html += '<td class="wppi-truncate" title="' + escHtml(entry.url) + '">' + escHtml(truncateUrl(entry.url)) + '</td>';
                html += '<td class="' + statusClass + '">' + (entry.response_code || '-') + '</td>';
                html += '<td>' + (parseFloat(entry.response_time) * 1000).toFixed(0) + ' ms</td>';
                html += '<td class="wppi-text-danger">' + escHtml(entry.error_message || '') + '</td>';
                html += '</tr>';
            });
            html += '</table>';
            $('#wppi-net-log').html(html);
            renderHttpChart(data);
        });
    }

    /* ================================================================
     * Frontend RUM tab
     * ================================================================*/
    function loadFrontendRUM() {
        apiFetch('frontend-metrics?range=24h').done(function (data) {
            $('#wppi-rum-load').text(data.avg_load_time ? data.avg_load_time + ' ms' : 'N/A');
            $('#wppi-rum-ttfb').text(data.avg_ttfb ? data.avg_ttfb + ' ms' : 'N/A');
            $('#wppi-rum-fcp').text(data.avg_fcp ? data.avg_fcp + ' ms' : 'N/A');
            $('#wppi-rum-lcp').text(data.avg_lcp ? data.avg_lcp + ' ms' : 'N/A');
            $('#wppi-rum-cls').text(data.avg_cls !== undefined ? data.avg_cls.toFixed(3) : 'N/A');
            $('#wppi-rum-fid').text(data.avg_fid ? data.avg_fid + ' ms' : 'N/A');
            $('#wppi-rum-samples').text(data.samples || 0);
            $('#wppi-rum-slow').text(data.slow_pages || 0);

            // Chart.
            var recent = data.recent || [];
            if (recent.length) {
                var labels = [], values = [];
                recent.forEach(function (r) {
                    labels.push(formatTime(r.recorded_at));
                    values.push(r.load_time);
                });
                var ctx = document.getElementById('wppi-chart-rum');
                if (ctx) {
                    if (rumChart) rumChart.destroy();
                    rumChart = createLineChart(ctx, 'Page Load (ms)', labels, values, '#10b981');
                }

                // Table.
                var html = '<table class="wppi-data-table"><tr><th>Time</th><th>URL</th><th>Load</th><th>TTFB</th><th>FCP</th><th>LCP</th><th>CLS</th></tr>';
                recent.slice(0, 30).forEach(function (r) {
                    html += '<tr>';
                    html += '<td class="wppi-nowrap">' + formatTime(r.recorded_at) + '</td>';
                    html += '<td class="wppi-truncate" title="' + escHtml(r.url) + '">' + escHtml(truncateUrl(r.url)) + '</td>';
                    html += '<td>' + Math.round(r.load_time) + '</td>';
                    html += '<td>' + Math.round(r.ttfb) + '</td>';
                    html += '<td>' + Math.round(r.fcp) + '</td>';
                    html += '<td>' + Math.round(r.lcp) + '</td>';
                    html += '<td>' + (r.cls || 0).toFixed(3) + '</td>';
                    html += '</tr>';
                });
                html += '</table>';
                $('#wppi-rum-table').html(html);
            } else {
                $('#wppi-rum-table').html('<p class="wppi-muted">No beacon data yet. Data appears as visitors browse your site.</p>');
            }
        });
    }

    /* ================================================================
     * DB Queries tab
     * ================================================================*/
    function loadDBQueries() {
        apiFetch('db-summary?range=24h').done(function (data) {
            if (data.message) {
                // Query monitor not enabled.
                return;
            }
            $('#wppi-db-avg-count').text(data.avg_query_count || '--');
            $('#wppi-db-avg-time').text(data.avg_total_time_ms ? data.avg_total_time_ms + ' ms' : '--');
            $('#wppi-db-avg-per').text(data.avg_per_query_ms ? data.avg_per_query_ms + ' ms' : '--');
            $('#wppi-db-slow-total').text(data.total_slow || 0);
        });

        apiFetch('slow-queries?range=24h').done(function (data) {
            if (!data || !data.length) {
                if ($('#wppi-setting-query-monitor').is(':checked')) {
                    $('#wppi-db-slow-table').html('<p class="wppi-muted">No slow queries recorded yet.</p>');
                }
                return;
            }

            var html = '<table class="wppi-data-table"><tr><th>Time</th><th>Duration (ms)</th><th>SQL</th><th>Caller</th></tr>';
            data.forEach(function (batch) {
                var queries = batch.queries || [];
                queries.forEach(function (q) {
                    html += '<tr>';
                    html += '<td class="wppi-nowrap">' + formatTime(batch.recorded_at) + '</td>';
                    html += '<td class="' + (q.duration > 100 ? 'wppi-text-danger' : 'wppi-text-warning') + '">' + q.duration + '</td>';
                    html += '<td class="wppi-truncate" title="' + escHtml(q.sql) + '">' + escHtml(q.sql ? q.sql.substring(0, 80) : '') + '</td>';
                    html += '<td class="wppi-truncate">' + escHtml(q.caller || '') + '</td>';
                    html += '</tr>';
                });
            });
            html += '</table>';
            $('#wppi-db-slow-table').html(html);
        });
    }

    /* ================================================================
     * Events tab
     * ================================================================*/
    function loadEvents() {
        var severity = $('#wppi-events-filter').val() || '';
        apiFetch('events?range=7d&severity=' + severity).done(function (data) {
            if (!data.length) {
                $('#wppi-events-body').html('<p class="wppi-muted">No events in the last 7 days.</p>');
                return;
            }
            var html = '<table class="wppi-data-table"><tr><th>Time</th><th>Type</th><th>Severity</th><th>Message</th></tr>';
            data.forEach(function (ev) {
                var sevClass = ev.severity === 'critical' ? 'wppi-badge-danger'
                    : ev.severity === 'warning' ? 'wppi-badge-warning'
                    : ev.severity === 'error' ? 'wppi-badge-danger'
                    : 'wppi-badge-info';
                html += '<tr>';
                html += '<td class="wppi-nowrap">' + formatTime(ev.recorded_at) + '</td>';
                html += '<td>' + escHtml(ev.event_type) + '</td>';
                html += '<td><span class="wppi-badge ' + sevClass + '">' + escHtml(ev.severity) + '</span></td>';
                html += '<td>' + escHtml(ev.message) + '</td>';
                html += '</tr>';
            });
            html += '</table>';
            $('#wppi-events-body').html(html);
        });
    }

    /* ================================================================
     * Analysis / scan
     * ================================================================*/
    function runScan() {
        $('#wppi-loading').show();
        $('#wppi-run-scan').prop('disabled', true).text('Scanning...');

        $.post(AJAX, { action: 'wppi_run_scan', nonce: AJNONCE }).done(function (response) {
            if (response.success) {
                var d = response.data;
                renderAnalysis(d.analysis);
                updateGauges(d.system);
                updateSystemPanel(d.system);
                fetchMetrics('cpu', '24h', renderCpuChart);
                fetchMetrics('memory', '24h', renderMemoryChart);
            }
        }).always(function () {
            $('#wppi-loading').hide();
            $('#wppi-run-scan').prop('disabled', false).text('Run Full Scan');
        });
    }

    function loadLatestAnalysis() {
        apiFetch('analysis').done(function (data) {
            if (data && data.analysis_data) renderAnalysis(data.analysis_data);
        });
    }

    function renderAnalysis(analysis) {
        var score = analysis.overall_score || 0;
        updateScoreRing(score);

        var allIssues = [];
        var sections = analysis.sections || {};
        for (var name in sections) {
            (sections[name].issues || []).forEach(function (issue) {
                allIssues.push($.extend({ section: name }, issue));
            });
        }

        var sevOrder = { critical: 0, warning: 1, error: 1, info: 2 };
        allIssues.sort(function (a, b) { return (sevOrder[a.severity] || 3) - (sevOrder[b.severity] || 3); });

        if (allIssues.length) {
            var html = '';
            allIssues.forEach(function (issue) {
                var icon = issue.severity === 'critical' || issue.severity === 'warning' ? '&#9888;' : '&#8505;';
                var cls = issue.severity === 'critical' ? 'wppi-issue-critical' : issue.severity === 'warning' ? 'wppi-issue-warning' : 'wppi-issue-info';
                html += '<div class="wppi-issue ' + cls + '">';
                html += '<span class="wppi-issue-icon">' + icon + '</span>';
                html += '<div class="wppi-issue-content">';
                html += '<strong>' + escHtml(issue.message) + '</strong>';
                if (issue.fix) html += '<p class="wppi-issue-fix">' + escHtml(issue.fix) + '</p>';
                html += '</div>';
                html += '<span class="wppi-badge wppi-badge-' + (issue.severity === 'info' ? 'info' : issue.severity === 'warning' ? 'warning' : 'danger') + '">' + escHtml(issue.severity) + '</span>';
                html += '</div>';
            });
            $('#wppi-issues-list').html(html);
        } else {
            $('#wppi-issues-list').html('<p class="wppi-text-success" style="padding:16px;">No issues found. Your site looks healthy!</p>');
        }

        renderWpSection('core', sections.wordpress);
        renderWpSection('db', sections.database);
        renderWpSection('plugins', sections.plugins);
        renderWpSection('cache', sections.caching);
        renderWpSection('themes', sections.themes);
        renderWpSection('security', sections.security);

        var recsHtml = '';
        allIssues.forEach(function (issue) {
            if (issue.fix) {
                recsHtml += '<div class="wppi-rec"><span class="wppi-rec-section">' + escHtml(issue.section) + '</span> ' + escHtml(issue.fix) + '</div>';
            }
        });
        $('#wppi-wp-recommendations').html(recsHtml || '<p class="wppi-muted">No recommendations.</p>');
    }

    function renderWpSection(id, section) {
        if (!section) return;
        var target = $('#wppi-wp-' + id + '-body');
        var html = '<div class="wppi-section-score"><span class="wppi-badge ' + scoreBadgeClass(section.score) + '">Score: ' + section.score + '</span></div>';
        html += '<table class="wppi-data-table">';
        var data = section.data || {};
        for (var key in data) {
            if (key === 'table_sizes' || key === 'extensions' || key === 'inactive_plugins' || key === 'outdated_plugins') continue;
            var display = data[key];
            if (typeof display === 'boolean') {
                display = display ? '<span class="wppi-badge wppi-badge-success">Yes</span>' : '<span class="wppi-badge wppi-badge-danger">No</span>';
            } else if (typeof display === 'number' && key.indexOf('size') >= 0 && key.indexOf('byte') >= 0) {
                display = formatBytes(display);
            }
            html += row(key.replace(/_/g, ' '), display);
        }
        html += '</table>';
        if (section.issues && section.issues.length) {
            html += '<div class="wppi-section-issues">';
            section.issues.forEach(function (issue) {
                var cls = issue.severity === 'critical' ? 'wppi-issue-critical' : issue.severity === 'warning' ? 'wppi-issue-warning' : 'wppi-issue-info';
                html += '<div class="wppi-issue-mini ' + cls + '">' + escHtml(issue.message) + '</div>';
            });
            html += '</div>';
        }
        target.html(html);
    }

    function updateScoreRing(score) {
        var circle = document.getElementById('wppi-score-circle');
        var valueEl = document.getElementById('wppi-score-value');
        if (!circle || !valueEl) return;
        var circumference = 2 * Math.PI * 54;
        var offset = circumference - (score / 100) * circumference;
        circle.style.strokeDasharray = circumference;
        circle.style.strokeDashoffset = offset;
        var color = score >= 80 ? '#22c55e' : score >= 50 ? '#f59e0b' : '#ef4444';
        circle.style.stroke = color;
        valueEl.textContent = score;
        valueEl.style.color = color;
    }

    /* ================================================================
     * Export
     * ================================================================*/
    function exportReport(format) {
        $.post(AJAX, { action: 'wppi_export', nonce: AJNONCE, format: format }).done(function (response) {
            if (!response.success) return;
            var d = response.data;
            var blob = new Blob([d.content], { type: format === 'json' ? 'application/json' : 'text/csv' });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url; a.download = d.filename; a.click();
            URL.revokeObjectURL(url);
        });
    }

    /* ================================================================
     * Settings (extended for all new features)
     * ================================================================*/
    function saveSettings() {
        // Collect alert severity checkboxes.
        var severities = [];
        $('.wppi-alert-severity:checked').each(function () { severities.push($(this).val()); });

        var data = {
            action: 'wppi_save_settings',
            nonce: AJNONCE,
            // Core settings.
            interval:  $('#wppi-setting-interval').val(),
            retention: $('#wppi-setting-retention').val(),
            slow_http: $('#wppi-setting-slow-http').val(),
            cpu_warn:  $('#wppi-thresh-cpu-warn').val(),
            cpu_crit:  $('#wppi-thresh-cpu-crit').val(),
            mem_warn:  $('#wppi-thresh-mem-warn').val(),
            mem_crit:  $('#wppi-thresh-mem-crit').val(),
            disk_warn: $('#wppi-thresh-disk-warn').val(),
            disk_crit: $('#wppi-thresh-disk-crit').val(),
            // Feature toggles.
            beacon_enabled:       $('#wppi-setting-beacon').is(':checked') ? 1 : 0,
            slow_page_threshold:  $('#wppi-setting-slow-page').val(),
            query_monitor_enabled: $('#wppi-setting-query-monitor').is(':checked') ? 1 : 0,
            slow_query_threshold: $('#wppi-setting-slow-query').val(),
            sse_enabled:          $('#wppi-setting-sse').is(':checked') ? 1 : 0,
            sse_interval:         $('#wppi-setting-sse-interval').val(),
            // Alert settings.
            alert_email_enabled:    $('#wppi-alert-email-enabled').is(':checked') ? 1 : 0,
            alert_email_recipients: $('#wppi-alert-email-recipients').val(),
            alert_slack_enabled:    $('#wppi-alert-slack-enabled').is(':checked') ? 1 : 0,
            alert_slack_webhook:    $('#wppi-alert-slack-webhook').val(),
            'alert_severities[]':   severities,
            alert_cooldown:         $('#wppi-alert-cooldown').val(),
        };

        $.post(AJAX, data).done(function (response) {
            if (response.success) {
                $('#wppi-settings-status').text('Saved!').show().delay(2000).fadeOut();
            }
        });
    }

    /* ================================================================
     * Utilities
     * ================================================================*/
    function row(label, value) {
        return '<tr><td class="wppi-label">' + escHtml(label.charAt(0).toUpperCase() + label.slice(1)) + '</td><td>' + value + '</td></tr>';
    }

    function formatBytes(bytes) {
        if (!bytes || bytes === 0) return '0 B';
        var sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
        var i = Math.floor(Math.log(Math.abs(bytes)) / Math.log(1024));
        return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
    }

    function formatTime(dateStr) {
        if (!dateStr) return '';
        var d = new Date(dateStr.replace(' ', 'T'));
        return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    }

    function truncateUrl(url) {
        if (!url) return '';
        if (url.length <= 60) return url;
        return url.substring(0, 57) + '...';
    }

    function escHtml(str) {
        if (str === null || str === undefined) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

    function scoreBadgeClass(score) {
        if (score >= 80) return 'wppi-badge-success';
        if (score >= 50) return 'wppi-badge-warning';
        return 'wppi-badge-danger';
    }

})(jQuery);
