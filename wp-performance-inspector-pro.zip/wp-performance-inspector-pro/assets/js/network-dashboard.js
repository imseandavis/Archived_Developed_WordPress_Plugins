/**
 * WP Performance Inspector Pro — Network (Multisite) Dashboard JS
 */
(function ($) {
    'use strict';

    const API   = wppiNetData.restBase;
    const NONCE = wppiNetData.nonce;

    $(document).ready(function () {
        loadNetworkOverview();
    });

    function apiFetch(endpoint) {
        return $.ajax({
            url: API + endpoint,
            method: 'GET',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', NONCE);
            },
        });
    }

    function loadNetworkOverview() {
        apiFetch('network-overview').done(function (data) {
            // System gauges (shared server).
            var cpu = data.system.cpu || {};
            var mem = data.system.memory || {};
            var disk = data.system.disk || {};

            setGauge('net-cpu', cpu.normalized_load || cpu.cpu_usage_pct || cpu.load_1 || 0,
                (cpu.normalized_load || cpu.cpu_usage_pct || cpu.load_1 || 0).toFixed(1) + '%');
            setGauge('net-mem', mem.system_pct || mem.php_memory_pct || 0,
                (mem.system_pct || mem.php_memory_pct || 0).toFixed(1) + '%');
            setGauge('net-disk', disk.disk_pct || 0, (disk.disk_pct || 0).toFixed(1) + '%');

            // Sites table.
            var sites = data.sites || [];
            if (!sites.length) {
                $('#wppi-net-sites-body').html('<p class="wppi-muted">No sites found.</p>');
                return;
            }

            var html = '<table class="wppi-data-table"><tr><th>Site</th><th>URL</th><th>Score</th><th>Last Scan</th></tr>';
            sites.forEach(function (s) {
                var scoreClass = s.score === null ? '' : (s.score >= 80 ? 'wppi-badge-success' : s.score >= 50 ? 'wppi-badge-warning' : 'wppi-badge-danger');
                var scoreHtml  = s.score !== null ? '<span class="wppi-badge ' + scoreClass + '">' + s.score + '</span>' : '<span class="wppi-muted">N/A</span>';
                html += '<tr>';
                html += '<td>' + escHtml(s.blog_name) + '</td>';
                html += '<td>' + escHtml(s.site_url) + '</td>';
                html += '<td>' + scoreHtml + '</td>';
                html += '<td>' + (s.last_scan || 'Never') + '</td>';
                html += '</tr>';
            });
            html += '</table>';
            $('#wppi-net-sites-body').html(html);
        }).fail(function () {
            $('#wppi-net-sites-body').html('<p class="wppi-muted">Failed to load network data.</p>');
        });
    }

    function setGauge(id, pct, label) {
        var fill = $('#wppi-' + id + '-fill');
        var val  = $('#wppi-' + id + '-val');
        var clamped = Math.min(100, Math.max(0, pct || 0));

        fill.css('width', clamped + '%');
        fill.css('background', clamped >= 90 ? '#ef4444' : clamped >= 70 ? '#f59e0b' : '#22c55e');
        val.text(label);
    }

    function escHtml(str) {
        if (!str) return '';
        var div = document.createElement('div');
        div.appendChild(document.createTextNode(String(str)));
        return div.innerHTML;
    }

})(jQuery);
