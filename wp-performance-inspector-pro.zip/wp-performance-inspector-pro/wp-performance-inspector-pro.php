<?php
/**
 * Plugin Name: WP Performance Inspector Pro
 * Plugin URI: https://github.com/imseandavis/wp-performance-inspector-pro
 * Description: A mini observability platform inside WordPress — combining APM, server resource monitoring, frontend performance insights, and actionable optimization recommendations.
 * Version: 1.1.0
 * Author: Sean Davis
 * Author URI: https://seandavis.com
 * License: GPL-2.0+
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-performance-inspector-pro
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 */

// Prevent direct access.
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

// Plugin constants.
define( 'WPPI_VERSION', '1.1.0' );
define( 'WPPI_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPPI_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPPI_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'WPPI_DB_VERSION', '1.0.0' );

/**
 * Main plugin class — bootstraps all components.
 */
final class WP_Performance_Inspector_Pro {

    /** @var self|null Singleton instance. */
    private static $instance = null;

    /** @var WPPI_Database */
    public $database;

    /** @var WPPI_Monitor */
    public $monitor;

    /** @var WPPI_Analyzer */
    public $analyzer;

    /** @var WPPI_Logger */
    public $logger;

    /** @var WPPI_Network_Monitor */
    public $network_monitor;

    /** @var WPPI_Dashboard */
    public $dashboard;

    /** @var WPPI_REST_API */
    public $rest_api;

    /** @var WPPI_Exporter */
    public $exporter;

    /** @var WPPI_Scheduler */
    public $scheduler;

    /** @var WPPI_SSE_Handler */
    public $sse_handler;

    /** @var WPPI_Frontend_Beacon */
    public $frontend_beacon;

    /** @var WPPI_Alerting */
    public $alerting;

    /** @var WPPI_Query_Monitor */
    public $query_monitor;

    /** @var WPPI_Multisite */
    public $multisite;

    /** @var float Page generation start time. */
    private $start_time;

    /**
     * Get singleton instance.
     */
    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    /**
     * Constructor — wire everything up.
     */
    private function __construct() {
        $this->start_time = microtime( true );

        // Load dependencies.
        $this->load_includes();

        // Initialize components.
        add_action( 'plugins_loaded', [ $this, 'init_components' ] );

        // Activation / deactivation hooks.
        register_activation_hook( __FILE__, [ $this, 'activate' ] );
        register_deactivation_hook( __FILE__, [ $this, 'deactivate' ] );
    }

    /**
     * Require all class files.
     */
    private function load_includes(): void {
        $includes = [
            'includes/class-database.php',
            'includes/class-monitor.php',
            'includes/class-analyzer.php',
            'includes/class-logger.php',
            'includes/class-network-monitor.php',
            'includes/class-dashboard.php',
            'includes/class-rest-api.php',
            'includes/class-exporter.php',
            'includes/class-scheduler.php',
            'includes/class-sse-handler.php',
            'includes/class-frontend-beacon.php',
            'includes/class-alerting.php',
            'includes/class-query-monitor.php',
            'includes/class-multisite.php',
            'includes/class-wp-cli.php',
        ];

        foreach ( $includes as $file ) {
            $path = WPPI_PLUGIN_DIR . $file;
            if ( file_exists( $path ) ) {
                require_once $path;
            }
        }
    }

    /**
     * Boot every subsystem.
     */
    public function init_components(): void {
        $this->database        = new WPPI_Database();
        $this->logger          = new WPPI_Logger( $this->database );
        $this->monitor         = new WPPI_Monitor( $this->logger );
        $this->analyzer        = new WPPI_Analyzer( $this->logger );
        $this->network_monitor = new WPPI_Network_Monitor( $this->logger );
        $this->exporter        = new WPPI_Exporter( $this->database );
        $this->scheduler       = new WPPI_Scheduler( $this->monitor, $this->analyzer );
        $this->rest_api        = new WPPI_REST_API( $this );

        // SSE real-time handler.
        $this->sse_handler = new WPPI_SSE_Handler( $this );

        // Frontend beacon for RUM data.
        $this->frontend_beacon = new WPPI_Frontend_Beacon( $this->logger );

        // Alerting (email/Slack).
        $this->alerting = new WPPI_Alerting( $this->logger );

        // Query monitor (slow SQL detection).
        $this->query_monitor = new WPPI_Query_Monitor( $this->logger );

        // Multisite support.
        $this->multisite = new WPPI_Multisite( $this );

        if ( is_admin() ) {
            $this->dashboard = new WPPI_Dashboard( $this );
        }

        // Register WP-CLI commands.
        if ( defined( 'WP_CLI' ) && WP_CLI ) {
            WP_CLI::add_command( 'perf-inspector', 'WPPI_CLI_Command' );
        }
    }

    /**
     * Plugin activation — create tables and schedule events.
     */
    public function activate(): void {
        $this->load_includes();
        $db = new WPPI_Database();
        $db->create_tables();

        // Schedule default cron.
        if ( ! wp_next_scheduled( 'wppi_collect_metrics' ) ) {
            wp_schedule_event( time(), 'wppi_five_minutes', 'wppi_collect_metrics' );
        }

        update_option( 'wppi_db_version', WPPI_DB_VERSION );
        flush_rewrite_rules();
    }

    /**
     * Plugin deactivation — remove scheduled events.
     */
    public function deactivate(): void {
        wp_clear_scheduled_hook( 'wppi_collect_metrics' );
    }

    /**
     * Get page generation start time.
     */
    public function get_start_time(): float {
        return $this->start_time;
    }
}

/**
 * Global accessor.
 */
function wppi(): WP_Performance_Inspector_Pro {
    return WP_Performance_Inspector_Pro::get_instance();
}

// Boot the plugin.
wppi();
