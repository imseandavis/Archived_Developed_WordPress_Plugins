/**
 * Membership Bridge Pro Admin JavaScript
 */

(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        MBPAdmin.init();
    });
    
    // Main admin object
    window.MBPAdmin = {
        
        init: function() {
            this.bindEvents();
            this.initTooltips();
            this.initProgressBars();
        },
        
        bindEvents: function() {
            // Test connection
            $(document).on('click', '#mbp-test-connection', this.testConnection);
            
            // Save connection
            $(document).on('click', '#mbp-save-connection', this.saveConnection);
            
            // Start migration
            $(document).on('click', '#mbp-start-migration', this.startMigration);
            
            // Check migration status
            $(document).on('click', '#mbp-check-status', this.checkMigrationStatus);
            
            // Cancel migration
            $(document).on('click', '#mbp-cancel-migration', this.cancelMigration);
            
            // Sync now
            $(document).on('click', '#mbp-sync-now', this.syncNow);
            
            // Enable/disable sync
            $(document).on('click', '#mbp-enable-sync', this.enableSync);
            $(document).on('click', '#mbp-disable-sync', this.disableSync);
            
            // Save sync settings
            $(document).on('click', '#mbp-save-sync-settings', this.saveSyncSettings);
            
            // Validate license
            $(document).on('click', '#mbp-validate-license', this.validateLicense);
            
            // Database tools
            $(document).on('click', '#mbp-clear-logs', this.clearLogs);
            $(document).on('click', '#mbp-reset-settings', this.resetSettings);
            $(document).on('click', '#mbp-export-settings', this.exportSettings);
            
            // Refresh log
            $(document).on('click', '#mbp-refresh-log', this.refreshLog);
        },
        
        initTooltips: function() {
            // Initialize tooltips if needed
            $('[data-tooltip]').each(function() {
                $(this).attr('title', $(this).data('tooltip'));
            });
        },
        
        initProgressBars: function() {
            // Initialize progress bars
            $('.mbp-progress-bar').each(function() {
                var $bar = $(this);
                var $fill = $bar.find('.mbp-progress-fill');
                var progress = $fill.data('progress') || 0;
                $fill.css('width', progress + '%');
            });
        },
        
        testConnection: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            var targetUrl = $('#target_url').val();
            var apiKey = $('#api_key').val();
            
            if (!targetUrl || !apiKey) {
                MBPAdmin.showNotice('Please enter both target URL and API key.', 'error');
                return;
            }
            
            $button.prop('disabled', true).text('Testing...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_test_connection',
                nonce: mbp_ajax.nonce,
                target_url: targetUrl,
                api_key: apiKey
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            })
            .fail(function() {
                MBPAdmin.showNotice('Connection test failed. Please try again.', 'error');
            })
            .always(function() {
                $button.prop('disabled', false).text('Test Connection');
            });
        },
        
        saveConnection: function(e) {
            e.preventDefault();
            
            var targetUrl = $('#target_url').val();
            var apiKey = $('#api_key').val();
            
            if (!targetUrl || !apiKey) {
                MBPAdmin.showNotice('Please enter both target URL and API key.', 'error');
                return;
            }
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_save_connection',
                nonce: mbp_ajax.nonce,
                target_url: targetUrl,
                api_key: apiKey
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice('Settings saved successfully!', 'success');
                    $('#mbp-start-migration').prop('disabled', false);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        startMigration: function(e) {
            e.preventDefault();
            
            if (!confirm(mbp_ajax.strings.confirm_migration)) {
                return;
            }
            
            var $button = $(this);
            $button.prop('disabled', true).text('Starting...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_start_migration',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                    $button.prop('disabled', false).text('Start Migration');
                }
            });
        },
        
        checkMigrationStatus: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            $button.prop('disabled', true).text('Checking...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_check_migration_status',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    var data = response.data;
                    $('#mbp-progress-fill').css('width', data.progress + '%');
                    $('#mbp-progress-text').text('Progress: ' + Math.round(data.progress) + '%');
                    
                    if (data.status !== 'in_progress') {
                        setTimeout(function() {
                            location.reload();
                        }, 1000);
                    }
                }
            })
            .always(function() {
                $button.prop('disabled', false).text('Check Status');
            });
        },
        
        cancelMigration: function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to cancel the migration?')) {
                return;
            }
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_cancel_migration',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        syncNow: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            $button.prop('disabled', true).text('Syncing...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_sync_now',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 2000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            })
            .always(function() {
                $button.prop('disabled', false).text('Sync Now');
            });
        },
        
        enableSync: function(e) {
            e.preventDefault();
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_enable_sync',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        disableSync: function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to disable sync?')) {
                return;
            }
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_disable_sync',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice(response.data.message, 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        saveSyncSettings: function(e) {
            e.preventDefault();
            
            var settings = {
                sync_frequency: $('#sync_frequency').val(),
                sync_users: $('#sync_users').is(':checked'),
                sync_memberships: $('#sync_memberships').is(':checked'),
                sync_payments: $('#sync_payments').is(':checked')
            };
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_save_sync_settings',
                nonce: mbp_ajax.nonce,
                settings: settings
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice('Settings saved successfully!', 'success');
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        validateLicense: function(e) {
            e.preventDefault();
            
            var licenseKey = $('#license_key').val();
            
            if (!licenseKey) {
                MBPAdmin.showNotice('Please enter a license key.', 'error');
                return;
            }
            
            var $button = $(this);
            $button.prop('disabled', true).text('Validating...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_validate_license',
                nonce: mbp_ajax.nonce,
                license_key: licenseKey
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice('License validated successfully!', 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            })
            .always(function() {
                $button.prop('disabled', false).text('Validate License');
            });
        },
        
        clearLogs: function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to clear all logs?')) {
                return;
            }
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_clear_logs',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice('Logs cleared successfully!', 'success');
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        resetSettings: function(e) {
            e.preventDefault();
            
            if (!confirm('Are you sure you want to reset all settings? This cannot be undone.')) {
                return;
            }
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_reset_settings',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    MBPAdmin.showNotice('Settings reset successfully!', 'success');
                    setTimeout(function() {
                        location.reload();
                    }, 1000);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        exportSettings: function(e) {
            e.preventDefault();
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_export_settings',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    // Create download link
                    var blob = new Blob([response.data.settings], {type: 'application/json'});
                    var url = window.URL.createObjectURL(blob);
                    var a = document.createElement('a');
                    a.href = url;
                    a.download = 'mbp-settings.json';
                    a.click();
                    window.URL.revokeObjectURL(url);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            });
        },
        
        refreshLog: function(e) {
            e.preventDefault();
            
            var $button = $(this);
            $button.prop('disabled', true).text('Refreshing...');
            
            $.post(mbp_ajax.ajax_url, {
                action: 'mbp_refresh_sync_log',
                nonce: mbp_ajax.nonce
            })
            .done(function(response) {
                if (response.success) {
                    $('#mbp-sync-log').html(response.data.log);
                } else {
                    MBPAdmin.showNotice(response.data.message, 'error');
                }
            })
            .always(function() {
                $button.prop('disabled', false).text('Refresh Log');
            });
        },
        
        showNotice: function(message, type) {
            type = type || 'info';
            
            var $notice = $('<div class="mbp-notice ' + type + '">' + message + '</div>');
            
            // Remove existing notices
            $('.mbp-notice').remove();
            
            // Add new notice
            $('.wrap h1').after($notice);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                $notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        }
    };
    
})(jQuery);
