/**
 * Membership Bridge Pro Wizard JavaScript
 */

(function($) {
    'use strict';
    
    // Initialize when document is ready
    $(document).ready(function() {
        MBPWizard.init();
        MBPWizard.hideAdminNotices();
    });
    
    // Main wizard object
    window.MBPWizard = {
        
    init: function() {
        console.log('🚀 MBPWizard initializing...');
        console.log('Current step:', mbp_wizard.current_step);
        console.log('AJAX URL:', mbp_wizard.ajax_url);
        console.log('Nonce:', mbp_wizard.nonce);
        
        this.bindEvents();
        this.initFormValidation();
        this.initPlatformSelection();
        this.initRoleSelection();
        this.initApiKeyCopy();
        this.initProToggle();
        this.initSetupMethod();
        this.initPasswordToggle();
        this.initUrlValidation();
        this.initTooltip();
        this.initTestConnection();
        
        console.log('✅ MBPWizard initialized successfully');
        
        // Test AJAX connectivity
        this.testAjaxConnectivity();
    },
    
    testAjaxConnectivity: function() {
        console.log('🧪 Testing AJAX connectivity...');
        
        $.ajax({
            url: mbp_wizard.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_debug_test',
                nonce: mbp_wizard.nonce
            },
            success: function(response) {
                console.log('✅ AJAX connectivity test successful:', response);
            },
            error: function(xhr, status, error) {
                console.error('❌ AJAX connectivity test failed:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText,
                    statusCode: xhr.status
                });
            }
        });
    },
        
        bindEvents: function() {
            // Next button
            $(document).on('click', '#mbp-wizard-next', this.nextStep);
            
            // Previous button
            $(document).on('click', '#mbp-wizard-previous', this.previousStep);
            
            // Test connection
            $(document).on('click', '#mbp-test-connection', this.testConnection);
            
            // Form changes
            $(document).on('change', '#mbp-target-setup-form input', this.validateTargetForm);
            $(document).on('change', '#mbp-data-selection-form input', this.validateDataForm);
            
            // Start migration
            $(document).on('click', '#mbp-start-migration', this.startMigration);
        },
        
        initFormValidation: function() {
            // Validate target form on page load
            this.validateTargetForm();
        },
        
        nextStep: function(e) {
            e.preventDefault();
            
            var button = $(this);
            var currentStep = mbp_wizard.current_step;
            
            console.log('Next step clicked, current step:', currentStep);
            
            // Validate current step
            if (!MBPWizard.validateCurrentStep(currentStep)) {
                console.log('Step validation failed');
                return;
            }
            
            // Save current step data
            var stepData = MBPWizard.getStepData(currentStep);
            console.log('Step data:', stepData);
            
            // Show loading
            button.prop('disabled', true).text(mbp_wizard.strings.saving);
            
            // Send to server
            var ajaxData = {
                action: 'mbp_wizard_next',
                nonce: mbp_wizard.nonce,
                step: currentStep,
                data: stepData
            };
            
            console.log('Sending AJAX data:', ajaxData);
            
            $.post(mbp_wizard.ajax_url, ajaxData)
            .done(function(response) {
                console.log('AJAX response:', response);
                if (response.success) {
                    if (response.data.completed) {
                        // Wizard completed, show success message
                        MBPWizard.showSuccess('Wizard completed successfully!');
                        setTimeout(function() {
                            window.location.href = response.data.redirect;
                        }, 2000);
                    } else {
                        // Normal step progression
                        window.location.href = response.data.redirect;
                    }
                } else {
                    MBPWizard.showError(response.data.message);
                    button.prop('disabled', false).text(mbp_wizard.strings.next);
                }
            })
            .fail(function(xhr, status, error) {
                console.log('AJAX error:', error);
                MBPWizard.showError(mbp_wizard.strings.error);
                button.prop('disabled', false).text(mbp_wizard.strings.next);
            });
        },
        
        previousStep: function(e) {
            e.preventDefault();
            
            var button = $(this);
            var currentStep = mbp_wizard.current_step;
            
            // Show loading
            button.prop('disabled', true).text(mbp_wizard.strings.saving);
            
            // Send to server
            $.post(mbp_wizard.ajax_url, {
                action: 'mbp_wizard_previous',
                nonce: mbp_wizard.nonce,
                step: currentStep
            })
            .done(function(response) {
                if (response.success) {
                    window.location.href = response.data.redirect;
                } else {
                    MBPWizard.showError(response.data.message);
                    button.prop('disabled', false).text(mbp_wizard.strings.previous);
                }
            })
            .fail(function() {
                MBPWizard.showError(mbp_wizard.strings.error);
                button.prop('disabled', false).text(mbp_wizard.strings.previous);
            });
        },
        
        testConnection: function(e) {
            e.preventDefault();
            
            var button = $(this);
            var targetUrl = $('#target_url').val();
            var apiKey = $('#api_key').val();
            
            if (!targetUrl || !apiKey) {
                MBPWizard.showConnectionResult('Please enter both target URL and API key.', 'error');
                return;
            }
            
            button.prop('disabled', true).text('Testing...');
            
            $.post(mbp_wizard.ajax_url, {
                action: 'mbp_test_connection',
                nonce: mbp_wizard.nonce,
                target_url: targetUrl,
                api_key: apiKey
            })
            .done(function(response) {
                if (response.success) {
                    MBPWizard.showConnectionResult(response.data.message, 'success');
                    $('#mbp-wizard-next').prop('disabled', false);
                } else {
                    MBPWizard.showConnectionResult(response.data.message, 'error');
                }
            })
            .fail(function() {
                MBPWizard.showConnectionResult('Connection test failed. Please try again.', 'error');
            })
            .always(function() {
                button.prop('disabled', false).text('Test Connection');
            });
        },
        
        validateCurrentStep: function(step) {
            switch (step) {
                case 1:
                    return this.validatePlatformSelection();
                case 2:
                    return this.validateRoleSelection();
                case 3:
                    return this.validateDataForm();
                case 4:
                case 5:
                case 6:
                    return true; // Advanced steps don't need validation
                default:
                    return true;
            }
        },
        
        validateTargetForm: function() {
            var targetUrl = $('#target_url').val();
            var apiKey = $('#api_key').val();
            var isValid = targetUrl && apiKey;
            
            $('#mbp-wizard-next').prop('disabled', !isValid);
            return isValid;
        },
        
        validateDataForm: function() {
            // Data selection is always valid (at least core data is selected)
            return true;
        },
        
        validatePlatformSelection: function() {
            var selectedPlatform = $('input[name="source_platform"]:checked').val();
            var $selectedItem = $('input[name="source_platform"]:checked').closest('.mbp-platform-radio-item');
            
            if (!selectedPlatform) {
                return false;
            }
            
            // Check if coming soon platform is selected
            if ($selectedItem.hasClass('coming-soon')) {
                return false;
            }
            
            return true;
        },

        validateRoleSelection: function() {
            var selectedRole = $('input[name="site_role"]:checked').val();
            
            if (!selectedRole) {
                return false;
            }
            
            // If source role, validate connection
            if (selectedRole === 'source') {
                var setupMethod = $('input[name="setup_method"]:checked').val();
                
                if (setupMethod === 'manual') {
                    // Check if manual connection was tested successfully
                    var connectionResult = $('#mbp-connection-result').html();
                    if (!connectionResult || !connectionResult.includes('successful')) {
                        MBPWizard.showError('Please test the connection first.');
                        return false;
                    }
                } else if (setupMethod === 'auto') {
                    // Check if pro auto-setup was completed successfully
                    var setupResult = $('#mbp-pro-setup-result').html();
                    if (!setupResult || !setupResult.includes('completed')) {
                        MBPWizard.showError('Please complete the pro auto-setup first.');
                        return false;
                    }
                }
            }
            
            return true;
        },
        
        getStepData: function(step) {
            var data = {};
            
            switch (step) {
                case 1:
                    data = {
                        source_platform: $('input[name="source_platform"]:checked').val()
                    };
                    break;
                case 2:
                    data = {
                        site_role: $('input[name="site_role"]:checked').val(),
                        target_url: $('#target_url').val(),
                        api_key: $('#api_key').val()
                    };
                    break;
                case 3:
                    data = {
                        migrate_content: $('#mbp-data-selection-form input[name="migrate_content"]').is(':checked'),
                        migrate_payments: $('#mbp-data-selection-form input[name="migrate_payments"]').is(':checked'),
                        migrate_emails: $('#mbp-data-selection-form input[name="migrate_emails"]').is(':checked'),
                        migrate_settings: $('#mbp-data-selection-form input[name="migrate_settings"]').is(':checked')
                    };
                    break;
            }
            
            return data;
        },
        
        showConnectionResult: function(message, type) {
            var resultDiv = $('#mbp-connection-result');
            resultDiv.removeClass('success error').addClass(type).html('<p>' + message + '</p>').show();
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                resultDiv.fadeOut();
            }, 5000);
        },
        
        showError: function(message) {
            // Create error notice
            var notice = $('<div class="notice notice-error"><p>' + message + '</p></div>');
            $('.mbp-wizard-container').prepend(notice);
            
            // Auto-hide after 5 seconds
            setTimeout(function() {
                notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 5000);
        },
        
        showSuccess: function(message) {
            // Create success notice
            var notice = $('<div class="notice notice-success"><p>' + message + '</p></div>');
            $('.mbp-wizard-container').prepend(notice);
            
            // Auto-hide after 3 seconds
            setTimeout(function() {
                notice.fadeOut(function() {
                    $(this).remove();
                });
            }, 3000);
        },
        
        startMigration: function(e) {
            e.preventDefault();
            
            var button = $(this);
            var startSync = $('#start_sync').is(':checked');
            var sendNotifications = $('#send_notifications').is(':checked');
            
            // Show loading
            button.prop('disabled', true).text('Starting Migration...');
            
            // Show progress section
            $('#mbp-migration-progress').show();
            
            // Send to server
            $.post(mbp_wizard.ajax_url, {
                action: 'mbp_wizard_complete',
                nonce: mbp_wizard.nonce,
                data: {
                    start_migration: true,
                    start_sync: startSync,
                    send_notifications: sendNotifications
                }
            })
            .done(function(response) {
                if (response.success) {
                    MBPWizard.startMigrationProgress();
                } else {
                    MBPWizard.showError(response.data.message);
                    button.prop('disabled', false).text('Start Migration');
                    $('#mbp-migration-progress').hide();
                }
            })
            .fail(function() {
                MBPWizard.showError(mbp_wizard.strings.error);
                button.prop('disabled', false).text('Start Migration');
                $('#mbp-migration-progress').hide();
            });
        },
        
        startMigrationProgress: function() {
            // Start progress monitoring
            var progressInterval = setInterval(function() {
                $.post(mbp_wizard.ajax_url, {
                    action: 'mbp_check_migration_status',
                    nonce: mbp_wizard.nonce
                })
                .done(function(response) {
                    if (response.success) {
                        var data = response.data;
                        $('#mbp-migration-progress-fill').css('width', data.progress + '%');
                        $('#mbp-migration-progress-text').text('Progress: ' + Math.round(data.progress) + '%');
                        
                        // Update migration details
                        var details = $('#mbp-migration-details');
                        if (data.status === 'in_progress') {
                            details.html('<div class="mbp-migration-step"><span class="dashicons dashicons-update"></span><span>Migrating users and data...</span></div>');
                        }
                        
                        if (data.status !== 'in_progress') {
                            clearInterval(progressInterval);
                            MBPWizard.showMigrationComplete();
                        }
                    }
                });
            }, 2000);
        },
        
        showMigrationComplete: function() {
            $('#mbp-migration-progress').hide();
            $('#mbp-migration-complete').show();
            $('#mbp-start-migration').hide();
        },
        
        hideAdminNotices: function() {
            // Add class to body for CSS targeting
            $('body').addClass('mbp-wizard-page');
            
            // Hide any notices that slipped through PHP prevention
            $('.notice, .updated, .error, .warning, .info').hide();
        },
        
        initPlatformSelection: function() {
            // Handle platform radio button changes
            $(document).on('change', 'input[name="source_platform"]', function() {
                var selectedPlatform = $(this).val();
                var $item = $(this).closest('.mbp-platform-radio-item');
                
                // Remove auto-selected class from all items
                $('.mbp-platform-radio-item').removeClass('auto-selected');
                
                // Add selected styling
                $item.addClass('auto-selected');
                
                // Update next button state
                MBPWizard.updateNextButtonState();
            });
            
            // Update button state on page load - check for pre-selected platforms
            this.updateNextButtonState();
            
            // Also trigger button state update after a short delay to ensure DOM is ready
            setTimeout(function() {
                MBPWizard.updateNextButtonState();
            }, 100);
        },
        
        updateNextButtonState: function() {
            var currentStep = parseInt(mbp_wizard.current_step);
            console.log('updateNextButtonState called, current step:', currentStep, 'type:', typeof currentStep);
            
            // Only update button state for step 1
            if (currentStep === 1) {
                var selectedPlatform = $('input[name="source_platform"]:checked').val();
                var $nextButton = $('#mbp-wizard-next');
                
                console.log('Step 1 - Selected platform:', selectedPlatform);
                console.log('Step 1 - Button element:', $nextButton.length);
                console.log('Step 1 - All radio buttons:', $('input[name="source_platform"]').length);
                console.log('Step 1 - Checked radio buttons:', $('input[name="source_platform"]:checked').length);
                
                if (selectedPlatform) {
                    var $selectedItem = $('input[name="source_platform"]:checked').closest('.mbp-platform-radio-item');
                    console.log('Step 1 - Selected item classes:', $selectedItem.attr('class'));
                    
                    if ($selectedItem.hasClass('coming-soon')) {
                        console.log('Step 1 - Platform is coming soon');
                        $nextButton.prop('disabled', true).text('Coming Soon');
                    } else {
                        console.log('Step 1 - Platform is available, enabling button');
                        $nextButton.prop('disabled', false).text('Next');
                    }
                } else {
                    console.log('Step 1 - No platform selected');
                    $nextButton.prop('disabled', true).text('Select Platform');
                }
            } else {
                console.log('Not step 1, skipping button state update');
            }
        },

        updateStep2ButtonState: function() {
            var currentStep = parseInt(mbp_wizard.current_step);
            
            // Only update button state for step 2
            if (currentStep !== 2) {
                return;
            }
            
            var selectedRole = $('input[name="site_role"]:checked').val();
            var $nextButton = $('#mbp-wizard-next');
            
            if (selectedRole === 'source') {
                var setupMethod = $('input[name="setup_method"]:checked').val();
                
                if (setupMethod === 'manual') {
                    var connectionResult = $('#mbp-connection-result').html();
                    if (connectionResult && connectionResult.includes('successful')) {
                        $nextButton.prop('disabled', false).text('Next');
                    } else {
                        $nextButton.prop('disabled', true).text('Test Connection First');
                    }
                } else if (setupMethod === 'auto') {
                    var setupResult = $('#mbp-pro-setup-result').html();
                    if (setupResult && setupResult.includes('completed')) {
                        $nextButton.prop('disabled', false).text('Next');
                    } else {
                        $nextButton.prop('disabled', true).text('Complete Auto-Setup First');
                    }
                }
            } else if (selectedRole === 'target') {
                $nextButton.prop('disabled', false).text('Next');
            } else {
                $nextButton.prop('disabled', true).text('Select Site Role');
            }
        },

        initRoleSelection: function() {
            $(document).on('change', 'input[name="site_role"]', function() {
                var role = $(this).val();
                if (role === 'source') {
                    $('#mbp-source-config').show();
                    $('#mbp-target-config').hide();
                } else if (role === 'target') {
                    $('#mbp-source-config').hide();
                    $('#mbp-target-config').show();
                }
                MBPWizard.updateStep2ButtonState();
            });
            
            // Initialize on page load
            var selectedRole = $('input[name="site_role"]:checked').val();
            if (selectedRole === 'target') {
                $('#mbp-source-config').hide();
                $('#mbp-target-config').show();
            }
            MBPWizard.updateStep2ButtonState();
        },

        initApiKeyCopy: function() {
            $(document).on('click', '#mbp-copy-api-key', function() {
                var apiKey = $('#generated_api_key').val();
                navigator.clipboard.writeText(apiKey).then(function() {
                    var $button = $('#mbp-copy-api-key');
                    var originalText = $button.text();
                    $button.text('Copied!').addClass('button-primary');
                    setTimeout(function() {
                        $button.text(originalText).removeClass('button-primary');
                    }, 2000);
                });
            });
        },

        initProToggle: function() {
            $(document).on('change', '#mbp-pro-toggle', function() {
                var isPro = $(this).is(':checked');
                console.log('Pro toggle changed:', isPro);
                
                // Update pro features visibility immediately
                if (isPro) {
                    $('.mbp-pro-feature').addClass('pro-enabled');
                    $('.mbp-pro-feature input').prop('disabled', false);
                    console.log('Pro features enabled');
                } else {
                    $('.mbp-pro-feature').removeClass('pro-enabled');
                    $('.mbp-pro-feature input').prop('disabled', true);
                    console.log('Pro features disabled');
                }
                
                // Save pro toggle state via AJAX
                $.post(mbp_wizard.ajax_url, {
                    action: 'mbp_toggle_pro',
                    nonce: mbp_wizard.nonce,
                    is_pro: isPro
                }).done(function(response) {
                    console.log('Pro toggle saved:', response);
                });
            });
            
            // Initialize on page load
            var isPro = $('#mbp-pro-toggle').is(':checked');
            console.log('Initial pro state:', isPro);
            if (isPro) {
                $('.mbp-pro-feature').addClass('pro-enabled');
                $('.mbp-pro-feature input').prop('disabled', false);
            }
        },

        initSetupMethod: function() {
            $(document).on('change', 'input[name="setup_method"]', function() {
                var method = $(this).val();
                if (method === 'manual') {
                    $('#mbp-manual-setup').show();
                    $('#mbp-auto-setup').hide();
                } else if (method === 'auto') {
                    $('#mbp-manual-setup').hide();
                    $('#mbp-auto-setup').show();
                }
                MBPWizard.updateStep2ButtonState();
            });
        },

        initPasswordToggle: function() {
            $(document).on('click', '#mbp-password-toggle', function() {
                var $passwordInput = $('#pro_password');
                var $toggleIcon = $(this).find('.dashicons');
                
                if ($passwordInput.attr('type') === 'password') {
                    $passwordInput.attr('type', 'text');
                    $toggleIcon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
                } else {
                    $passwordInput.attr('type', 'password');
                    $toggleIcon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
                }
            });
        },

        initUrlValidation: function() {
            var urlTimeout;
            
            $(document).on('input', '#pro_target_url', function() {
                var url = $(this).val();
                var $globeIcon = $('#mbp-globe-icon');
                
                // Clear previous timeout
                clearTimeout(urlTimeout);
                
                if (!url.trim()) {
                    $globeIcon.removeClass('mbp-globe-checking mbp-globe-valid mbp-globe-invalid').addClass('mbp-globe-idle');
                    return;
                }
                
                // Basic URL validation
                try {
                    new URL(url);
                } catch {
                    $globeIcon.removeClass('mbp-globe-checking mbp-globe-valid mbp-globe-idle').addClass('mbp-globe-invalid');
                    return;
                }
                
                // Set checking state
                $globeIcon.removeClass('mbp-globe-valid mbp-globe-invalid mbp-globe-idle').addClass('mbp-globe-checking');
                
                // Debounce the URL check
                urlTimeout = setTimeout(function() {
                    MBPWizard.validateUrl(url);
                }, 1000);
            });
        },

        validateUrl: function(url) {
            var $globeIcon = $('#mbp-globe-icon');
            
            // Show loading state
            $globeIcon.removeClass('mbp-globe-valid mbp-globe-invalid mbp-globe-idle').addClass('mbp-globe-checking');
            $globeIcon.html('<span class="dashicons dashicons-update-alt mbp-loading-spinner"></span>');
            
            $.post(mbp_wizard.ajax_url, {
                action: 'mbp_validate_url',
                nonce: mbp_wizard.nonce,
                url: url
            })
            .done(function(response) {
                if (response.success) {
                    var data = response.data;
                    if (data.valid) {
                        $globeIcon.removeClass('mbp-globe-checking mbp-globe-invalid mbp-globe-idle').addClass('mbp-globe-valid');
                        $globeIcon.html('<span class="dashicons dashicons-admin-site"></span>');
                        console.log('URL validation successful:', data.message);
                    } else {
                        $globeIcon.removeClass('mbp-globe-checking mbp-globe-valid mbp-globe-idle').addClass('mbp-globe-invalid');
                        $globeIcon.html('<span class="dashicons dashicons-admin-site"></span>');
                        console.log('URL validation failed:', data.message);
                    }
                } else {
                    $globeIcon.removeClass('mbp-globe-checking mbp-globe-valid mbp-globe-idle').addClass('mbp-globe-invalid');
                    $globeIcon.html('<span class="dashicons dashicons-admin-site"></span>');
                    console.log('URL validation error:', response.data.message);
                }
            })
            .fail(function(xhr, status, error) {
                $globeIcon.removeClass('mbp-globe-checking mbp-globe-valid mbp-globe-idle').addClass('mbp-globe-invalid');
                $globeIcon.html('<span class="dashicons dashicons-admin-site"></span>');
                console.log('URL validation AJAX error:', error);
            });
        },

        initTooltip: function() {
            $(document).on('mouseenter', '#mbp-info-btn', function() {
                $('#mbp-tooltip').show();
            });
            
            $(document).on('mouseleave', '#mbp-info-btn', function() {
                $('#mbp-tooltip').hide();
            });
        },

        initTestConnection: function() {
            $(document).on('click', '#mbp-test-connection', function() {
                var $button = $(this);
                var targetUrl = $('#target_url').val();
                var apiKey = $('#api_key').val();
                
                if (!targetUrl || !apiKey) {
                    MBPWizard.showError('Please enter both target URL and API key.');
                    return;
                }
                
                $button.prop('disabled', true).text('Testing...');
                
                // Real connection test via AJAX
                console.log('🔗 Starting connection test...');
                console.log('Target URL:', targetUrl);
                console.log('API Key:', apiKey);
                
                $.ajax({
                    url: mbp_wizard.ajax_url,
                    type: 'POST',
                    data: {
                        action: 'mbp_test_connection',
                        nonce: mbp_wizard.nonce,
                        target_url: targetUrl,
                        api_key: apiKey
                    },
                    success: function(response) {
                        console.log('✅ Connection test response:', response);
                        
                        if (response.success) {
                            console.log('✅ Connection test successful!');
                            MBPWizard.showSuccess('✅ ' + response.data.message);
                            $('#mbp-connection-result').html('<div class="notice notice-success"><p>✅ ' + response.data.message + '</p></div>').show();
                            
                            // Store validated connection for Pro Auto-Setup
                            MBPWizard.validatedConnection = {
                                target_url: targetUrl,
                                api_key: apiKey
                            };
                            console.log('💾 Stored validated connection for Pro Auto-Setup');
                        } else {
                            console.log('❌ Connection test failed:', response.data.message);
                            MBPWizard.showError('❌ ' + response.data.message);
                            $('#mbp-connection-result').html('<div class="notice notice-error"><p>❌ ' + response.data.message + '</p></div>').show();
                        }
                        
                        $button.prop('disabled', false).text('Test Connection');
                        MBPWizard.updateStep2ButtonState();
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Connection test AJAX error:', {
                            status: status,
                            error: error,
                            responseText: xhr.responseText,
                            statusCode: xhr.status
                        });
                        MBPWizard.showError('❌ Connection test failed. Please try again.');
                        $('#mbp-connection-result').html('<div class="notice notice-error"><p>❌ Connection test failed. Please try again.</p></div>').show();
                        $button.prop('disabled', false).text('Test Connection');
                        MBPWizard.updateStep2ButtonState();
                    }
                });
            });
            
            // Validate connection button
            $(document).on('click', '#mbp-validate-connection', function() {
                var $button = $(this);
                var targetUrl = $('#pro_target_url').val();
                var username = $('#pro_username').val();
                var password = $('#pro_password').val();
                
                if (!targetUrl || !username || !password) {
                    MBPWizard.showError('Please fill in all fields.');
                    return;
                }
                
                $button.prop('disabled', true).text('Validating...');
                
        // Real credential validation via AJAX
        console.log('🔐 Starting credential validation...');
        console.log('Target URL:', targetUrl);
        console.log('Username:', username);
        console.log('Password length:', password.length);
        
        $.ajax({
            url: mbp_wizard.ajax_url,
            type: 'POST',
            data: {
                action: 'mbp_validate_credentials',
                nonce: mbp_wizard.nonce,
                target_url: targetUrl,
                username: username,
                password: password
            },
            success: function(response) {
                console.log('✅ Credential validation response:', response);
                
                if (response.success) {
                    console.log('✅ Credentials validated successfully!');
                    MBPWizard.showSuccess('✅ ' + response.data.message);
                    $('#mbp-pro-setup-result').html('<div class="notice notice-success"><p>✅ ' + response.data.message + '</p></div>').show();
                    $('#mbp-pro-setup').show();
                    $button.hide();
                    
                    // Store validated credentials for Pro Auto-Setup
                    MBPWizard.validatedCredentials = {
                        target_url: targetUrl,
                        username: username,
                        password: password
                    };
                    console.log('💾 Stored validated credentials for Pro Auto-Setup');
                } else {
                    console.log('❌ Credential validation failed:', response.data.message);
                    MBPWizard.showError('❌ ' + response.data.message);
                    $('#mbp-pro-setup-result').html('<div class="notice notice-error"><p>❌ ' + response.data.message + '</p></div>').show();
                }
                
                $button.prop('disabled', false).text('🔐 Validate Connection');
            },
            error: function(xhr, status, error) {
                console.error('❌ Credential validation AJAX error:', {
                    status: status,
                    error: error,
                    responseText: xhr.responseText,
                    statusCode: xhr.status
                });
                MBPWizard.showError('❌ Validation failed. Please try again.');
                $('#mbp-pro-setup-result').html('<div class="notice notice-error"><p>❌ Validation failed. Please try again.</p></div>').show();
                $button.prop('disabled', false).text('🔐 Validate Connection');
            }
        });
            });
            
            // Pro setup button
            $(document).on('click', '#mbp-pro-setup', function() {
                var $button = $(this);
                
                console.log('🚀 Starting Pro Auto-Setup...');
                
                // Use validated credentials if available, otherwise use form values
                var targetUrl, username, password;
                if (MBPWizard.validatedCredentials) {
                    targetUrl = MBPWizard.validatedCredentials.target_url;
                    username = MBPWizard.validatedCredentials.username;
                    password = MBPWizard.validatedCredentials.password;
                    console.log('✅ Using validated credentials from previous step');
                } else {
                    targetUrl = $('#pro_target_url').val();
                    username = $('#pro_username').val();
                    password = $('#pro_password').val();
                    console.log('⚠️ Using form values (credentials not validated)');
                }
                
                console.log('Pro Auto-Setup parameters:', {
                    target_url: targetUrl,
                    username: username,
                    password_length: password.length
                });
                
                if (!targetUrl || !username || !password) {
                    console.log('❌ Missing required fields for Pro Auto-Setup');
                    MBPWizard.showError('Please validate your credentials first.');
                    return;
                }
                
                $button.prop('disabled', true).text('Starting...');
                $('#mbp-pro-setup-result').show();
                
                // Show initial progress
                $('#mbp-pro-setup-result').html('<div class="mbp-progress-step"><div class="mbp-progress-icon">🚀</div><div class="mbp-progress-text">Starting Pro Auto-Setup...</div><div class="mbp-progress-spinner"></div></div>');
                
                console.log('📡 Making AJAX call to mbp_pro_auto_setup...');
                
                // Make real AJAX call
                $.post(mbp_wizard.ajax_url, {
                    action: 'mbp_pro_auto_setup',
                    nonce: mbp_wizard.nonce,
                    target_url: targetUrl,
                    username: username,
                    password: password
                })
                .done(function(response) {
                    console.log('✅ Pro Auto-Setup AJAX response:', response);
                    
                    if (response.success) {
                        var data = response.data;
                        console.log('🎉 Pro Auto-Setup completed successfully!', data);
                        MBPWizard.showSuccess('🚀 Pro Auto-Setup completed successfully!');
                        $('#mbp-pro-setup-result').html('<div class="notice notice-success"><p>🚀 Pro Auto-Setup completed successfully!<br>API Key: <code>' + data.api_key + '</code></p></div>');
                        $button.prop('disabled', false).text('🚀 Pro Auto-Setup');
                        MBPWizard.updateStep2ButtonState();
                    } else {
                        console.log('❌ Pro Auto-Setup failed:', response.data.message);
                        MBPWizard.showError('❌ Pro Auto-Setup failed: ' + response.data.message);
                        $('#mbp-pro-setup-result').html('<div class="notice notice-error"><p>❌ Pro Auto-Setup failed: ' + response.data.message + '</p></div>');
                        $button.prop('disabled', false).text('🚀 Pro Auto-Setup');
                    }
                })
                .fail(function(xhr, status, error) {
                    console.error('❌ Pro Auto-Setup AJAX failed:', {
                        status: status,
                        error: error,
                        responseText: xhr.responseText,
                        statusCode: xhr.status,
                        readyState: xhr.readyState
                    });
                    MBPWizard.showError('❌ Pro Auto-Setup failed: ' + error);
                    $('#mbp-pro-setup-result').html('<div class="notice notice-error"><p>❌ Pro Auto-Setup failed: ' + error + '</p></div>');
                    $button.prop('disabled', false).text('🚀 Pro Auto-Setup');
                });
            });
        }
    };
    
})(jQuery);
