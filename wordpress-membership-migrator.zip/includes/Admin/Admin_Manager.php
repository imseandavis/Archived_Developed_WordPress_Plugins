<?php

namespace MBP\Admin;

/**
 * Admin Manager - Handles admin interface and functionality
 */
class Admin_Manager {
    
    public function __construct() {
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('admin_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('admin_notices', array($this, 'admin_notices'));
        add_action('wp_ajax_mbp_refresh_sync_log', array($this, 'ajax_refresh_sync_log'));
    }
    
    public function enqueue_scripts($hook) {
        if (strpos($hook, 'membership-bridge') === false) {
            return;
        }
        
        wp_enqueue_script('mbp-admin', MBP_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), MBP_VERSION, true);
        wp_enqueue_style('mbp-admin', MBP_PLUGIN_URL . 'assets/css/admin.css', array(), MBP_VERSION);
        
        wp_localize_script('mbp-admin', 'mbp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mbp_nonce'),
            'strings' => array(
                'confirm_migration' => __('Are you sure you want to start the migration?', 'membership-bridge-pro'),
                'migration_started' => __('Migration started successfully!', 'membership-bridge-pro'),
                'error_occurred' => __('An error occurred. Please try again.', 'membership-bridge-pro'),
                'connection_success' => __('Connection successful!', 'membership-bridge-pro'),
                'connection_failed' => __('Connection failed. Please check your settings.', 'membership-bridge-pro'),
            )
        ));
    }
    
    public function admin_notices() {
        $migration_status = get_option('mbp_migration_status', 'not_started');
        $last_sync = get_option('mbp_last_sync', null);
        
        if ($migration_status === 'in_progress') {
            ?>
            <div class="notice notice-info">
                <p><?php _e('Migration is currently in progress. Please wait for it to complete.', 'membership-bridge-pro'); ?></p>
            </div>
            <?php
        }
        
        if ($migration_status === 'completed' && $last_sync) {
            $sync_time = date('Y-m-d H:i:s', $last_sync);
            ?>
            <div class="notice notice-success">
                <p><?php printf(__('Migration completed successfully! Last sync: %s', 'membership-bridge-pro'), $sync_time); ?></p>
            </div>
            <?php
        }
    }
    
    public function render_dashboard() {
        $migration_status = get_option('mbp_migration_status', 'not_started');
        $total_users = $this->get_total_users();
        $migrated_users = $this->get_migrated_users_count();
        $sync_enabled = get_option('mbp_sync_enabled', false);
        
        include MBP_PLUGIN_DIR . 'templates/admin/dashboard.php';
    }
    
    public function render_migration_page() {
        $migration_status = get_option('mbp_migration_status', 'not_started');
        $target_url = get_option('mbp_target_url', '');
        $api_key = get_option('mbp_target_api_key', '');
        
        include MBP_PLUGIN_DIR . 'templates/admin/migration.php';
    }
    
    public function render_sync_page() {
        $sync_enabled = get_option('mbp_sync_enabled', false);
        $sync_frequency = get_option('mbp_sync_frequency', 'hourly');
        $last_sync = get_option('mbp_last_sync', null);
        
        include MBP_PLUGIN_DIR . 'templates/admin/sync.php';
    }
    
    public function render_advanced_page() {
        $license_key = get_option('mbp_license_key', '');
        $license_status = get_option('mbp_license_status', 'inactive');
        $pro_features_enabled = apply_filters('mbp_pro_features_enabled', false);
        
        include MBP_PLUGIN_DIR . 'templates/admin/advanced.php';
    }
    
    private function get_total_users() {
        global $wpdb;
        
        $count = $wpdb->get_var("
            SELECT COUNT(DISTINCT u.ID) 
            FROM {$wpdb->users} u
            INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
            WHERE um.meta_key = 'pmpro_membership_level'
            AND um.meta_value != '0'
        ");
        
        return intval($count);
    }
    
    private function get_migrated_users_count() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'mbp_migration_log';
        $count = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(DISTINCT user_id) 
            FROM {$table_name} 
            WHERE action = 'user_migrated' 
            AND status = 'success'
        "));
        
        return intval($count);
    }
    
    public function ajax_refresh_sync_log() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        global $wpdb;
        $recent_activity = $wpdb->get_results("
            SELECT 
                action,
                status,
                created_at,
                data
            FROM {$wpdb->prefix}mbp_sync_queue 
            ORDER BY created_at DESC 
            LIMIT 10
        ");
        
        $log_html = '';
        if (empty($recent_activity)) {
            $log_html = '<p>' . __('No recent sync activity to display.', 'membership-bridge-pro') . '</p>';
        } else {
            foreach ($recent_activity as $activity) {
                $status_class = $activity->status === 'success' ? 'success' : 'error';
                $status_icon = $activity->status === 'success' ? 'dashicons-yes-alt' : 'dashicons-no-alt';
                $log_html .= '<div class="mbp-sync-log-item">';
                $log_html .= '<span class="dashicons ' . $status_icon . '"></span>';
                $log_html .= '<span class="mbp-sync-action">' . esc_html(ucfirst(str_replace('_', ' ', $activity->action))) . '</span>';
                $log_html .= '<span class="mbp-sync-time">' . esc_html(date('Y-m-d H:i:s', strtotime($activity->created_at))) . '</span>';
                $log_html .= '</div>';
            }
        }
        
        wp_send_json_success(array(
            'log' => $log_html
        ));
    }
}
