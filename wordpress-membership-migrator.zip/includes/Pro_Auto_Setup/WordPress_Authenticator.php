<?php
/**
 * WordPress Authenticator
 * 
 * Handles authentication with remote WordPress sites
 */

namespace MBP\Pro_Auto_Setup;

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Authenticator {
    
    private $cookies_file;
    
    public function __construct() {
        error_log('WordPress_Authenticator constructor called');
        $this->cookies_file = tempnam(sys_get_temp_dir(), 'mbp_cookies');
        error_log('Cookies file: ' . $this->cookies_file);
        
        // Ensure the cookies file is writable
        if (!is_writable(dirname($this->cookies_file))) {
            error_log('Warning: Cookies directory not writable: ' . dirname($this->cookies_file));
        }
    }
    
    public function __destruct() {
        if (file_exists($this->cookies_file)) {
            unlink($this->cookies_file);
        }
    }
    
    /**
     * Authenticate with TARGET WordPress site
     * 
     * This authenticates with the target site where we want to install the plugin
     */
    public function authenticate($target_url, $username, $password) {
        error_log('=== WORDPRESS AUTHENTICATE START ===');
        error_log('TARGET SITE URL: ' . $target_url);
        error_log('TARGET SITE USERNAME: ' . $username);
        
        $login_url = rtrim($target_url, '/') . '/wp-login.php';
        $admin_url = rtrim($target_url, '/') . '/wp-admin/';
        
        error_log('TARGET LOGIN URL: ' . $login_url);
        error_log('TARGET ADMIN URL: ' . $admin_url);
        
        try {
            // Step 1: Get login page to extract nonce and cookies
            error_log('Step 1: Getting login page...');
            $login_page = $this->get_login_page($login_url);
            error_log('Login page result: ' . print_r($login_page, true));
            
            if (!$login_page['success']) {
                return $login_page;
            }
        
        // Step 2: Extract WordPress nonce (optional for some WordPress versions)
        $nonce = $this->extract_nonce($login_page['content']);
        if (!$nonce) {
            error_log('Warning: Could not extract WordPress nonce, proceeding without nonce');
            // Some WordPress installations don't require nonce for login
        }
        
        // Step 3: Submit login form
        error_log('=== SUBMITTING LOGIN FORM ===');
        $login_result = $this->submit_login($login_url, $username, $password, $nonce);
        error_log('Login result: ' . print_r($login_result, true));
        
        if (!$login_result['success']) {
            error_log('Login failed, returning error');
            return $login_result;
        }
        
        error_log('Login successful, proceeding to admin verification');
        
        // Step 3.5: Test basic admin access first
        $basic_admin_test = $this->test_basic_admin_access($admin_url);
        error_log('Basic admin test result: ' . print_r($basic_admin_test, true));
        
            // Step 4: Verify authentication using WordPress REST API
            error_log('=== VERIFYING USER PERMISSIONS VIA API ===');
            $api_check = $this->verify_user_permissions_via_api($target_url);
            error_log('API check result: ' . print_r($api_check, true));
            
            if (!$api_check['success']) {
                error_log('API check failed, trying traditional admin access check');
                // Fallback to traditional admin access check
                $admin_check = $this->verify_admin_access($admin_url);
                error_log('Admin check result: ' . print_r($admin_check, true));
                if (!$admin_check['success']) {
                    error_log('Both API and admin checks failed');
                    return $admin_check;
                }
            } else {
                error_log('API check successful');
            }
            
            return array(
                'success' => true, 
                'message' => 'Authentication successful',
                'user_info' => array(
                    'username' => $username,
                    'target_url' => $target_url,
                    'admin_access' => true
                )
            );
        } catch (\Exception $e) {
            error_log('Authentication error: ' . $e->getMessage());
            return array('success' => false, 'message' => 'Authentication failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Get login page content
     */
    private function get_login_page($login_url) {
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $login_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return array('success' => false, 'message' => 'Connection error: ' . $error);
        }
        
        if ($http_code !== 200) {
            return array('success' => false, 'message' => 'HTTP error: ' . $http_code);
        }
        
        return array('success' => true, 'content' => $response);
    }
    
    /**
     * Extract WordPress nonce from login page
     */
    private function extract_nonce($content) {
        error_log('=== NONCE EXTRACTION START ===');
        error_log('Content length: ' . strlen($content));
        
        // Log a sample of the content for debugging
        $sample = substr($content, 0, 1000);
        error_log('Content sample: ' . $sample);
        
        // Look for WordPress nonce in various forms
        $patterns = array(
            // Standard WordPress nonce in form
            '/name="_wpnonce"\s+value="([^"]+)"/',
            // WordPress nonce in JavaScript
            '/_wpnonce["\']?\s*:\s*["\']([^"\']+)["\']/',
            '/wp_nonce["\']?\s*:\s*["\']([^"\']+)["\']/',
            // Alternative nonce patterns
            '/"nonce"\s*:\s*"([^"]+)"/',
            '/nonce["\']?\s*:\s*["\']([^"\']+)["\']/',
            // Hidden input field variations
            '/<input[^>]*name="_wpnonce"[^>]*value="([^"]+)"/',
            // WordPress REST API nonce
            '/wp_rest["\']?\s*:\s*["\']([^"\']+)["\']/',
            // Generic nonce patterns
            '/nonce["\']?\s*:\s*["\']([a-f0-9]{10})["\']/',
            '/"([a-f0-9]{10})"/'
        );
        
        foreach ($patterns as $i => $pattern) {
            error_log("Trying pattern $i: " . $pattern);
            if (preg_match($pattern, $content, $matches)) {
                error_log("Found nonce with pattern $i: " . $matches[1]);
                return $matches[1];
            }
        }
        
        // If no nonce found, try to extract any 10-character hex string that might be a nonce
        if (preg_match('/[a-f0-9]{10}/', $content, $matches)) {
            error_log("Found potential nonce (10-char hex): " . $matches[0]);
            return $matches[0];
        }
        
        error_log('No nonce found in content');
        return null;
    }
    
    /**
     * Submit login form
     */
    private function submit_login($login_url, $username, $password, $nonce) {
        error_log('=== SUBMIT LOGIN START ===');
        error_log('Login URL: ' . $login_url);
        error_log('Username: ' . $username);
        error_log('Nonce: ' . ($nonce ? $nonce : 'NULL'));
        
        $post_data = array(
            'log' => $username,
            'pwd' => $password,
            'wp-submit' => 'Log In',
            'redirect_to' => rtrim($login_url, '/wp-login.php') . '/wp-admin/',
            'testcookie' => '1'
        );
        
        // Only add nonce if we have one
        if ($nonce) {
            $post_data['_wpnonce'] = $nonce;
        }
        
        error_log('Post data: ' . print_r($post_data, true));
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $login_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => http_build_query($post_data),
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HEADER => true,  // Include headers in response
            CURLOPT_MAXREDIRS => 5    // Limit redirects
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('Login response HTTP code: ' . $http_code);
        error_log('Login final URL: ' . $final_url);
        error_log('Login response length: ' . strlen($response));
        error_log('Login response sample: ' . substr($response, 0, 500));
        
        if ($error) {
            error_log('Login error: ' . $error);
            return array('success' => false, 'message' => 'Login error: ' . $error);
        }
        
        // Check if we were redirected to admin area (good sign)
        if (strpos($final_url, '/wp-admin/') !== false) {
            error_log('Login successful - redirected to admin area');
            return array('success' => true, 'message' => 'Login successful (redirected to admin)');
        }
        
        // Check for explicit login error messages
        $login_error_indicators = array(
            'login_error',
            'incorrect_password',
            'invalid_username',
            'authentication_failed',
            'login_failed',
            'error',
            'invalid_username',
            'incorrect_password'
        );
        
        foreach ($login_error_indicators as $indicator) {
            if (stripos($response, $indicator) !== false) {
                error_log('Login failed - found error indicator: ' . $indicator);
                return array('success' => false, 'message' => 'Invalid credentials');
            }
        }
        
        // Check for success indicators in response
        $success_indicators = array(
            'wp-admin',
            'dashboard',
            'admin-ajax.php',
            'admin_menu',
            'wp-admin-bar'
        );
        
        $has_success_indicator = false;
        foreach ($success_indicators as $indicator) {
            if (stripos($response, $indicator) !== false) {
                $has_success_indicator = true;
                error_log('Found success indicator: ' . $indicator);
                break;
            }
        }
        
        // If we have success indicators, login was successful
        if ($has_success_indicator) {
            error_log('Login successful - found success indicators');
            return array('success' => true, 'message' => 'Login successful');
        }
        
        // If we're still on login page, it failed
        if (stripos($response, 'wp-login.php') !== false || stripos($response, 'loginform') !== false) {
            error_log('Login failed - still on login page');
            return array('success' => false, 'message' => 'Invalid credentials');
        }
        
        // If we got here, assume login was successful (lenient approach)
        // Check if cookies were saved
        $this->debug_cookies();
        
        error_log('Login appears successful (lenient check)');
        return array('success' => true, 'message' => 'Login successful (lenient check)');
    }
    
    /**
     * Test basic admin access
     */
    private function test_basic_admin_access($admin_url) {
        error_log('=== TESTING BASIC ADMIN ACCESS ===');
        error_log('Admin URL: ' . $admin_url);
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $admin_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('Basic admin test HTTP code: ' . $http_code);
        error_log('Basic admin test final URL: ' . $final_url);
        error_log('Basic admin test response length: ' . strlen($response));
        error_log('Basic admin test response sample: ' . substr($response, 0, 500));
        
        if ($error) {
            return array('success' => false, 'message' => 'Basic admin test error: ' . $error);
        }
        
        // Check if we were redirected to login
        if (strpos($final_url, 'wp-login.php') !== false) {
            error_log('Basic admin test failed - redirected to login');
            return array('success' => false, 'message' => 'Redirected to login page');
        }
        
        // Check if we're in admin area
        if (strpos($final_url, '/wp-admin/') !== false) {
            error_log('Basic admin test successful - in admin area');
            return array('success' => true, 'message' => 'In admin area');
        }
        
        error_log('Basic admin test - unclear result');
        return array('success' => false, 'message' => 'Unclear admin access result');
    }
    
    /**
     * Debug cookie file contents
     */
    private function debug_cookies() {
        if (file_exists($this->cookies_file)) {
            $cookie_content = file_get_contents($this->cookies_file);
            error_log('Cookie file exists, size: ' . strlen($cookie_content));
            if (strlen($cookie_content) > 0) {
                error_log('Cookie content sample: ' . substr($cookie_content, 0, 200));
            } else {
                error_log('Warning: Cookie file is empty');
            }
        } else {
            error_log('Warning: Cookie file does not exist');
        }
    }
    
    /**
     * Verify user permissions via WordPress REST API
     */
    private function verify_user_permissions_via_api($target_url) {
        error_log('=== VERIFY USER PERMISSIONS VIA API START ===');
        
        $api_url = rtrim($target_url, '/') . '/wp-json/wp/v2/users/me?context=edit';
        error_log('API URL: ' . $api_url);
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $api_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_HTTPHEADER => array(
                'Accept: application/json',
                'Content-Type: application/json'
            )
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('API response HTTP code: ' . $http_code);
        error_log('API final URL: ' . $final_url);
        error_log('API response: ' . $response);
        
        // Debug cookies before API call
        $this->debug_cookies();
        
        if ($error) {
            error_log('API request error: ' . $error);
            return array('success' => false, 'message' => 'API request error: ' . $error);
        }
        
        if ($http_code === 401 || $http_code === 403) {
            error_log('API access denied - user not authenticated or insufficient permissions');
            return array('success' => false, 'message' => 'User not authenticated or insufficient permissions');
        }
        
        if ($http_code !== 200) {
            error_log('API request failed with HTTP code: ' . $http_code);
            return array('success' => false, 'message' => 'API request failed: HTTP ' . $http_code);
        }
        
        // Parse JSON response
        $user_data = json_decode($response, true);
        if (!$user_data) {
            error_log('Failed to parse API response JSON');
            return array('success' => false, 'message' => 'Invalid API response');
        }
        
        // Check if user has admin capabilities
        if (isset($user_data['capabilities'])) {
            $capabilities = $user_data['capabilities'];
            $has_admin_cap = isset($capabilities['administrator']) || 
                            isset($capabilities['manage_options']) || 
                            isset($capabilities['edit_users']);
            
            if ($has_admin_cap) {
                error_log('User has admin capabilities via API');
                return array('success' => true, 'message' => 'Admin access verified via API', 'user_data' => $user_data);
            }
        }
        
        // Check user roles
        if (isset($user_data['roles']) && is_array($user_data['roles'])) {
            $roles = $user_data['roles'];
            if (in_array('administrator', $roles)) {
                error_log('User has administrator role via API');
                return array('success' => true, 'message' => 'Admin access verified via API (administrator role)', 'user_data' => $user_data);
            }
        }
        
        // If we got user data with context=edit, that means they have edit permissions
        if (isset($user_data['id']) && isset($user_data['name'])) {
            error_log('User has edit permissions (context=edit successful)');
            return array('success' => true, 'message' => 'Admin access verified via API (edit context)', 'user_data' => $user_data);
        }
        
        error_log('User does not have sufficient permissions');
        return array('success' => false, 'message' => 'User does not have sufficient permissions');
    }
    
    /**
     * Verify admin access
     */
    private function verify_admin_access($admin_url) {
        error_log('=== VERIFY ADMIN ACCESS START ===');
        error_log('Admin URL: ' . $admin_url);
        
        $ch = curl_init();
        curl_setopt_array($ch, array(
            CURLOPT_URL => $admin_url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        ));
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('Admin access HTTP code: ' . $http_code);
        error_log('Admin access response length: ' . strlen($response));
        error_log('Admin access response sample: ' . substr($response, 0, 1000));
        
        if ($error) {
            error_log('Admin access error: ' . $error);
            return array('success' => false, 'message' => 'Admin access error: ' . $error);
        }
        
        if ($http_code !== 200) {
            error_log('Admin access failed with HTTP code: ' . $http_code);
            return array('success' => false, 'message' => 'Admin access failed: HTTP ' . $http_code);
        }
        
        // Check for admin access indicators
        $admin_indicators = array(
            'wp-admin',
            'dashboard',
            'admin-ajax.php',
            'wp-admin/admin.php',
            'admin_menu',
            'wp-admin-bar',
            'admin-bar',
            'user-edit.php',
            'profile.php',
            'edit.php',
            'post-new.php',
            'plugins.php',
            'themes.php',
            'users.php',
            'options-general.php'
        );
        
        $login_indicators = array(
            'wp-login.php',
            'loginform',
            'lostpassword',
            'register',
            'login_error',
            'incorrect_password',
            'invalid_username'
        );
        
        // Check for login page indicators - be more specific
        $has_login_indicator = false;
        foreach ($login_indicators as $indicator) {
            if (stripos($response, $indicator) !== false) {
                $has_login_indicator = true;
                error_log('Found login indicator: ' . $indicator);
                break;
            }
        }
        
        // Additional check: if we have login indicators AND no admin indicators, it's likely a login page
        if ($has_login_indicator) {
            $has_admin_indicator = false;
            foreach ($admin_indicators as $indicator) {
                if (stripos($response, $indicator) !== false) {
                    $has_admin_indicator = true;
                    break;
                }
            }
            
            if (!$has_admin_indicator) {
                error_log('Admin access failed - redirected to login page (no admin indicators found)');
                return array('success' => false, 'message' => 'No admin access - redirected to login');
            } else {
                error_log('Found both login and admin indicators - likely admin page with login elements');
            }
        }
        
        // Check for admin indicators (if not already checked above)
        if (!isset($has_admin_indicator)) {
            $has_admin_indicator = false;
            foreach ($admin_indicators as $indicator) {
                if (stripos($response, $indicator) !== false) {
                    $has_admin_indicator = true;
                    error_log('Found admin indicator: ' . $indicator);
                    break;
                }
            }
        }
        
        if (!$has_admin_indicator) {
            // If no admin indicators found, check if we're not on a login page
            // This is a more lenient check for cases where the admin page structure is different
            if (!stripos($response, 'wp-login.php') && !stripos($response, 'loginform')) {
                error_log('Admin access verified - not on login page and no login indicators found');
                return array('success' => true, 'message' => 'Admin access verified (lenient check)');
            }
            error_log('Admin access failed - no admin indicators found and on login page');
            return array('success' => false, 'message' => 'No admin access - no admin indicators found');
        }
        
        error_log('Admin access verified successfully');
        return array('success' => true, 'message' => 'Admin access verified');
    }
    
    /**
     * Make authenticated file upload request to WordPress site
     */
    public function make_authenticated_file_upload($url, $data = array()) {
        error_log('=== AUTHENTICATED FILE UPLOAD START ===');
        error_log('Upload URL: ' . $url);
        error_log('Upload data: ' . print_r($data, true));
        
        $ch = curl_init();
        
        $options = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_POST => true,
            CURLOPT_POSTFIELDS => $data,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 300, // 5 minutes for large uploads
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        );
        
        curl_setopt_array($ch, $options);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $final_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
        $error = curl_error($ch);
        curl_close($ch);
        
        error_log('File upload HTTP code: ' . $http_code);
        error_log('File upload final URL: ' . $final_url);
        error_log('File upload response length: ' . strlen($response));
        error_log('File upload response sample: ' . substr($response, 0, 500));
        
        if ($error) {
            error_log('File upload error: ' . $error);
            return array('success' => false, 'message' => 'File upload error: ' . $error);
        }
        
        if ($http_code === 401 || $http_code === 403) {
            error_log('File upload access denied - user not authenticated');
            return array('success' => false, 'message' => 'User not authenticated for file upload');
        }
        
        if ($http_code !== 200) {
            error_log('File upload failed with HTTP code: ' . $http_code);
            return array('success' => false, 'message' => 'File upload failed: HTTP ' . $http_code);
        }
        
        // Check if upload was successful by looking for success indicators
        $success_indicators = array(
            'Plugin installed successfully',
            'Plugin uploaded successfully',
            'Successfully installed',
            'Plugin activated'
        );
        
        $error_indicators = array(
            'Plugin installation failed',
            'Upload failed',
            'Error uploading',
            'Invalid plugin'
        );
        
        foreach ($error_indicators as $indicator) {
            if (stripos($response, $indicator) !== false) {
                error_log('File upload failed - found error indicator: ' . $indicator);
                return array('success' => false, 'message' => 'Plugin upload failed: ' . $indicator);
            }
        }
        
        foreach ($success_indicators as $indicator) {
            if (stripos($response, $indicator) !== false) {
                error_log('File upload successful - found success indicator: ' . $indicator);
                return array('success' => true, 'message' => 'Plugin uploaded successfully');
            }
        }
        
        // If no clear indicators, assume success if we got a 200 response
        error_log('File upload completed with HTTP 200');
        return array('success' => true, 'message' => 'Plugin uploaded successfully');
    }
    
    /**
     * Make authenticated request to WordPress site
     */
    public function make_authenticated_request($url, $data = array(), $method = 'GET') {
        $ch = curl_init();
        
        $options = array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_COOKIEJAR => $this->cookies_file,
            CURLOPT_COOKIEFILE => $this->cookies_file,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_TIMEOUT => 30,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false
        );
        
        if ($method === 'POST' && !empty($data)) {
            $options[CURLOPT_POST] = true;
            $options[CURLOPT_POSTFIELDS] = http_build_query($data);
        }
        
        curl_setopt_array($ch, $options);
        
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);
        
        if ($error) {
            return array('success' => false, 'message' => 'Request error: ' . $error);
        }
        
        return array(
            'success' => true,
            'content' => $response,
            'http_code' => $http_code
        );
    }
}
