<?php
/**
 * Pro Auto-Setup Manager
 * 
 * Handles the Pro Auto-Setup functionality for remote WordPress installations
 */

namespace MBP\Pro_Auto_Setup;

if (!defined('ABSPATH')) {
    exit;
}

class Pro_Auto_Setup_Manager {
    
    /**
     * Constructor
     */
    public function __construct() {
        error_log('Pro_Auto_Setup_Manager constructor called');
        $this->init_hooks();
    }
    
    /**
     * Initialize hooks
     */
    private function init_hooks() {
        error_log('Pro_Auto_Setup_Manager: Registering AJAX hook for mbp_pro_auto_setup');
        add_action('wp_ajax_mbp_pro_auto_setup', array($this, 'ajax_pro_auto_setup'));
        add_action('wp_ajax_mbp_test_ajax', array($this, 'ajax_test'));
        error_log('Pro_Auto_Setup_Manager: AJAX hook registered successfully');
    }
    
    /**
     * Test AJAX handler
     */
    public function ajax_test() {
        error_log('Test AJAX handler called!');
        wp_send_json_success(array('message' => 'Test AJAX working'));
    }
    
    /**
     * Handle Pro Auto-Setup AJAX request
     */
    public function ajax_pro_auto_setup() {
        // Enable comprehensive error reporting
        error_reporting(E_ALL);
        ini_set('display_errors', 1);
        ini_set('log_errors', 1);
        ini_set('error_log', WP_CONTENT_DIR . '/debug.log');
        
        error_log('=== PRO AUTO SETUP AJAX START ===');
        error_log('AJAX handler called successfully!');
        error_log('POST data: ' . print_r($_POST, true));
        error_log('Available AJAX actions: ' . print_r($GLOBALS['wp_filter']['wp_ajax_mbp_pro_auto_setup'] ?? 'Not found', true));
        error_log('WordPress version: ' . get_bloginfo('version'));
        error_log('PHP version: ' . phpversion());
        error_log('Current user: ' . get_current_user_id());
        error_log('Is admin: ' . (is_admin() ? 'yes' : 'no'));
        error_log('Doing AJAX: ' . (wp_doing_ajax() ? 'yes' : 'no'));
        
        try {
            // Check if we're in admin and doing AJAX
            if (!is_admin() || !wp_doing_ajax()) {
                error_log('Not in admin or not AJAX request');
                wp_send_json_error(array('message' => 'Invalid request'));
                return;
            }
            
            // Check nonce
            if (!check_ajax_referer('mbp_wizard_nonce', 'nonce', false)) {
                error_log('Nonce verification failed');
                wp_send_json_error(array('message' => 'Security check failed'));
                return;
            }
            
            $target_url = isset($_POST['target_url']) ? sanitize_url($_POST['target_url']) : '';
            $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
            $password = isset($_POST['password']) ? $_POST['password'] : '';
            
            error_log('=== CREDENTIAL VALIDATION ===');
            error_log('Target URL: ' . $target_url);
            error_log('Username: ' . $username);
            error_log('Password length: ' . strlen($password));
            error_log('URL validation: ' . (filter_var($target_url, FILTER_VALIDATE_URL) ? 'VALID' : 'INVALID'));
            
            if (empty($target_url) || empty($username) || empty($password)) {
                error_log('Missing required fields');
                wp_send_json_error(array('message' => 'Missing required fields'));
                return;
            }
            
            error_log('=== STARTING PRO AUTO SETUP PROCESS ===');
            $result = $this->perform_pro_auto_setup($target_url, $username, $password);
            error_log('=== PRO AUTO SETUP PROCESS COMPLETED ===');
            error_log('Final result: ' . print_r($result, true));
            wp_send_json_success($result);
        } catch (\Exception $e) {
            error_log('Pro auto setup error: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            wp_send_json_error(array('message' => 'Error: ' . $e->getMessage()));
        } catch (\Error $e) {
            error_log('Pro auto setup fatal error: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            wp_send_json_error(array('message' => 'Fatal error: ' . $e->getMessage()));
        }
        error_log('=== PRO AUTO SETUP AJAX END ===');
    }
    
    /**
     * Perform the actual Pro Auto-Setup
     * 
     * This installs the Membership Bridge Pro plugin on the TARGET site
     * using the provided credentials for that target site.
     */
    public function perform_pro_auto_setup($target_url, $username, $password) {
        error_log('=== PERFORM PRO AUTO SETUP START ===');
        error_log('TARGET SITE URL: ' . $target_url);
        error_log('TARGET SITE USERNAME: ' . $username);
        error_log('TARGET SITE PASSWORD: [HIDDEN]');
        $results = array();
        
        try {
            // Check if required classes exist
            if (!class_exists('MBP\Pro_Auto_Setup\WordPress_Authenticator')) {
                throw new \Exception('WordPress_Authenticator class not found');
            }
            
            if (!class_exists('MBP\Pro_Auto_Setup\Plugin_Installer')) {
                throw new \Exception('Plugin_Installer class not found');
            }
            
            error_log('Required classes found, proceeding with setup');
            
            // Step 1: Authenticate with TARGET site (where we're installing the plugin)
            error_log('=== STEP 1: AUTHENTICATION ===');
            error_log('Authenticating with TARGET site: ' . $target_url);
            error_log('Using username: ' . $username);
            $auth_result = $this->authenticate_with_target($target_url, $username, $password);
            $results['authentication'] = $auth_result;
            error_log('Authentication completed. Success: ' . ($auth_result['success'] ? 'YES' : 'NO'));
            error_log('Authentication message: ' . $auth_result['message']);
            error_log('Full auth result: ' . print_r($auth_result, true));
            
            if (!$auth_result['success']) {
                throw new \Exception('Authentication failed: ' . $auth_result['message']);
            }
        
            // Step 2: Install plugin on TARGET site
            error_log('=== STEP 2: PLUGIN INSTALLATION ===');
            error_log('Installing plugin on TARGET site: ' . $target_url);
            $install_result = $this->install_plugin_on_target($target_url, $username, $password);
            $results['install'] = $install_result;
            error_log('Plugin installation completed. Success: ' . ($install_result['success'] ? 'YES' : 'NO'));
            error_log('Install message: ' . $install_result['message']);
            error_log('Full install result: ' . print_r($install_result, true));
            
            if (!$install_result['success']) {
                throw new \Exception('Failed to install plugin: ' . $install_result['message']);
            }
            
            // Step 3: Activate plugin on TARGET site
            error_log('=== STEP 3: PLUGIN ACTIVATION ===');
            error_log('Activating plugin on TARGET site: ' . $target_url);
            $activate_result = $this->activate_plugin_on_target($target_url, $username, $password);
            $results['activate'] = $activate_result;
            error_log('Plugin activation completed. Success: ' . ($activate_result['success'] ? 'YES' : 'NO'));
            error_log('Activate message: ' . $activate_result['message']);
            error_log('Full activate result: ' . print_r($activate_result, true));
            
            if (!$activate_result['success']) {
                throw new \Exception('Failed to activate plugin: ' . $activate_result['message']);
            }
            
            // Step 4: Generate API key on TARGET site
            error_log('=== STEP 4: API KEY GENERATION ===');
            error_log('Generating API key on TARGET site: ' . $target_url);
            $api_key_result = $this->generate_api_key_on_target($target_url, $username, $password);
            $results['api_key'] = $api_key_result;
            error_log('API key generation completed. Success: ' . ($api_key_result['success'] ? 'YES' : 'NO'));
            error_log('API key message: ' . $api_key_result['message']);
            error_log('Generated API key: ' . (isset($api_key_result['api_key']) ? $api_key_result['api_key'] : 'NOT GENERATED'));
            error_log('Full API key result: ' . print_r($api_key_result, true));
            
            if (!$api_key_result['success']) {
                throw new \Exception('Failed to generate API key: ' . $api_key_result['message']);
            }
            
            // Step 5: Configure TARGET site
            error_log('=== STEP 5: TARGET SITE CONFIGURATION ===');
            error_log('Configuring TARGET site: ' . $target_url);
            error_log('Using API key: ' . $api_key_result['api_key']);
            $config_result = $this->configure_target_site($target_url, $username, $password, $api_key_result['api_key']);
            $results['configure'] = $config_result;
            error_log('Target site configuration completed. Success: ' . ($config_result['success'] ? 'YES' : 'NO'));
            error_log('Config message: ' . $config_result['message']);
            error_log('Full config result: ' . print_r($config_result, true));
            
            if (!$config_result['success']) {
                throw new \Exception('Failed to configure target site: ' . $config_result['message']);
            }
            
        } catch (\Exception $e) {
            error_log('Pro auto setup error: ' . $e->getMessage());
            throw $e;
        }
        
        error_log('=== PRO AUTO SETUP SUCCESS ===');
        error_log('All steps completed successfully!');
        error_log('Final API key: ' . $api_key_result['api_key']);
        error_log('Total results: ' . print_r($results, true));
        
        return array(
            'success' => true,
            'message' => 'Pro Auto-Setup completed successfully!',
            'api_key' => $api_key_result['api_key'],
            'results' => $results
        );
    }
    
    /**
     * Authenticate with target site using WordPress REST API
     */
    private function authenticate_with_target($target_url, $username, $password) {
        error_log('=== AUTHENTICATE WITH TARGET START ===');
        error_log('Target URL: ' . $target_url);
        error_log('Username: ' . $username);
        
        try {
            $authenticator = new WordPress_Authenticator();
            error_log('WordPress_Authenticator created successfully');
            
            $result = $authenticator->authenticate($target_url, $username, $password);
            error_log('Authentication result: ' . print_r($result, true));
            return $result;
        } catch (\Exception $e) {
            error_log('Authentication error: ' . $e->getMessage());
            error_log('Stack trace: ' . $e->getTraceAsString());
            return array('success' => false, 'message' => 'Authentication error: ' . $e->getMessage());
        }
        error_log('=== AUTHENTICATE WITH TARGET END ===');
    }
    
    /**
     * Install plugin on target site
     */
    private function install_plugin_on_target($target_url, $username, $password) {
        error_log('=== INSTALL PLUGIN ON TARGET START ===');
        error_log('Creating WordPress_Authenticator...');
        $authenticator = new WordPress_Authenticator();
        error_log('Creating Plugin_Installer...');
        $installer = new Plugin_Installer($authenticator);
        
        // First authenticate
        $auth_result = $authenticator->authenticate($target_url, $username, $password);
        if (!$auth_result['success']) {
            return $auth_result;
        }
        
        // Then install plugin
        return $installer->install_plugin($target_url, $username, $password);
    }

    /**
     * Activate plugin on target site
     */
    private function activate_plugin_on_target($target_url, $username, $password) {
        $authenticator = new WordPress_Authenticator();
        $installer = new Plugin_Installer($authenticator);
        
        // First authenticate
        $auth_result = $authenticator->authenticate($target_url, $username, $password);
        if (!$auth_result['success']) {
            return $auth_result;
        }
        
        // Then activate plugin
        return $installer->activate_plugin($target_url, $username, $password);
    }
    
    /**
     * Generate API key on target site
     */
    private function generate_api_key_on_target($target_url, $username, $password) {
        // Generate a secure API key
        $api_key = 'mbp_' . wp_generate_password(32, false);
        
        // Store API key in target site's database
        $store_result = $this->store_api_key_on_target($target_url, $username, $password, $api_key);
        
        if (!$store_result['success']) {
            return $store_result;
        }
        
        return array(
            'success' => true,
            'message' => 'API key generated and stored successfully',
            'api_key' => $api_key
        );
    }
    
    /**
     * Configure target site
     */
    private function configure_target_site($target_url, $username, $password, $api_key) {
        // Configure plugin settings on target site
        $config_settings = array(
            'mbp_site_role' => 'target',
            'mbp_api_key' => $api_key,
            'mbp_auto_setup_completed' => true,
            'mbp_auto_setup_date' => current_time('mysql')
        );
        
        $config_result = $this->update_target_settings($target_url, $username, $password, $config_settings);
        
        if (!$config_result['success']) {
            return $config_result;
        }
        
        return array(
            'success' => true,
            'message' => 'Target site configured successfully',
            'api_key' => $api_key
        );
    }
    
    
    /**
     * Store API key on target site
     */
    private function store_api_key_on_target($target_url, $username, $password, $api_key) {
        error_log('=== STORE API KEY ON TARGET START ===');
        error_log('Storing API key on target: ' . $target_url);
        
        try {
            // Use WordPress REST API to store the API key
            $api_url = rtrim($target_url, '/') . '/wp-json/membership-bridge/v1/settings';
            
            $response = wp_remote_post($api_url, array(
                'method' => 'POST',
                'timeout' => 30,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Basic ' . base64_encode($username . ':' . $password)
                ),
                'body' => json_encode(array(
                    'api_key' => $api_key,
                    'source_site' => home_url(),
                    'configured_at' => current_time('mysql')
                ))
            ));
            
            if (is_wp_error($response)) {
                error_log('API key storage failed: ' . $response->get_error_message());
                return array(
                    'success' => false,
                    'message' => 'Failed to store API key: ' . $response->get_error_message()
                );
            }
            
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            
            error_log('API key storage response code: ' . $response_code);
            error_log('API key storage response: ' . $response_body);
            
            if ($response_code === 200) {
                $data = json_decode($response_body, true);
                if ($data && isset($data['success']) && $data['success']) {
                    error_log('API key stored successfully');
                    return array(
                        'success' => true,
                        'message' => 'API key stored successfully',
                        'api_key' => $api_key
                    );
                } else {
                    error_log('Target site returned error: ' . ($data['message'] ?? 'Unknown error'));
                    return array(
                        'success' => false,
                        'message' => 'Target site error: ' . ($data['message'] ?? 'Unknown error')
                    );
                }
            } else {
                error_log('HTTP error storing API key: ' . $response_code);
                return array(
                    'success' => false,
                    'message' => 'Failed to store API key with HTTP ' . $response_code
                );
            }
        } catch (\Exception $e) {
            error_log('API key storage error: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => 'API key storage error: ' . $e->getMessage()
            );
        }
        
        error_log('=== STORE API KEY ON TARGET END ===');
    }
    
    /**
     * Update target site settings
     */
    private function update_target_settings($target_url, $username, $password, $settings) {
        error_log('=== UPDATE TARGET SETTINGS START ===');
        error_log('Updating settings on target: ' . $target_url);
        
        try {
            // Use WordPress REST API to update settings
            $api_url = rtrim($target_url, '/') . '/wp-json/membership-bridge/v1/configure';
            
            $response = wp_remote_post($api_url, array(
                'method' => 'POST',
                'timeout' => 30,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'Authorization' => 'Basic ' . base64_encode($username . ':' . $password)
                ),
                'body' => json_encode(array(
                    'settings' => $settings,
                    'source_site' => home_url(),
                    'configured_at' => current_time('mysql')
                ))
            ));
            
            if (is_wp_error($response)) {
                error_log('Settings update failed: ' . $response->get_error_message());
                return array(
                    'success' => false,
                    'message' => 'Failed to update settings: ' . $response->get_error_message()
                );
            }
            
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            
            error_log('Settings update response code: ' . $response_code);
            error_log('Settings update response: ' . $response_body);
            
            if ($response_code === 200) {
                $data = json_decode($response_body, true);
                if ($data && isset($data['success']) && $data['success']) {
                    error_log('Settings updated successfully');
                    return array(
                        'success' => true,
                        'message' => 'Target site configured successfully',
                        'settings' => $settings
                    );
                } else {
                    error_log('Target site returned error: ' . ($data['message'] ?? 'Unknown error'));
                    return array(
                        'success' => false,
                        'message' => 'Target site error: ' . ($data['message'] ?? 'Unknown error')
                    );
                }
            } else {
                error_log('HTTP error updating settings: ' . $response_code);
                return array(
                    'success' => false,
                    'message' => 'Failed to update settings with HTTP ' . $response_code
                );
            }
        } catch (\Exception $e) {
            error_log('Settings update error: ' . $e->getMessage());
            return array(
                'success' => false,
                'message' => 'Settings update error: ' . $e->getMessage()
            );
        }
        
        error_log('=== UPDATE TARGET SETTINGS END ===');
    }
}
