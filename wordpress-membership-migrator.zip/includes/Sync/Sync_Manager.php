<?php

namespace MBP\Sync;

use MBP\API\API_Manager;

/**
 * Sync Manager - Handles ongoing synchronization between sites
 */
class Sync_Manager {
    
    private $api_manager;
    
    public function __construct() {
        $this->api_manager = new API_Manager();
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('mbp_sync_cron', array($this, 'sync_cron'));
        add_action('wp_ajax_mbp_sync_now', array($this, 'ajax_sync_now'));
        add_action('wp_ajax_mbp_enable_sync', array($this, 'ajax_enable_sync'));
        add_action('wp_ajax_mbp_disable_sync', array($this, 'ajax_disable_sync'));
    }
    
    /**
     * Enable sync
     */
    public function enable_sync() {
        update_option('mbp_sync_enabled', true);
        update_option('mbp_sync_started', current_time('timestamp'));
        
        // Schedule sync events
        if (!wp_next_scheduled('mbp_sync_cron')) {
            $frequency = get_option('mbp_sync_frequency', 'hourly');
            wp_schedule_event(time(), $frequency, 'mbp_sync_cron');
        }
        
        return array(
            'success' => true,
            'message' => __('Sync enabled successfully.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Disable sync
     */
    public function disable_sync() {
        update_option('mbp_sync_enabled', false);
        
        // Clear scheduled events
        wp_clear_scheduled_hook('mbp_sync_cron');
        
        return array(
            'success' => true,
            'message' => __('Sync disabled successfully.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Sync now
     */
    public function sync_now() {
        $sync_enabled = get_option('mbp_sync_enabled', false);
        
        if (!$sync_enabled) {
            return array(
                'success' => false,
                'message' => __('Sync is not enabled.', 'membership-bridge-pro')
            );
        }
        
        $result = $this->perform_sync();
        
        if ($result['success']) {
            update_option('mbp_last_sync', current_time('timestamp'));
        }
        
        return $result;
    }
    
    /**
     * Perform sync
     */
    private function perform_sync() {
        $sync_id = 'sync_' . time() . '_' . wp_generate_password(8, false);
        
        // Get changes since last sync
        $changes = $this->get_changes_since_last_sync();
        
        if (empty($changes)) {
            return array(
                'success' => true,
                'message' => __('No changes to sync.', 'membership-bridge-pro'),
                'changes_count' => 0
            );
        }
        
        $success_count = 0;
        $error_count = 0;
        
        foreach ($changes as $change) {
            $result = $this->sync_change($change, $sync_id);
            
            if ($result['success']) {
                $success_count++;
            } else {
                $error_count++;
                $this->log_sync_error($sync_id, $change, $result['message']);
            }
        }
        
        return array(
            'success' => true,
            'message' => sprintf(__('Sync completed. %d successful, %d errors.', 'membership-bridge-pro'), $success_count, $error_count),
            'success_count' => $success_count,
            'error_count' => $error_count,
            'changes_count' => count($changes)
        );
    }
    
    /**
     * Get changes since last sync
     */
    private function get_changes_since_last_sync() {
        $last_sync = get_option('mbp_last_sync', 0);
        $changes = array();
        
        // Get user changes
        $user_changes = $this->get_user_changes($last_sync);
        $changes = array_merge($changes, $user_changes);
        
        // Get membership changes
        $membership_changes = $this->get_membership_changes($last_sync);
        $changes = array_merge($changes, $membership_changes);
        
        return $changes;
    }
    
    /**
     * Get user changes since last sync
     */
    private function get_user_changes($last_sync) {
        global $wpdb;
        
        $changes = $wpdb->get_results($wpdb->prepare("
            SELECT 
                u.ID,
                u.user_login,
                u.user_email,
                u.user_registered,
                u.display_name,
                um.meta_value as membership_level,
                um2.meta_value as membership_status,
                um3.meta_value as startdate,
                um4.meta_value as enddate,
                'user_update' as change_type
            FROM {$wpdb->users} u
            INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
            LEFT JOIN {$wpdb->usermeta} um2 ON u.ID = um2.user_id AND um2.meta_key = 'pmpro_membership_status'
            LEFT JOIN {$wpdb->usermeta} um3 ON u.ID = um3.user_id AND um3.meta_key = 'pmpro_startdate'
            LEFT JOIN {$wpdb->usermeta} um4 ON u.ID = um4.user_id AND um4.meta_key = 'pmpro_enddate'
            WHERE um.meta_key = 'pmpro_membership_level'
            AND um.meta_value != '0'
            AND u.user_registered > %s
        ", date('Y-m-d H:i:s', $last_sync)));
        
        return $changes;
    }
    
    /**
     * Get membership changes since last sync
     */
    private function get_membership_changes($last_sync) {
        global $wpdb;
        
        $changes = $wpdb->get_results($wpdb->prepare("
            SELECT 
                mu.id,
                mu.user_id,
                mu.membership_id,
                mu.status,
                mu.startdate,
                mu.enddate,
                mu.modified,
                'membership_update' as change_type
            FROM {$wpdb->prefix}pmpro_memberships_users mu
            WHERE mu.modified > %s
        ", date('Y-m-d H:i:s', $last_sync)));
        
        return $changes;
    }
    
    /**
     * Sync a single change
     */
    private function sync_change($change, $sync_id) {
        try {
            if ($change->change_type === 'user_update') {
                return $this->sync_user_change($change, $sync_id);
            } elseif ($change->change_type === 'membership_update') {
                return $this->sync_membership_change($change, $sync_id);
            }
            
            return array('success' => false, 'message' => 'Unknown change type');
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * Sync user change
     */
    private function sync_user_change($change, $sync_id) {
        $user_data = array(
            'user_login' => $change->user_login,
            'user_email' => $change->user_email,
            'display_name' => $change->display_name,
            'membership_level' => $change->membership_level,
            'membership_status' => $change->membership_status,
            'startdate' => $change->startdate,
            'enddate' => $change->enddate,
        );
        
        $result = $this->api_manager->update_user($change->ID, $user_data);
        
        if ($result['success']) {
            $this->log_sync_success($sync_id, $change->ID, 'user_sync', 'User synced successfully');
        }
        
        return $result;
    }
    
    /**
     * Sync membership change
     */
    private function sync_membership_change($change, $sync_id) {
        $membership_data = array(
            'user_id' => $change->user_id,
            'membership_id' => $change->membership_id,
            'status' => $change->status,
            'startdate' => $change->startdate,
            'enddate' => $change->enddate,
        );
        
        $result = $this->api_manager->sync_data($membership_data);
        
        if ($result['success']) {
            $this->log_sync_success($sync_id, $change->user_id, 'membership_sync', 'Membership synced successfully');
        }
        
        return $result;
    }
    
    /**
     * Cron sync
     */
    public function sync_cron() {
        $sync_enabled = get_option('mbp_sync_enabled', false);
        
        if (!$sync_enabled) {
            return;
        }
        
        $this->perform_sync();
    }
    
    /**
     * Log sync success
     */
    private function log_sync_success($sync_id, $user_id, $action, $message) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'mbp_sync_queue',
            array(
                'sync_id' => $sync_id,
                'action' => $action,
                'data' => json_encode(array('user_id' => $user_id)),
                'status' => 'success',
                'created_at' => current_time('mysql')
            )
        );
    }
    
    /**
     * Log sync error
     */
    private function log_sync_error($sync_id, $change, $message) {
        global $wpdb;
        
        $wpdb->insert(
            $wpdb->prefix . 'mbp_sync_queue',
            array(
                'sync_id' => $sync_id,
                'action' => 'error',
                'data' => json_encode($change),
                'status' => 'error',
                'created_at' => current_time('mysql')
            )
        );
    }
    
    // AJAX handlers
    public function ajax_sync_now() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $result = $this->sync_now();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_enable_sync() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $result = $this->enable_sync();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_disable_sync() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $result = $this->disable_sync();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
}
