<?php

namespace MBP\Wizard;

/**
 * Wizard Manager - Handles the guided migration wizard
 */
class Wizard_Manager {
    
    private $current_step;
    private $wizard_data;
    private $platform_detector;
    
    public function __construct() {
        $this->init_hooks();
        $this->current_step = $this->get_current_step();
        $this->wizard_data = $this->get_wizard_data();
        $this->platform_detector = new \MBP\Detectors\Platform_Detector();
    }
    
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_wizard_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_wizard_scripts'));
        add_action('wp_ajax_mbp_wizard_next', array($this, 'ajax_wizard_next'));
        add_action('wp_ajax_mbp_wizard_previous', array($this, 'ajax_wizard_previous'));
        add_action('wp_ajax_mbp_wizard_save', array($this, 'ajax_wizard_save'));
        add_action('wp_ajax_mbp_wizard_complete', array($this, 'ajax_wizard_complete'));
        add_action('wp_ajax_mbp_toggle_pro', array($this, 'ajax_toggle_pro'));
        add_action('wp_ajax_mbp_validate_url', array($this, 'ajax_validate_url'));
        add_action('wp_ajax_mbp_validate_credentials', array($this, 'ajax_validate_credentials'));
        add_action('wp_ajax_mbp_test_connection', array($this, 'ajax_test_connection'));
        add_action('wp_ajax_mbp_debug_test', array($this, 'ajax_debug_test'));
    }
    
    /**
     * Add wizard submenu under main plugin menu
     */
    public function add_wizard_menu() {
        add_submenu_page(
            'membership-bridge',
            __('MemberBridge Wizard', 'membership-bridge-pro'),
            __('Wizard', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge-wizard',
            array($this, 'render_wizard')
        );
    }
    
    /**
     * Enqueue wizard scripts
     */
    public function enqueue_wizard_scripts($hook) {
        if (strpos($hook, 'membership-bridge-wizard') === false) {
            return;
        }
        
        wp_enqueue_script('mbp-wizard', MBP_PLUGIN_URL . 'assets/js/wizard.js', array('jquery'), MBP_VERSION, true);
        wp_enqueue_style('mbp-wizard', MBP_PLUGIN_URL . 'assets/css/wizard.css', array(), MBP_VERSION);
        
        wp_localize_script('mbp-wizard', 'mbp_wizard', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mbp_wizard_nonce'),
            'current_step' => $this->current_step,
            'total_steps' => 6,
            'strings' => array(
                'next' => __('Next', 'membership-bridge-pro'),
                'previous' => __('Previous', 'membership-bridge-pro'),
                'complete' => __('Complete Setup', 'membership-bridge-pro'),
                'saving' => __('Saving...', 'membership-bridge-pro'),
                'error' => __('An error occurred. Please try again.', 'membership-bridge-pro'),
            )
        ));
    }
    
    /**
     * Render wizard
     */
    public function render_wizard() {
        error_log('=== WIZARD RENDER START ===');
        error_log('Wizard - URL: ' . $_SERVER['REQUEST_URI']);
        error_log('Wizard - GET params: ' . print_r($_GET, true));
        error_log('Wizard - POST params: ' . print_r($_POST, true));
        
        // Detect current step right before rendering
        $step = $this->get_current_step();
        error_log('Wizard - Final step determined: ' . $step);
        
        // Remove all admin notices on wizard pages
        remove_all_actions('admin_notices');
        remove_all_actions('all_admin_notices');
        
        // Add custom CSS to hide any remaining notices
        add_action('admin_head', array($this, 'hide_admin_notices_css'));
        
        // Get platform detection results
        $detected_platforms = $this->platform_detector->get_detected_platforms();
        $active_platforms = $this->platform_detector->get_active_platforms();
        $available_platforms = $this->platform_detector->get_available_platforms();
        $coming_soon_platforms = $this->platform_detector->get_coming_soon_platforms();
        $has_supported_platform = $this->platform_detector->has_supported_platform();
        
        // Render current step
        $step_file = MBP_PLUGIN_DIR . "templates/wizard/step-{$step}.php";
        error_log('Wizard - Step file path: ' . $step_file);
        error_log('Wizard - File exists: ' . (file_exists($step_file) ? 'YES' : 'NO'));
        
        // Check for alternative step file names
        $alternative_files = array(
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-welcome.php",
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-target-setup.php",
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-data-selection.php",
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-advanced-options.php",
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-preview.php",
            MBP_PLUGIN_DIR . "templates/wizard/step-{$step}-execute.php"
        );
        
        $found_file = null;
        if (file_exists($step_file)) {
            $found_file = $step_file;
        } else {
            foreach ($alternative_files as $alt_file) {
                if (file_exists($alt_file)) {
                    $found_file = $alt_file;
                    break;
                }
            }
        }
        
        if ($found_file) {
            error_log('Wizard - INCLUDING step file: ' . $found_file);
            include $found_file;
        } else {
            error_log('Wizard - Step file NOT FOUND, falling back to step-1');
            include MBP_PLUGIN_DIR . 'templates/wizard/step-1-welcome.php';
        }
        
        error_log('=== WIZARD RENDER END ===');
    }
    
    /**
     * Get current wizard step
     */
    private function get_current_step() {
        // Check URL parameter first
        if (isset($_GET['step']) && is_numeric($_GET['step'])) {
            $step = intval($_GET['step']);
            // Update the database option to match URL
            update_option('mbp_wizard_step', $step);
            error_log('Wizard - Using URL step: ' . $step . ' (URL: ' . $_GET['step'] . ')');
            return $step;
        }
        
        // Fall back to database option
        $step = get_option('mbp_wizard_step', 1);
        error_log('Wizard - Using database step: ' . $step . ' (URL step not set)');
        return intval($step);
    }
    
    /**
     * Get wizard data
     */
    private function get_wizard_data() {
        $data = get_option('mbp_wizard_data', array());
        return is_array($data) ? $data : array();
    }
    
    /**
     * Save wizard data
     */
    private function save_wizard_data($data) {
        $this->wizard_data = array_merge($this->wizard_data, $data);
        update_option('mbp_wizard_data', $this->wizard_data);
    }
    
    /**
     * Get wizard steps
     */
    public function get_wizard_steps() {
        return array(
            1 => __('Welcome', 'membership-bridge-pro'),
            2 => __('Target Setup', 'membership-bridge-pro'),
            3 => __('Data Selection', 'membership-bridge-pro'),
            4 => __('Advanced Options', 'membership-bridge-pro'),
            5 => __('Preview', 'membership-bridge-pro'),
            6 => __('Execute', 'membership-bridge-pro'),
        );
    }
    
    /**
     * Check if wizard is completed
     */
    public function is_wizard_completed() {
        return get_option('mbp_wizard_completed', false);
    }
    
    /**
     * Show wizard completion alert
     */
    public function show_wizard_alert() {
        if (!$this->is_wizard_completed()) {
            ?>
            <div class="notice notice-warning mbp-wizard-alert">
                <p>
                    <strong><?php _e('Migration Wizard Required', 'membership-bridge-pro'); ?></strong>
                    <?php _e('Please complete the migration wizard before accessing other features.', 'membership-bridge-pro'); ?>
                    <a href="<?php echo admin_url('admin.php?page=membership-bridge-wizard'); ?>" class="button button-primary">
                        <?php _e('Start Wizard', 'membership-bridge-pro'); ?>
                    </a>
                </p>
            </div>
            <?php
        }
    }
    
    // AJAX handlers
    public function ajax_wizard_next() {
        try {
            error_log('=== AJAX WIZARD NEXT START ===');
            error_log('Wizard Next AJAX - Step: ' . (isset($_POST['step']) ? $_POST['step'] : 'not set'));
            error_log('Wizard Next AJAX - Data: ' . print_r($_POST['data'] ?? 'not set', true));
            error_log('Wizard Next AJAX - All POST: ' . print_r($_POST, true));
            
            check_ajax_referer('mbp_wizard_nonce', 'nonce');
            
            $step = intval($_POST['step']);
            $data = isset($_POST['data']) ? $_POST['data'] : array();
            
            // Handle JSON data if it's a string
            if (is_string($data)) {
                $data = json_decode($data, true);
            }
            
            // Ensure data is an array
            if (!is_array($data)) {
                $data = array();
            }
            
            error_log('Wizard Next AJAX - Processed step: ' . $step);
            error_log('Wizard Next AJAX - Processed data: ' . print_r($data, true));
            
            // Save step data
            $this->save_wizard_data($data);
            
            // Check if we're at the last step
            $total_steps = count($this->get_wizard_steps());
            error_log('Wizard Next AJAX - Total steps: ' . $total_steps);
            
            if ($step >= $total_steps) {
                // Complete the wizard
                error_log('Wizard Next AJAX - Completing wizard');
                update_option('mbp_wizard_completed', true);
                wp_send_json_success(array(
                    'next_step' => $step,
                    'redirect' => admin_url('admin.php?page=membership-bridge'),
                    'completed' => true
                ));
            } else {
                // Move to next step
                $next_step = $step + 1;
                update_option('mbp_wizard_step', $next_step);
                
                error_log('Wizard Next AJAX - Moving from step ' . $step . ' to step ' . $next_step);
                error_log('Wizard Next AJAX - Database step after update: ' . get_option('mbp_wizard_step'));
                
                $redirect_url = admin_url('admin.php?page=membership-bridge-wizard&step=' . $next_step);
                error_log('Wizard Next AJAX - Redirect URL: ' . $redirect_url);
                
                wp_send_json_success(array(
                    'next_step' => $next_step,
                    'redirect' => $redirect_url
                ));
            }
            
        } catch (Exception $e) {
            error_log('Wizard Next AJAX Error: ' . $e->getMessage());
            error_log('Wizard Next AJAX Error Stack: ' . $e->getTraceAsString());
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
        
        error_log('=== AJAX WIZARD NEXT END ===');
    }

    /**
     * Handle pro toggle AJAX request
     */
    public function ajax_toggle_pro() {
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $is_pro = isset($_POST['is_pro']) ? (bool) $_POST['is_pro'] : false;
        update_option('mbp_pro_mode_enabled', $is_pro);
        
        wp_send_json_success(array('is_pro' => $is_pro));
    }

    /**
     * Handle URL validation AJAX request
     */
    public function ajax_validate_url() {
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $url = isset($_POST['url']) ? sanitize_url($_POST['url']) : '';
        
        if (empty($url)) {
            wp_send_json_error(array('message' => 'URL is required'));
        }
        
        // Validate URL format
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            wp_send_json_success(array(
                'valid' => false,
                'status' => 'invalid',
                'message' => 'Invalid URL format'
            ));
        }
        
        // Check if URL is accessible
        $response = $this->check_url_accessibility($url);
        
        wp_send_json_success(array(
            'valid' => $response['accessible'],
            'status' => $response['accessible'] ? 'valid' : 'invalid',
            'message' => $response['message'],
            'response_code' => $response['response_code']
        ));
    }
    
    /**
     * AJAX handler for WordPress credential validation
     */
    public function ajax_validate_credentials() {
        error_log('=== CREDENTIAL VALIDATION AJAX START ===');
        
        // Enhanced logging for debugging
        error_log('🔐 Credential validation AJAX started');
        
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $target_url = isset($_POST['target_url']) ? sanitize_url($_POST['target_url']) : '';
        $username = isset($_POST['username']) ? sanitize_text_field($_POST['username']) : '';
        $password = isset($_POST['password']) ? $_POST['password'] : '';
        
        error_log('Validating credentials for: ' . $target_url);
        error_log('Username: ' . $username);
        error_log('Password length: ' . strlen($password));
        
        if (empty($target_url) || empty($username) || empty($password)) {
            error_log('Missing required fields');
            wp_send_json_error(array('message' => 'All fields are required'));
            return;
        }
        
        try {
            // Use the WordPress Authenticator to validate credentials
            $authenticator = new \MBP\Pro_Auto_Setup\WordPress_Authenticator();
            $result = $authenticator->authenticate($target_url, $username, $password);
            
            error_log('Credential validation result: ' . print_r($result, true));
            
            if ($result['success']) {
                error_log('Credentials validated successfully');
                wp_send_json_success(array(
                    'message' => 'Credentials validated successfully!',
                    'user_info' => $result['user_info'] ?? null
                ));
            } else {
                error_log('Credential validation failed: ' . $result['message']);
                wp_send_json_error(array('message' => $result['message']));
            }
        } catch (Exception $e) {
            error_log('Credential validation error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Validation error: ' . $e->getMessage()));
        }
        
        error_log('=== CREDENTIAL VALIDATION AJAX END ===');
    }
    
    
    /**
     * AJAX handler for testing connection to target site
     */
    public function ajax_test_connection() {
        error_log('=== TEST CONNECTION AJAX START ===');
        
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $target_url = isset($_POST['target_url']) ? sanitize_url($_POST['target_url']) : '';
        $api_key = isset($_POST['api_key']) ? sanitize_text_field($_POST['api_key']) : '';
        
        error_log('Testing connection to: ' . $target_url);
        error_log('API key: ' . $api_key);
        
        if (empty($target_url) || empty($api_key)) {
            error_log('Missing required fields');
            wp_send_json_error(array('message' => 'Target URL and API key are required'));
            return;
        }
        
        try {
            // Test connection to target site
            $test_url = rtrim($target_url, '/') . '/wp-json/membership-bridge/v1/test';
            
            $response = wp_remote_post($test_url, array(
                'method' => 'POST',
                'timeout' => 30,
                'headers' => array(
                    'Content-Type' => 'application/json',
                    'X-API-Key' => $api_key
                ),
                'body' => json_encode(array(
                    'action' => 'test_connection',
                    'source_site' => home_url()
                ))
            ));
            
            if (is_wp_error($response)) {
                error_log('Connection test failed: ' . $response->get_error_message());
                wp_send_json_error(array('message' => 'Connection failed: ' . $response->get_error_message()));
                return;
            }
            
            $response_code = wp_remote_retrieve_response_code($response);
            $response_body = wp_remote_retrieve_body($response);
            
            error_log('Response code: ' . $response_code);
            error_log('Response body: ' . $response_body);
            
            if ($response_code === 200) {
                $data = json_decode($response_body, true);
                if ($data && isset($data['success']) && $data['success']) {
                    error_log('Connection test successful');
                    wp_send_json_success(array('message' => 'Connection successful! Target site is ready.'));
                } else {
                    error_log('Target site returned error: ' . ($data['message'] ?? 'Unknown error'));
                    wp_send_json_error(array('message' => 'Target site error: ' . ($data['message'] ?? 'Unknown error')));
                }
            } else {
                error_log('HTTP error: ' . $response_code);
                wp_send_json_error(array('message' => 'Connection failed with HTTP ' . $response_code));
            }
        } catch (Exception $e) {
            error_log('Connection test error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Connection error: ' . $e->getMessage()));
        }
        
        error_log('=== TEST CONNECTION AJAX END ===');
    }
    
    /**
     * Debug test AJAX handler
     */
    public function ajax_debug_test() {
        error_log('=== DEBUG TEST AJAX START ===');
        
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $debug_info = array(
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'is_admin' => is_admin(),
            'doing_ajax' => wp_doing_ajax(),
            'wordpress_version' => get_bloginfo('version'),
            'php_version' => phpversion(),
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'post_data' => $_POST,
            'server_info' => array(
                'REQUEST_METHOD' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
                'HTTP_HOST' => $_SERVER['HTTP_HOST'] ?? 'unknown',
                'REQUEST_URI' => $_SERVER['REQUEST_URI'] ?? 'unknown'
            )
        );
        
        error_log('Debug test data: ' . print_r($debug_info, true));
        
        wp_send_json_success(array(
            'message' => 'Debug test successful',
            'debug_info' => $debug_info
        ));
        
        error_log('=== DEBUG TEST AJAX END ===');
    }


    /**
     * Check if URL is accessible
     */
    private function check_url_accessibility($url) {
        // Check if cURL is available
        if (!function_exists('curl_init')) {
            return array(
                'accessible' => false,
                'message' => 'cURL is not available on this server',
                'response_code' => 0
            );
        }
        
        // Set timeout for the request
        $timeout = 10;
        
        // Initialize cURL
        $ch = curl_init();
        
        if (!$ch) {
            return array(
                'accessible' => false,
                'message' => 'Failed to initialize cURL',
                'response_code' => 0
            );
        }
        
        // Set cURL options
        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_MAXREDIRS => 5,
            CURLOPT_TIMEOUT => $timeout,
            CURLOPT_CONNECTTIMEOUT => $timeout,
            CURLOPT_SSL_VERIFYPEER => false,
            CURLOPT_SSL_VERIFYHOST => false,
            CURLOPT_USERAGENT => 'Membership Bridge Pro/1.0',
            CURLOPT_NOBODY => true, // HEAD request only
            CURLOPT_HEADER => true
        ));
        
        // Execute request
        $response = curl_exec($ch);
        $http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        
        curl_close($ch);
        
        // Check for cURL errors
        if ($error) {
            return array(
                'accessible' => false,
                'message' => 'Connection error: ' . $error,
                'response_code' => 0
            );
        }
        
        // Check HTTP response code
        if ($http_code >= 200 && $http_code < 400) {
            return array(
                'accessible' => true,
                'message' => 'URL is accessible (HTTP ' . $http_code . ')',
                'response_code' => $http_code
            );
        } else {
            return array(
                'accessible' => false,
                'message' => 'URL returned HTTP ' . $http_code,
                'response_code' => $http_code
            );
        }
    }
    
    public function ajax_wizard_previous() {
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $step = intval($_POST['step']);
        
        // Move to previous step
        $prev_step = max(1, $step - 1);
        update_option('mbp_wizard_step', $prev_step);
        
        wp_send_json_success(array(
            'prev_step' => $prev_step,
            'redirect' => admin_url('admin.php?page=membership-bridge-wizard')
        ));
    }
    
    public function ajax_wizard_save() {
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        $data = $_POST['data'];
        $this->save_wizard_data($data);
        
        wp_send_json_success(array(
            'message' => __('Settings saved successfully!', 'membership-bridge-pro')
        ));
    }
    
    public function ajax_wizard_complete() {
        check_ajax_referer('mbp_wizard_nonce', 'nonce');
        
        // Mark wizard as completed
        update_option('mbp_wizard_completed', true);
        
        // Save final data
        $data = $_POST['data'];
        $this->save_wizard_data($data);
        
        // Start migration if requested
        if (isset($data['start_migration']) && $data['start_migration']) {
            $migration_manager = new \MBP\Migration\Migration_Manager();
            $result = $migration_manager->start_migration();
            
            if ($result['success']) {
                wp_send_json_success(array(
                    'message' => __('Wizard completed and migration started!', 'membership-bridge-pro'),
                    'redirect' => admin_url('admin.php?page=membership-bridge')
                ));
            } else {
                wp_send_json_error($result);
            }
        } else {
            wp_send_json_success(array(
                'message' => __('Wizard completed successfully!', 'membership-bridge-pro'),
                'redirect' => admin_url('admin.php?page=membership-bridge')
            ));
        }
    }
    
    /**
     * Hide admin notices with CSS
     */
    public function hide_admin_notices_css() {
        ?>
        <style>
        /* Hide all admin notices on wizard pages */
        .notice,
        .updated,
        .error,
        .warning,
        .info,
        .notice-success,
        .notice-error,
        .notice-warning,
        .notice-info,
        .update-nag,
        .wp-core-ui .notice,
        .wp-core-ui .updated,
        .wp-core-ui .error,
        .wp-core-ui .warning,
        .wp-core-ui .info {
            display: none !important;
        }
        </style>
        <?php
    }
}
