<?php

namespace MBP\Detectors;

/**
 * Platform Detector - Detects active membership platforms
 */
class Platform_Detector {
    
    private $detected_platforms = array();
    
    public function __construct() {
        $this->detect_platforms();
    }
    
    /**
     * Detect all active membership platforms
     */
    private function detect_platforms() {
        $this->detected_platforms = array(
            'pmpro' => $this->detect_pmpro(),
            'memberpress' => $this->detect_memberpress(),
            'woocommerce_memberships' => $this->detect_woocommerce_memberships(),
            'restrict_content_pro' => $this->detect_restrict_content_pro(),
            'ultimate_member' => $this->detect_ultimate_member(),
            'buddypress' => $this->detect_buddypress(),
            'lifter_lms' => $this->detect_lifter_lms(),
            'learnpress' => $this->detect_learnpress()
        );
    }
    
    /**
     * Detect Paid Memberships Pro
     */
    private function detect_pmpro() {
        $is_active = class_exists('PMPro_Membership_Level');
        $is_configured = false;
        
        if ($is_active) {
            // Check if PMPro is properly configured
            try {
                global $wpdb;
                $table_name = $wpdb->prefix . 'pmpro_membership_levels';
                $levels_exist = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");
                $is_configured = !empty($levels_exist);
            } catch (Exception $e) {
                error_log('PMPro detection error: ' . $e->getMessage());
                $is_configured = false;
            }
        }
        
        return array(
            'active' => $is_active,
            'configured' => $is_configured,
            'name' => 'Paid Memberships Pro',
            'slug' => 'paid-memberships-pro',
            'status' => ($is_active && $is_configured) ? 'available' : 'coming_soon',
            'description' => $is_active ? 
                ($is_configured ? 'Full migration support with user data, subscriptions, and settings' : 'Plugin active but not configured - setup required') :
                'Plugin not detected',
            'icon' => 'dashicons-groups',
            'version' => defined('PMPRO_VERSION') ? PMPRO_VERSION : null
        );
    }
    
    /**
     * Detect MemberPress
     */
    private function detect_memberpress() {
        return array(
            'active' => class_exists('MeprAppCtrl'),
            'name' => 'MemberPress',
            'slug' => 'memberpress',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-awards',
            'version' => defined('MEPR_VERSION') ? MEPR_VERSION : null
        );
    }
    
    /**
     * Detect WooCommerce Memberships
     */
    private function detect_woocommerce_memberships() {
        return array(
            'active' => class_exists('WC_Memberships'),
            'name' => 'WooCommerce Memberships',
            'slug' => 'woocommerce-memberships',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-cart',
            'version' => defined('WC_MEMBERSHIPS_VERSION') ? WC_MEMBERSHIPS_VERSION : null
        );
    }
    
    /**
     * Detect Restrict Content Pro
     */
    private function detect_restrict_content_pro() {
        return array(
            'active' => class_exists('Restrict_Content_Pro'),
            'name' => 'Restrict Content Pro',
            'slug' => 'restrict-content-pro',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-lock',
            'version' => defined('RCP_VERSION') ? RCP_VERSION : null
        );
    }
    
    /**
     * Detect Ultimate Member
     */
    private function detect_ultimate_member() {
        return array(
            'active' => class_exists('UM'),
            'name' => 'Ultimate Member',
            'slug' => 'ultimate-member',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-admin-users',
            'version' => defined('UM_VERSION') ? UM_VERSION : null
        );
    }
    
    /**
     * Detect BuddyPress
     */
    private function detect_buddypress() {
        return array(
            'active' => class_exists('BuddyPress'),
            'name' => 'BuddyPress',
            'slug' => 'buddypress',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-groups',
            'version' => defined('BP_VERSION') ? BP_VERSION : null
        );
    }
    
    /**
     * Detect LifterLMS
     */
    private function detect_lifter_lms() {
        return array(
            'active' => class_exists('LifterLMS'),
            'name' => 'LifterLMS',
            'slug' => 'lifterlms',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-welcome-learn-more',
            'version' => defined('LLMS_VERSION') ? LLMS_VERSION : null
        );
    }
    
    /**
     * Detect LearnPress
     */
    private function detect_learnpress() {
        return array(
            'active' => class_exists('LearnPress'),
            'name' => 'LearnPress',
            'slug' => 'learnpress',
            'status' => 'coming_soon',
            'description' => 'Migration support coming soon - stay tuned!',
            'icon' => 'dashicons-book',
            'version' => defined('LEARNPRESS_VERSION') ? LEARNPRESS_VERSION : null
        );
    }
    
    /**
     * Get all detected platforms
     */
    public function get_detected_platforms() {
        return $this->detected_platforms;
    }
    
    /**
     * Get active platforms only
     */
    public function get_active_platforms() {
        return array_filter($this->detected_platforms, function($platform) {
            return $platform['active'];
        });
    }
    
    /**
     * Get available platforms (active and supported)
     */
    public function get_available_platforms() {
        return array_filter($this->detected_platforms, function($platform) {
            return $platform['active'] && $platform['status'] === 'available';
        });
    }
    
    /**
     * Get coming soon platforms
     */
    public function get_coming_soon_platforms() {
        return array_filter($this->detected_platforms, function($platform) {
            return $platform['status'] === 'coming_soon';
        });
    }
    
    /**
     * Check if any supported platform is active
     */
    public function has_supported_platform() {
        return !empty($this->get_available_platforms());
    }
    
    /**
     * Get primary platform (first available platform)
     */
    public function get_primary_platform() {
        $available = $this->get_available_platforms();
        return !empty($available) ? reset($available) : null;
    }
}
