<?php

namespace MBP\Analyzers;

/**
 * Settings Analyzer - Analyzes and extracts PMPro settings for migration
 */
class Settings_Analyzer {
    
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    /**
     * Analyze all PMPro settings
     */
    public function analyze_settings() {
        return array(
            'payment_gateways' => $this->get_payment_gateway_settings(),
            'email_templates' => $this->get_email_template_settings(),
            'checkout_settings' => $this->get_checkout_settings(),
            'account_settings' => $this->get_account_settings(),
            'billing_settings' => $this->get_billing_settings(),
            'tax_settings' => $this->get_tax_settings(),
            'coupon_settings' => $this->get_coupon_settings(),
            'page_settings' => $this->get_page_settings(),
            'general_settings' => $this->get_general_settings(),
        );
    }
    
    /**
     * Get payment gateway settings
     */
    private function get_payment_gateway_settings() {
        $gateways = array();
        
        // Get active gateways
        $active_gateways = get_option('pmpro_gateway', array());
        
        // Stripe settings
        if (in_array('stripe', $active_gateways)) {
            $gateways['stripe'] = array(
                'enabled' => true,
                'api_key' => get_option('pmpro_stripe_secretkey', ''),
                'publishable_key' => get_option('pmpro_stripe_publishablekey', ''),
                'webhook_secret' => get_option('pmpro_stripe_webhook_secret', ''),
                'test_mode' => get_option('pmpro_stripe_test', false),
            );
        }
        
        // PayPal settings
        if (in_array('paypal', $active_gateways)) {
            $gateways['paypal'] = array(
                'enabled' => true,
                'api_username' => get_option('pmpro_paypal_api_username', ''),
                'api_password' => get_option('pmpro_paypal_api_password', ''),
                'api_signature' => get_option('pmpro_paypal_api_signature', ''),
                'test_mode' => get_option('pmpro_paypal_test', false),
            );
        }
        
        return $gateways;
    }
    
    /**
     * Get email template settings
     */
    private function get_email_template_settings() {
        $templates = array();
        
        $email_options = array(
            'pmpro_email_from_name',
            'pmpro_email_from_email',
            'pmpro_email_admin_billing',
            'pmpro_email_admin_cancelled',
            'pmpro_email_admin_changed',
            'pmpro_email_admin_checkout',
            'pmpro_email_admin_payment_failed',
            'pmpro_email_admin_payment_success',
            'pmpro_email_admin_trial_to_paid',
            'pmpro_email_member_checkout',
            'pmpro_email_member_payment_failed',
            'pmpro_email_member_payment_success',
            'pmpro_email_member_trial_to_paid',
        );
        
        foreach ($email_options as $option) {
            $templates[$option] = get_option($option, '');
        }
        
        return $templates;
    }
    
    /**
     * Get checkout settings
     */
    private function get_checkout_settings() {
        return array(
            'checkout_page_id' => get_option('pmpro_checkout_page_id', ''),
            'confirmation_page_id' => get_option('pmpro_confirmation_page_id', ''),
            'cancel_page_id' => get_option('pmpro_cancel_page_id', ''),
            'billing_address_required' => get_option('pmpro_billing_address_required', true),
            'collect_billing_address' => get_option('pmpro_collect_billing_address', true),
            'show_address_fields' => get_option('pmpro_show_address_fields', true),
        );
    }
    
    /**
     * Get account settings
     */
    private function get_account_settings() {
        return array(
            'account_page_id' => get_option('pmpro_account_page_id', ''),
            'login_page_id' => get_option('pmpro_login_page_id', ''),
            'logout_page_id' => get_option('pmpro_logout_page_id', ''),
            'profile_page_id' => get_option('pmpro_profile_page_id', ''),
        );
    }
    
    /**
     * Get billing settings
     */
    private function get_billing_settings() {
        return array(
            'currency' => get_option('pmpro_currency', 'USD'),
            'currency_position' => get_option('pmpro_currency_position', 'left'),
            'thousand_separator' => get_option('pmpro_thousand_separator', ','),
            'decimal_separator' => get_option('pmpro_decimal_separator', '.'),
            'decimal_places' => get_option('pmpro_decimal_places', 2),
        );
    }
    
    /**
     * Get tax settings
     */
    private function get_tax_settings() {
        return array(
            'tax_rate' => get_option('pmpro_tax_rate', 0),
            'tax_state' => get_option('pmpro_tax_state', ''),
            'tax_country' => get_option('pmpro_tax_country', ''),
        );
    }
    
    /**
     * Get coupon settings
     */
    private function get_coupon_settings() {
        return array(
            'coupons_enabled' => get_option('pmpro_coupons_enabled', false),
            'coupon_code_required' => get_option('pmpro_coupon_code_required', false),
        );
    }
    
    /**
     * Get page settings
     */
    private function get_page_settings() {
        return array(
            'levels_page_id' => get_option('pmpro_levels_page_id', ''),
            'checkout_page_id' => get_option('pmpro_checkout_page_id', ''),
            'confirmation_page_id' => get_option('pmpro_confirmation_page_id', ''),
            'cancel_page_id' => get_option('pmpro_cancel_page_id', ''),
            'account_page_id' => get_option('pmpro_account_page_id', ''),
            'login_page_id' => get_option('pmpro_login_page_id', ''),
            'logout_page_id' => get_option('pmpro_logout_page_id', ''),
            'profile_page_id' => get_option('pmpro_profile_page_id', ''),
        );
    }
    
    /**
     * Get general settings
     */
    private function get_general_settings() {
        return array(
            'version' => get_option('pmpro_version', ''),
            'license_key' => get_option('pmpro_license_key', ''),
            'license_status' => get_option('pmpro_license_status', ''),
            'debug_mode' => get_option('pmpro_debug_mode', false),
            'log_level' => get_option('pmpro_log_level', 'error'),
        );
    }
}
