<?php

namespace MBP\Analyzers;

/**
 * PMPro Analyzer - Analyzes PMPro data structure and extracts membership information
 */
class PMPro_Analyzer {
    
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    /**
     * Analyze PMPro installation and return comprehensive data
     */
    public function analyze() {
        $settings_analyzer = new \MBP\Analyzers\Settings_Analyzer();
        
        $analysis = array(
            'plugin_detected' => $this->is_pmpro_active(),
            'version' => $this->get_pmpro_version(),
            'membership_levels' => $this->get_membership_levels(),
            'users' => $this->get_membership_users(),
            'subscriptions' => $this->get_subscriptions(),
            'content_rules' => $this->get_content_rules(),
            'settings' => $this->get_pmpro_settings(),
            'advanced_settings' => $settings_analyzer->analyze_settings(),
            'database_tables' => $this->get_database_tables(),
        );
        
        return $analysis;
    }
    
    /**
     * Check if PMPro is active
     */
    public function is_pmpro_active() {
        return class_exists('PMPro_Membership_Level') && function_exists('pmpro_getAllLevels');
    }
    
    /**
     * Get PMPro version
     */
    public function get_pmpro_version() {
        if (!$this->is_pmpro_active()) {
            return null;
        }
        
        return defined('PMPRO_VERSION') ? PMPRO_VERSION : 'Unknown';
    }
    
    /**
     * Get all membership levels
     */
    public function get_membership_levels() {
        if (!$this->is_pmpro_active()) {
            return array();
        }
        
        $levels = pmpro_getAllLevels(true, true);
        $formatted_levels = array();
        
        foreach ($levels as $level) {
            $formatted_levels[] = array(
                'id' => $level->id,
                'name' => $level->name,
                'description' => $level->description,
                'confirmation' => $level->confirmation,
                'initial_payment' => $level->initial_payment,
                'billing_amount' => $level->billing_amount,
                'cycle_number' => $level->cycle_number,
                'cycle_period' => $level->cycle_period,
                'billing_limit' => $level->billing_limit,
                'trial_amount' => $level->trial_amount,
                'trial_limit' => $level->trial_limit,
                'allow_signups' => $level->allow_signups,
                'expiration_number' => $level->expiration_number,
                'expiration_period' => $level->expiration_period,
            );
        }
        
        return $formatted_levels;
    }
    
    /**
     * Get users with membership levels
     */
    public function get_membership_users() {
        $users = $this->wpdb->get_results("
            SELECT 
                u.ID,
                u.user_login,
                u.user_email,
                u.user_registered,
                u.display_name,
                um.meta_value as membership_level,
                um2.meta_value as membership_status,
                um3.meta_value as startdate,
                um4.meta_value as enddate
            FROM {$this->wpdb->users} u
            INNER JOIN {$this->wpdb->usermeta} um ON u.ID = um.user_id
            LEFT JOIN {$this->wpdb->usermeta} um2 ON u.ID = um2.user_id AND um2.meta_key = 'pmpro_membership_status'
            LEFT JOIN {$this->wpdb->usermeta} um3 ON u.ID = um3.user_id AND um3.meta_key = 'pmpro_startdate'
            LEFT JOIN {$this->wpdb->usermeta} um4 ON u.ID = um4.user_id AND um4.meta_key = 'pmpro_enddate'
            WHERE um.meta_key = 'pmpro_membership_level'
            AND um.meta_value != '0'
            ORDER BY u.user_registered DESC
        ");
        
        return $users;
    }
    
    /**
     * Get subscription data
     */
    public function get_subscriptions() {
        $subscriptions = $this->wpdb->get_results("
            SELECT 
                s.id,
                s.user_id,
                s.membership_id,
                s.subscription_transaction_id,
                s.status,
                s.gateway,
                s.gateway_environment,
                s.next_payment_date,
                s.billing_amount,
                s.cycle_number,
                s.cycle_period,
                s.trial_amount,
                s.trial_limit,
                s.startdate,
                s.enddate,
                s.created_at,
                s.updated_at
            FROM {$this->wpdb->prefix}pmpro_subscriptions s
            WHERE s.status IN ('active', 'cancelled', 'expired')
            ORDER BY s.created_at DESC
        ");
        
        return $subscriptions;
    }
    
    /**
     * Get content protection rules
     */
    public function get_content_rules() {
        $rules = array();
        
        // Get posts/pages with PMPro restrictions
        $restricted_content = $this->wpdb->get_results("
            SELECT 
                p.ID,
                p.post_title,
                p.post_type,
                pm.meta_value as pmpro_membership_levels
            FROM {$this->wpdb->posts} p
            INNER JOIN {$this->wpdb->postmeta} pm ON p.ID = pm.post_id
            WHERE pm.meta_key = 'pmpro_membership_levels'
            AND pm.meta_value != ''
            AND p.post_status = 'publish'
        ");
        
        foreach ($restricted_content as $content) {
            $levels = maybe_unserialize($content->pmpro_membership_levels);
            if (is_array($levels)) {
                $rules[] = array(
                    'post_id' => $content->ID,
                    'post_title' => $content->post_title,
                    'post_type' => $content->post_type,
                    'required_levels' => $levels,
                );
            }
        }
        
        return $rules;
    }
    
    /**
     * Get PMPro settings
     */
    public function get_pmpro_settings() {
        $settings = array();
        
        // Get PMPro options
        $pmpro_options = array(
            'pmpro_currency',
            'pmpro_currency_position',
            'pmpro_thousand_separator',
            'pmpro_decimal_separator',
            'pmpro_decimal_places',
            'pmpro_email_from_name',
            'pmpro_email_from_email',
            'pmpro_email_admin_billing',
            'pmpro_email_admin_cancelled',
            'pmpro_email_admin_changed',
            'pmpro_email_admin_checkout',
            'pmpro_email_admin_payment_failed',
            'pmpro_email_admin_payment_success',
            'pmpro_email_admin_trial_to_paid',
            'pmpro_email_member_checkout',
            'pmpro_email_member_payment_failed',
            'pmpro_email_member_payment_success',
            'pmpro_email_member_trial_to_paid',
        );
        
        foreach ($pmpro_options as $option) {
            $settings[$option] = get_option($option, '');
        }
        
        return $settings;
    }
    
    /**
     * Get PMPro database tables
     */
    public function get_database_tables() {
        $tables = array();
        
        $pmpro_tables = array(
            'pmpro_membership_levels',
            'pmpro_memberships_users',
            'pmpro_membership_orders',
            'pmpro_subscriptions',
            'pmpro_discount_codes',
            'pmpro_discount_codes_levels',
            'pmpro_discount_codes_uses',
        );
        
        foreach ($pmpro_tables as $table) {
            $full_table_name = $this->wpdb->prefix . $table;
            $exists = $this->wpdb->get_var("SHOW TABLES LIKE '$full_table_name'");
            
            if ($exists) {
                $count = $this->wpdb->get_var("SELECT COUNT(*) FROM $full_table_name");
                $tables[$table] = array(
                    'exists' => true,
                    'count' => intval($count),
                );
            } else {
                $tables[$table] = array(
                    'exists' => false,
                    'count' => 0,
                );
            }
        }
        
        return $tables;
    }
    
    /**
     * Get user's password hash (for seamless migration)
     */
    public function get_user_password_hash($user_id) {
        $user = get_user_by('ID', $user_id);
        if (!$user) {
            return null;
        }
        
        return $user->user_pass;
    }
    
    /**
     * Get user's membership history
     */
    public function get_user_membership_history($user_id) {
        $history = $this->wpdb->get_results($this->wpdb->prepare("
            SELECT 
                mu.id,
                mu.membership_id,
                mu.status,
                mu.startdate,
                mu.enddate,
                mu.modified,
                l.name as level_name
            FROM {$this->wpdb->prefix}pmpro_memberships_users mu
            LEFT JOIN {$this->wpdb->prefix}pmpro_membership_levels l ON mu.membership_id = l.id
            WHERE mu.user_id = %d
            ORDER BY mu.startdate DESC
        ", $user_id));
        
        return $history;
    }
    
    /**
     * Get payment history for a user
     */
    public function get_user_payment_history($user_id) {
        $payments = $this->wpdb->get_results($this->wpdb->prepare("
            SELECT 
                o.id,
                o.code,
                o.user_id,
                o.membership_id,
                o.paypal_token,
                o.billing_name,
                o.billing_street,
                o.billing_city,
                o.billing_state,
                o.billing_zip,
                o.billing_country,
                o.billing_phone,
                o.payment_type,
                o.cardtype,
                o.accountnumber,
                o.expirationmonth,
                o.expirationyear,
                o.status,
                o.gateway,
                o.gateway_environment,
                o.payment_transaction_id,
                o.subscription_transaction_id,
                o.timestamp,
                o.affiliate_id,
                o.affiliate_subid,
                o.notes,
                o.checkout_id,
                o.amount,
                o.tax_amount,
                o.surcharge,
                o.discount_code,
                o.discount_amount,
                o.total,
                o.currency,
                o.paypal_token,
                o.billing_name,
                o.billing_street,
                o.billing_city,
                o.billing_state,
                o.billing_zip,
                o.billing_country,
                o.billing_phone,
                o.payment_type,
                o.cardtype,
                o.accountnumber,
                o.expirationmonth,
                o.expirationyear,
                o.status,
                o.gateway,
                o.gateway_environment,
                o.payment_transaction_id,
                o.subscription_transaction_id,
                o.timestamp,
                o.affiliate_id,
                o.affiliate_subid,
                o.notes,
                o.checkout_id,
                o.amount,
                o.tax_amount,
                o.surcharge,
                o.discount_code,
                o.discount_amount,
                o.total,
                o.currency
            FROM {$this->wpdb->prefix}pmpro_membership_orders o
            WHERE o.user_id = %d
            ORDER BY o.timestamp DESC
        ", $user_id));
        
        return $payments;
    }
}
