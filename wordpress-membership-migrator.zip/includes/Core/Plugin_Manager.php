<?php

namespace MBP\Core;

/**
 * Plugin Manager - Core functionality and initialization
 */
class Plugin_Manager {
    
    private $version;
    private $plugin_file;
    private $plugin_dir;
    private $plugin_url;
    
    public function __construct() {
        $this->version = MBP_VERSION;
        $this->plugin_file = MBP_PLUGIN_FILE;
        $this->plugin_dir = MBP_PLUGIN_DIR;
        $this->plugin_url = MBP_PLUGIN_URL;
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('init', array($this, 'init'));
        add_action('admin_init', array($this, 'admin_init'));
        add_action('wp_ajax_mbp_ajax_handler', array($this, 'handle_ajax'));
        add_action('wp_ajax_nopriv_mbp_ajax_handler', array($this, 'handle_ajax'));
    }
    
    public function init() {
        // Initialize plugin functionality
        $this->check_dependencies();
        $this->init_license();
    }
    
    public function admin_init() {
        // Admin-specific initialization
        $this->register_settings();
    }
    
    private function check_dependencies() {
        // Check if PMPro is active
        if (!class_exists('PMPro_Membership_Level')) {
            add_action('admin_notices', array($this, 'pmpro_missing_notice'));
        }
        
        // Check if MemberPress is active (for target site)
        // This will be checked during migration setup
    }
    
    public function pmpro_missing_notice() {
        ?>
        <div class="notice notice-error">
            <p><?php _e('Membership Bridge Pro requires Paid Memberships Pro to be active.', 'membership-bridge-pro'); ?></p>
        </div>
        <?php
    }
    
    private function init_license() {
        // Initialize license checking
        $license_key = get_option('mbp_license_key', '');
        $license_status = get_option('mbp_license_status', 'inactive');
        
        if (!empty($license_key) && $license_status === 'active') {
            // License is active, enable pro features
            add_filter('mbp_pro_features_enabled', '__return_true');
        }
    }
    
    private function register_settings() {
        register_setting('mbp_settings', 'mbp_license_key');
        register_setting('mbp_settings', 'mbp_target_url');
        register_setting('mbp_settings', 'mbp_target_api_key');
        register_setting('mbp_settings', 'mbp_sync_enabled');
        register_setting('mbp_settings', 'mbp_sync_frequency');
    }
    
    public function handle_ajax() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'mbp_nonce')) {
            wp_die('Security check failed');
        }
        
        $action = sanitize_text_field($_POST['mbp_action']);
        
        switch ($action) {
            case 'start_migration':
                $this->start_migration();
                break;
            case 'check_migration_status':
                $this->check_migration_status();
                break;
            case 'test_connection':
                $this->test_connection();
                break;
            case 'sync_now':
                $this->sync_now();
                break;
            default:
                wp_send_json_error('Invalid action');
        }
    }
    
    private function start_migration() {
        $migration_manager = new \MBP\Migration\Migration_Manager();
        $result = $migration_manager->start_migration();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    private function check_migration_status() {
        $migration_manager = new \MBP\Migration\Migration_Manager();
        $status = $migration_manager->get_migration_status();
        
        wp_send_json_success($status);
    }
    
    private function test_connection() {
        $target_url = sanitize_url($_POST['target_url']);
        $api_key = sanitize_text_field($_POST['api_key']);
        
        $api_manager = new \MBP\API\API_Manager();
        $result = $api_manager->test_connection($target_url, $api_key);
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    private function sync_now() {
        $sync_manager = new \MBP\Sync\Sync_Manager();
        $result = $sync_manager->sync_now();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function get_version() {
        return $this->version;
    }
    
    public function get_plugin_file() {
        return $this->plugin_file;
    }
    
    public function get_plugin_dir() {
        return $this->plugin_dir;
    }
    
    public function get_plugin_url() {
        return $this->plugin_url;
    }
}
