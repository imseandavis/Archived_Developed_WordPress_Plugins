<?php

namespace MBP\API;

/**
 * API Manager - Handles communication with target MemberPress site
 */
class API_Manager {
    
    private $target_url;
    private $api_key;
    
    public function __construct() {
        $this->target_url = get_option('mbp_target_url', '');
        $this->api_key = get_option('mbp_target_api_key', '');
    }
    
    /**
     * Test connection to target site
     */
    public function test_connection($target_url = null, $api_key = null) {
        $url = $target_url ?: $this->target_url;
        $key = $api_key ?: $this->api_key;
        
        if (empty($url) || empty($key)) {
            return array(
                'success' => false,
                'message' => __('Target URL and API key are required.', 'membership-bridge-pro')
            );
        }
        
        $response = $this->make_request('GET', '/test-connection', array(), $url, $key);
        
        if ($response && isset($response['success'])) {
            return $response;
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to connect to target site.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Create user on target site
     */
    public function create_user($user_data) {
        $response = $this->make_request('POST', '/create-user', $user_data);
        
        if ($response && isset($response['success'])) {
            return $response;
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to create user on target site.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Update user on target site
     */
    public function update_user($user_id, $user_data) {
        $response = $this->make_request('PUT', '/update-user/' . $user_id, $user_data);
        
        if ($response && isset($response['success'])) {
            return $response;
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to update user on target site.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Create membership on target site
     */
    public function create_membership($membership_data) {
        $response = $this->make_request('POST', '/create-membership', $membership_data);
        
        if ($response && isset($response['success'])) {
            return $response;
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to create membership on target site.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Sync data to target site
     */
    public function sync_data($data) {
        $response = $this->make_request('POST', '/sync-data', $data);
        
        if ($response && isset($response['success'])) {
            return $response;
        }
        
        return array(
            'success' => false,
            'message' => __('Failed to sync data to target site.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Make API request to target site
     */
    private function make_request($method, $endpoint, $data = array(), $target_url = null, $api_key = null) {
        $url = ($target_url ?: $this->target_url) . '/wp-json/mbp/v1' . $endpoint;
        $key = $api_key ?: $this->api_key;
        
        $args = array(
            'method' => $method,
            'headers' => array(
                'Content-Type' => 'application/json',
                'Authorization' => 'Bearer ' . $key,
            ),
            'timeout' => 30,
        );
        
        if (!empty($data)) {
            $args['body'] = json_encode($data);
        }
        
        $response = wp_remote_request($url, $args);
        
        if (is_wp_error($response)) {
            return array(
                'success' => false,
                'message' => $response->get_error_message()
            );
        }
        
        $body = wp_remote_retrieve_body($response);
        $decoded = json_decode($body, true);
        
        return $decoded ?: array(
            'success' => false,
            'message' => __('Invalid response from target site.', 'membership-bridge-pro')
        );
    }
}
