<?php

namespace MBP\Mappers;

/**
 * MemberPress Mapper - Maps PMPro data to MemberPress format
 */
class MemberPress_Mapper {
    
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    /**
     * Map PMPro membership level to MemberPress membership
     */
    public function map_membership_level($pmpro_level) {
        return array(
            'title' => $pmpro_level['name'],
            'description' => $pmpro_level['description'],
            'price' => $pmpro_level['initial_payment'],
            'period' => $this->map_period($pmpro_level['cycle_period']),
            'period_type' => $this->map_period_type($pmpro_level['cycle_period']),
            'period_number' => $pmpro_level['cycle_number'],
            'trial' => $pmpro_level['trial_amount'] > 0,
            'trial_amount' => $pmpro_level['trial_amount'],
            'trial_days' => $pmpro_level['trial_limit'],
            'expires_after' => $pmpro_level['expiration_number'],
            'expires_unit' => $this->map_period_type($pmpro_level['expiration_period']),
            'allow_signups' => $pmpro_level['allow_signups'] == 1,
        );
    }
    
    /**
     * Map PMPro user to MemberPress user
     */
    public function map_user($pmpro_user) {
        return array(
            'user_login' => $pmpro_user->user_login,
            'user_email' => $pmpro_user->user_email,
            'user_pass' => $pmpro_user->user_pass,
            'display_name' => $pmpro_user->display_name,
            'user_registered' => $pmpro_user->user_registered,
            'membership_id' => $this->get_memberpress_membership_id($pmpro_user->membership_level),
            'status' => $this->map_membership_status($pmpro_user->membership_status),
            'start_date' => $pmpro_user->startdate,
            'end_date' => $pmpro_user->enddate,
        );
    }
    
    /**
     * Map PMPro period to MemberPress period
     */
    private function map_period($pmpro_period) {
        $mapping = array(
            'Day' => 'days',
            'Week' => 'weeks',
            'Month' => 'months',
            'Year' => 'years',
        );
        
        return isset($mapping[$pmpro_period]) ? $mapping[$pmpro_period] : 'months';
    }
    
    /**
     * Map PMPro period type
     */
    private function map_period_type($pmpro_period) {
        $mapping = array(
            'Day' => 'days',
            'Week' => 'weeks',
            'Month' => 'months',
            'Year' => 'years',
        );
        
        return isset($mapping[$pmpro_period]) ? $mapping[$pmpro_period] : 'months';
    }
    
    /**
     * Map PMPro membership status to MemberPress
     */
    private function map_membership_status($pmpro_status) {
        $mapping = array(
            'active' => 'active',
            'inactive' => 'inactive',
            'cancelled' => 'cancelled',
            'expired' => 'expired',
        );
        
        return isset($mapping[$pmpro_status]) ? $mapping[$pmpro_status] : 'inactive';
    }
    
    /**
     * Map PMPro settings to MemberPress settings
     */
    public function map_settings($pmpro_settings) {
        $settings_mapper = new \MBP\Mappers\Settings_Mapper();
        return $settings_mapper->map_settings($pmpro_settings);
    }
    
    /**
     * Get MemberPress membership ID for PMPro level
     */
    private function get_memberpress_membership_id($pmpro_level_id) {
        // Get the PMPro level data to create corresponding MemberPress membership
        global $wpdb;
        
        $pmpro_level = $wpdb->get_row($wpdb->prepare(
            "SELECT * FROM {$wpdb->prefix}pmpro_membership_levels WHERE id = %d",
            $pmpro_level_id
        ));
        
        if (!$pmpro_level) {
            return null;
        }
        
        // Create MemberPress membership level
        $membership_data = array(
            'post_title' => $pmpro_level->name,
            'post_content' => $pmpro_level->description,
            'post_status' => 'publish',
            'post_type' => 'memberpressproduct'
        );
        
        $membership_id = wp_insert_post($membership_data);
        
        if (is_wp_error($membership_id)) {
            return null;
        }
        
        // Set membership meta data
        update_post_meta($membership_id, '_mepr_product_price', $pmpro_level->initial_payment);
        update_post_meta($membership_id, '_mepr_product_period', $pmpro_level->billing_amount);
        update_post_meta($membership_id, '_mepr_product_period_type', $this->map_billing_period($pmpro_level->cycle_period));
        update_post_meta($membership_id, '_mepr_product_limit_cycles', $pmpro_level->billing_limit);
        update_post_meta($membership_id, '_mepr_product_trial', $pmpro_level->trial_amount > 0 ? 'on' : '');
        update_post_meta($membership_id, '_mepr_product_trial_days', $pmpro_level->trial_limit);
        
        return $membership_id;
    }
    
    /**
     * Map PMPro billing period to MemberPress period type
     */
    private function map_billing_period($pmpro_period) {
        $mapping = array(
            'Day' => 'days',
            'Week' => 'weeks', 
            'Month' => 'months',
            'Year' => 'years'
        );
        
        return isset($mapping[$pmpro_period]) ? $mapping[$pmpro_period] : 'months';
    }
}
