<?php

namespace MBP\Mappers;

/**
 * Settings Mapper - Maps PMPro settings to MemberPress settings
 */
class Settings_Mapper {
    
    private $wpdb;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
    }
    
    /**
     * Map PMPro settings to MemberPress settings
     */
    public function map_settings($pmpro_settings) {
        return array(
            'payment_gateways' => $this->map_payment_gateways($pmpro_settings['payment_gateways']),
            'email_templates' => $this->map_email_templates($pmpro_settings['email_templates']),
            'checkout_settings' => $this->map_checkout_settings($pmpro_settings['checkout_settings']),
            'account_settings' => $this->map_account_settings($pmpro_settings['account_settings']),
            'billing_settings' => $this->map_billing_settings($pmpro_settings['billing_settings']),
            'tax_settings' => $this->map_tax_settings($pmpro_settings['tax_settings']),
            'coupon_settings' => $this->map_coupon_settings($pmpro_settings['coupon_settings']),
            'page_settings' => $this->map_page_settings($pmpro_settings['page_settings']),
            'general_settings' => $this->map_general_settings($pmpro_settings['general_settings']),
        );
    }
    
    /**
     * Map payment gateways
     */
    private function map_payment_gateways($pmpro_gateways) {
        $memberpress_gateways = array();
        
        // Map Stripe
        if (isset($pmpro_gateways['stripe']) && $pmpro_gateways['stripe']['enabled']) {
            $memberpress_gateways['stripe'] = array(
                'enabled' => true,
                'api_key' => $pmpro_gateways['stripe']['api_key'],
                'publishable_key' => $pmpro_gateways['stripe']['publishable_key'],
                'webhook_secret' => $pmpro_gateways['stripe']['webhook_secret'],
                'test_mode' => $pmpro_gateways['stripe']['test_mode'],
            );
        }
        
        // Map PayPal
        if (isset($pmpro_gateways['paypal']) && $pmpro_gateways['paypal']['enabled']) {
            $memberpress_gateways['paypal'] = array(
                'enabled' => true,
                'api_username' => $pmpro_gateways['paypal']['api_username'],
                'api_password' => $pmpro_gateways['paypal']['api_password'],
                'api_signature' => $pmpro_gateways['paypal']['api_signature'],
                'test_mode' => $pmpro_gateways['paypal']['test_mode'],
            );
        }
        
        return $memberpress_gateways;
    }
    
    /**
     * Map email templates
     */
    private function map_email_templates($pmpro_templates) {
        $memberpress_templates = array();
        
        // Map email templates
        $template_mapping = array(
            'pmpro_email_from_name' => 'mepr_email_from_name',
            'pmpro_email_from_email' => 'mepr_email_from_email',
            'pmpro_email_admin_billing' => 'mepr_admin_email_billing',
            'pmpro_email_admin_cancelled' => 'mepr_admin_email_cancelled',
            'pmpro_email_admin_changed' => 'mepr_admin_email_changed',
            'pmpro_email_admin_checkout' => 'mepr_admin_email_checkout',
            'pmpro_email_admin_payment_failed' => 'mepr_admin_email_payment_failed',
            'pmpro_email_admin_payment_success' => 'mepr_admin_email_payment_success',
            'pmpro_email_admin_trial_to_paid' => 'mepr_admin_email_trial_to_paid',
            'pmpro_email_member_checkout' => 'mepr_member_email_checkout',
            'pmpro_email_member_payment_failed' => 'mepr_member_email_payment_failed',
            'pmpro_email_member_payment_success' => 'mepr_member_email_payment_success',
            'pmpro_email_member_trial_to_paid' => 'mepr_member_email_trial_to_paid',
        );
        
        foreach ($template_mapping as $pmpro_key => $memberpress_key) {
            if (isset($pmpro_templates[$pmpro_key])) {
                $memberpress_templates[$memberpress_key] = $pmpro_templates[$pmpro_key];
            }
        }
        
        return $memberpress_templates;
    }
    
    /**
     * Map checkout settings
     */
    private function map_checkout_settings($pmpro_checkout) {
        return array(
            'checkout_page_id' => $this->map_page_id($pmpro_checkout['checkout_page_id']),
            'confirmation_page_id' => $this->map_page_id($pmpro_checkout['confirmation_page_id']),
            'cancel_page_id' => $this->map_page_id($pmpro_checkout['cancel_page_id']),
            'billing_address_required' => $pmpro_checkout['billing_address_required'],
            'collect_billing_address' => $pmpro_checkout['collect_billing_address'],
            'show_address_fields' => $pmpro_checkout['show_address_fields'],
        );
    }
    
    /**
     * Map account settings
     */
    private function map_account_settings($pmpro_account) {
        return array(
            'account_page_id' => $this->map_page_id($pmpro_account['account_page_id']),
            'login_page_id' => $this->map_page_id($pmpro_account['login_page_id']),
            'logout_page_id' => $this->map_page_id($pmpro_account['logout_page_id']),
            'profile_page_id' => $this->map_page_id($pmpro_account['profile_page_id']),
        );
    }
    
    /**
     * Map billing settings
     */
    private function map_billing_settings($pmpro_billing) {
        return array(
            'currency' => $pmpro_billing['currency'],
            'currency_position' => $this->map_currency_position($pmpro_billing['currency_position']),
            'thousand_separator' => $pmpro_billing['thousand_separator'],
            'decimal_separator' => $pmpro_billing['decimal_separator'],
            'decimal_places' => $pmpro_billing['decimal_places'],
        );
    }
    
    /**
     * Map tax settings
     */
    private function map_tax_settings($pmpro_tax) {
        return array(
            'tax_rate' => $pmpro_tax['tax_rate'],
            'tax_state' => $pmpro_tax['tax_state'],
            'tax_country' => $pmpro_tax['tax_country'],
        );
    }
    
    /**
     * Map coupon settings
     */
    private function map_coupon_settings($pmpro_coupon) {
        return array(
            'coupons_enabled' => $pmpro_coupon['coupons_enabled'],
            'coupon_code_required' => $pmpro_coupon['coupon_code_required'],
        );
    }
    
    /**
     * Map page settings
     */
    private function map_page_settings($pmpro_pages) {
        $memberpress_pages = array();
        
        foreach ($pmpro_pages as $key => $page_id) {
            $memberpress_pages[$key] = $this->map_page_id($page_id);
        }
        
        return $memberpress_pages;
    }
    
    /**
     * Map general settings
     */
    private function map_general_settings($pmpro_general) {
        return array(
            'debug_mode' => $pmpro_general['debug_mode'],
            'log_level' => $pmpro_general['log_level'],
        );
    }
    
    /**
     * Map currency position
     */
    private function map_currency_position($pmpro_position) {
        $mapping = array(
            'left' => 'left',
            'right' => 'right',
            'left_space' => 'left_space',
            'right_space' => 'right_space',
        );
        
        return isset($mapping[$pmpro_position]) ? $mapping[$pmpro_position] : 'left';
    }
    
    /**
     * Map page ID (create new page on target site)
     */
    private function map_page_id($pmpro_page_id) {
        if (empty($pmpro_page_id)) {
            return null;
        }
        
        // Get page details from source
        $page = get_post($pmpro_page_id);
        if (!$page) {
            return null;
        }
        
        // Return page data for creation on target
        return array(
            'title' => $page->post_title,
            'content' => $page->post_content,
            'slug' => $page->post_name,
            'status' => $page->post_status,
            'template' => get_page_template_slug($pmpro_page_id),
        );
    }
}
