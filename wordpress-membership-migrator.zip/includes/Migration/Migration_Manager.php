<?php

namespace MBP\Migration;

use MBP\Analyzers\PMPro_Analyzer;
use MBP\Mappers\MemberPress_Mapper;
use MBP\API\API_Manager;

/**
 * Migration Manager - Handles the migration process from PMPro to MemberPress
 */
class Migration_Manager {
    
    private $wpdb;
    private $pmpro_analyzer;
    private $memberpress_mapper;
    private $api_manager;
    
    public function __construct() {
        global $wpdb;
        $this->wpdb = $wpdb;
        $this->pmpro_analyzer = new PMPro_Analyzer();
        $this->memberpress_mapper = new MemberPress_Mapper();
        $this->api_manager = new API_Manager();
        
        $this->init_hooks();
    }
    
    private function init_hooks() {
        add_action('wp_ajax_mbp_start_migration', array($this, 'ajax_start_migration'));
        add_action('wp_ajax_mbp_check_migration_status', array($this, 'ajax_check_migration_status'));
        add_action('wp_ajax_mbp_cancel_migration', array($this, 'ajax_cancel_migration'));
    }
    
    /**
     * Start the migration process
     */
    public function start_migration() {
        // Check if migration is already in progress
        $current_status = get_option('mbp_migration_status', 'not_started');
        if ($current_status === 'in_progress') {
            return array(
                'success' => false,
                'message' => __('Migration is already in progress.', 'membership-bridge-pro')
            );
        }
        
        // Validate target connection
        $target_url = get_option('mbp_target_url', '');
        $api_key = get_option('mbp_target_api_key', '');
        
        if (empty($target_url) || empty($api_key)) {
            return array(
                'success' => false,
                'message' => __('Please configure target URL and API key first.', 'membership-bridge-pro')
            );
        }
        
        // Test connection
        $connection_test = $this->api_manager->test_connection($target_url, $api_key);
        if (!$connection_test['success']) {
            return array(
                'success' => false,
                'message' => __('Failed to connect to target site. Please check your settings.', 'membership-bridge-pro')
            );
        }
        
        // Start migration process
        update_option('mbp_migration_status', 'in_progress');
        update_option('mbp_migration_started', current_time('timestamp'));
        
        // Generate migration ID
        $migration_id = 'migration_' . time() . '_' . wp_generate_password(8, false);
        update_option('mbp_migration_id', $migration_id);
        
        // Migrate settings first
        $this->migrate_settings($migration_id);
        
        // Start background migration
        $this->schedule_migration_batch();
        
        return array(
            'success' => true,
            'message' => __('Migration started successfully!', 'membership-bridge-pro'),
            'migration_id' => $migration_id
        );
    }
    
    /**
     * Process migration in batches
     */
    public function process_migration_batch() {
        $migration_id = get_option('mbp_migration_id', '');
        if (empty($migration_id)) {
            return;
        }
        
        $batch_size = 10; // Process 10 users at a time
        $offset = get_option('mbp_migration_offset', 0);
        
        // Get users to migrate
        $users = $this->pmpro_analyzer->get_membership_users();
        $total_users = count($users);
        $users_batch = array_slice($users, $offset, $batch_size);
        
        if (empty($users_batch)) {
            // Migration complete
            $this->complete_migration();
            return;
        }
        
        $success_count = 0;
        $error_count = 0;
        
        foreach ($users_batch as $user) {
            $result = $this->migrate_user($user, $migration_id);
            
            if ($result['success']) {
                $success_count++;
            } else {
                $error_count++;
                $this->log_migration_error($migration_id, $user->ID, 'user_migration', $result['message']);
            }
        }
        
        // Update offset
        $new_offset = $offset + $batch_size;
        update_option('mbp_migration_offset', $new_offset);
        
        // Update progress
        $progress = ($new_offset / $total_users) * 100;
        update_option('mbp_migration_progress', $progress);
        
        // Schedule next batch if not complete
        if ($new_offset < $total_users) {
            wp_schedule_single_event(time() + 5, 'mbp_process_migration_batch');
        }
        
        return array(
            'success' => true,
            'processed' => count($users_batch),
            'success_count' => $success_count,
            'error_count' => $error_count,
            'progress' => $progress
        );
    }
    
    /**
     * Migrate a single user
     */
    private function migrate_user($user, $migration_id) {
        try {
            // Prepare user data for MemberPress
            $user_data = array(
                'user_login' => $user->user_login,
                'user_email' => $user->user_email,
                'user_pass' => $this->pmpro_analyzer->get_user_password_hash($user->ID),
                'display_name' => $user->display_name,
                'user_registered' => $user->user_registered,
                'membership_level' => $user->membership_level,
                'membership_status' => $user->membership_status,
                'startdate' => $user->startdate,
                'enddate' => $user->enddate,
            );
            
            // Get additional user data
            $user_data['membership_history'] = $this->pmpro_analyzer->get_user_membership_history($user->ID);
            $user_data['payment_history'] = $this->pmpro_analyzer->get_user_payment_history($user->ID);
            
            // Send to target site
            $result = $this->api_manager->create_user($user_data);
            
            if ($result['success']) {
                $this->log_migration_success($migration_id, $user->ID, 'user_migrated', 'User migrated successfully');
                return array('success' => true);
            } else {
                return array('success' => false, 'message' => $result['message']);
            }
            
        } catch (Exception $e) {
            return array('success' => false, 'message' => $e->getMessage());
        }
    }
    
    /**
     * Migrate settings to target site
     */
    private function migrate_settings($migration_id) {
        try {
            // Get PMPro settings
            $pmpro_analysis = $this->pmpro_analyzer->analyze();
            $pmpro_settings = $pmpro_analysis['advanced_settings'];
            
            // Map settings to MemberPress format
            $memberpress_settings = $this->memberpress_mapper->map_settings($pmpro_settings);
            
            // Send settings to target site
            $result = $this->api_manager->sync_data(array(
                'type' => 'settings',
                'settings' => $memberpress_settings
            ));
            
            if ($result['success']) {
                $this->log_migration_success($migration_id, 0, 'settings_migrated', 'Settings migrated successfully');
            } else {
                $this->log_migration_error($migration_id, 0, 'settings_migration', $result['message']);
            }
            
        } catch (Exception $e) {
            $this->log_migration_error($migration_id, 0, 'settings_migration', $e->getMessage());
        }
    }
    
    /**
     * Complete migration
     */
    private function complete_migration() {
        update_option('mbp_migration_status', 'completed');
        update_option('mbp_migration_completed', current_time('timestamp'));
        
        // Clear migration data
        delete_option('mbp_migration_id');
        delete_option('mbp_migration_offset');
        delete_option('mbp_migration_progress');
        
        // Enable sync if configured
        $sync_enabled = get_option('mbp_sync_enabled', false);
        if ($sync_enabled) {
            $this->enable_sync();
        }
    }
    
    /**
     * Get migration status
     */
    public function get_migration_status() {
        $status = get_option('mbp_migration_status', 'not_started');
        $progress = get_option('mbp_migration_progress', 0);
        $started = get_option('mbp_migration_started', null);
        $completed = get_option('mbp_migration_completed', null);
        
        return array(
            'status' => $status,
            'progress' => floatval($progress),
            'started' => $started,
            'completed' => $completed,
            'total_users' => $this->get_total_users_count(),
            'migrated_users' => $this->get_migrated_users_count(),
        );
    }
    
    /**
     * Cancel migration
     */
    public function cancel_migration() {
        update_option('mbp_migration_status', 'cancelled');
        
        // Clear migration data
        delete_option('mbp_migration_id');
        delete_option('mbp_migration_offset');
        delete_option('mbp_migration_progress');
        
        // Clear scheduled events
        wp_clear_scheduled_hook('mbp_process_migration_batch');
        
        return array(
            'success' => true,
            'message' => __('Migration cancelled successfully.', 'membership-bridge-pro')
        );
    }
    
    /**
     * Schedule migration batch
     */
    private function schedule_migration_batch() {
        wp_schedule_single_event(time() + 10, 'mbp_process_migration_batch');
    }
    
    /**
     * Enable sync after migration
     */
    private function enable_sync() {
        update_option('mbp_sync_enabled', true);
        update_option('mbp_last_sync', current_time('timestamp'));
    }
    
    /**
     * Log migration success
     */
    private function log_migration_success($migration_id, $user_id, $action, $message) {
        $this->wpdb->insert(
            $this->wpdb->prefix . 'mbp_migration_log',
            array(
                'migration_id' => $migration_id,
                'user_id' => $user_id,
                'action' => $action,
                'status' => 'success',
                'message' => $message,
                'created_at' => current_time('mysql')
            )
        );
    }
    
    /**
     * Log migration error
     */
    private function log_migration_error($migration_id, $user_id, $action, $message) {
        $this->wpdb->insert(
            $this->wpdb->prefix . 'mbp_migration_log',
            array(
                'migration_id' => $migration_id,
                'user_id' => $user_id,
                'action' => $action,
                'status' => 'error',
                'message' => $message,
                'created_at' => current_time('mysql')
            )
        );
    }
    
    /**
     * Get total users count
     */
    private function get_total_users_count() {
        $users = $this->pmpro_analyzer->get_membership_users();
        return count($users);
    }
    
    /**
     * Get migrated users count
     */
    private function get_migrated_users_count() {
        $migration_id = get_option('mbp_migration_id', '');
        if (empty($migration_id)) {
            return 0;
        }
        
        $count = $this->wpdb->get_var($this->wpdb->prepare("
            SELECT COUNT(DISTINCT user_id) 
            FROM {$this->wpdb->prefix}mbp_migration_log 
            WHERE migration_id = %s 
            AND action = 'user_migrated' 
            AND status = 'success'
        ", $migration_id));
        
        return intval($count);
    }
    
    // AJAX handlers
    public function ajax_start_migration() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $result = $this->start_migration();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
    
    public function ajax_check_migration_status() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $status = $this->get_migration_status();
        wp_send_json_success($status);
    }
    
    public function ajax_cancel_migration() {
        check_ajax_referer('mbp_nonce', 'nonce');
        
        $result = $this->cancel_migration();
        
        if ($result['success']) {
            wp_send_json_success($result);
        } else {
            wp_send_json_error($result);
        }
    }
}
