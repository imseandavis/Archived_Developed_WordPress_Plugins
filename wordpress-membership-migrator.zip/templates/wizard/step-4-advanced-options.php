<?php
/**
 * Step 4: Advanced Options
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();
$wizard_data = $wizard_manager->get_wizard_data();

// Get PMPro data for preview
$pmpro_analyzer = new \MBP\Analyzers\PMPro_Analyzer();
$pmpro_data = $pmpro_analyzer->analyze();
$settings_analyzer = new \MBP\Analyzers\Settings_Analyzer();
$settings_data = $settings_analyzer->analyze_settings();
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 4;
    $show_pro_toggle = false;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-advanced">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-admin-settings"></span>
            </div>
            
            <h2><?php _e('What We Found on Your Site', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-data-preview">
                <div class="mbp-preview-section">
                    <h3><?php _e('👥 User Data', 'membership-bridge-pro'); ?></h3>
                    <div class="mbp-data-stats">
                        <div class="mbp-stat-item">
                            <span class="mbp-stat-number"><?php echo count($pmpro_data['users']); ?></span>
                            <span class="mbp-stat-label"><?php _e('Total Users', 'membership-bridge-pro'); ?></span>
                        </div>
                        <div class="mbp-stat-item">
                            <span class="mbp-stat-number"><?php echo count(array_filter($pmpro_data['users'], function($user) { return $user->membership_status === 'active'; })); ?></span>
                            <span class="mbp-stat-label"><?php _e('Active Members', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                    <div class="mbp-data-preview-item">
                        <strong><?php _e('Sample Users:', 'membership-bridge-pro'); ?></strong>
                        <div class="mbp-user-list">
                            <?php 
                            $sample_users = array_slice($pmpro_data['users'], 0, 3);
                            foreach ($sample_users as $user): 
                            ?>
                            <div class="mbp-user-item">
                                <span class="mbp-user-name"><?php echo esc_html($user->display_name); ?></span>
                                <span class="mbp-user-email"><?php echo esc_html($user->user_email); ?></span>
                                <span class="mbp-user-status status-<?php echo esc_attr($user->membership_status); ?>"><?php echo esc_html(ucfirst($user->membership_status)); ?></span>
                            </div>
                            <?php endforeach; ?>
                            <?php if (count($pmpro_data['users']) > 3): ?>
                            <div class="mbp-more-users"><?php printf(__('... and %d more users', 'membership-bridge-pro'), count($pmpro_data['users']) - 3); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <div class="mbp-preview-section">
                    <h3><?php _e('💳 Membership Levels', 'membership-bridge-pro'); ?></h3>
                    <div class="mbp-data-stats">
                        <div class="mbp-stat-item">
                            <span class="mbp-stat-number"><?php echo count($pmpro_data['membership_levels']); ?></span>
                            <span class="mbp-stat-label"><?php _e('Membership Levels', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                    <div class="mbp-levels-preview">
                        <?php foreach ($pmpro_data['membership_levels'] as $level): ?>
                        <div class="mbp-level-item">
                            <div class="mbp-level-info">
                                <strong><?php echo esc_html($level['name']); ?></strong>
                                <span class="mbp-level-price">$<?php echo esc_html($level['initial_payment']); ?></span>
                            </div>
                            <div class="mbp-level-details">
                                <?php if ($level['billing_amount'] > 0): ?>
                                <span><?php printf(__('$%s every %d %s', 'membership-bridge-pro'), $level['billing_amount'], $level['cycle_number'], strtolower($level['cycle_period'])); ?></span>
                                <?php endif; ?>
                                <?php if ($level['trial_amount'] > 0): ?>
                                <span class="mbp-trial"><?php printf(__('Trial: $%s for %d days', 'membership-bridge-pro'), $level['trial_amount'], $level['trial_limit']); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                
                <div class="mbp-preview-section">
                    <h3><?php _e('📧 Email Templates', 'membership-bridge-pro'); ?></h3>
                    <div class="mbp-email-preview">
                        <?php 
                        $email_templates = array(
                            'pmpro_email_member_checkout' => 'Member Checkout',
                            'pmpro_email_member_payment_success' => 'Payment Success',
                            'pmpro_email_admin_billing' => 'Admin Billing',
                            'pmpro_email_admin_payment_success' => 'Admin Payment Success'
                        );
                        $template_count = 0;
                        foreach ($email_templates as $key => $name):
                            if (!empty($settings_data['email_templates'][$key])):
                                $template_count++;
                        ?>
                        <div class="mbp-email-item">
                            <span class="mbp-email-name"><?php echo esc_html($name); ?></span>
                            <span class="mbp-email-status"><?php _e('Ready to migrate', 'membership-bridge-pro'); ?></span>
                        </div>
                        <?php 
                            endif;
                        endforeach; 
                        ?>
                        <div class="mbp-email-summary">
                            <strong><?php printf(__('%d email templates found', 'membership-bridge-pro'), $template_count); ?></strong>
                        </div>
                    </div>
                </div>
                
                <div class="mbp-preview-section">
                    <h3><?php _e('💳 Payment Gateways', 'membership-bridge-pro'); ?></h3>
                    <div class="mbp-gateway-preview">
                        <?php if (!empty($settings_data['payment_gateways']['stripe'])): ?>
                        <div class="mbp-gateway-item">
                            <span class="mbp-gateway-name">Stripe</span>
                            <span class="mbp-gateway-status"><?php echo $settings_data['payment_gateways']['stripe']['test_mode'] ? __('Test Mode', 'membership-bridge-pro') : __('Live Mode', 'membership-bridge-pro'); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (!empty($settings_data['payment_gateways']['paypal'])): ?>
                        <div class="mbp-gateway-item">
                            <span class="mbp-gateway-name">PayPal</span>
                            <span class="mbp-gateway-status"><?php echo $settings_data['payment_gateways']['paypal']['test_mode'] ? __('Test Mode', 'membership-bridge-pro') : __('Live Mode', 'membership-bridge-pro'); ?></span>
                        </div>
                        <?php endif; ?>
                        <?php if (empty($settings_data['payment_gateways']['stripe']) && empty($settings_data['payment_gateways']['paypal'])): ?>
                        <div class="mbp-gateway-item">
                            <span class="mbp-gateway-name"><?php _e('No payment gateways configured', 'membership-bridge-pro'); ?></span>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            
            <div class="mbp-wizard-upsell">
                <div class="mbp-upsell-box">
                    <h3><?php _e('🔧 Pro Advanced Features', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Custom field mapping and data transformation', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced email template customization', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Bulk data operations for large datasets', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Real-time migration monitoring and analytics', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced error handling and rollback capabilities', 'membership-bridge-pro'); ?></li>
                    </ul>
                    <a href="#" class="button button-primary"><?php _e('Upgrade to Pro', 'membership-bridge-pro'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <button type="button" class="button button-secondary" id="mbp-wizard-previous">
                <?php _e('Previous', 'membership-bridge-pro'); ?>
            </button>
            <button type="button" class="button button-primary" id="mbp-wizard-next">
                <?php _e('Next', 'membership-bridge-pro'); ?>
            </button>
        </div>
    </div>
</div>
