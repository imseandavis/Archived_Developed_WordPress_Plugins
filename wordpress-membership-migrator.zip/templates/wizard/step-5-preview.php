<?php
/**
 * Step 5: Preview & Confirmation
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();
$wizard_data = $wizard_manager->get_wizard_data();

// Get PMPro data for preview
$pmpro_analyzer = new \MBP\Analyzers\PMPro_Analyzer();
$pmpro_data = $pmpro_analyzer->analyze();
$settings_analyzer = new \MBP\Analyzers\Settings_Analyzer();
$settings_data = $settings_analyzer->analyze_settings();

// Calculate migration summary
$total_users = count($pmpro_data['users']);
$active_members = count(array_filter($pmpro_data['users'], function($user) { return $user->membership_status === 'active'; }));
$total_levels = count($pmpro_data['membership_levels']);
$total_transactions = count($pmpro_data['subscriptions']);
$content_rules = count($pmpro_data['content_rules']);
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 5;
    $show_pro_toggle = false;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-preview">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-visibility"></span>
            </div>
            
            <h2><?php _e('Migration Summary', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-migration-summary">
                <div class="mbp-summary-stats">
                    <div class="mbp-summary-stat">
                        <span class="mbp-stat-icon">👥</span>
                        <div class="mbp-stat-content">
                            <span class="mbp-stat-number"><?php echo $total_users; ?></span>
                            <span class="mbp-stat-label"><?php _e('Users', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                    
                    <div class="mbp-summary-stat">
                        <span class="mbp-stat-icon">💳</span>
                        <div class="mbp-stat-content">
                            <span class="mbp-stat-number"><?php echo $total_levels; ?></span>
                            <span class="mbp-stat-label"><?php _e('Membership Levels', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                    
                    <div class="mbp-summary-stat">
                        <span class="mbp-stat-icon">💰</span>
                        <div class="mbp-stat-content">
                            <span class="mbp-stat-number"><?php echo $total_transactions; ?></span>
                            <span class="mbp-stat-label"><?php _e('Transactions', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                    
                    <div class="mbp-summary-stat">
                        <span class="mbp-stat-icon">📧</span>
                        <div class="mbp-stat-content">
                            <span class="mbp-stat-number"><?php echo count($settings_data['email_templates']); ?></span>
                            <span class="mbp-stat-label"><?php _e('Email Templates', 'membership-bridge-pro'); ?></span>
                        </div>
                    </div>
                </div>
                
                <div class="mbp-migration-details">
                    <h3><?php _e('What Will Be Migrated', 'membership-bridge-pro'); ?></h3>
                    
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('User Accounts', 'membership-bridge-pro'); ?></strong>
                            <p><?php printf(__('%d users with preserved passwords for seamless login', 'membership-bridge-pro'), $total_users); ?></p>
                        </div>
                    </div>
                    
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('Membership Levels', 'membership-bridge-pro'); ?></strong>
                            <p><?php printf(__('%d membership levels with pricing and subscription details', 'membership-bridge-pro'), $total_levels); ?></p>
                        </div>
                    </div>
                    
                    <?php if ($wizard_data['migrate_content'] ?? true): ?>
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('Content Protection Rules', 'membership-bridge-pro'); ?></strong>
                            <p><?php printf(__('%d content access rules and restrictions', 'membership-bridge-pro'), $content_rules); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($wizard_data['migrate_payments'] ?? true): ?>
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('Payment History', 'membership-bridge-pro'); ?></strong>
                            <p><?php printf(__('%d transaction records and payment history', 'membership-bridge-pro'), $total_transactions); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($wizard_data['migrate_emails'] ?? true): ?>
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('Email Templates', 'membership-bridge-pro'); ?></strong>
                            <p><?php printf(__('%d email templates and notification settings', 'membership-bridge-pro'), count($settings_data['email_templates'])); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if ($wizard_data['migrate_settings'] ?? true): ?>
                    <div class="mbp-migration-item">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <div class="mbp-migration-content">
                            <strong><?php _e('Plugin Settings', 'membership-bridge-pro'); ?></strong>
                            <p><?php _e('Payment gateways, billing settings, and all configurations', 'membership-bridge-pro'); ?></p>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <div class="mbp-migration-estimate">
                    <h3><?php _e('Estimated Migration Time', 'membership-bridge-pro'); ?></h3>
                    <div class="mbp-time-estimate">
                        <?php 
                        $estimated_minutes = max(5, ceil($total_users / 10)); // Rough estimate: 10 users per minute
                        if ($estimated_minutes < 60) {
                            $time_text = sprintf(__('%d minutes', 'membership-bridge-pro'), $estimated_minutes);
                        } else {
                            $hours = floor($estimated_minutes / 60);
                            $minutes = $estimated_minutes % 60;
                            $time_text = sprintf(__('%d hours %d minutes', 'membership-bridge-pro'), $hours, $minutes);
                        }
                        ?>
                        <span class="mbp-time-icon">⏱️</span>
                        <span class="mbp-time-text"><?php echo $time_text; ?></span>
                    </div>
                    <p class="mbp-time-note"><?php _e('Migration time depends on server performance and data size.', 'membership-bridge-pro'); ?></p>
                </div>
            </div>
            
            <div class="mbp-wizard-upsell">
                <div class="mbp-upsell-box">
                    <h3><?php _e('📊 Pro Migration Analytics', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Real-time migration progress and status', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Detailed migration reports and analytics', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced error handling and rollback', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Migration performance optimization', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Priority support during migration', 'membership-bridge-pro'); ?></li>
                    </ul>
                    <a href="#" class="button button-primary"><?php _e('Upgrade to Pro', 'membership-bridge-pro'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <button type="button" class="button button-secondary" id="mbp-wizard-previous">
                <?php _e('Previous', 'membership-bridge-pro'); ?>
            </button>
            <button type="button" class="button button-primary" id="mbp-wizard-next">
                <?php _e('Continue to Migration', 'membership-bridge-pro'); ?>
            </button>
        </div>
    </div>
</div>
