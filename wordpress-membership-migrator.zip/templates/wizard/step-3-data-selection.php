<?php
/**
 * Step 3: Data Selection
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();
$wizard_data = $wizard_manager->get_wizard_data();

// Get PMPro data for preview
$pmpro_analyzer = new \MBP\Analyzers\PMPro_Analyzer();
$pmpro_data = $pmpro_analyzer->analyze();
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 3;
    $show_pro_toggle = false;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-data">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-database"></span>
            </div>
            
            <h2><?php _e('What Data Will Be Migrated?', 'membership-bridge-pro'); ?></h2>
            
            <form id="mbp-data-selection-form">
                <div class="mbp-wizard-form">
                    <div class="mbp-data-section">
                        <h3><?php _e('Core Data (Always Migrated)', 'membership-bridge-pro'); ?></h3>
                        
                        <div class="mbp-data-item mbp-data-required">
                            <label>
                                <input type="checkbox" checked disabled>
                                <span class="mbp-data-title"><?php _e('User Accounts', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php printf(__('(%d users)', 'membership-bridge-pro'), count($pmpro_data['users'])); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('All user accounts with preserved passwords for seamless login.', 'membership-bridge-pro'); ?></p>
                        </div>
                        
                        <div class="mbp-data-item mbp-data-required">
                            <label>
                                <input type="checkbox" checked disabled>
                                <span class="mbp-data-title"><?php _e('Membership Levels', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php printf(__('(%d levels)', 'membership-bridge-pro'), count($pmpro_data['membership_levels'])); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('All membership levels with pricing and subscription details.', 'membership-bridge-pro'); ?></p>
                        </div>
                    </div>
                    
                    <div class="mbp-data-section">
                        <h3><?php _e('Optional Data', 'membership-bridge-pro'); ?></h3>
                        
                        <div class="mbp-data-item">
                            <label>
                                <input type="checkbox" name="migrate_content" value="1" checked>
                                <span class="mbp-data-title"><?php _e('Content Protection Rules', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php printf(__('(%d rules)', 'membership-bridge-pro'), count($pmpro_data['content_rules'])); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('Content access rules and restrictions.', 'membership-bridge-pro'); ?></p>
                        </div>
                        
                        <div class="mbp-data-item">
                            <label>
                                <input type="checkbox" name="migrate_payments" value="1" checked>
                                <span class="mbp-data-title"><?php _e('Payment History', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php printf(__('(%d transactions)', 'membership-bridge-pro'), count($pmpro_data['subscriptions'])); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('Transaction history and payment records.', 'membership-bridge-pro'); ?></p>
                        </div>
                        
                        <div class="mbp-data-item">
                            <label>
                                <input type="checkbox" name="migrate_emails" value="1" checked>
                                <span class="mbp-data-title"><?php _e('Email Templates', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php _e('(All templates)', 'membership-bridge-pro'); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('Email templates and notification settings.', 'membership-bridge-pro'); ?></p>
                        </div>
                        
                        <div class="mbp-data-item">
                            <label>
                                <input type="checkbox" name="migrate_settings" value="1" checked>
                                <span class="mbp-data-title"><?php _e('Plugin Settings', 'membership-bridge-pro'); ?></span>
                                <span class="mbp-data-count"><?php _e('(All settings)', 'membership-bridge-pro'); ?></span>
                            </label>
                            <p class="mbp-data-description"><?php _e('Payment gateways, billing settings, and configurations.', 'membership-bridge-pro'); ?></p>
                        </div>
                    </div>
                </div>
            </form>
            
            <div class="mbp-wizard-upsell">
                <div class="mbp-upsell-box">
                    <h3><?php _e('🎯 Pro Data Customization', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Custom field mapping and transformation', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced data filtering and selection', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Bulk data operations and batch processing', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Data validation and error handling', 'membership-bridge-pro'); ?></li>
                    </ul>
                    <a href="#" class="button button-primary"><?php _e('Upgrade to Pro', 'membership-bridge-pro'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <button type="button" class="button button-secondary" id="mbp-wizard-previous">
                <?php _e('Previous', 'membership-bridge-pro'); ?>
            </button>
            <button type="button" class="button button-primary" id="mbp-wizard-next">
                <?php _e('Next', 'membership-bridge-pro'); ?>
            </button>
        </div>
    </div>
</div>
