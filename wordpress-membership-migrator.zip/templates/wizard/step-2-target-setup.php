<?php
/**
 * Step 2: Site Role Configuration
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();
$wizard_data = $wizard_manager->get_wizard_data();
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 2;
    $show_pro_toggle = true;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-progress">
        <div class="mbp-progress-bar">
            <div class="mbp-progress-fill" style="width: 33.33%;"></div>
        </div>
        <div class="mbp-progress-text"><?php printf(__('Step %d of %d', 'membership-bridge-pro'), 2, count($steps)); ?></div>
    </div>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-role">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-admin-site"></span>
            </div>
            
            <h2><?php _e('Select Your Site Role', 'membership-bridge-pro'); ?></h2>
            <p><?php _e('Choose whether this site is the source (where you\'re migrating FROM) or target (where you\'re migrating TO).', 'membership-bridge-pro'); ?></p>
            
            <!-- Role Selection -->
            <div class="mbp-role-selection">
                <div class="mbp-role-options">
                    <label class="mbp-role-option">
                        <input type="radio" name="site_role" value="source" checked>
                        <div class="mbp-role-content">
                            <span class="dashicons dashicons-upload"></span>
                            <h4><?php _e('Source Site', 'membership-bridge-pro'); ?></h4>
                            <p><?php _e('This site contains the membership data you want to migrate FROM.', 'membership-bridge-pro'); ?></p>
                            <small><?php _e('You\'ll need to install this plugin on your target site as well.', 'membership-bridge-pro'); ?></small>
                        </div>
                    </label>
                    
                    <label class="mbp-role-option">
                        <input type="radio" name="site_role" value="target">
                        <div class="mbp-role-content">
                            <span class="dashicons dashicons-download"></span>
                            <h4><?php _e('Target Site', 'membership-bridge-pro'); ?></h4>
                            <p><?php _e('This site will receive the migrated membership data.', 'membership-bridge-pro'); ?></p>
                            <small><?php _e('We\'ll generate an API key for the source site to connect.', 'membership-bridge-pro'); ?></small>
                        </div>
                    </label>
                </div>
            </div>
            
            <!-- Source Site Configuration -->
            <div id="mbp-source-config" class="mbp-config-section">
                <h3><?php _e('Target Site Configuration', 'membership-bridge-pro'); ?></h3>
                <p><?php _e('Configure your target WordPress site where you want to migrate the data TO.', 'membership-bridge-pro'); ?></p>
                
                <!-- Setup Method Selection -->
                <div class="mbp-setup-method">
                    <h4><?php _e('Choose Setup Method', 'membership-bridge-pro'); ?></h4>
                    <div class="mbp-method-options">
                        <label class="mbp-method-option">
                            <input type="radio" name="setup_method" value="manual" checked>
                            <div class="mbp-method-content">
                                <span class="dashicons dashicons-admin-tools"></span>
                                <h5><?php _e('Manual Setup', 'membership-bridge-pro'); ?></h5>
                                <p><?php _e('Step-by-step instructions to install and configure the plugin on your target site.', 'membership-bridge-pro'); ?></p>
                                <small><?php _e('Free', 'membership-bridge-pro'); ?></small>
                            </div>
                        </label>
                        
                        <label class="mbp-method-option mbp-pro-feature pro-enabled">
                            <input type="radio" name="setup_method" value="auto">
                            <div class="mbp-method-content">
                                <span class="dashicons dashicons-yes-alt"></span>
                                <h5><?php _e('Pro Auto-Setup', 'membership-bridge-pro'); ?></h5>
                                <p><?php _e('One-click installation and configuration on your target site.', 'membership-bridge-pro'); ?></p>
                                <small><?php _e('Pro Feature', 'membership-bridge-pro'); ?></small>
                            </div>
                        </label>
                    </div>
                </div>
                
                <!-- Manual Setup Form -->
                <div id="mbp-manual-setup" class="mbp-setup-form">
                    <form id="mbp-target-setup-form" class="mbp-wizard-form">
                        <div class="mbp-form-group">
                            <label for="target_url"><?php _e('Target Site URL', 'membership-bridge-pro'); ?></label>
                            <input type="url" id="target_url" name="target_url" value="<?php echo esc_attr($wizard_data['target_url'] ?? ''); ?>" placeholder="https://yoursite.com" required>
                            <small><?php _e('Enter the full URL of your target WordPress site.', 'membership-bridge-pro'); ?></small>
                        </div>
                        
                        <div class="mbp-form-group">
                            <label for="api_key"><?php _e('API Key', 'membership-bridge-pro'); ?></label>
                            <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($wizard_data['api_key'] ?? ''); ?>" placeholder="Enter API key from target site" required>
                            <small><?php _e('Get this from the target site\'s Membership Bridge Pro settings.', 'membership-bridge-pro'); ?></small>
                        </div>
                        
                        <div class="mbp-form-actions">
                            <button type="button" id="mbp-test-connection" class="button button-secondary">
                                <?php _e('Test Connection', 'membership-bridge-pro'); ?>
                            </button>
                            <div id="mbp-connection-result" class="mbp-connection-result" style="display: none;"></div>
                        </div>
                    </form>
                </div>
                
                <!-- Pro Auto-Setup Form -->
                <div id="mbp-auto-setup" class="mbp-setup-form" style="display: none;">
                    <div class="mbp-pro-benefits">
                        <h4><?php _e('🚀 Pro Auto-Setup Benefits', 'membership-bridge-pro'); ?></h4>
                        <ul>
                            <li><?php _e('Auto-install target plugin', 'membership-bridge-pro'); ?></li>
                            <li><?php _e('Auto-configure API keys', 'membership-bridge-pro'); ?></li>
                            <li><?php _e('Health check target requirements', 'membership-bridge-pro'); ?></li>
                            <li><?php _e('One-click complete setup', 'membership-bridge-pro'); ?></li>
                        </ul>
                    </div>
                    
                    <div class="mbp-wordpress-login">
                        <div class="mbp-login-main-card">
                            <!-- Top toolbar with browser styling -->
                            <div class="mbp-login-toolbar">
                                <!-- Browser tab styling -->
                                <div class="mbp-browser-tab"></div>
                                
                                <div class="mbp-toolbar-content">
                                    <!-- Browser controls -->
                                    <div class="mbp-browser-controls">
                                        <div class="mbp-control-btn mbp-control-red"></div>
                                        <div class="mbp-control-btn mbp-control-yellow"></div>
                                        <div class="mbp-control-btn mbp-control-green"></div>
                                    </div>
                                    
                                    <!-- Globe icon with status -->
                                    <div class="mbp-globe-icon mbp-globe-idle" id="mbp-globe-icon">
                                        <span class="dashicons dashicons-admin-site"></span>
                                    </div>
                                    
                                    <!-- URL input -->
                                    <div class="mbp-url-section">
                                        <input type="url" id="pro_target_url" name="pro_target_url" class="mbp-url-input" value="" placeholder="<?php _e('https://example.com/wp-admin', 'membership-bridge-pro'); ?>" required>
                                    </div>
                                    
                                       <!-- Info button with tooltip -->
                                       <div class="mbp-info-container">
                                           <button class="mbp-info-btn" id="mbp-info-btn">
                                               <span class="dashicons dashicons-editor-help"></span>
                                           </button>
                                        
                                        <!-- Tooltip -->
                                        <div class="mbp-tooltip" id="mbp-tooltip">
                                            <div class="mbp-tooltip-arrow"></div>
                                            <div class="mbp-tooltip-content">
                                                <h3><?php _e('How it works', 'membership-bridge-pro'); ?></h3>
                                                <p><?php _e('Enter the login details for your WordPress admin account. Membership Bridge Pro will only use these details to migrate your website.', 'membership-bridge-pro'); ?></p>
                                                <p class="mbp-tooltip-subtitle"><?php _e('Make sure that:', 'membership-bridge-pro'); ?></p>
                                                <ul class="mbp-tooltip-list">
                                                    <li><?php _e('The provided user has admin privileges.', 'membership-bridge-pro'); ?></li>
                                                    <li><?php _e('2FA and CAPTCHA are disabled for your account.', 'membership-bridge-pro'); ?></li>
                                                    <li><?php _e('If you\'re using a plugin for a custom WordPress admin login, update it in the \'Login URL\' field.', 'membership-bridge-pro'); ?></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <!-- Main content -->
                            <div class="mbp-login-content">
                                <div class="mbp-login-form-wrapper">
                                    <!-- WordPress logo -->
                                    <div class="mbp-wp-logo-container">
                                        <div class="mbp-wp-logo">
                                            <img src="https://hpanel.hostinger.com/assets/images/migrationsOnboarding/word-press-logo.png" alt="WordPress Logo" class="mbp-wp-logo-img">
                                        </div>
                                    </div>

                                    <!-- Login form -->
                                    <div class="mbp-login-form-fields">
                                        <form id="mbp-pro-setup-form" class="mbp-login-form">
                                            <!-- Username field -->
                                            <div class="mbp-form-field">
                                                <input type="text" id="pro_username" name="pro_username" class="mbp-form-input" placeholder="<?php _e('Username or Email Address', 'membership-bridge-pro'); ?>" required>
                                            </div>

                                            <!-- Password field -->
                                            <div class="mbp-form-field mbp-password-field">
                                                <input type="password" id="pro_password" name="pro_password" class="mbp-form-input mbp-password-input" placeholder="<?php _e('Password', 'membership-bridge-pro'); ?>" required>
                                                <button type="button" class="mbp-password-toggle" id="mbp-password-toggle">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                </button>
                                            </div>

                                            <!-- Login button -->
                                            <div class="mbp-form-field">
                                                <button type="button" id="mbp-validate-connection" class="mbp-login-btn mbp-validate-btn">
                                                    <?php _e('Log In', 'membership-bridge-pro'); ?>
                                                </button>
                                                <button type="button" id="mbp-pro-setup" class="mbp-login-btn mbp-setup-btn" style="display: none;">
                                                    <?php _e('🚀 Pro Auto-Setup', 'membership-bridge-pro'); ?>
                                                </button>
                                            </div>

                                            <!-- Information text -->
                                            <div class="mbp-login-info">
                                                <p class="mbp-info-text">
                                                    <?php _e('Membership Bridge Pro will <span class="mbp-info-bold">only</span> use these details to migrate your website.', 'membership-bridge-pro'); ?>
                                                </p>
                                            </div>
                                            
                                            <div id="mbp-pro-setup-result" class="mbp-connection-result" style="display: none;"></div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <!-- Target Site Configuration -->
            <div id="mbp-target-config" class="mbp-config-section" style="display: none;">
                <h3><?php _e('API Key Generated', 'membership-bridge-pro'); ?></h3>
                <p><?php _e('This site is configured as the target. Share this API key with your source site.', 'membership-bridge-pro'); ?></p>
                
                <div class="mbp-api-key-display">
                    <div class="mbp-form-group">
                        <label><?php _e('Your API Key', 'membership-bridge-pro'); ?></label>
                        <div class="mbp-api-key-container">
                            <input type="text" id="generated_api_key" value="<?php echo wp_generate_password(32, false); ?>" readonly>
                            <button type="button" id="mbp-copy-api-key" class="button button-secondary">
                                <?php _e('Copy', 'membership-bridge-pro'); ?>
                            </button>
                        </div>
                        <small><?php _e('Copy this key and enter it on your source site.', 'membership-bridge-pro'); ?></small>
                    </div>
                </div>
                
                <div class="mbp-installation-guide">
                    <h4><?php _e('Next Steps', 'membership-bridge-pro'); ?></h4>
                    <ol>
                        <li><?php _e('Copy the API key above', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Go to your source site', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Install this same plugin on the source site', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Run the wizard and select "Source Site"', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Enter this site\'s URL and API key', 'membership-bridge-pro'); ?></li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <button type="button" class="button button-secondary" id="mbp-wizard-previous">
                <?php _e('Previous', 'membership-bridge-pro'); ?>
            </button>
            <button type="button" class="button button-primary" id="mbp-wizard-next">
                <?php _e('Next', 'membership-bridge-pro'); ?>
            </button>
        </div>
    </div>
</div>