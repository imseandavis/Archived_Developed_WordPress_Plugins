<?php
/**
 * Step 6: Execute Migration
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();
$wizard_data = $wizard_manager->get_wizard_data();

// Get PMPro data for final summary
$pmpro_analyzer = new \MBP\Analyzers\PMPro_Analyzer();
$pmpro_data = $pmpro_analyzer->analyze();
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 5; // This is the final step in our 5-step navigation
    $show_pro_toggle = false;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-execute">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-controls-play"></span>
            </div>
            
            <h2><?php _e('Ready to Migrate', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-migration-ready">
                <div class="mbp-ready-summary">
                    <h3><?php _e('Final Migration Summary', 'membership-bridge-pro'); ?></h3>
                    
                    <div class="mbp-ready-stats">
                        <div class="mbp-ready-stat">
                            <span class="mbp-stat-icon">👥</span>
                            <div class="mbp-stat-content">
                                <span class="mbp-stat-number"><?php echo count($pmpro_data['users']); ?></span>
                                <span class="mbp-stat-label"><?php _e('Users', 'membership-bridge-pro'); ?></span>
                            </div>
                        </div>
                        
                        <div class="mbp-ready-stat">
                            <span class="mbp-stat-icon">💳</span>
                            <div class="mbp-stat-content">
                                <span class="mbp-stat-number"><?php echo count($pmpro_data['membership_levels']); ?></span>
                                <span class="mbp-stat-label"><?php _e('Membership Levels', 'membership-bridge-pro'); ?></span>
                            </div>
                        </div>
                        
                        <div class="mbp-ready-stat">
                            <span class="mbp-stat-icon">💰</span>
                            <div class="mbp-stat-content">
                                <span class="mbp-stat-number"><?php echo count($pmpro_data['subscriptions']); ?></span>
                                <span class="mbp-stat-label"><?php _e('Transactions', 'membership-bridge-pro'); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="mbp-migration-warnings">
                    <h3><?php _e('⚠️ Important Notes', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Do not close this page during migration', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Migration may take several minutes depending on data size', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Users can continue using your site during migration', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('You will receive email notifications when migration completes', 'membership-bridge-pro'); ?></li>
                    </ul>
                </div>
                
                <div class="mbp-migration-options">
                    <h3><?php _e('Migration Options', 'membership-bridge-pro'); ?></h3>
                    
                    <div class="mbp-option-group">
                        <label>
                            <input type="checkbox" id="start_sync" name="start_sync" checked>
                            <span class="mbp-option-title"><?php _e('Enable Ongoing Sync', 'membership-bridge-pro'); ?></span>
                        </label>
                        <p class="mbp-option-description"><?php _e('Keep both sites synchronized after migration completes.', 'membership-bridge-pro'); ?></p>
                    </div>
                    
                    <div class="mbp-option-group">
                        <label>
                            <input type="checkbox" id="send_notifications" name="send_notifications" checked>
                            <span class="mbp-option-title"><?php _e('Send Email Notifications', 'membership-bridge-pro'); ?></span>
                        </label>
                        <p class="mbp-option-description"><?php _e('Receive email updates about migration progress and completion.', 'membership-bridge-pro'); ?></p>
                    </div>
                </div>
            </div>
            
            <div class="mbp-migration-progress" id="mbp-migration-progress" style="display: none;">
                <h3><?php _e('Migration in Progress', 'membership-bridge-pro'); ?></h3>
                
                <div class="mbp-progress-section">
                    <div class="mbp-progress-bar">
                        <div class="mbp-progress-fill" id="mbp-migration-progress-fill" style="width: 0%;"></div>
                    </div>
                    <div class="mbp-progress-text" id="mbp-migration-progress-text">
                        <?php _e('Starting migration...', 'membership-bridge-pro'); ?>
                    </div>
                </div>
                
                <div class="mbp-migration-details" id="mbp-migration-details">
                    <div class="mbp-migration-step">
                        <span class="dashicons dashicons-clock"></span>
                        <span><?php _e('Preparing migration...', 'membership-bridge-pro'); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="mbp-migration-complete" id="mbp-migration-complete" style="display: none;">
                <div class="mbp-complete-success">
                    <span class="dashicons dashicons-yes-alt"></span>
                    <h3><?php _e('Migration Completed Successfully!', 'membership-bridge-pro'); ?></h3>
                    <p><?php _e('Your membership data has been successfully migrated to MemberPress.', 'membership-bridge-pro'); ?></p>
                    
                    <div class="mbp-complete-actions">
                        <a href="<?php echo admin_url('admin.php?page=membership-bridge'); ?>" class="button button-primary button-large">
                            <?php _e('Go to Dashboard', 'membership-bridge-pro'); ?>
                        </a>
                        <a href="<?php echo admin_url('admin.php?page=membership-bridge-sync'); ?>" class="button button-secondary button-large">
                            <?php _e('Configure Sync', 'membership-bridge-pro'); ?>
                        </a>
                    </div>
                </div>
            </div>
            
            <div class="mbp-wizard-upsell">
                <div class="mbp-upsell-box">
                    <h3><?php _e('🚀 Pro Migration Features', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Real-time migration monitoring and analytics', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced error handling and automatic retry', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Migration rollback and recovery options', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Priority support during migration process', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Advanced sync configuration and monitoring', 'membership-bridge-pro'); ?></li>
                    </ul>
                    <a href="#" class="button button-primary"><?php _e('Upgrade to Pro', 'membership-bridge-pro'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <button type="button" class="button button-secondary" id="mbp-wizard-previous">
                <?php _e('Previous', 'membership-bridge-pro'); ?>
            </button>
            <button type="button" class="button button-primary button-large" id="mbp-start-migration">
                <?php _e('Start Migration', 'membership-bridge-pro'); ?>
            </button>
        </div>
    </div>
</div>
