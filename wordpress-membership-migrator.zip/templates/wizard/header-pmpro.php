<?php
/**
 * PMPro-style Header Template
 * 
 * Reusable header component for all wizard steps
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$current_step = isset($current_step) ? $current_step : 1;
$show_pro_toggle = isset($show_pro_toggle) ? $show_pro_toggle : false;
?>

<!-- PMPro-style Header -->
<div class="mbp-wizard-header-pmpro">
    <!-- Plugin Branding -->
    <div class="mbp-plugin-branding">
        <div class="mbp-plugin-logo">
            <span class="dashicons dashicons-bridge"></span>
        </div>
        <h1 class="mbp-plugin-title"><?php _e('MemberBridge', 'membership-bridge-pro'); ?></h1>
    </div>
    
    <!-- Step-by-Step Navigation -->
    <div class="mbp-step-navigation">
        <div class="mbp-step-line"></div>
        <div class="mbp-steps-container">
            <?php 
            $step_labels = array(
                1 => __('Platform', 'membership-bridge-pro'),
                2 => __('Setup', 'membership-bridge-pro'), 
                3 => __('Migration', 'membership-bridge-pro'),
                4 => __('Review', 'membership-bridge-pro'),
                5 => __('Complete', 'membership-bridge-pro')
            );
            ?>
            <?php for ($i = 1; $i <= 5; $i++): ?>
                <div class="mbp-step-item <?php echo ($i <= $current_step) ? 'active' : ''; ?>">
                    <div class="mbp-step-circle">
                        <span class="mbp-step-number"><?php echo $i; ?></span>
                    </div>
                    <span class="mbp-step-label"><?php echo esc_html($step_labels[$i]); ?></span>
                </div>
            <?php endfor; ?>
        </div>
    </div>
    
    <?php if ($show_pro_toggle): ?>
    <!-- Pro Toggle -->
    <div class="mbp-pro-toggle-header">
        <label class="mbp-toggle-switch">
            <input type="checkbox" id="mbp-pro-toggle" <?php echo (get_option('mbp_pro_mode_enabled', true) ? 'checked' : ''); ?>>
            <span class="mbp-toggle-slider"></span>
        </label>
        <span class="mbp-pro-label"><?php _e('Pro Mode', 'membership-bridge-pro'); ?></span>
    </div>
    <?php endif; ?>
</div>
