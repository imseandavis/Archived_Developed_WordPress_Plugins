<?php
/**
 * Step 1: Welcome with Platform Detection
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$wizard_manager = new \MBP\Wizard\Wizard_Manager();
$steps = $wizard_manager->get_wizard_steps();

// Get platform detection results
$detected_platforms = $this->platform_detector->get_detected_platforms();
$active_platforms = $this->platform_detector->get_active_platforms();
$available_platforms = $this->platform_detector->get_available_platforms();
$coming_soon_platforms = $this->platform_detector->get_coming_soon_platforms();
$has_supported_platform = $this->platform_detector->has_supported_platform();
?>

<div class="mbp-wizard-container">
    <?php 
    $current_step = 1;
    $show_pro_toggle = false;
    include 'header-pmpro.php'; 
    ?>
    
    <div class="mbp-wizard-content">
        <div class="mbp-wizard-step mbp-wizard-step-welcome">
            <div class="mbp-step-icon">
                <span class="dashicons dashicons-bridge"></span>
            </div>
            
            <!-- Platform Selection -->
            <div class="mbp-platform-selection">
                <h2><?php _e('Select Your Source Platform', 'membership-bridge-pro'); ?></h2>
                <p><?php _e('Choose the membership platform you want to migrate from:', 'membership-bridge-pro'); ?></p>
                
                <div class="mbp-platform-radio-grid">
                    <?php 
                    // Get all platforms in a specific order
                    $platform_order = array('pmpro', 'memberpress', 'woocommerce_memberships', 'restrict_content_pro', 'ultimate_member', 'buddypress', 'lifter_lms', 'learnpress');
                    $ordered_platforms = array();
                    
                    // Add platforms in order
                    foreach ($platform_order as $key) {
                        if (isset($detected_platforms[$key])) {
                            $ordered_platforms[$key] = $detected_platforms[$key];
                        }
                    }
                    
                    $first_available = null;
                    foreach ($ordered_platforms as $key => $platform) {
                        if ($platform['status'] === 'available' && !$first_available) {
                            $first_available = $key;
                        }
                    }
                    ?>
                    
                    <?php foreach ($ordered_platforms as $key => $platform): ?>
                        <label class="mbp-platform-radio-item <?php echo $platform['status']; ?> <?php echo ($key === $first_available) ? 'auto-selected' : ''; ?>">
                            <input type="radio" 
                                   name="source_platform" 
                                   value="<?php echo esc_attr($key); ?>" 
                                   <?php echo ($key === $first_available) ? 'checked' : ''; ?>
                                   <?php echo ($platform['status'] === 'coming_soon') ? 'disabled' : ''; ?>>
                            
                            <div class="mbp-platform-radio-content">
                                <span class="dashicons <?php echo $platform['icon']; ?>"></span>
                                <div class="mbp-platform-info">
                                    <h4><?php echo esc_html($platform['name']); ?></h4>
                                    <p><?php echo esc_html($platform['description']); ?></p>
                                    <?php if ($platform['version']): ?>
                                        <small><?php printf(__('Version %s', 'membership-bridge-pro'), $platform['version']); ?></small>
                                    <?php endif; ?>
                                </div>
                                
                                <?php if ($key !== 'pmpro'): ?>
                                    <span class="mbp-coming-soon-chip"><?php _e('Coming Soon', 'membership-bridge-pro'); ?></span>
                                <?php endif; ?>
                            </div>
                        </label>
                    <?php endforeach; ?>
                </div>
                
                <?php if (empty($ordered_platforms)): ?>
                    <div class="mbp-no-platforms">
                        <div class="mbp-no-platforms-icon">
                            <span class="dashicons dashicons-search"></span>
                        </div>
                        <h3><?php _e('No Membership Platforms Detected', 'membership-bridge-pro'); ?></h3>
                        <p><?php _e('Don\'t worry! You can still proceed with manual data import or set up a membership platform first.', 'membership-bridge-pro'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
            
            <!-- Migration Benefits -->
            <div class="mbp-wizard-benefits">
                <h3><?php _e('Why Choose Our Migration Tool?', 'membership-bridge-pro'); ?></h3>
                <ul>
                    <li><?php _e('Zero downtime - members can continue using your site', 'membership-bridge-pro'); ?></li>
                    <li><?php _e('Preserved passwords - no password reset required', 'membership-bridge-pro'); ?></li>
                    <li><?php _e('Complete data transfer - nothing gets lost', 'membership-bridge-pro'); ?></li>
                    <li><?php _e('Ongoing sync - keep both sites in sync', 'membership-bridge-pro'); ?></li>
                </ul>
            </div>
            
            <!-- Pro Upsell -->
            <div class="mbp-wizard-upsell">
                <div class="mbp-upsell-box">
                    <h3><?php _e('🚀 Upgrade to Pro for Advanced Features', 'membership-bridge-pro'); ?></h3>
                    <ul>
                        <li><?php _e('Advanced field mapping and data transformation', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Bulk operations for large datasets', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Real-time sync with webhooks', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Priority support and advanced monitoring', 'membership-bridge-pro'); ?></li>
                    </ul>
                    <a href="#" class="button button-primary"><?php _e('Upgrade to Pro', 'membership-bridge-pro'); ?></a>
                </div>
            </div>
        </div>
    </div>
    
    <div class="mbp-wizard-footer">
        <div class="mbp-wizard-actions">
            <?php if ($has_supported_platform): ?>
                <button type="button" class="button button-primary button-large" id="mbp-wizard-next">
                    <?php _e('Next', 'membership-bridge-pro'); ?>
                </button>
            <?php else: ?>
                <button type="button" class="button button-primary button-large" id="mbp-wizard-next">
                    <?php _e('Next', 'membership-bridge-pro'); ?>
                </button>
            <?php endif; ?>
        </div>
    </div>
</div>