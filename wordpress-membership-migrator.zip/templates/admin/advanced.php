<?php
/**
 * Advanced template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$license_key = get_option('mbp_license_key', '');
$license_status = get_option('mbp_license_status', 'inactive');
$pro_features_enabled = apply_filters('mbp_pro_features_enabled', false);
?>

<div class="wrap">
    <h1><?php _e('Advanced Settings', 'membership-bridge-pro'); ?></h1>
    
    <div class="mbp-advanced-settings">
        <!-- License Settings -->
        <div class="mbp-card">
            <h2><?php _e('License Settings', 'membership-bridge-pro'); ?></h2>
            
            <form id="mbp-license-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="license_key"><?php _e('License Key', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="license_key" name="license_key" value="<?php echo esc_attr($license_key); ?>" class="regular-text">
                            <p class="description"><?php _e('Enter your license key to enable pro features.', 'membership-bridge-pro'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="button" id="mbp-validate-license" class="button button-primary">
                        <?php _e('Validate License', 'membership-bridge-pro'); ?>
                    </button>
                </p>
            </form>
            
            <div class="mbp-license-status">
                <?php if ($pro_features_enabled): ?>
                    <div class="mbp-license-active">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Pro Features Enabled', 'membership-bridge-pro'); ?></strong>
                    </div>
                <?php else: ?>
                    <div class="mbp-license-inactive">
                        <span class="dashicons dashicons-no-alt"></span>
                        <strong><?php _e('Pro Features Disabled', 'membership-bridge-pro'); ?></strong>
                        <p><?php _e('Upgrade to pro to access advanced features.', 'membership-bridge-pro'); ?></p>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Pro Features -->
        <div class="mbp-card">
            <h2><?php _e('Pro Features', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-pro-features">
                <div class="mbp-feature <?php echo $pro_features_enabled ? 'enabled' : 'disabled'; ?>">
                    <h3><?php _e('Advanced Field Mapping', 'membership-bridge-pro'); ?></h3>
                    <p><?php _e('Custom field mapping and transformation rules.', 'membership-bridge-pro'); ?></p>
                    <button type="button" class="button button-secondary" <?php echo !$pro_features_enabled ? 'disabled' : ''; ?>>
                        <?php _e('Configure', 'membership-bridge-pro'); ?>
                    </button>
                </div>
                
                <div class="mbp-feature <?php echo $pro_features_enabled ? 'enabled' : 'disabled'; ?>">
                    <h3><?php _e('Bulk Operations', 'membership-bridge-pro'); ?></h3>
                    <p><?php _e('Bulk import/export and batch processing capabilities.', 'membership-bridge-pro'); ?></p>
                    <button type="button" class="button button-secondary" <?php echo !$pro_features_enabled ? 'disabled' : ''; ?>>
                        <?php _e('Access', 'membership-bridge-pro'); ?>
                    </button>
                </div>
                
                <div class="mbp-feature <?php echo $pro_features_enabled ? 'enabled' : 'disabled'; ?>">
                    <h3><?php _e('API Access', 'membership-bridge-pro'); ?></h3>
                    <p><?php _e('REST API endpoints for custom integrations.', 'membership-bridge-pro'); ?></p>
                    <button type="button" class="button button-secondary" <?php echo !$pro_features_enabled ? 'disabled' : ''; ?>>
                        <?php _e('View API', 'membership-bridge-pro'); ?>
                    </button>
                </div>
                
                <div class="mbp-feature <?php echo $pro_features_enabled ? 'enabled' : 'disabled'; ?>">
                    <h3><?php _e('Advanced Logging', 'membership-bridge-pro'); ?></h3>
                    <p><?php _e('Detailed logs and rollback capabilities.', 'membership-bridge-pro'); ?></p>
                    <button type="button" class="button button-secondary" <?php echo !$pro_features_enabled ? 'disabled' : ''; ?>>
                        <?php _e('View Logs', 'membership-bridge-pro'); ?>
                    </button>
                </div>
            </div>
        </div>
        
        <!-- System Information -->
        <div class="mbp-card">
            <h2><?php _e('System Information', 'membership-bridge-pro'); ?></h2>
            
            <table class="widefat">
                <tbody>
                    <tr>
                        <td><strong><?php _e('Plugin Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo MBP_VERSION; ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('WordPress Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo get_bloginfo('version'); ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('PHP Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo PHP_VERSION; ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('MySQL Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo $GLOBALS['wpdb']->db_version(); ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('PMPro Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo defined('PMPRO_VERSION') ? PMPRO_VERSION : __('Not Active', 'membership-bridge-pro'); ?></td>
                    </tr>
                    <tr>
                        <td><strong><?php _e('MemberPress Version', 'membership-bridge-pro'); ?></strong></td>
                        <td><?php echo defined('MEPR_VERSION') ? MEPR_VERSION : __('Not Detected', 'membership-bridge-pro'); ?></td>
                    </tr>
                </tbody>
            </table>
        </div>
        
        <!-- Database Tools -->
        <div class="mbp-card">
            <h2><?php _e('Database Tools', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-database-tools">
                <p>
                    <button type="button" id="mbp-clear-logs" class="button button-secondary">
                        <?php _e('Clear Migration Logs', 'membership-bridge-pro'); ?>
                    </button>
                    <span class="description"><?php _e('Clear all migration and sync logs.', 'membership-bridge-pro'); ?></span>
                </p>
                
                <p>
                    <button type="button" id="mbp-reset-settings" class="button button-secondary">
                        <?php _e('Reset Settings', 'membership-bridge-pro'); ?>
                    </button>
                    <span class="description"><?php _e('Reset all plugin settings to defaults.', 'membership-bridge-pro'); ?></span>
                </p>
                
                <p>
                    <button type="button" id="mbp-export-settings" class="button button-secondary">
                        <?php _e('Export Settings', 'membership-bridge-pro'); ?>
                    </button>
                    <span class="description"><?php _e('Export plugin settings for backup.', 'membership-bridge-pro'); ?></span>
                </p>
            </div>
        </div>
        
        <!-- Support -->
        <div class="mbp-card">
            <h2><?php _e('Support & Documentation', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-support-links">
                <p>
                    <a href="#" class="button button-secondary"><?php _e('Documentation', 'membership-bridge-pro'); ?></a>
                    <a href="#" class="button button-secondary"><?php _e('Support Forum', 'membership-bridge-pro'); ?></a>
                    <a href="#" class="button button-secondary"><?php _e('Contact Support', 'membership-bridge-pro'); ?></a>
                </p>
            </div>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Validate license
    $('#mbp-validate-license').on('click', function() {
        var license_key = $('#license_key').val();
        
        if (!license_key) {
            alert('<?php _e('Please enter a license key.', 'membership-bridge-pro'); ?>');
            return;
        }
        
        var button = $(this);
        button.prop('disabled', true).text('<?php _e('Validating...', 'membership-bridge-pro'); ?>');
        
        $.post(ajaxurl, {
            action: 'mbp_validate_license',
            nonce: mbp_ajax.nonce,
            license_key: license_key
        }, function(response) {
            if (response.success) {
                alert('<?php _e('License validated successfully!', 'membership-bridge-pro'); ?>');
                location.reload();
            } else {
                alert(response.data.message);
            }
            button.prop('disabled', false).text('<?php _e('Validate License', 'membership-bridge-pro'); ?>');
        });
    });
    
    // Clear logs
    $('#mbp-clear-logs').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to clear all logs?', 'membership-bridge-pro'); ?>')) {
            $.post(ajaxurl, {
                action: 'mbp_clear_logs',
                nonce: mbp_ajax.nonce
            }, function(response) {
                if (response.success) {
                    alert('<?php _e('Logs cleared successfully!', 'membership-bridge-pro'); ?>');
                } else {
                    alert(response.data.message);
                }
            });
        }
    });
    
    // Reset settings
    $('#mbp-reset-settings').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to reset all settings? This cannot be undone.', 'membership-bridge-pro'); ?>')) {
            $.post(ajaxurl, {
                action: 'mbp_reset_settings',
                nonce: mbp_ajax.nonce
            }, function(response) {
                if (response.success) {
                    alert('<?php _e('Settings reset successfully!', 'membership-bridge-pro'); ?>');
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            });
        }
    });
    
    // Export settings
    $('#mbp-export-settings').on('click', function() {
        $.post(ajaxurl, {
            action: 'mbp_export_settings',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                // Create download link
                var blob = new Blob([response.data.settings], {type: 'application/json'});
                var url = window.URL.createObjectURL(blob);
                var a = document.createElement('a');
                a.href = url;
                a.download = 'mbp-settings.json';
                a.click();
                window.URL.revokeObjectURL(url);
            } else {
                alert(response.data.message);
            }
        });
    });
});
</script>
