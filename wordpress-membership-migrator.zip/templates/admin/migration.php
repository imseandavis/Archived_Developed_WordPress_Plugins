<?php
/**
 * Migration template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$migration_status = get_option('mbp_migration_status', 'not_started');
$target_url = get_option('mbp_target_url', '');
$api_key = get_option('mbp_target_api_key', '');
?>

<div class="wrap">
    <h1><?php _e('Migration Setup', 'membership-bridge-pro'); ?></h1>
    
    <div class="mbp-migration-setup">
        <!-- Connection Test -->
        <div class="mbp-card">
            <h2><?php _e('Target Site Connection', 'membership-bridge-pro'); ?></h2>
            
            <form id="mbp-connection-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="target_url"><?php _e('Target Site URL', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="url" id="target_url" name="target_url" value="<?php echo esc_attr($target_url); ?>" class="regular-text" required>
                            <p class="description"><?php _e('Enter the URL of your target WordPress site with MemberPress.', 'membership-bridge-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="api_key"><?php _e('API Key', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="text" id="api_key" name="api_key" value="<?php echo esc_attr($api_key); ?>" class="regular-text" required>
                            <p class="description"><?php _e('Enter the API key from your target site.', 'membership-bridge-pro'); ?></p>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="button" id="mbp-test-connection" class="button button-secondary">
                        <?php _e('Test Connection', 'membership-bridge-pro'); ?>
                    </button>
                    <button type="button" id="mbp-save-connection" class="button button-primary">
                        <?php _e('Save Settings', 'membership-bridge-pro'); ?>
                    </button>
                </p>
            </form>
            
            <div id="mbp-connection-result" class="mbp-result" style="display: none;"></div>
        </div>
        
        <!-- Migration Options -->
        <div class="mbp-card">
            <h2><?php _e('Migration Options', 'membership-bridge-pro'); ?></h2>
            
            <form id="mbp-migration-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="migrate_users"><?php _e('Migrate Users', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="migrate_users" name="migrate_users" checked>
                            <label for="migrate_users"><?php _e('Migrate all user accounts and passwords', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="migrate_memberships"><?php _e('Migrate Memberships', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="migrate_memberships" name="migrate_memberships" checked>
                            <label for="migrate_memberships"><?php _e('Migrate membership levels and subscriptions', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="migrate_content"><?php _e('Migrate Content Rules', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="migrate_content" name="migrate_content" checked>
                            <label for="migrate_content"><?php _e('Migrate content protection rules', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="migrate_payments"><?php _e('Migrate Payment History', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="migrate_payments" name="migrate_payments" checked>
                            <label for="migrate_payments"><?php _e('Migrate payment and transaction history', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                </table>
            </form>
        </div>
        
        <!-- Migration Status -->
        <?php if ($migration_status !== 'not_started'): ?>
        <div class="mbp-card">
            <h2><?php _e('Migration Status', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-migration-status">
                <div class="mbp-status-indicator status-<?php echo esc_attr($migration_status); ?>">
                    <?php
                    switch ($migration_status) {
                        case 'in_progress':
                            echo '<span class="dashicons dashicons-update"></span> ' . __('Migration in progress...', 'membership-bridge-pro');
                            break;
                        case 'completed':
                            echo '<span class="dashicons dashicons-yes-alt"></span> ' . __('Migration completed successfully!', 'membership-bridge-pro');
                            break;
                        case 'cancelled':
                            echo '<span class="dashicons dashicons-no-alt"></span> ' . __('Migration was cancelled.', 'membership-bridge-pro');
                            break;
                    }
                    ?>
                </div>
                
                <?php if ($migration_status === 'in_progress'): ?>
                <div class="mbp-progress-section">
                    <div class="mbp-progress-bar">
                        <div class="mbp-progress-fill" id="mbp-progress-fill" style="width: 0%;"></div>
                    </div>
                    <div class="mbp-progress-text" id="mbp-progress-text">
                        <?php _e('Starting migration...', 'membership-bridge-pro'); ?>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
        
        <!-- Start Migration -->
        <div class="mbp-card">
            <h2><?php _e('Start Migration', 'membership-bridge-pro'); ?></h2>
            
            <?php if ($migration_status === 'not_started'): ?>
            <div class="mbp-migration-warning">
                <div class="notice notice-warning">
                    <p><strong><?php _e('Important:', 'membership-bridge-pro'); ?></strong></p>
                    <ul>
                        <li><?php _e('Make sure you have a backup of both sites before starting migration.', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('The migration process may take some time depending on the number of users.', 'membership-bridge-pro'); ?></li>
                        <li><?php _e('Do not close this page during migration.', 'membership-bridge-pro'); ?></li>
                    </ul>
                </div>
            </div>
            
            <p class="submit">
                <button type="button" id="mbp-start-migration" class="button button-primary button-large" <?php echo empty($target_url) || empty($api_key) ? 'disabled' : ''; ?>>
                    <?php _e('Start Migration', 'membership-bridge-pro'); ?>
                </button>
            </p>
            <?php elseif ($migration_status === 'completed'): ?>
            <div class="mbp-migration-success">
                <div class="notice notice-success">
                    <p><?php _e('Migration completed successfully! You can now configure sync settings.', 'membership-bridge-pro'); ?></p>
                </div>
                <p class="submit">
                    <a href="<?php echo admin_url('admin.php?page=membership-bridge-sync'); ?>" class="button button-primary button-large">
                        <?php _e('Configure Sync', 'membership-bridge-pro'); ?>
                    </a>
                </p>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Test connection
    $('#mbp-test-connection').on('click', function() {
        var button = $(this);
        var target_url = $('#target_url').val();
        var api_key = $('#api_key').val();
        
        if (!target_url || !api_key) {
            alert('<?php _e('Please enter both target URL and API key.', 'membership-bridge-pro'); ?>');
            return;
        }
        
        button.prop('disabled', true).text('<?php _e('Testing...', 'membership-bridge-pro'); ?>');
        
        $.post(ajaxurl, {
            action: 'mbp_test_connection',
            nonce: mbp_ajax.nonce,
            target_url: target_url,
            api_key: api_key
        }, function(response) {
            if (response.success) {
                $('#mbp-connection-result').removeClass('error').addClass('success').html('<p>' + response.data.message + '</p>').show();
            } else {
                $('#mbp-connection-result').removeClass('success').addClass('error').html('<p>' + response.data.message + '</p>').show();
            }
            button.prop('disabled', false).text('<?php _e('Test Connection', 'membership-bridge-pro'); ?>');
        });
    });
    
    // Save connection settings
    $('#mbp-save-connection').on('click', function() {
        var target_url = $('#target_url').val();
        var api_key = $('#api_key').val();
        
        if (!target_url || !api_key) {
            alert('<?php _e('Please enter both target URL and API key.', 'membership-bridge-pro'); ?>');
            return;
        }
        
        $.post(ajaxurl, {
            action: 'mbp_save_connection',
            nonce: mbp_ajax.nonce,
            target_url: target_url,
            api_key: api_key
        }, function(response) {
            if (response.success) {
                alert('<?php _e('Settings saved successfully!', 'membership-bridge-pro'); ?>');
                $('#mbp-start-migration').prop('disabled', false);
            } else {
                alert(response.data.message);
            }
        });
    });
    
    // Start migration
    $('#mbp-start-migration').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to start the migration?', 'membership-bridge-pro'); ?>')) {
            var button = $(this);
            button.prop('disabled', true).text('<?php _e('Starting...', 'membership-bridge-pro'); ?>');
            
            $.post(ajaxurl, {
                action: 'mbp_start_migration',
                nonce: mbp_ajax.nonce
            }, function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message);
                    button.prop('disabled', false).text('<?php _e('Start Migration', 'membership-bridge-pro'); ?>');
                }
            });
        }
    });
    
    // Check migration status if in progress
    <?php if ($migration_status === 'in_progress'): ?>
    var statusCheckInterval = setInterval(function() {
        $.post(ajaxurl, {
            action: 'mbp_check_migration_status',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                var data = response.data;
                $('#mbp-progress-fill').css('width', data.progress + '%');
                $('#mbp-progress-text').text('Progress: ' + Math.round(data.progress) + '%');
                
                if (data.status !== 'in_progress') {
                    clearInterval(statusCheckInterval);
                    location.reload();
                }
            }
        });
    }, 5000);
    <?php endif; ?>
});
</script>
