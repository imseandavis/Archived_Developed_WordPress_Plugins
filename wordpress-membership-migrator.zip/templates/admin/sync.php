<?php
/**
 * Sync template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$sync_enabled = get_option('mbp_sync_enabled', false);
$sync_frequency = get_option('mbp_sync_frequency', 'hourly');
$last_sync = get_option('mbp_last_sync', null);
?>

<div class="wrap">
    <h1><?php _e('Sync Settings', 'membership-bridge-pro'); ?></h1>
    
    <div class="mbp-sync-settings">
        <!-- Sync Status -->
        <div class="mbp-card">
            <h2><?php _e('Sync Status', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-sync-status">
                <?php if ($sync_enabled): ?>
                    <div class="mbp-status-enabled">
                        <span class="dashicons dashicons-yes-alt"></span>
                        <strong><?php _e('Sync is Enabled', 'membership-bridge-pro'); ?></strong>
                        <?php if ($last_sync): ?>
                            <p><?php printf(__('Last sync: %s', 'membership-bridge-pro'), date('Y-m-d H:i:s', $last_sync)); ?></p>
                        <?php endif; ?>
                    </div>
                <?php else: ?>
                    <div class="mbp-status-disabled">
                        <span class="dashicons dashicons-no-alt"></span>
                        <strong><?php _e('Sync is Disabled', 'membership-bridge-pro'); ?></strong>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Sync Configuration -->
        <div class="mbp-card">
            <h2><?php _e('Sync Configuration', 'membership-bridge-pro'); ?></h2>
            
            <form id="mbp-sync-form">
                <table class="form-table">
                    <tr>
                        <th scope="row">
                            <label for="sync_frequency"><?php _e('Sync Frequency', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <select id="sync_frequency" name="sync_frequency">
                                <option value="hourly" <?php selected($sync_frequency, 'hourly'); ?>><?php _e('Every Hour', 'membership-bridge-pro'); ?></option>
                                <option value="twicedaily" <?php selected($sync_frequency, 'twicedaily'); ?>><?php _e('Twice Daily', 'membership-bridge-pro'); ?></option>
                                <option value="daily" <?php selected($sync_frequency, 'daily'); ?>><?php _e('Daily', 'membership-bridge-pro'); ?></option>
                                <option value="weekly" <?php selected($sync_frequency, 'weekly'); ?>><?php _e('Weekly', 'membership-bridge-pro'); ?></option>
                            </select>
                            <p class="description"><?php _e('How often to sync changes between sites.', 'membership-bridge-pro'); ?></p>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="sync_users"><?php _e('Sync Users', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="sync_users" name="sync_users" checked>
                            <label for="sync_users"><?php _e('Sync user profile changes', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="sync_memberships"><?php _e('Sync Memberships', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="sync_memberships" name="sync_memberships" checked>
                            <label for="sync_memberships"><?php _e('Sync membership status changes', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                    <tr>
                        <th scope="row">
                            <label for="sync_payments"><?php _e('Sync Payments', 'membership-bridge-pro'); ?></label>
                        </th>
                        <td>
                            <input type="checkbox" id="sync_payments" name="sync_payments" checked>
                            <label for="sync_payments"><?php _e('Sync payment and subscription changes', 'membership-bridge-pro'); ?></label>
                        </td>
                    </tr>
                </table>
                
                <p class="submit">
                    <button type="button" id="mbp-save-sync-settings" class="button button-primary">
                        <?php _e('Save Settings', 'membership-bridge-pro'); ?>
                    </button>
                </p>
            </form>
        </div>
        
        <!-- Sync Controls -->
        <div class="mbp-card">
            <h2><?php _e('Sync Controls', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-sync-controls">
                <p>
                    <button type="button" id="mbp-sync-now" class="button button-secondary" <?php echo !$sync_enabled ? 'disabled' : ''; ?>>
                        <?php _e('Sync Now', 'membership-bridge-pro'); ?>
                    </button>
                    <span class="description"><?php _e('Manually trigger a sync operation.', 'membership-bridge-pro'); ?></span>
                </p>
                
                <p>
                    <?php if ($sync_enabled): ?>
                        <button type="button" id="mbp-disable-sync" class="button button-secondary">
                            <?php _e('Disable Sync', 'membership-bridge-pro'); ?>
                        </button>
                    <?php else: ?>
                        <button type="button" id="mbp-enable-sync" class="button button-primary">
                            <?php _e('Enable Sync', 'membership-bridge-pro'); ?>
                        </button>
                    <?php endif; ?>
                    <span class="description"><?php _e('Enable or disable automatic synchronization.', 'membership-bridge-pro'); ?></span>
                </p>
            </div>
        </div>
        
        <!-- Sync Log -->
        <div class="mbp-card">
            <h2><?php _e('Recent Sync Activity', 'membership-bridge-pro'); ?></h2>
            
            <div class="mbp-sync-log" id="mbp-sync-log">
                <?php
                // Get recent sync activity
                global $wpdb;
                $recent_activity = $wpdb->get_results("
                    SELECT 
                        action,
                        status,
                        created_at,
                        data
                    FROM {$wpdb->prefix}mbp_sync_queue 
                    ORDER BY created_at DESC 
                    LIMIT 10
                ");
                
                if (empty($recent_activity)) {
                    echo '<p>' . __('No recent sync activity to display.', 'membership-bridge-pro') . '</p>';
                } else {
                    foreach ($recent_activity as $activity) {
                        $status_class = $activity->status === 'success' ? 'success' : 'error';
                        $status_icon = $activity->status === 'success' ? 'dashicons-yes-alt' : 'dashicons-no-alt';
                        echo '<div class="mbp-sync-log-item">';
                        echo '<span class="dashicons ' . $status_icon . '"></span>';
                        echo '<span class="mbp-sync-action">' . esc_html(ucfirst(str_replace('_', ' ', $activity->action))) . '</span>';
                        echo '<span class="mbp-sync-time">' . esc_html(date('Y-m-d H:i:s', strtotime($activity->created_at))) . '</span>';
                        echo '</div>';
                    }
                }
                ?>
            </div>
            
            <p class="submit">
                <button type="button" id="mbp-refresh-log" class="button button-secondary">
                    <?php _e('Refresh Log', 'membership-bridge-pro'); ?>
                </button>
            </p>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Save sync settings
    $('#mbp-save-sync-settings').on('click', function() {
        var settings = {
            sync_frequency: $('#sync_frequency').val(),
            sync_users: $('#sync_users').is(':checked'),
            sync_memberships: $('#sync_memberships').is(':checked'),
            sync_payments: $('#sync_payments').is(':checked')
        };
        
        $.post(ajaxurl, {
            action: 'mbp_save_sync_settings',
            nonce: mbp_ajax.nonce,
            settings: settings
        }, function(response) {
            if (response.success) {
                alert('<?php _e('Settings saved successfully!', 'membership-bridge-pro'); ?>');
            } else {
                alert(response.data.message);
            }
        });
    });
    
    // Sync now
    $('#mbp-sync-now').on('click', function() {
        var button = $(this);
        button.prop('disabled', true).text('<?php _e('Syncing...', 'membership-bridge-pro'); ?>');
        
        $.post(ajaxurl, {
            action: 'mbp_sync_now',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                alert(response.data.message);
                location.reload();
            } else {
                alert(response.data.message);
            }
            button.prop('disabled', false).text('<?php _e('Sync Now', 'membership-bridge-pro'); ?>');
        });
    });
    
    // Enable sync
    $('#mbp-enable-sync').on('click', function() {
        $.post(ajaxurl, {
            action: 'mbp_enable_sync',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                alert(response.data.message);
                location.reload();
            } else {
                alert(response.data.message);
            }
        });
    });
    
    // Disable sync
    $('#mbp-disable-sync').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to disable sync?', 'membership-bridge-pro'); ?>')) {
            $.post(ajaxurl, {
                action: 'mbp_disable_sync',
                nonce: mbp_ajax.nonce
            }, function(response) {
                if (response.success) {
                    alert(response.data.message);
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            });
        }
    });
    
    // Refresh log
    $('#mbp-refresh-log').on('click', function() {
        var button = $(this);
        button.prop('disabled', true).text('<?php _e('Refreshing...', 'membership-bridge-pro'); ?>');
        
        $.post(ajaxurl, {
            action: 'mbp_refresh_sync_log',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                $('#mbp-sync-log').html(response.data.log);
            } else {
                alert(response.data.message);
            }
            button.prop('disabled', false).text('<?php _e('Refresh Log', 'membership-bridge-pro'); ?>');
        });
    });
});
</script>
