<?php
/**
 * Dashboard template
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

$migration_status = get_option('mbp_migration_status', 'not_started');
$sync_enabled = get_option('mbp_sync_enabled', false);
$last_sync = get_option('mbp_last_sync', null);

// Get user counts safely
$total_users = 0;
$migrated_users = 0;

// Only get user counts if PMPro is active
if (class_exists('PMPro_Membership_Level')) {
    global $wpdb;
    
    // Get total PMPro users
    $total_users = $wpdb->get_var("
        SELECT COUNT(DISTINCT u.ID) 
        FROM {$wpdb->users} u
        INNER JOIN {$wpdb->usermeta} um ON u.ID = um.user_id
        WHERE um.meta_key = 'pmpro_membership_level'
        AND um.meta_value != '0'
    ");
    
    // Get migrated users count
    $migration_id = get_option('mbp_migration_id', '');
    if (!empty($migration_id)) {
        $migrated_users = $wpdb->get_var($wpdb->prepare("
            SELECT COUNT(DISTINCT user_id) 
            FROM {$wpdb->prefix}mbp_migration_log 
            WHERE migration_id = %s 
            AND action = 'user_migrated' 
            AND status = 'success'
        ", $migration_id));
    }
}
?>

<div class="wrap">
    <h1><?php _e('Membership Bridge Pro', 'membership-bridge-pro'); ?></h1>
    
    <?php if (!class_exists('PMPro_Membership_Level')): ?>
    <div class="notice notice-warning">
        <p><strong><?php _e('Paid Memberships Pro Not Detected', 'membership-bridge-pro'); ?></strong></p>
        <p><?php _e('This plugin requires Paid Memberships Pro to be active on the source site. Please install and activate Paid Memberships Pro to use this plugin.', 'membership-bridge-pro'); ?></p>
        <p><?php _e('You can download Paid Memberships Pro from their official website or upload it manually to your site.', 'membership-bridge-pro'); ?></p>
    </div>
    <?php endif; ?>
    
    <div class="mbp-dashboard">
        <!-- Status Cards -->
        <div class="mbp-status-cards">
            <div class="mbp-card">
                <h3><?php _e('Migration Status', 'membership-bridge-pro'); ?></h3>
                <div class="mbp-status-indicator status-<?php echo esc_attr($migration_status); ?>">
                    <?php
                    switch ($migration_status) {
                        case 'not_started':
                            echo '<span class="dashicons dashicons-clock"></span> ' . __('Not Started', 'membership-bridge-pro');
                            break;
                        case 'in_progress':
                            echo '<span class="dashicons dashicons-update"></span> ' . __('In Progress', 'membership-bridge-pro');
                            break;
                        case 'completed':
                            echo '<span class="dashicons dashicons-yes-alt"></span> ' . __('Completed', 'membership-bridge-pro');
                            break;
                        case 'cancelled':
                            echo '<span class="dashicons dashicons-no-alt"></span> ' . __('Cancelled', 'membership-bridge-pro');
                            break;
                    }
                    ?>
                </div>
            </div>
            
            <div class="mbp-card">
                <h3><?php _e('Users', 'membership-bridge-pro'); ?></h3>
                <div class="mbp-stats">
                    <div class="mbp-stat">
                        <span class="mbp-stat-number"><?php echo esc_html($migrated_users); ?></span>
                        <span class="mbp-stat-label"><?php _e('Migrated', 'membership-bridge-pro'); ?></span>
                    </div>
                    <div class="mbp-stat">
                        <span class="mbp-stat-number"><?php echo esc_html($total_users); ?></span>
                        <span class="mbp-stat-label"><?php _e('Total', 'membership-bridge-pro'); ?></span>
                    </div>
                </div>
            </div>
            
            <div class="mbp-card">
                <h3><?php _e('Sync Status', 'membership-bridge-pro'); ?></h3>
                <div class="mbp-sync-status">
                    <?php if ($sync_enabled): ?>
                        <span class="dashicons dashicons-yes-alt"></span>
                        <span><?php _e('Enabled', 'membership-bridge-pro'); ?></span>
                        <?php if ($last_sync): ?>
                            <small><?php printf(__('Last sync: %s', 'membership-bridge-pro'), date('Y-m-d H:i:s', $last_sync)); ?></small>
                        <?php endif; ?>
                    <?php else: ?>
                        <span class="dashicons dashicons-no-alt"></span>
                        <span><?php _e('Disabled', 'membership-bridge-pro'); ?></span>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <div class="mbp-quick-actions">
            <h2><?php _e('Quick Actions', 'membership-bridge-pro'); ?></h2>
            
            <?php if (class_exists('PMPro_Membership_Level')): ?>
            <div class="mbp-action-buttons">
                <?php if ($migration_status === 'not_started'): ?>
                    <a href="<?php echo admin_url('admin.php?page=membership-bridge-migration'); ?>" class="button button-primary button-large">
                        <?php _e('Start Migration', 'membership-bridge-pro'); ?>
                    </a>
                <?php elseif ($migration_status === 'in_progress'): ?>
                    <button type="button" class="button button-secondary button-large" id="mbp-check-status">
                        <?php _e('Check Status', 'membership-bridge-pro'); ?>
                    </button>
                    <button type="button" class="button button-secondary button-large" id="mbp-cancel-migration">
                        <?php _e('Cancel Migration', 'membership-bridge-pro'); ?>
                    </button>
                <?php elseif ($migration_status === 'completed'): ?>
                    <a href="<?php echo admin_url('admin.php?page=membership-bridge-sync'); ?>" class="button button-primary button-large">
                        <?php _e('Configure Sync', 'membership-bridge-pro'); ?>
                    </a>
                <?php endif; ?>
                
                <button type="button" class="button button-secondary button-large" id="mbp-sync-now" <?php echo !$sync_enabled ? 'disabled' : ''; ?>>
                    <?php _e('Sync Now', 'membership-bridge-pro'); ?>
                </button>
            </div>
            <?php else: ?>
            <div class="mbp-action-buttons">
                <a href="<?php echo admin_url('plugins.php'); ?>" class="button button-primary button-large">
                    <?php _e('Manage Plugins', 'membership-bridge-pro'); ?>
                </a>
                <a href="https://www.paidmembershipspro.com/" target="_blank" class="button button-secondary button-large">
                    <?php _e('Get Paid Memberships Pro', 'membership-bridge-pro'); ?>
                </a>
            </div>
            <?php endif; ?>
        </div>
        
        <!-- Progress Bar (if migration in progress) -->
        <?php if ($migration_status === 'in_progress' && class_exists('PMPro_Membership_Level')): ?>
            <div class="mbp-progress-section">
                <h3><?php _e('Migration Progress', 'membership-bridge-pro'); ?></h3>
                <div class="mbp-progress-bar">
                    <div class="mbp-progress-fill" id="mbp-progress-fill" style="width: 0%;"></div>
                </div>
                <div class="mbp-progress-text" id="mbp-progress-text">
                    <?php _e('Starting migration...', 'membership-bridge-pro'); ?>
                </div>
            </div>
        <?php endif; ?>
        
        <!-- Recent Activity -->
        <?php if (class_exists('PMPro_Membership_Level')): ?>
        <div class="mbp-recent-activity">
            <h3><?php _e('Recent Activity', 'membership-bridge-pro'); ?></h3>
            <div class="mbp-activity-log" id="mbp-activity-log">
                <p><?php _e('No recent activity to display.', 'membership-bridge-pro'); ?></p>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<?php if (class_exists('PMPro_Membership_Level')): ?>
<script>
jQuery(document).ready(function($) {
    // Check migration status if in progress
    <?php if ($migration_status === 'in_progress'): ?>
    var statusCheckInterval = setInterval(function() {
        $.post(ajaxurl, {
            action: 'mbp_check_migration_status',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                var data = response.data;
                $('#mbp-progress-fill').css('width', data.progress + '%');
                $('#mbp-progress-text').text('Progress: ' + Math.round(data.progress) + '%');
                
                if (data.status !== 'in_progress') {
                    clearInterval(statusCheckInterval);
                    location.reload();
                }
            }
        });
    }, 5000);
    <?php endif; ?>
    
    // Sync now button
    $('#mbp-sync-now').on('click', function() {
        var button = $(this);
        button.prop('disabled', true).text('<?php _e('Syncing...', 'membership-bridge-pro'); ?>');
        
        $.post(ajaxurl, {
            action: 'mbp_sync_now',
            nonce: mbp_ajax.nonce
        }, function(response) {
            if (response.success) {
                alert(response.data.message);
                location.reload();
            } else {
                alert(response.data.message);
            }
            button.prop('disabled', false).text('<?php _e('Sync Now', 'membership-bridge-pro'); ?>');
        });
    });
    
    // Cancel migration button
    $('#mbp-cancel-migration').on('click', function() {
        if (confirm('<?php _e('Are you sure you want to cancel the migration?', 'membership-bridge-pro'); ?>')) {
            $.post(ajaxurl, {
                action: 'mbp_cancel_migration',
                nonce: mbp_ajax.nonce
            }, function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data.message);
                }
            });
        }
    });
});
</script>
<?php endif; ?>
