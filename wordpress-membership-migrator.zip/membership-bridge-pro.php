<?php
/**
 * Plugin Name: Membership Bridge Pro
 * Plugin URI: https://seanasaservice.com
 * Description: Seamlessly migrate and sync membership data from Paid Memberships Pro to MemberPress with ongoing synchronization.
 * Version: 1.0.4
 * Author: Sean Davis
 * License: GPL v2 or later
 * Text Domain: membership-bridge-pro
 * Domain Path: /languages
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('MBP_VERSION', '1.0.0');
define('MBP_PLUGIN_FILE', __FILE__);
define('MBP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('MBP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('MBP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoloader
spl_autoload_register(function ($class) {
    $prefix = 'MBP\\';
    $base_dir = MBP_PLUGIN_DIR . 'includes/';
    
    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }
    
    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';
    
    if (file_exists($file)) {
        require $file;
    }
});

// Main plugin class
class MembershipBridgePro {
    
    private static $instance = null;
    
    public static function get_instance() {
        if (null === self::$instance) {
            self::$instance = new self();
        }
        return self::$instance;
    }
    
    private function __construct() {
        add_action('plugins_loaded', array($this, 'init'));
        register_activation_hook(__FILE__, array($this, 'activate'));
        register_deactivation_hook(__FILE__, array($this, 'deactivate'));
    }
    
    public function init() {
        // Load text domain
        load_plugin_textdomain('membership-bridge-pro', false, dirname(plugin_basename(__FILE__)) . '/languages');
        
        // Handle activation redirect
        $this->handle_activation_redirect();
        
        // Initialize core components
        $this->init_hooks();
        $this->init_components();
    }
    
    private function init_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_scripts'));
        add_action('wp_enqueue_scripts', array($this, 'enqueue_frontend_scripts'));
    }
    
    private function init_components() {
        // Initialize core components
        new MBP\Core\Plugin_Manager();
        new MBP\Admin\Admin_Manager();
        new MBP\Wizard\Wizard_Manager();
        new MBP\Pro_Auto_Setup\Pro_Auto_Setup_Manager();
        
        // Only initialize migration/sync components if PMPro is active
        if (class_exists('PMPro_Membership_Level')) {
            new MBP\Migration\Migration_Manager();
            new MBP\Sync\Sync_Manager();
            new MBP\API\API_Manager();
        }
    }
    
    public function add_admin_menu() {
        add_menu_page(
            __('MemberBridge', 'membership-bridge-pro'),
            __('MemberBridge', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge',
            array($this, 'admin_page'),
            'dashicons-bridge',
            30
        );
        
        add_submenu_page(
            'membership-bridge',
            __('Dashboard', 'membership-bridge-pro'),
            __('Dashboard', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge',
            array($this, 'admin_page')
        );
        
        add_submenu_page(
            'membership-bridge',
            __('Migration', 'membership-bridge-pro'),
            __('Migration', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge-migration',
            array($this, 'migration_page')
        );
        
        add_submenu_page(
            'membership-bridge',
            __('Sync Settings', 'membership-bridge-pro'),
            __('Sync Settings', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge-sync',
            array($this, 'sync_page')
        );
        
        add_submenu_page(
            'membership-bridge',
            __('Advanced', 'membership-bridge-pro'),
            __('Advanced', 'membership-bridge-pro'),
            'manage_options',
            'membership-bridge-advanced',
            array($this, 'advanced_page')
        );
    }
    
    public function admin_page() {
        $this->check_wizard_completion();
        include MBP_PLUGIN_DIR . 'templates/admin/dashboard.php';
    }
    
    public function migration_page() {
        $this->check_wizard_completion();
        include MBP_PLUGIN_DIR . 'templates/admin/migration.php';
    }
    
    public function sync_page() {
        $this->check_wizard_completion();
        include MBP_PLUGIN_DIR . 'templates/admin/sync.php';
    }
    
    public function advanced_page() {
        $this->check_wizard_completion();
        include MBP_PLUGIN_DIR . 'templates/admin/advanced.php';
    }
    
    private function check_wizard_completion() {
        $wizard_manager = new \MBP\Wizard\Wizard_Manager();
        if (!$wizard_manager->is_wizard_completed()) {
            $wizard_manager->show_wizard_alert();
        }
    }
    
    public function enqueue_admin_scripts($hook) {
        if (strpos($hook, 'membership-bridge') === false) {
            return;
        }
        
        wp_enqueue_script('mbp-admin', MBP_PLUGIN_URL . 'assets/js/admin.js', array('jquery'), MBP_VERSION, true);
        wp_enqueue_style('mbp-admin', MBP_PLUGIN_URL . 'assets/css/admin.css', array(), MBP_VERSION);
        
        wp_localize_script('mbp-admin', 'mbp_ajax', array(
            'ajax_url' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('mbp_nonce'),
            'strings' => array(
                'confirm_migration' => __('Are you sure you want to start the migration?', 'membership-bridge-pro'),
                'migration_started' => __('Migration started successfully!', 'membership-bridge-pro'),
                'error_occurred' => __('An error occurred. Please try again.', 'membership-bridge-pro'),
            )
        ));
    }
    
    public function enqueue_frontend_scripts() {
        // Frontend scripts if needed
    }
    
    public function activate() {
        // Create database tables
        $this->create_tables();
        
        // Set default options
        $this->set_default_options();
        
        // Schedule cron events
        $this->schedule_cron_events();
        
        // Redirect to wizard on first activation
        add_option('mbp_activation_redirect', true);
    }
    
    public function deactivate() {
        // Clear scheduled events
        wp_clear_scheduled_hook('mbp_sync_cron');
    }
    
    private function handle_activation_redirect() {
        // Check if we need to redirect after activation
        if (get_option('mbp_activation_redirect', false)) {
            delete_option('mbp_activation_redirect');
            
            // Only redirect if we're in admin and not doing AJAX
            if (is_admin() && !wp_doing_ajax()) {
                wp_redirect(admin_url('admin.php?page=membership-bridge-wizard'));
                exit;
            }
        }
    }
    
    private function create_tables() {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();
        
        // Migration log table
        $table_name = $wpdb->prefix . 'mbp_migration_log';
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            migration_id varchar(50) NOT NULL,
            user_id bigint(20) NOT NULL,
            action varchar(50) NOT NULL,
            status varchar(20) NOT NULL,
            message text,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY migration_id (migration_id),
            KEY user_id (user_id),
            KEY status (status)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        // Sync queue table
        $table_name = $wpdb->prefix . 'mbp_sync_queue';
        $sql = "CREATE TABLE $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            sync_id varchar(50) NOT NULL,
            action varchar(50) NOT NULL,
            data longtext,
            status varchar(20) DEFAULT 'pending',
            attempts int(11) DEFAULT 0,
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            processed_at datetime NULL,
            PRIMARY KEY (id),
            KEY sync_id (sync_id),
            KEY status (status)
        ) $charset_collate;";
        
        dbDelta($sql);
    }
    
    private function set_default_options() {
        $default_options = array(
            'mbp_version' => MBP_VERSION,
            'mbp_license_key' => '',
            'mbp_license_status' => 'inactive',
            'mbp_sync_enabled' => false,
            'mbp_sync_frequency' => 'hourly',
            'mbp_target_url' => '',
            'mbp_target_api_key' => '',
            'mbp_migration_status' => 'not_started',
            'mbp_last_sync' => null,
        );
        
        foreach ($default_options as $option => $value) {
            if (get_option($option) === false) {
                add_option($option, $value);
            }
        }
    }
    
    private function schedule_cron_events() {
        if (!wp_next_scheduled('mbp_sync_cron')) {
            wp_schedule_event(time(), 'hourly', 'mbp_sync_cron');
        }
    }
}

// Initialize the plugin
function membership_bridge_pro() {
    return MembershipBridgePro::get_instance();
}

// Start the plugin
membership_bridge_pro();
