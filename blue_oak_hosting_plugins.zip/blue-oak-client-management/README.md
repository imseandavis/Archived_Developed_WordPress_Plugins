# Blue Oak Client Management

A comprehensive WordPress plugin for managing client relationships and providing clients with a unified dashboard for monitoring their website's performance and marketing metrics.

## Overview

The Blue Oak Client Management plugin is a comprehensive WordPress solution designed for marketing and web design agencies to manage client relationships and data. The plugin provides a client portal where clients can access their website metrics, analytics, and other service-related information in one central location.

## Core Features

1. **Client Role Management**
   - Creates a custom "Blue Oak Client" role with specific capabilities
   - Restricts client access to designated areas only
   - Custom login redirects for client users

2. **Client Portal Interface**
   - A front-end dashboard accessible to clients via a shortcode `[blue_oak_client_portal]`
   - Multiple service integration tabs (Overview, Uptime, Analytics, Search Console, Ads)
   - Responsive design with modern UI components

3. **Service Integrations**
   - **UptimeRobot**: Website monitoring and uptime tracking
   - **Google Analytics**: Detailed website analytics and reporting
   - **Google Search Console**: Search performance and indexing metrics
   - **Google Ads**: Basic ad campaign performance tracking
   - **Vendasta**: Client service purchase tracking and management

4. **Admin Interface**
   - Dedicated settings page for API configurations
   - Client profile field management
   - Service connection management

5. **PageSpeed Insights**
   - Website performance monitoring and reporting
   - Scheduled performance scans
   - Historical performance data tracking

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher
- MySQL 5.6 or higher
- Google API Client library (via Composer)
- Vendasta API Client (via Composer)
- Font Awesome 6.5.1
- ApexCharts for data visualization

## Installation

1. Upload the `blue-oak-client-management` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Configure the plugin settings via the 'Blue Oak CM' menu in your WordPress admin panel
4. Add required API keys and service account credentials in the settings
5. Set up client profiles with associated service IDs
6. Add the `[blue_oak_client_portal]` shortcode to a page to create the client portal

## Technical Architecture

### Core Components

1. **Main Plugin File**: `blue-oak-client-management.php`
   - Plugin initialization
   - Constants definition
   - Core file loading
   - Activation/deactivation hooks

2. **Core Classes**:
   - `Plugin`: Main plugin loader and initialization
   - `Admin_Menu`: Admin menu and settings management
   - `User_Profile`: Client profile customization and portal functionality
   - `Activator`: Plugin activation setup
   - `Deactivator`: Plugin deactivation cleanup

3. **API Integration Classes**:
   - `UptimeRobot`: UptimeRobot API integration for website monitoring
   - `GoogleAnalytics`: Google Analytics API integration for website analytics
   - `GoogleSearchConsole`: GSC API integration for search performance metrics
   - `Vendasta`: Vendasta API integration for service and purchase tracking
   - `PageSpeed_Scanner`: Google PageSpeed API integration for performance metrics

4. **Front-end Components**:
   - Tab-based client portal interface
   - Interactive data visualizations with ApexCharts
   - Responsive design with modern UI elements

### Directory Structure

```
blue-oak-client-management/
├── includes/               # Core plugin classes
│   ├── Admin.php           # Admin functionality
│   ├── User_Profile.php    # Client profile and portal functionality
│   ├── UptimeRobot.php     # UptimeRobot API integration
│   ├── GoogleAnalytics.php # Google Analytics API integration
│   ├── GoogleSearchConsole.php # GSC API integration
│   ├── Vendasta.php        # Vendasta API integration
│   ├── PageSpeed_Scanner.php # PageSpeed API integration
│   ├── PageSpeed_Admin.php # PageSpeed admin interface
│   ├── Plugin.php          # Main plugin class
│   ├── Activator.php       # Plugin activation
│   ├── Deactivator.php     # Plugin deactivation
│   ├── Admin_Menu.php      # Admin menu and settings
│   └── views/              # PHP view templates
│       └── tabs/           # Client portal tab templates
├── admin/                  # Admin-specific functionality
├── public/                 # Public-facing functionality
├── assets/                 # Frontend assets
│   ├── js/                 # JavaScript files
│   └── css/                # CSS stylesheets
├── languages/              # Internationalization files
└── blue-oak-client-management.php # Main plugin file
```

## Client Portal Functionality

The client portal is the core user-facing feature of the plugin, providing clients with a comprehensive view of their website and marketing performance.

### Portal Tabs

1. **Overview Tab**
   - Service overview with access status indicators
   - Quick access to all client services
   - Website status monitoring
   - Service upgrade options

2. **Uptime Tab**
   - Website uptime percentages (24h, 7d, 30d, 90d)
   - Response time graphs
   - Downtime incident history
   - Performance metrics

3. **Google Analytics Tab**
   - Traffic overview and trends
   - Key metrics (sessions, users, page views, bounce rate)
   - Traffic sources
   - Page performance
   - User demographics

4. **Google Search Console Tab**
   - Search query performance
   - Click-through rates
   - Impression data
   - Position tracking
   - Mobile usability

5. **Google Ads Tab**
   - Campaign performance metrics
   - Ad spend tracking
   - Conversion rates
   - Ad performance analytics

6. **Upgrade Tab**
   - Available service upgrade options
   - Service comparison information
   - Contact forms for service inquiries

## Admin Interface

The plugin provides a comprehensive admin interface for managing client settings and configuring service integrations.

### Admin Menu Structure

1. **Blue Oak Client Management**
   - Main settings page
   - API key management
   - Service account configurations

2. **Uptime Robot Settings**
   - API key configuration
   - Monitor management

3. **Google Analytics Settings**
   - Service account credentials
   - Property management

4. **Google Search Console Settings**
   - Authorization management
   - Site property configuration

5. **User Profile Extensions**
   - Client-specific fields in user profiles
   - Service association settings

## API Integrations

The plugin integrates with multiple third-party APIs to provide comprehensive data to clients:

1. **UptimeRobot API**
   - Monitor management
   - Uptime reporting
   - Response time tracking
   - Incident logging

2. **Google Analytics API**
   - Traffic analytics
   - User behavior metrics
   - Demographic information
   - Conversion tracking

3. **Google Search Console API**
   - Search query performance
   - Site indexing status
   - Mobile usability
   - Click-through data

4. **Vendasta API**
   - Client purchase tracking
   - Service management
   - Subscription status

5. **Google PageSpeed API**
   - Performance scoring
   - Website optimization recommendations
   - Mobile and desktop performance

## Security Measures

The plugin implements several security best practices:

1. **Data Validation and Sanitization**
   - Input sanitization for all user inputs
   - Data validation before processing

2. **Role-Based Access Control**
   - Custom client role with limited capabilities
   - Restricted access to WordPress admin areas

3. **API Security**
   - Secure API key storage
   - Authentication for all API requests
   - Credential verification

4. **Nonce Verification**
   - Form submission security
   - AJAX request verification

## Database Structure

The plugin primarily uses WordPress user meta for storing client-specific data and options tables for global settings:

1. **User Meta Fields**
   - `bocm_ga_property_id`: Google Analytics property ID
   - `bocm_gsc_site_url`: Google Search Console site URL
   - `bocm_uptime_monitor_id`: UptimeRobot monitor ID
   - `bocm_ads_customer_id`: Google Ads customer ID
   - `bocm_partner_account_group_id`: Vendasta partner account group ID
   - `bocm_pagespeed_timestamp`: Last PageSpeed scan timestamp
   - `bocm_pagespeed_data`: PageSpeed scan results

2. **Options**
   - `bocm_version`: Plugin version
   - `bocm_uptimerobot_api_key`: UptimeRobot API key
   - `bocm_ga_service_account`: Google Analytics service account credentials
   - `bocm_vendasta_service_account`: Vendasta service account credentials
   - `bocm_pagespeed_api_key`: Google PageSpeed API key

## Customization and Extension

The plugin is built with extensibility in mind:

1. **Object-Oriented Architecture**
   - Modular class structure for easy extension
   - Clear separation of concerns

2. **Hooks System**
   - Actions and filters for extending functionality
   - Integration points for additional features

3. **Template System**
   - Separate view files for easier customization
   - Tab-based structure for adding new portal sections

## Internationalization

The plugin is fully internationalized:
- Text domain: `blue-oak-client-management`
- Domain path: `/languages/`
- Translation-ready strings using WordPress i18n functions

## Development

### Setup

1. Clone this repository to your local development environment
2. Run `composer install` to install required dependencies
3. Ensure you have access to the required API keys and service accounts
4. Follow WordPress coding standards and best practices

## License

This plugin is licensed under the GPL v2 or later.

## Changelog

### 1.0.1
- Added GoogleSearchConsole integration
- Fixed uptime monitoring display issues
- Improved mobile responsiveness

### 1.0.0
- Initial release 