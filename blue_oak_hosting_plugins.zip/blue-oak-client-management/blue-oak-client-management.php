<?php
/**
 * Plugin Name: Blue Oak Client Management
 * Plugin URI: https://blueoakmarketing.com
 * Description: A comprehensive client management system for WordPress
 * Version: 1.0.0
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * Author: Blue Oak Marketing
 * Author URI: https://blueoakmarketing.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: blue-oak-client-management
 * Domain Path: /languages
 */

declare(strict_types=1);

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('BOCM_VERSION', '1.0.1');
define('BOCM_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BOCM_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BOCM_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Define debug constants - uncomment to enable debug logging
// define('BOCM_DEBUG', true); // Enables all debug logging
// define('BOCM_LOG_LEVEL', 'info'); // Options: debug, info, warning, error

// Load Composer autoloader if it exists
$composer_autoloader = BOCM_PLUGIN_DIR . 'vendor/autoload.php';
if (file_exists($composer_autoloader)) {
    require_once $composer_autoloader;
}

// Fallback autoloader for plugin classes
spl_autoload_register(function ($class) {
    $prefix = 'BlueOak\\ClientManagement\\';
    $base_dir = BOCM_PLUGIN_DIR . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . $relative_class . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Activation hook
register_activation_hook(__FILE__, function() {
    require_once BOCM_PLUGIN_DIR . 'includes/Activator.php';
    BlueOak\ClientManagement\Activator::activate();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    require_once BOCM_PLUGIN_DIR . 'includes/Deactivator.php';
    BlueOak\ClientManagement\Deactivator::deactivate();
});

// Initialize the plugin
add_action('plugins_loaded', function() {
    
    require_once BOCM_PLUGIN_DIR . 'includes/Plugin.php';
    $plugin = new BlueOak\ClientManagement\Plugin();
    $plugin->run();
}); 