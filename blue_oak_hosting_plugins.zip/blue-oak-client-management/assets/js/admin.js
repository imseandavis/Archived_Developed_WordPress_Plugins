jQuery(document).ready(function($) {
    'use strict';

    console.log('Blue Oak Client Management admin.js loaded');

    // Initialize debug panel
    initializeDebugPanel();

    // Initialize tooltips
    $('.tooltip').tooltip();

    // Handle tab navigation in settings page
    const urlParams = new URLSearchParams(window.location.search);
    const tab = urlParams.get('tab');
    
    if (tab) {
        // Ensure the correct tab is active
        $('.nav-tab-wrapper .nav-tab').removeClass('nav-tab-active');
        $(`.nav-tab-wrapper .nav-tab[href*="tab=${tab}"]`).addClass('nav-tab-active');
    }

    // Check if the overlay element exists, if not, create it and append to body
    if (!$('.bocm-scan-overlay').length) {
        $('body').append(`
            <div class="bocm-scan-overlay">
                <div class="bocm-scan-overlay-content">
                    <div class="bocm-scan-overlay-spinner">
                        <div class="spinner-inline"></div>
                    </div>
                    <div class="bocm-scan-overlay-text">
                        Scanning website performance...
                    </div>
                </div>
            </div>
        `);

        // Add overlay styles if not already present in CSS
        $('head').append(`
            <style id="bocm-overlay-styles">
                .bocm-scan-overlay {
                    display: none;
                    position: fixed;
                    top: 0;
                    left: 0;
                    width: 100%;
                    height: 100%;
                    background-color: rgba(0, 0, 0, 0.7);
                    z-index: 999999;
                    justify-content: center;
                    align-items: center;
                }
                
                .bocm-scan-overlay.scanning {
                    display: flex !important;
                }
                
                .bocm-scan-overlay-content {
                    background-color: #fff;
                    padding: 30px;
                    border-radius: 5px;
                    text-align: center;
                    box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
                    max-width: 80%;
                }
                
                .bocm-scan-overlay-spinner {
                    margin-bottom: 15px;
                    display: flex;
                    justify-content: center;
                }
                
                .bocm-scan-overlay-spinner .spinner-inline {
                    width: 40px;
                    height: 40px;
                    border-width: 4px;
                }
            </style>
        `);
    }

    // Add modal for PageSpeed history
    if (!$('#bocm-pagespeed-history-modal').length) {
        $('body').append(`
            <div id="bocm-pagespeed-history-modal" class="bocm-modal">
                <div class="bocm-modal-content">
                    <span class="bocm-modal-close">&times;</span>
                    <h2 class="bocm-modal-title">PageSpeed History</h2>
                    <div class="bocm-modal-body">
                        <div id="pagespeed-history-chart"></div>
                        <div class="bocm-history-table-container">
                            <table class="wp-list-table widefat fixed striped bocm-history-table">
                                <thead>
                                    <tr>
                                        <th>Date</th>
                                        <th>Desktop Score</th>
                                        <th>Page Size</th>
                                        <th>FCP</th>
                                        <th>LCP</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <!-- Will be populated dynamically -->
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        `);

        // Add modal styles if not already present
        if (!$('#bocm-modal-styles').length) {
            $('head').append(`
                <style id="bocm-modal-styles">
                    .bocm-modal {
                        display: none;
                        position: fixed;
                        z-index: 999999;
                        left: 0;
                        top: 0;
                        width: 100%;
                        height: 100%;
                        overflow: auto;
                        background-color: rgba(0,0,0,0.4);
                    }
                    
                    .bocm-modal-content {
                        position: relative;
                        background-color: #fefefe;
                        margin: 5% auto;
                        padding: 20px;
                        border: 1px solid #888;
                        width: 80%;
                        max-width: 800px;
                        border-radius: 4px;
                    }
                    
                    .bocm-modal-close {
                        color: #aaa;
                        float: right;
                        font-size: 28px;
                        font-weight: bold;
                        cursor: pointer;
                    }
                    
                    .bocm-modal-close:hover,
                    .bocm-modal-close:focus {
                        color: black;
                        text-decoration: none;
                    }
                    
                    .bocm-modal-title {
                        margin-top: 0;
                    }
                    
                    .bocm-history-table-container {
                        margin-top: 20px;
                        max-height: 300px;
                        overflow-y: auto;
                    }
                    
                    #pagespeed-history-chart {
                        height: 300px;
                    }
                </style>
            `);
        }

        // Handle modal close
        $('.bocm-modal-close').on('click', function() {
            $('.bocm-modal').hide();
        });

        // Close modal when clicking outside
        $(window).on('click', function(event) {
            if ($(event.target).hasClass('bocm-modal')) {
                $('.bocm-modal').hide();
            }
        });
    }

    const $overlay = $('.bocm-scan-overlay');
    
    // Show overlay when scanning
    function showScanningOverlay(message) {
        $('.bocm-scan-overlay-text').text(message || 'Scanning website performance...');
        $overlay.addClass('scanning');
        
        // Force overlay display with both class and style
        $overlay.css({
            'display': 'flex',
            'opacity': '1',
            'visibility': 'visible'
        });
        
        // Log to console to help with debugging
        console.log('Showing overlay with message: ' + message);
        
        // Add a debug message directly in the page for admin
        if ($('#bocm-debug-info').length === 0) {
            $('body').append('<div id="bocm-debug-info" style="position:fixed; bottom:10px; right:10px; background:rgba(0,0,0,0.7); color:white; padding:10px; z-index:9999999; max-width:300px;"></div>');
        }
        $('#bocm-debug-info').html('Status: ' + message);
    }
    
    // Hide overlay when done
    function hideScanningOverlay() {
        $overlay.removeClass('scanning');
        $overlay.css({
            'display': 'none',
            'opacity': '0',
            'visibility': 'hidden'
        });
        console.log('Hiding overlay');
        
        $('#bocm-debug-info').html('Status: Idle');
    }

    // Custom enhanced spinner for status indicators - use WordPress native spinner
    function createSpinner() {
        return '<span class="spinner is-active" style="visibility:visible !important; float:none; margin:0 5px 0 0; opacity:1;"></span>';
    }

    // PageSpeed scan functionality
    if ($('.run-scan').length) {
        // Handle view history button clicks
        $('.view-history').on('click', function() {
            const userId = $(this).data('user-id');
            const clientName = $(this).closest('tr').find('td:first-child').text();
            
            // Show loading state in modal
            $('#bocm-pagespeed-history-modal').show();
            $('.bocm-modal-title').text('PageSpeed History: ' + clientName);
            $('.bocm-history-table tbody').html('<tr><td colspan="5">' + createSpinner() + ' Loading history data...</td></tr>');
            
            // Fetch history data
            $.ajax({
                url: bocmAdminData.ajaxurl || ajaxurl,
                type: 'POST',
                data: {
                    action: 'bocm_get_pagespeed_history',
                    user_id: userId,
                    nonce: bocmAdminData.nonce
                },
                success: function(response) {
                    if (response.success && response.data.history) {
                        // Prepare data for chart and table
                        const historyData = response.data.history;
                        const dates = [];
                        const scores = [];
                        let tableRows = '';
                        
                        // Sort dates chronologically
                        const sortedDates = Object.keys(historyData).sort();
                        
                        sortedDates.forEach(function(date) {
                            const data = historyData[date];
                            if (data && data.desktop_score) {
                                dates.push(date);
                                scores.push(data.desktop_score);
                                
                                // Add row to table
                                tableRows += `
                                    <tr>
                                        <td>${date}</td>
                                        <td class="${getScoreClass(data.desktop_score)}">${data.desktop_score}</td>
                                        <td>${data.page_size} MB</td>
                                        <td>${data.first_contentful_paint}s</td>
                                        <td>${data.largest_contentful_paint}s</td>
                                    </tr>
                                `;
                            }
                        });
                        
                        // Update table
                        $('.bocm-history-table tbody').html(tableRows);
                        
                        // Create chart if we have data
                        if (dates.length > 0) {
                            const options = {
                                series: [{
                                    name: 'Desktop Score',
                                    data: scores
                                }],
                                chart: {
                                    height: 300,
                                    type: 'line',
                                    toolbar: {
                                        show: true,
                                        tools: {
                                            download: true,
                                            selection: false,
                                            zoom: true,
                                            zoomin: true,
                                            zoomout: true,
                                            pan: true
                                        }
                                    }
                                },
                                stroke: {
                                    curve: 'smooth',
                                    width: 3
                                },
                                colors: ['#2271b1'],
                                xaxis: {
                                    categories: dates
                                },
                                yaxis: {
                                    min: 0,
                                    max: 100,
                                    title: {
                                        text: 'PageSpeed Score'
                                    }
                                },
                                markers: {
                                    size: 4,
                                    hover: {
                                        size: 7
                                    }
                                },
                                tooltip: {
                                    y: {
                                        formatter: function(val) {
                                            return val;
                                        }
                                    }
                                },
                                annotations: {
                                    yaxis: [
                                        {
                                            y: 90,
                                            borderColor: '#00E396',
                                            label: {
                                                text: 'Excellent (90+)'
                                            }
                                        },
                                        {
                                            y: 50,
                                            borderColor: '#FEB019',
                                            label: {
                                                text: 'Poor (<50)'
                                            }
                                        }
                                    ]
                                }
                            };
                            
                            // Clear previous chart and create new one
                            $('#pagespeed-history-chart').empty();
                            const chart = new ApexCharts(document.querySelector('#pagespeed-history-chart'), options);
                            chart.render();
                        } else {
                            $('#pagespeed-history-chart').html('<p>No historical data available.</p>');
                        }
                    } else {
                        $('.bocm-history-table tbody').html('<tr><td colspan="5">No history data available.</td></tr>');
                        $('#pagespeed-history-chart').html('<p>No historical data available.</p>');
                    }
                },
                error: function() {
                    $('.bocm-history-table tbody').html('<tr><td colspan="5">Error loading history data.</td></tr>');
                    $('#pagespeed-history-chart').html('<p>Error loading history data.</p>');
                }
            });
        });
        
        // Individual scan button
        $('.run-scan').on('click', function() {
            const button = $(this);
            const userId = button.data('user-id');
            const url = button.data('url');
            const statusSpan = button.siblings('.scan-status');
            
            // Update debug info
            $('#bocm-debug-info').html('Status: Starting scan for user ID ' + userId + ' with URL: ' + url);
            
            // Disable button and show loading spinner
            button.prop('disabled', true);
            button.addClass('button-busy');
            statusSpan.html(createSpinner() + '<span class="scanning-pulse">Scanning...</span>');
            
            // Show the overlay notification
            showScanningOverlay('Scanning ' + url);
            
            console.log('Started scan for user ID: ' + userId + ', URL: ' + url);
            console.log('AJAX URL:', bocmAdminData.ajaxurl || ajaxurl);
            console.log('Nonce:', bocmAdminData.nonce);
            
            // Send AJAX request to run scan
            $.ajax({
                url: bocmAdminData.ajaxurl || ajaxurl,
                type: 'POST',
                data: {
                    action: 'bocm_run_pagespeed_scan',
                    user_id: userId,
                    url: url,
                    nonce: bocmAdminData.nonce
                },
                beforeSend: function() {
                    console.log('AJAX request being sent');
                    $('#bocm-debug-info').html('Status: AJAX request sent, waiting for response...');
                },
                success: function(response) {
                    console.log('Scan completed with result:', response);
                    $('#bocm-debug-info').html('Status: Scan completed. Response received: ' + JSON.stringify(response).substring(0, 100) + '...');
                    
                    // Hide the overlay notification
                    hideScanningOverlay();
                    
                    if (response.success) {
                        statusSpan.html('<span class="dashicons dashicons-yes" style="color:green;"></span> ' + response.data.message);
                        
                        // Update score and other fields in the row
                        const row = button.closest('tr');
                        const data = response.data.scan_data;
                        
                        row.find('td:nth-child(3)').text('Just now');
                        row.find('td:nth-child(4)').text(data.desktop_score).attr('class', getScoreClass(data.desktop_score));
                        
                        // If we have a view-history button, enable it (new data available)
                        const historyButton = row.find('.view-history');
                        if (historyButton.length === 0) {
                            // Add a history button if it doesn't exist
                            button.after(' <button type="button" class="button view-history" data-user-id="' + userId + '">History</button>');
                            // Bind the click event to the new button
                            row.find('.view-history').on('click', function() {
                                $(this).trigger('click');
                            });
                        }
                        
                        // Page needs to be refreshed to see updated sparkline
                        row.find('td:nth-child(5)').html('<em>Refresh page to see updated trend</em>');
                        
                        row.find('td:nth-child(6)').text(data.page_size + ' MB');
                        row.find('td:nth-child(7)').text(data.first_contentful_paint + 's');
                        row.find('td:nth-child(8)').text(data.largest_contentful_paint + 's');
                        
                        // Highlight the row briefly to show it's been updated
                        row.css('background-color', 'rgba(70, 180, 80, 0.1)');
                        setTimeout(function() {
                            row.css('background-color', '');
                        }, 2000);
                        
                        // Re-enable button after a short delay
                        setTimeout(function() {
                            button.prop('disabled', false);
                            button.removeClass('button-busy');
                            statusSpan.html('<span class="dashicons dashicons-yes" style="color:green;"></span> <span style="color:green;">Completed</span>');
                            
                            // Auto-clear success message after 5 seconds
                            setTimeout(function() {
                                statusSpan.html('');
                            }, 5000);
                        }, 1000);
                    } else {
                        statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> ' + response.data.message);
                        
                        // Re-enable button
                        setTimeout(function() {
                            button.prop('disabled', false);
                            button.removeClass('button-busy');
                        }, 1000);
                    }
                },
                error: function(xhr, status, error) {
                    // Hide the overlay notification
                    hideScanningOverlay();
                    
                    console.error('AJAX error:', status, error);
                    console.error('Response text:', xhr.responseText);
                    $('#bocm-debug-info').html('Status: AJAX error - ' + status + ': ' + error + '<br>Response: ' + xhr.responseText.substring(0, 100));
                    
                    statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> Error running scan.');
                    
                    // Re-enable button
                    setTimeout(function() {
                        button.prop('disabled', false);
                        button.removeClass('button-busy');
                    }, 1000);
                }
            });
        });
        
        // Run all scans button
        $('.run-all-scans').on('click', function() {
            const button = $(this);
            const statusSpan = $('.all-scans-status');
            
            // Disable button and show loading spinner
            button.prop('disabled', true);
            button.addClass('button-busy');
            statusSpan.html(createSpinner() + '<span class="scanning-pulse">Scanning all sites. This may take a while...</span>');
            
            // Show overlay notification
            showScanningOverlay('Running scans for all websites. This may take a while...');
            
            console.log('Started scanning all sites');
            console.log('AJAX URL:', bocmAdminData.ajaxurl || ajaxurl);
            console.log('Nonce:', bocmAdminData.nonce);
            
            // Send AJAX request to run all scans
            $.ajax({
                url: bocmAdminData.ajaxurl || ajaxurl,
                type: 'POST',
                data: {
                    action: 'bocm_run_all_pagespeed_scans',
                    nonce: bocmAdminData.nonce
                },
                beforeSend: function() {
                    console.log('AJAX request being sent for all scans');
                    $('#bocm-debug-info').html('Status: AJAX request sent for all scans, waiting for response...');
                },
                success: function(response) {
                    console.log('All scans completed with result:', response);
                    $('#bocm-debug-info').html('Status: All scans completed. Response received: ' + JSON.stringify(response).substring(0, 100) + '...');
                    
                    // Hide the overlay notification
                    hideScanningOverlay();
                    
                    if (response.success) {
                        statusSpan.html('<span class="dashicons dashicons-yes" style="color:green;"></span> ' + response.data.message);
                        
                        // Show completion message in overlay
                        showScanningOverlay('All scans completed! Page will refresh in 3 seconds...');
                        
                        // Reload the page after a delay to show updated results
                        setTimeout(function() {
                            location.reload();
                        }, 3000);
                    } else {
                        statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> ' + response.data.message);
                        
                        // Re-enable button
                        setTimeout(function() {
                            button.prop('disabled', false);
                            button.removeClass('button-busy');
                        }, 1000);
                    }
                },
                error: function(xhr, status, error) {
                    // Hide the overlay notification
                    hideScanningOverlay();
                    
                    console.error('AJAX error for all scans:', status, error);
                    console.error('Response text:', xhr.responseText);
                    $('#bocm-debug-info').html('Status: AJAX error on all scans - ' + status + ': ' + error + '<br>Response: ' + xhr.responseText.substring(0, 100));
                    
                    statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> Error running scans.');
                    
                    // Re-enable button
                    setTimeout(function() {
                        button.prop('disabled', false);
                        button.removeClass('button-busy');
                    }, 1000);
                }
            });
        });
        
        // Schedule now button
        $('.schedule-now').on('click', function() {
            const button = $(this);
            const statusSpan = $('.schedule-status');
            
            // Disable button and show loading spinner
            button.prop('disabled', true);
            button.addClass('button-busy');
            statusSpan.html(createSpinner() + '<span class="scanning-pulse">Scheduling...</span>');
            
            console.log('Scheduling PageSpeed scans');
            console.log('AJAX URL:', bocmAdminData.ajaxurl || ajaxurl);
            console.log('Nonce:', bocmAdminData.nonce);
            
            // Show a minimal overlay for feedback
            showScanningOverlay('Scheduling PageSpeed scans...');
            
            // Send AJAX request to schedule scans
            $.ajax({
                url: bocmAdminData.ajaxurl || ajaxurl,
                type: 'POST',
                data: {
                    action: 'bocm_schedule_pagespeed_scans',
                    nonce: bocmAdminData.nonce
                },
                beforeSend: function() {
                    console.log('AJAX request being sent for scheduling');
                    $('#bocm-debug-info').html('Status: AJAX request sent for scheduling, waiting for response...');
                },
                success: function(response) {
                    console.log('Schedule scans completed with result:', response);
                    $('#bocm-debug-info').html('Status: Scheduling completed. Response received: ' + JSON.stringify(response).substring(0, 100) + '...');
                    
                    // Hide the overlay
                    hideScanningOverlay();
                    
                    if (response.success) {
                        statusSpan.html('<span class="dashicons dashicons-yes" style="color:green;"></span> ' + response.data.message);
                        
                        // Show a success message
                        showScanningOverlay('Scans scheduled successfully! Page will refresh in 3 seconds...');
                        
                        // Reload the page after a delay to show updated schedule
                        setTimeout(function() {
                            location.reload();
                        }, 3000);
                    } else {
                        statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> ' + response.data.message);
                        
                        // Re-enable button
                        setTimeout(function() {
                            button.prop('disabled', false);
                            button.removeClass('button-busy');
                        }, 1000);
                    }
                },
                error: function(xhr, status, error) {
                    // Hide overlay
                    hideScanningOverlay();
                    
                    console.error('AJAX error for scheduling:', status, error);
                    console.error('Response text:', xhr.responseText);
                    $('#bocm-debug-info').html('Status: AJAX error on scheduling - ' + status + ': ' + error + '<br>Response: ' + xhr.responseText.substring(0, 100));
                    
                    statusSpan.html('<span class="dashicons dashicons-warning" style="color:red;"></span> Error scheduling scans.');
                    
                    // Re-enable button
                    setTimeout(function() {
                        button.prop('disabled', false);
                        button.removeClass('button-busy');
                    }, 1000);
                }
            });
        });
    }
    
    // Helper function to get the score class based on the score value
    function getScoreClass(score) {
        if (score >= 90) {
            return 'score-excellent';
        } else if (score >= 70) {
            return 'score-good';
        } else if (score >= 50) {
            return 'score-average';
        } else {
            return 'score-poor';
        }
    }

    // Add test button
    function addTestAjaxButton() {
        if ($('#test-ajax-button').length === 0) {
            // Add the button after debug panel is created
            const testButton = $('<button id="test-ajax-button" class="button button-primary" style="position:fixed; bottom:180px; right:10px; z-index:999999; padding:10px 15px; font-weight:bold; background-color:#2271b1; color:white; border:none; border-radius:4px; cursor:pointer;">Test AJAX</button>');
            $('body').append(testButton);
            
            // Add clear button for debug panel
            const clearButton = $('<button id="clear-debug-button" class="button" style="position:fixed; bottom:140px; right:10px; z-index:999999; padding:8px 12px; background-color:#f0f0f1; color:#333; border:1px solid #c3c4c7; border-radius:4px; cursor:pointer;">Clear Debug</button>');
            $('body').append(clearButton);
            
            // Clear debug panel on click
            clearButton.on('click', function() {
                $('#bocm-debug-info').html('Debug panel cleared');
            });
            
            // Add click handler
            testButton.on('click', function() {
                $('#bocm-debug-info').html('Testing AJAX connection...');
                
                // Get the correct AJAX URL and nonce
                let ajaxUrl, nonce;
                
                // Try bocmAdminData first
                if (typeof bocmAdminData !== 'undefined') {
                    ajaxUrl = bocmAdminData.ajaxurl;
                    nonce = bocmAdminData.nonce;
                    console.log('Using bocmAdminData for AJAX test');
                } 
                // Then try bocmPageSpeed
                else if (typeof bocmPageSpeed !== 'undefined') {
                    ajaxUrl = bocmPageSpeed.ajaxUrl;
                    nonce = bocmPageSpeed.nonce;
                    console.log('Using bocmPageSpeed for AJAX test');
                } 
                // Fall back to global ajaxurl
                else if (typeof ajaxurl !== 'undefined') {
                    ajaxUrl = ajaxurl;
                    nonce = ''; // No nonce available
                    console.log('Using global ajaxurl for AJAX test (no nonce available)');
                } else {
                    $('#bocm-debug-info').html('AJAX Test Failed: No AJAX URL available');
                    console.error('AJAX test failed: No AJAX URL available');
                    return;
                }
                
                console.log('AJAX Test URL:', ajaxUrl);
                console.log('AJAX Nonce:', nonce);
                
                // Update debug panel with request details
                $('#bocm-debug-info').html(
                    'Sending AJAX request to: ' + ajaxUrl + '<br>' +
                    'Action: bocm_test_ajax<br>' +
                    'Nonce: ' + (nonce ? nonce.substring(0, 5) + '...' : 'None') + '<br><br>' +
                    'Waiting for response...'
                );
                
                $.ajax({
                    url: ajaxUrl,
                    type: 'POST',
                    data: {
                        action: 'bocm_test_ajax', // This should match the PHP add_action hook
                        nonce: nonce
                    },
                    beforeSend: function() {
                        console.log('Sending AJAX test request...');
                        testButton.text('Testing...').prop('disabled', true);
                    },
                    success: function(response) {
                        $('#bocm-debug-info').html(
                            '<strong style="color:#4caf50">AJAX Test Successful!</strong><br><br>' +
                            'Response: <pre style="background:#f5f5f5; padding:10px; overflow:auto; max-height:300px;">' + 
                            JSON.stringify(response, null, 2) + 
                            '</pre>'
                        );
                        console.log('AJAX test successful:', response);
                        testButton.text('Test AJAX').prop('disabled', false);
                    },
                    error: function(xhr, status, error) {
                        $('#bocm-debug-info').html(
                            '<strong style="color:#f44336">AJAX Test Failed!</strong><br><br>' +
                            'Status: ' + status + '<br>' +
                            'Error: ' + error + '<br><br>' +
                            'Response: <pre style="background:#f5f5f5; padding:10px; overflow:auto; max-height:300px;">' + 
                            xhr.responseText + 
                            '</pre>'
                        );
                        console.error('AJAX test failed:', status, error, xhr.responseText);
                        testButton.text('Test AJAX').prop('disabled', false);
                    }
                });
            });
        }
    }

    // Initialize debug panel and check AJAX setup
    function initializeDebugPanel() {
        // Create debug panel if it doesn't exist
        if ($('#bocm-debug-info').length === 0) {
            // Add toggle button
            const toggleButton = $('<button id="debug-toggle-button" class="button" style="position:fixed; bottom:220px; right:10px; z-index:999999; padding:8px 12px; background-color:#2271b1; color:white; border:none; border-radius:4px; cursor:pointer; font-size:12px;">Show/Hide Debug</button>');
            $('body').append(toggleButton);
            
            // Add debug panel
            $('body').append('<div id="bocm-debug-info" style="position:fixed; bottom:10px; right:10px; background:rgba(0,0,0,0.8); color:white; padding:10px; z-index:9999999; max-width:500px; max-height:400px; overflow-y:auto; font-family:monospace; font-size:12px; display:none;"></div>');
            
            // Toggle debug panel visibility
            toggleButton.on('click', function() {
                $('#bocm-debug-info').toggle();
            });
        }
        
        // Check that AJAX URL and nonce are available
        let debugInfo = '<strong>AJAX Debug:</strong><br>';
        
        // Check all possible admin data objects
        if (typeof bocmAdminData !== 'undefined') {
            debugInfo += '✓ bocmAdminData is defined<br>';
            
            if (bocmAdminData.ajaxurl) {
                debugInfo += '✓ ajaxurl: ' + bocmAdminData.ajaxurl + '<br>';
            } else {
                debugInfo += '✗ ajaxurl not defined in bocmAdminData!<br>';
            }
            
            if (bocmAdminData.nonce) {
                debugInfo += '✓ nonce: ' + bocmAdminData.nonce.substring(0, 5) + '...<br>';
            } else {
                debugInfo += '✗ nonce not defined in bocmAdminData!<br>';
            }
        } else {
            debugInfo += '✗ bocmAdminData is NOT defined!<br>';
        }
        
        // Check for alternate variable names
        if (typeof bocmPageSpeed !== 'undefined') {
            debugInfo += '✓ bocmPageSpeed is defined<br>';
            
            if (bocmPageSpeed.ajaxUrl) {
                debugInfo += '✓ bocmPageSpeed.ajaxUrl: ' + bocmPageSpeed.ajaxUrl + '<br>';
            }
            
            if (bocmPageSpeed.nonce) {
                debugInfo += '✓ bocmPageSpeed.nonce: ' + bocmPageSpeed.nonce.substring(0, 5) + '...<br>';
            }
        } else {
            debugInfo += '✗ bocmPageSpeed is NOT defined!<br>';
        }
        
        // Check for global ajaxurl
        if (typeof ajaxurl !== 'undefined') {
            debugInfo += '✓ global ajaxurl found: ' + ajaxurl + '<br>';
        } else {
            debugInfo += '✗ global ajaxurl NOT found!<br>';
        }
        
        // Check for jQuery AJAX functionality
        if ($.ajax) {
            debugInfo += '✓ jQuery AJAX is available<br>';
        } else {
            debugInfo += '✗ jQuery AJAX not available!<br>';
        }
        
        // Log scan buttons found
        const scanButtons = $('.run-scan').length;
        const allScansButton = $('.run-all-scans').length;
        const scheduleButton = $('.schedule-now').length;
        
        debugInfo += '<br><strong>Buttons found:</strong><br>';
        debugInfo += '- Run Scan: ' + scanButtons + '<br>';
        debugInfo += '- Run All Scans: ' + allScansButton + '<br>';
        debugInfo += '- Schedule Now: ' + scheduleButton + '<br>';
        
        $('#bocm-debug-info').html(debugInfo);
        console.log('Debug initialization complete');
        
        // Add test AJAX button
        addTestAjaxButton();
    }
}); 