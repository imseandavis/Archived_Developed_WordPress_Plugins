/**
 * Upgrade Tab JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initUpgradeTab();
});

/**
 * Initialize upgrade tab functionality
 */
function initUpgradeTab() {
    // Handle upgrade button clicks
    const upgradeButtons = document.querySelectorAll('.bocm-upgrade-button');
    upgradeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const planId = this.dataset.planId;
            const planName = this.dataset.planName;
            const planPrice = this.dataset.planPrice;

            // Here you would typically handle the upgrade process
            console.log(`Upgrading to plan: ${planName} (${planId}) at ${planPrice}`);
        });
    });

    // Handle contact sales button clicks
    const contactSalesButtons = document.querySelectorAll('.bocm-contact-sales');
    contactSalesButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            const subject = encodeURIComponent('Enterprise Plan Inquiry');
            const body = encodeURIComponent('I am interested in learning more about the Enterprise plan.');
            window.location.href = `mailto:sales@example.com?subject=${subject}&body=${body}`;
        });
    });

    // Add hover effects for plan cards
    const planCards = document.querySelectorAll('.bocm-plan-card');
    planCards.forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
            this.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.1)';
        });

        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
} 