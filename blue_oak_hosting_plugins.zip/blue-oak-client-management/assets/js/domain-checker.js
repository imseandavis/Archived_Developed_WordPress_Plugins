jQuery(document).ready(function($) {
    const form = $('#bocm-domain-checker-form');
    const input = $('#bocm-domain-input');
    const result = $('#bocm-domain-checker-result');
    const button = form.find('button[type="submit"]');

    form.on('submit', function(e) {
        e.preventDefault();

        const domain = input.val().trim();
        if (!domain) {
            showResult('error', bocmDomainChecker.error_text);
            return;
        }

        // Show loading state
        button.prop('disabled', true);
        showResult('loading', bocmDomainChecker.checking_text);

        // Make AJAX request
        $.ajax({
            url: bocmDomainChecker.ajaxurl,
            type: 'POST',
            data: {
                action: 'check_domain',
                nonce: bocmDomainChecker.nonce,
                domain: domain
            },
            success: function(response) {
                console.log('Domain check response:', response);
                
                if (response.success) {
                    const data = response.data;
                    console.log('Domain check data:', data);
                    
                    if (data.available) {
                        let resultHtml = bocmDomainChecker.available_text;
                        console.log('Domain is available, price:', data.price);
                        
                        if (data.price) {
                            const buyButtonUrl = bocmDomainChecker.buy_button_url.replace('{domain}', encodeURIComponent(data.domain));
                            const buyButton = `<div class="bocm-domain-checker-buy-container">
                                <a href="${buyButtonUrl}" 
                                   class="bocm-domain-checker-buy-button" 
                                   target="_blank">
                                    ${bocmDomainChecker.buy_now_text} - ${data.price}
                                </a>
                            </div>`;
                            resultHtml += buyButton;
                            console.log('Generated HTML:', resultHtml);
                        }
                        showResult('available', resultHtml);
                    } else {
                        showResult('unavailable', bocmDomainChecker.unavailable_text);
                    }
                } else {
                    showResult('error', response.data.message || bocmDomainChecker.error_text);
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', {xhr, status, error});
                showResult('error', bocmDomainChecker.error_text);
            },
            complete: function() {
                button.prop('disabled', false);
            }
        });
    });

    function showResult(type, message) {
        console.log('Showing result:', {type, message});
        result
            .removeClass('available unavailable error loading')
            .addClass(type)
            .html(message)
            .show();
    }
}); 