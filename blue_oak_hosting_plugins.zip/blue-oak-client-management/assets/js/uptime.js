/**
 * Uptime Tab JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initUptimeTab();
});

/**
 * Initialize uptime tab functionality
 */
function initUptimeTab() {
    // Initialize tooltips for uptime bars
    initUptimeTooltips();
    
    // Initialize tooltips for SVG rectangles in 90-day chart
    initSvgRectTooltips();

    // Initialize incident modal functionality
    initIncidentModal();

    // Initialize response time chart if data is available
    if (window.responseData) {
        initResponseTimeChart();
    }
}

/**
 * Initialize tooltips for uptime bars
 */
function initUptimeTooltips() {
    const uptimeBars = document.querySelectorAll('.bocm-uptime-bar');
    const tooltip = document.createElement('div');
    tooltip.className = 'bocm-tooltip';
    document.body.appendChild(tooltip);

    uptimeBars.forEach(bar => {
        bar.addEventListener('mouseenter', function(e) {
            const date = this.dataset.date;
            const uptime = this.dataset.uptime;
            
            tooltip.innerHTML = `
                <div class="date">${date}</div>
                <div class="uptime">${uptime}% Uptime</div>
            `;
            tooltip.style.opacity = '1';
            
            const rect = this.getBoundingClientRect();
            tooltip.style.left = rect.left + (rect.width / 2) + 'px';
            tooltip.style.top = rect.top + 'px';
        });

        bar.addEventListener('mouseleave', function() {
            tooltip.style.opacity = '0';
        });
    });
}

/**
 * Initialize tooltips for SVG rectangles in 90-day chart
 */
function initSvgRectTooltips() {
    const svgRects = document.querySelectorAll('.bocm-90-days-chart svg rect');
    const tooltip = document.querySelector('.bocm-tooltip') || document.createElement('div');
    
    if (!document.querySelector('.bocm-tooltip')) {
        tooltip.className = 'bocm-tooltip';
        document.body.appendChild(tooltip);
    }

    svgRects.forEach(rect => {
        rect.addEventListener('mouseenter', function(e) {
            const tooltipData = JSON.parse(this.getAttribute('data-tooltip'));
            
            tooltip.innerHTML = `
                <div class="date">${tooltipData.date}</div>
                <div class="uptime">${tooltipData.uptime}</div>
            `;
            tooltip.style.opacity = '1';
            
            const rectPosition = this.getBoundingClientRect();
            tooltip.style.left = rectPosition.left + (rectPosition.width / 2) + 'px';
            tooltip.style.top = rectPosition.top + 'px';
        });

        rect.addEventListener('mouseleave', function() {
            tooltip.style.opacity = '0';
        });
    });
}

/**
 * Initialize incident modal functionality
 */
function initIncidentModal() {
    // Create modal elements if they don't exist
    if (!document.querySelector('.bocm-incident-modal')) {
        const modalOverlay = document.createElement('div');
        modalOverlay.className = 'bocm-modal-overlay';
        
        const modal = document.createElement('div');
        modal.className = 'bocm-incident-modal';
        
        const modalHeader = document.createElement('div');
        modalHeader.className = 'bocm-modal-header';
        
        const modalTitle = document.createElement('h3');
        modalTitle.className = 'bocm-modal-title';
        
        const closeButton = document.createElement('button');
        closeButton.className = 'bocm-modal-close';
        closeButton.innerHTML = '&times;';
        closeButton.addEventListener('click', function() {
            modalOverlay.style.display = 'none';
        });
        
        const modalContent = document.createElement('div');
        modalContent.className = 'bocm-modal-content';
        
        modalHeader.appendChild(modalTitle);
        modalHeader.appendChild(closeButton);
        modal.appendChild(modalHeader);
        modal.appendChild(modalContent);
        modalOverlay.appendChild(modal);
        document.body.appendChild(modalOverlay);
        
        // Close modal when clicking on overlay
        modalOverlay.addEventListener('click', function(e) {
            if (e.target === modalOverlay) {
                modalOverlay.style.display = 'none';
            }
        });
    }
    
    // Add click event to all incident count elements
    const incidentCounts = document.querySelectorAll('.bocm-incident-count');
    incidentCounts.forEach(count => {
        count.style.cursor = 'pointer';
        count.addEventListener('click', function() {
            const periodTitle = this.parentElement.querySelector('h3').textContent;
            const incidentCount = this.textContent.trim();
            
            // Get period type from the title
            let periodKey;
            if (periodTitle.includes('24 hours')) {
                periodKey = 'day';
            } else if (periodTitle.includes('7 days')) {
                periodKey = 'week';
            } else if (periodTitle.includes('30 days')) {
                periodKey = 'month';
            } else if (periodTitle.includes('90 days')) {
                periodKey = 'ninety_day';
            }
            
            // Display modal with incidents
            showIncidentModal(periodTitle, periodKey);
        });
    });
}

/**
 * Show incident modal with relevant incidents
 * 
 * @param {string} periodTitle The title of the period (e.g., "Last 24 hours")
 * @param {string} periodKey The key for the period data (day, week, month, ninety_day)
 */
function showIncidentModal(periodTitle, periodKey) {
    const modalOverlay = document.querySelector('.bocm-modal-overlay');
    const modalTitle = document.querySelector('.bocm-modal-title');
    const modalContent = document.querySelector('.bocm-modal-content');
    
    // Set modal title
    modalTitle.textContent = `Incidents - ${periodTitle}`;
    
    // Clear previous content
    modalContent.innerHTML = '';
    
    // Get incidents based on period
    let incidents;
    if (periodKey === 'day' && window.dayIncidents) {
        incidents = window.dayIncidents;
    } else if (periodKey === 'week' && window.weekIncidents) {
        incidents = window.weekIncidents;
    } else if (periodKey === 'month' && window.monthIncidents) {
        incidents = window.monthIncidents;
    } else if (periodKey === 'ninety_day' && window.ninetyDayIncidents) {
        incidents = window.ninetyDayIncidents;
    }
    
    // Add incidents to modal or display no incidents message
    if (incidents && incidents.length > 0) {
        const table = document.createElement('table');
        table.className = 'bocm-incident-table';
        
        // Create table header
        const thead = document.createElement('thead');
        thead.innerHTML = `
            <tr>
                <th>Date/Time</th>
                <th>Duration</th>
                <th>Reason</th>
            </tr>
        `;
        table.appendChild(thead);
        
        // Create table body
        const tbody = document.createElement('tbody');
        incidents.forEach(incident => {
            const tr = document.createElement('tr');
            
            // Format date
            const date = new Date(incident.datetime * 1000);
            const formattedDate = date.toLocaleString();
            
            // Format duration
            const duration = formatDuration(incident.duration);
            
            tr.innerHTML = `
                <td>${formattedDate}</td>
                <td>${duration}</td>
                <td>${incident.reason || 'Unknown'}</td>
            `;
            
            tbody.appendChild(tr);
        });
        
        table.appendChild(tbody);
        modalContent.appendChild(table);
    } else {
        modalContent.innerHTML = `<div class="bocm-no-incidents">🎆 No Incidents 🎆</div>`;
    }
    
    // Show modal
    modalOverlay.style.display = 'flex';
}

/**
 * Format duration in seconds to a human-readable string
 * 
 * @param {number} seconds Duration in seconds
 * @return {string} Formatted duration string
 */
function formatDuration(seconds) {
    if (!seconds) return 'N/A';
    
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const remainingSeconds = seconds % 60;
    
    if (hours > 0) {
        return `${hours}h ${minutes}m ${remainingSeconds}s`;
    } else if (minutes > 0) {
        return `${minutes}m ${remainingSeconds}s`;
    } else {
        return `${remainingSeconds}s`;
    }
}

/**
 * Initialize response time chart
 */
function initResponseTimeChart() {
    // Calculate average response time
    const avgResponseTime = window.responseData.times.reduce((a, b) => a + b, 0) / window.responseData.times.length;
    
    const options = {
        series: [{
            name: 'Response Time',
            data: window.responseData.times
        }],
        chart: {
            type: 'line',
            height: 200,
            toolbar: {
                show: false
            },
            animations: {
                enabled: true,
                easing: 'easeinout',
                speed: 800
            }
        },
        stroke: {
            width: 2,
            curve: 'smooth'
        },
        colors: ['#7e3ff2'],
        annotations: {
            yaxis: [
                {
                    y: Math.max(...window.responseData.times),
                    borderColor: '#EF4444',
                    label: {
                        text: 'Max',
                        style: {
                            color: '#EF4444',
                            background: '#FEE2E2'
                        }
                    }
                },
                {
                    y: avgResponseTime,
                    borderColor: '#3B82F6',
                    borderWidth: 1,
                    borderDash: [2, 2],
                    label: {
                        text: 'Average',
                        style: {
                            color: '#3B82F6',
                            background: '#EFF6FF'
                        }
                    }
                }
            ]
        },
        xaxis: {
            categories: window.responseData.labels,
            labels: {
                style: {
                    colors: '#64748B'
                }
            }
        },
        yaxis: {
            labels: {
                formatter: function(value) {
                    return value + 'ms';
                },
                style: {
                    colors: '#64748B'
                }
            }
        },
        grid: {
            borderColor: '#E2E8F0',
            strokeDashArray: 4
        },
        tooltip: {
            y: {
                formatter: function(value) {
                    return value + 'ms';
                }
            }
        }
    };

    const chart = new ApexCharts(document.querySelector('#responseTimeChart'), options);
    chart.render();
}