/**
 * Overview Tab JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initOverviewTab();
    initServicesSection();
    setupRequestButtons();
    enhanceDisabledServices();
    initPurchaseHistoryModal();
});

/**
 * Initialize overview tab functionality
 */
function initOverviewTab() {
    // Handle disabled buttons
    const disabledButtons = document.querySelectorAll('.bocm-action-button.disabled');
    disabledButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            return false;
        });
    });

    // Add hover effects for action buttons
    const actionButtons = document.querySelectorAll('.bocm-action-button:not(.disabled)');
    actionButtons.forEach(button => {
        button.addEventListener('mouseenter', function() {
            const icon = this.querySelector('.bocm-button-icon');
            const arrow = this.querySelector('.bocm-button-arrow');
            
            if (icon) {
                icon.style.background = '#7e3ff2';
                icon.style.color = '#ffffff';
            }
            
            if (arrow) {
                arrow.style.color = '#7e3ff2';
            }
        });

        button.addEventListener('mouseleave', function() {
            const icon = this.querySelector('.bocm-button-icon');
            const arrow = this.querySelector('.bocm-button-arrow');
            
            if (icon) {
                icon.style.background = '#f1f5f9';
                icon.style.color = '#7e3ff2';
            }
            
            if (arrow) {
                arrow.style.color = '#94a3b8';
            }
        });
    });

    // Add animation for score values
    const scoreValues = document.querySelectorAll('.bocm-score-value');
    scoreValues.forEach(value => {
        const finalValue = parseFloat(value.textContent);
        let currentValue = 0;
        const duration = 1000; // 1 second
        const steps = 60;
        const increment = finalValue / steps;
        const interval = duration / steps;

        const counter = setInterval(() => {
            currentValue += increment;
            if (currentValue >= finalValue) {
                value.textContent = Number.isInteger(finalValue) ? 
                    finalValue.toString() : 
                    finalValue.toFixed(2);
                clearInterval(counter);
            } else {
                value.textContent = Number.isInteger(finalValue) ? 
                    Math.round(currentValue).toString() : 
                    currentValue.toFixed(2);
            }
        }, interval);
    });
}

/**
 * Initialize services section functionality
 */
function initServicesSection() {
    const serviceItems = document.querySelectorAll('.bocm-service-item');
    
    serviceItems.forEach(item => {
        // Add subtle animation to the icons on hover
        item.addEventListener('mouseenter', function() {
            const icon = this.querySelector('.bocm-service-icon');
            if (icon && !this.classList.contains('disabled')) {
                icon.style.transform = 'scale(1.05)';
                icon.style.boxShadow = '0 6px 16px rgba(126, 63, 242, 0.35)';
            }
        });
        
        item.addEventListener('mouseleave', function() {
            const icon = this.querySelector('.bocm-service-icon');
            if (icon && !this.classList.contains('disabled')) {
                icon.style.transform = '';
                icon.style.boxShadow = '';
            }
        });
        
        // Add tooltips to disabled service items
        if (item.classList.contains('disabled')) {
            const serviceName = item.querySelector('.bocm-service-name').textContent.trim();
            item.setAttribute('title', serviceName + ' service is not currently active in your account');
        }
        
        // Add click handlers for service items with URLs
        const url = item.getAttribute('data-url');
        if (url && !item.classList.contains('disabled')) {
            item.style.cursor = 'pointer';
            
            // Add hover effect to indicate clickable
            const serviceName = item.querySelector('.bocm-service-name').textContent.trim();
            item.setAttribute('title', 'Click to open ' + serviceName + ' dashboard');
            
            // Handle click
            item.addEventListener('click', function() {
                window.open(url, '_blank');
            });
        }
    });
}

/**
 * Enhance the disabled services with upgrade functionality
 */
function enhanceDisabledServices() {
    const disabledServices = document.querySelectorAll('.bocm-service-item.disabled');
    
    disabledServices.forEach(service => {
        service.addEventListener('click', function(e) {
            // Only handle clicks on the service item, not on the upgrade button
            if (!e.target.closest('.bocm-service-upgrade')) {
                const upgradeBtn = this.querySelector('.bocm-service-upgrade');
                if (upgradeBtn) {
                    upgradeBtn.style.opacity = '1';
                    upgradeBtn.style.transform = 'translateY(0)';
                    
                    // Auto-hide the upgrade button after a delay
                    setTimeout(() => {
                        upgradeBtn.style.opacity = '';
                        upgradeBtn.style.transform = '';
                    }, 3000);
                }
            }
        });
    });
    
    // Handle the upgrade buttons clicks
    const upgradeButtons = document.querySelectorAll('.bocm-service-upgrade');
    upgradeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.stopPropagation(); // Prevent the service item click from firing
            
            // If the link uses a hash anchor, also change tabs programmatically
            const href = this.getAttribute('href');
            if (href && href.includes('#upgrade')) {
                // Find and click the upgrade tab
                const upgradeTab = document.querySelector('.bocm-tab[href="#upgrade"]');
                if (upgradeTab) {
                    upgradeTab.click();
                }
            }
        });
    });
}

/**
 * Set up request buttons functionality
 */
function setupRequestButtons() {
    const requestUptimeButton = document.getElementById('request-uptime-monitor');
    if (requestUptimeButton) {
        requestUptimeButton.addEventListener('click', function(e) {
            e.preventDefault();
            
            // Show confirmation message
            const confirmMessage = document.createElement('div');
            confirmMessage.className = 'bocm-confirmation-message';
            confirmMessage.textContent = 'Setup request sent! Our team will contact you shortly.';
            
            // Add confirmation message to the parent container
            const parent = this.parentNode;
            this.style.display = 'none';
            parent.appendChild(confirmMessage);
            
            // Send AJAX request to backend (implement this when backend is ready)
            // For now, this is just a UI demo
            console.log('Uptime monitor setup requested');
            
            return false;
        });
    }
}

/**
 * Initialize purchase history modal functionality
 * This handles both the jQuery and vanilla JS approach for maximum compatibility
 */
function initPurchaseHistoryModal() {
    const modal = document.getElementById('bocm-purchase-modal');
    const btn = document.getElementById('bocm-purchase-history-btn');
    const closeBtn = document.querySelector('.bocm-modal-close');
    
    if (!modal || !btn) {
        console.error('Purchase history modal elements not found');
        return;
    }

    // Open modal when button is clicked
    btn.addEventListener('click', function() {
        // Using vanilla JS
        modal.style.display = 'block';
        
        // Animate the modal with a fade effect
        setTimeout(function() {
            modal.style.opacity = '1';
        }, 10);
        
        // Animate table rows
        const rows = modal.querySelectorAll('.bocm-purchases-table tbody tr');
        rows.forEach((row, index) => {
            row.style.opacity = '0';
            row.style.transform = 'translateY(20px)';
            
            setTimeout(function() {
                row.style.opacity = '1';
                row.style.transform = 'translateY(0)';
            }, index * 50);
        });
    });
    
    // Close modal when the x is clicked
    if (closeBtn) {
        closeBtn.addEventListener('click', function() {
            modal.style.opacity = '0';
            setTimeout(function() {
                modal.style.display = 'none';
            }, 300); // Wait for fade out animation
        });
    }
    
    // Close modal when clicking outside of it
    window.addEventListener('click', function(event) {
        if (event.target === modal) {
            modal.style.opacity = '0';
            setTimeout(function() {
                modal.style.display = 'none';
            }, 300); // Wait for fade out animation
        }
    });
    
    // Store original SKU as data attribute for tooltips
    const purchaseRows = document.querySelectorAll('.bocm-purchases-table tbody tr');
    purchaseRows.forEach(row => {
        const sku = row.getAttribute('data-sku');
        const productCell = row.querySelector('td:first-child');
        
        if (sku && productCell && productCell.textContent !== sku) {
            productCell.setAttribute('title', 'SKU: ' + sku);
        }
    });
} 