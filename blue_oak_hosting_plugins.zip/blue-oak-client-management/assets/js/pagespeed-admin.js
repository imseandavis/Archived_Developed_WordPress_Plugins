/**
 * PageSpeed Admin JavaScript
 */
(function($) {
    'use strict';

    $(document).ready(function() {
        // Add overlay element to the page
        $('body').append(`
            <div class="bocm-scan-overlay">
                <div class="bocm-scan-overlay-content">
                    <div class="bocm-scan-overlay-spinner">
                        <span class="spinner-inline"></span>
                    </div>
                    <div class="bocm-scan-overlay-text">
                        Scanning website performance...
                    </div>
                </div>
            </div>
        `);

        const $overlay = $('.bocm-scan-overlay');
        
        // Show overlay when scanning
        function showScanningOverlay(message) {
            $('.bocm-scan-overlay-text').text(message || 'Scanning website performance...');
            $overlay.addClass('scanning');
        }
        
        // Hide overlay when done
        function hideScanningOverlay() {
            $overlay.removeClass('scanning');
        }

        // Run scan for individual client
        $('.run-scan').on('click', function() {
            const button = $(this);
            const statusSpan = button.next('.scan-status');
            const userId = button.data('user-id');
            const url = button.data('url');
            const row = button.closest('tr');
            
            // Disable the button and show status
            button.prop('disabled', true);
            statusSpan.html('<span class="spinner-inline"></span><span class="status-running">' + bocmPageSpeed.running + '</span>');
            
            // Show the overlay notification
            showScanningOverlay('Scanning ' + url);
            
            // Make AJAX request to run scan
            $.ajax({
                url: bocmPageSpeed.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'bocm_run_pagespeed_scan',
                    nonce: bocmPageSpeed.nonce,
                    user_id: userId,
                    url: url
                },
                success: function(response) {
                    // Hide overlay
                    hideScanningOverlay();
                    
                    if (response.success) {
                        // Update status
                        statusSpan.html('<span class="status-success">' + bocmPageSpeed.success + '</span>');
                        
                        // Update row data
                        row.find('td:eq(2)').text(response.data.last_scan);
                        
                        const scoreCell = row.find('td:eq(3)');
                        scoreCell.text(response.data.score);
                        
                        // Update score class
                        scoreCell.removeClass('score-excellent score-good score-average score-poor');
                        if (response.data.score >= 90) {
                            scoreCell.addClass('score-excellent');
                        } else if (response.data.score >= 70) {
                            scoreCell.addClass('score-good');
                        } else if (response.data.score >= 50) {
                            scoreCell.addClass('score-average');
                        } else {
                            scoreCell.addClass('score-poor');
                        }
                        
                        row.find('td:eq(4)').text(response.data.page_size);
                        row.find('td:eq(5)').text(response.data.fcp);
                        row.find('td:eq(6)').text(response.data.lcp);
                        
                        // Highlight the row briefly to show it's been updated
                        row.css('background-color', 'rgba(70, 180, 80, 0.1)');
                        setTimeout(function() {
                            row.css('background-color', '');
                        }, 2000);
                        
                        // Re-enable button after 2 seconds
                        setTimeout(function() {
                            button.prop('disabled', false);
                            statusSpan.empty();
                        }, 2000);
                    } else {
                        // Show error
                        statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                        
                        // Re-enable button after 2 seconds
                        setTimeout(function() {
                            button.prop('disabled', false);
                            statusSpan.empty();
                        }, 2000);
                    }
                },
                error: function() {
                    // Hide overlay
                    hideScanningOverlay();
                    
                    // Show error
                    statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                    
                    // Re-enable button after 2 seconds
                    setTimeout(function() {
                        button.prop('disabled', false);
                        statusSpan.empty();
                    }, 2000);
                }
            });
        });
        
        // Run all scans
        $('.run-all-scans').on('click', function() {
            const button = $(this);
            const statusSpan = $('.all-scans-status');
            
            // Disable the button and show status
            button.prop('disabled', true);
            statusSpan.html('<span class="spinner-inline"></span><span class="status-running">' + bocmPageSpeed.running + '</span>');
            
            // Show the overlay notification
            showScanningOverlay('Running scans for all websites. This may take a while...');
            
            // Make AJAX request to run all scans
            $.ajax({
                url: bocmPageSpeed.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'bocm_run_pagespeed_scan',
                    nonce: bocmPageSpeed.nonce,
                    run_all: true
                },
                success: function(response) {
                    // Hide overlay
                    hideScanningOverlay();
                    
                    if (response.success) {
                        // Update status
                        statusSpan.html('<span class="status-success">' + response.data.message + '</span>');
                        
                        // Show a notification that page will refresh
                        showScanningOverlay('Scans completed! Page will refresh in 3 seconds...');
                        
                        // Reload the page after a short delay to show updated results
                        setTimeout(function() {
                            location.reload();
                        }, 3000);
                    } else {
                        // Show error
                        statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                        
                        // Re-enable button after 2 seconds
                        setTimeout(function() {
                            button.prop('disabled', false);
                            statusSpan.empty();
                        }, 2000);
                    }
                },
                error: function() {
                    // Hide overlay
                    hideScanningOverlay();
                    
                    // Show error
                    statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                    
                    // Re-enable button after 2 seconds
                    setTimeout(function() {
                        button.prop('disabled', false);
                        statusSpan.empty();
                    }, 2000);
                }
            });
        });
        
        // Schedule scans now
        $('.schedule-now').on('click', function() {
            const button = $(this);
            const statusSpan = $('.schedule-status');
            
            // Disable the button and show status
            button.prop('disabled', true);
            statusSpan.html('<span class="spinner-inline"></span><span class="status-running">' + bocmPageSpeed.running + '</span>');
            
            // Make AJAX request to schedule scans
            $.ajax({
                url: bocmPageSpeed.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'bocm_run_pagespeed_scan',
                    nonce: bocmPageSpeed.nonce,
                    run_all: true
                },
                success: function(response) {
                    if (response.success) {
                        // Update status
                        statusSpan.html('<span class="status-success">' + response.data.message + '</span>');
                        
                        // Refresh the page after 2 seconds to show the updated schedule
                        setTimeout(function() {
                            location.reload();
                        }, 2000);
                    } else {
                        // Show error
                        statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                        
                        // Re-enable button after 2 seconds
                        setTimeout(function() {
                            button.prop('disabled', false);
                            statusSpan.empty();
                        }, 2000);
                    }
                },
                error: function() {
                    // Show error
                    statusSpan.html('<span class="status-error">' + bocmPageSpeed.error + '</span>');
                    
                    // Re-enable button after 2 seconds
                    setTimeout(function() {
                        button.prop('disabled', false);
                        statusSpan.empty();
                    }, 2000);
                }
            });
        });
    });
})(jQuery); 