/**
 * Common Portal JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initPortal();
});

/**
 * Initialize common portal functionality
 */
function initPortal() {
    // Handle tab navigation
    const tabs = document.querySelectorAll('.bocm-tab');
    tabs.forEach(tab => {
        tab.addEventListener('click', function(e) {
            // Remove active class from all tabs
            tabs.forEach(t => t.classList.remove('active'));
            // Add active class to clicked tab
            this.classList.add('active');
        });
    });

    // Add any other common portal functionality here
} 