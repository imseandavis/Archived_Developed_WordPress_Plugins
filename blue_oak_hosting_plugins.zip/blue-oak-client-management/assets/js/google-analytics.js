/**
 * Google Analytics Tab JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initGoogleAnalyticsTab();
});

/**
 * Initialize Google Analytics tab functionality
 */
function initGoogleAnalyticsTab() {
    // Check if analytics data is available
    const analyticsData = window.analyticsData || null;
    
    // Check if there's an error in the analytics data
    if (analyticsData && analyticsData.error) {
        console.error('Google Analytics data error:', analyticsData.error);
        displayErrorMessage(analyticsData.error);
        return;
    }
    
    // Update summary metrics
    updateSummaryMetrics(analyticsData);
    
    // Initialize user types chart
    initUserTypesChart(analyticsData);
    
    // Initialize device category chart
    initDeviceCategoryChart(analyticsData);
    
    // Initialize top countries chart
    initTopCountriesChart(analyticsData);
    
    // Initialize countries map chart
    initCountriesMapChart(analyticsData);
    
    // Initialize operating system chart
    initOperatingSystemChart(analyticsData);
    
    // Initialize browser chart
    initBrowserChart(analyticsData);
    
    // Initialize trends chart
    initTrendsChart(analyticsData);
    
    // Update tables with data
    updateTablesWithData(analyticsData);
    
    // Handle chart type changes
    const chartTypeButtons = document.querySelectorAll('.bocm-chart-type');
    chartTypeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const chartType = this.dataset.type;
            const chartContainer = this.closest('.bocm-portal-card').querySelector('.bocm-chart-container');
            
            // Update active state
            this.closest('.bocm-card-actions').querySelectorAll('.bocm-chart-type').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');

            // Update chart type if we have the chart object stored
            if (chartContainer.id === 'trendsChart' && window.trendsChart) {
                window.trendsChart.updateOptions({
                    chart: {
                        type: chartType
                    }
                });
                
                // Additional options specific to chart type
                if (chartType === 'line') {
                    window.trendsChart.updateOptions({
                        stroke: {
                            curve: 'smooth',
                            width: 3
                        },
                        markers: {
                            size: 4
                        }
                    });
                } else {
                    window.trendsChart.updateOptions({
                        stroke: {
                            width: 0
                        },
                        markers: {
                            size: 0
                        }
                    });
                }
                
                // Force redraw the chart after changing type
                setTimeout(() => {
                    window.trendsChart.render();
                }, 100);
            }
        });
    });

    // Handle global date range changes
    const globalDateRangeSelector = document.querySelector('#bocmGlobalDateRange');
    const updateAnalyticsButton = document.querySelector('#bocmUpdateAnalytics');
    
    if (globalDateRangeSelector) {
        // Set initial value to match the default PHP value (30 days)
        globalDateRangeSelector.value = '30';
        
        // Add change event listener to automatically update data
        globalDateRangeSelector.addEventListener('change', function() {
            const days = parseInt(this.value);
            
            // Show loading state in the selector
            const originalText = this.options[this.selectedIndex].text;
            this.options[this.selectedIndex].text = 'Loading...';
            this.disabled = true;
            
            // Make AJAX request to get new data
            fetchAnalyticsData(days).then(response => {
                if (response.success) {
                    // Update global analytics data
                    window.analyticsData = response.data;
                    
                    // Refresh all charts and tables
                    updateSummaryMetrics(response.data);
                    initUserTypesChart(response.data);
                    initDeviceCategoryChart(response.data);
                    initTopCountriesChart(response.data);
                    initCountriesMapChart(response.data);
                    initOperatingSystemChart(response.data);
                    initBrowserChart(response.data);
                    initTrendsChart(response.data);
                    updateTablesWithData(response.data);
                    
                    // Update the trends chart select to match the global one
                    const trendsDateRange = document.querySelector('#analyticsPerformanceRange');
                    if (trendsDateRange) {
                        // Find the closest option value
                        const options = Array.from(trendsDateRange.options).map(opt => parseInt(opt.value));
                        const closestValue = options.reduce((prev, curr) => 
                            Math.abs(curr - days) < Math.abs(prev - days) ? curr : prev
                        );
                        trendsDateRange.value = closestValue;
                    }
                    
                    // Show success notification
                    showNotification('Analytics data updated successfully for the last ' + days + ' days.', 'success');
                } else {
                    // Show error notification
                    showNotification('Error updating analytics data: ' + (response.message || 'Unknown error'), 'error');
                }
            }).catch(error => {
                console.error('Error fetching analytics data:', error);
                showNotification('Failed to update analytics data. Please try again.', 'error');
            }).finally(() => {
                // Reset selector
                this.options[this.selectedIndex].text = originalText;
                this.disabled = false;
            });
        });
    }

    // Hide the update button since we're auto-updating now
    if (updateAnalyticsButton) {
        updateAnalyticsButton.style.display = 'none';
    }

    // Handle original trends date range changes (this now only affects the trends chart)
    const dateRangeSelector = document.querySelector('#analyticsPerformanceRange');
    if (dateRangeSelector) {
        dateRangeSelector.addEventListener('change', (e) => {
            // Only update this specific chart, not the global data
            const days = parseInt(e.target.value);
            
            if (window.trendsChart) {
                window.trendsChart.updateOptions({
                    title: {
                        text: `Last ${days} ${days === 1 ? 'Day' : 'Days'}`
                    }
                });
            }
            
            // We could fetch data just for this chart if needed
            // For now, just show a message
            console.log('Trends chart date range changed to:', days);
        });
    }

    // Remove shimmer effect from tables and cards after data loads
    setTimeout(() => {
        document.querySelectorAll('.bocm-analytics-metric-card, .bocm-chart-container, .bocm-events-table, .bocm-landing-pages-table, .bocm-top-pages-table').forEach(element => {
            element.classList.remove('shimmer');
        });
    }, 1000);
}

/**
 * Fetch analytics data via AJAX
 * 
 * @param {number} days Number of days to fetch data for
 * @returns {Promise} Promise that resolves with the response
 */
function fetchAnalyticsData(days) {
    return new Promise((resolve, reject) => {
        // Create form data
        const formData = new FormData();
        formData.append('action', 'bocm_fetch_analytics_data');
        formData.append('days', days);
        formData.append('nonce', bocmData.nonce); // Assuming nonce is available in global object
        
        // Make AJAX request
        fetch(bocmData.ajax_url, {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        })
        .then(response => response.json())
        .then(resolve)
        .catch(reject);
    });
}

/**
 * Display a notification to the user
 * 
 * @param {string} message The notification message
 * @param {string} type The notification type (success, error, warning, info)
 */
function showNotification(message, type = 'info') {
    // Check if notification container exists, create if not
    let container = document.querySelector('.bocm-notifications');
    if (!container) {
        container = document.createElement('div');
        container.className = 'bocm-notifications';
        document.body.appendChild(container);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `bocm-notification bocm-notification-${type}`;
    notification.innerHTML = `
        <div class="bocm-notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="bocm-notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Add notification to container
    container.appendChild(notification);
    
    // Add close button functionality
    notification.querySelector('.bocm-notification-close').addEventListener('click', function() {
        notification.classList.add('bocm-notification-hiding');
        setTimeout(() => {
            container.removeChild(notification);
            if (container.children.length === 0) {
                document.body.removeChild(container);
            }
        }, 300);
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.add('bocm-notification-hiding');
            setTimeout(() => {
                if (notification.parentNode) {
                    container.removeChild(notification);
                    if (container.children.length === 0) {
                        document.body.removeChild(container);
                    }
                }
            }, 300);
        }
    }, 5000);
}

/**
 * Display an error message in the dashboard
 */
function displayErrorMessage(errorMessage) {
    // Create a UI element to display the error
    const tabContent = document.querySelector('.bocm-tab-content');
    if (!tabContent) return;
    
    // Clear existing content
    tabContent.innerHTML = '';
    
    // Create error card
    const errorCard = document.createElement('div');
    errorCard.className = 'bocm-portal-card';
    errorCard.innerHTML = `
        <div class="bocm-card-header">
            <h3>Google Analytics Error</h3>
        </div>
        <div class="bocm-card-content">
            <p>There was an error loading your Google Analytics data:</p>
            <p><strong>${errorMessage}</strong></p>
            <p>Please try refreshing the page or contact your administrator if the issue persists.</p>
        </div>
    `;
    
    // Add the error card to the tab content
    tabContent.appendChild(errorCard);
}

/**
 * Update summary metrics with real data
 */
function updateSummaryMetrics(analyticsData) {
    if (!analyticsData || !analyticsData.summary) {
        return;
    }
    
    const summary = analyticsData.summary;
    
    // Update active users - target by icon/label
    const activeUsersCard = document.querySelector('.bocm-analytics-metric-card .bocm-analytics-metric-icon i.fa-users');
    if (activeUsersCard && summary.active_users) {
        const card = activeUsersCard.closest('.bocm-analytics-metric-card');
        const valueEl = card.querySelector('.bocm-analytics-metric-value');
        const changeEl = card.querySelector('.bocm-analytics-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.active_users.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = Math.abs(summary.active_users.change).toFixed(1) + '%';
            
            if (summary.active_users.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
    }
    
    // Update session duration - target by icon/label
    const durationCard = document.querySelector('.bocm-analytics-metric-card .bocm-analytics-metric-icon i.fa-clock');
    if (durationCard && summary.avg_session_duration) {
        const card = durationCard.closest('.bocm-analytics-metric-card');
        const valueEl = card.querySelector('.bocm-analytics-metric-value');
        const changeEl = card.querySelector('.bocm-analytics-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.avg_session_duration.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = summary.avg_session_duration.change + '%';
            
            if (summary.avg_session_duration.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
    }
    
    // Update bounce rate - target by icon/label
    const bounceRateCard = document.querySelector('.bocm-analytics-metric-card .bocm-analytics-metric-icon i.fa-percent');
    if (bounceRateCard && summary.bounce_rate) {
        const card = bounceRateCard.closest('.bocm-analytics-metric-card');
        const valueEl = card.querySelector('.bocm-analytics-metric-value');
        const changeEl = card.querySelector('.bocm-analytics-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.bounce_rate.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = summary.bounce_rate.change + '%';
            
            // For bounce rate, lower is better
            if (summary.bounce_rate.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            }
        }
    }
    
    // Update pages per session - target by icon/label
    const pagesPerSessionCard = document.querySelector('.bocm-analytics-metric-card .bocm-analytics-metric-icon i.fa-eye');
    if (pagesPerSessionCard && summary.pages_per_session) {
        const card = pagesPerSessionCard.closest('.bocm-analytics-metric-card');
        const valueEl = card.querySelector('.bocm-analytics-metric-value');
        const changeEl = card.querySelector('.bocm-analytics-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.pages_per_session.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = summary.pages_per_session.change;
            
            if (summary.pages_per_session.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
    }
}

/**
 * Initialize device category chart with real data
 */
function initDeviceCategoryChart(analyticsData) {
    const deviceCategoryChartEl = document.querySelector('#deviceCategoryChart');
    if (!deviceCategoryChartEl) {
        return;
    }
    
    // Use default data if no real data available
    let series = [96, 4];
    let labels = ['Desktop', 'Mobile'];
    
    if (analyticsData && analyticsData.device_categories) {
        const deviceData = analyticsData.device_categories;
        if (deviceData.series.length > 0 && deviceData.labels.length > 0) {
            series = deviceData.series;
            labels = deviceData.labels;
        }
    }
    
    const deviceCategoryChart = new ApexCharts(deviceCategoryChartEl, {
        series: series,
        chart: {
            type: 'donut',
            height: 350
        },
        labels: labels,
        colors: ['#7e3ff2', '#64748b', '#cbd5e0'],
        legend: {
            position: 'bottom'
        },
        plotOptions: {
            pie: {
                donut: {
                    size: '65%',
                    labels: {
                        show: true,
                        name: {
                            show: true
                        },
                        value: {
                            show: true,
                            formatter: function(val) {
                                return val;
                            }
                        },
                        total: {
                            show: true,
                            label: 'Total',
                            formatter: function(w) {
                                return w.globals.seriesTotals.reduce((a, b) => a + b, 0);
                            }
                        }
                    }
                }
            }
        }
    });
    
    deviceCategoryChart.render();
    window.deviceCategoryChart = deviceCategoryChart;
}

/**
 * Initialize top countries chart with real data
 */
function initTopCountriesChart(analyticsData) {
    const topCountriesChartEl = document.querySelector('#topCountriesChart');
    if (!topCountriesChartEl) {
        return;
    }
    
    // Use default data if no real data available
    let data = [780, 420, 260, 180];
    let categories = ['United States', 'India', 'Mexico', 'Philippines'];
    
    if (analyticsData && analyticsData.countries) {
        const countriesData = analyticsData.countries;
        if (countriesData.data.length > 0 && countriesData.categories.length > 0) {
            data = countriesData.data;
            categories = countriesData.categories;
        }
    }
    
    const topCountriesChart = new ApexCharts(topCountriesChartEl, {
        series: [{
            name: 'Active Users',
            data: data
        }],
        chart: {
            type: 'bar',
            height: 350,
            toolbar: {
                show: false
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                borderRadius: 4
            }
        },
        colors: ['#7e3ff2'],
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        }
    });
    
    topCountriesChart.render();
    window.topCountriesChart = topCountriesChart;
}

/**
 * Initialize countries map chart with real data
 */
function initCountriesMapChart(analyticsData) {
    const countriesMapChartEl = document.querySelector('#countriesMapChart');
    if (!countriesMapChartEl) {
        return;
    }
    
    // Default map data if no real data available
    let data = [
        { name: 'United States', value: 68, code: 'US' },
        { name: 'India', value: 1, code: 'IN' }
    ];
    
    // Create data for the map from the countries data
    if (analyticsData && analyticsData.countries) {
        const countriesData = analyticsData.countries;
        if (countriesData.categories.length > 0 && countriesData.data.length > 0) {
            data = countriesData.categories.map((country, index) => {
                return {
                    name: country,
                    value: countriesData.data[index],
                    code: getCountryCode(country)
                };
            });
        }
    }
    
    // Clear the container first
    countriesMapChartEl.innerHTML = '';
    countriesMapChartEl.classList.remove('shimmer');
    
    // Create interactive map container
    const mapContainer = document.createElement('div');
    mapContainer.className = 'bocm-map-container';
    countriesMapChartEl.appendChild(mapContainer);
    
    // Create data table
    const dataTable = document.createElement('div');
    dataTable.className = 'bocm-map-data-table';
    dataTable.innerHTML = `
        <table class="countries-data-table">
            <thead>
                <tr>
                    <th><?php _e('Country', 'blue-oak-client-management'); ?></th>
                    <th><?php _e('Active Users', 'blue-oak-client-management'); ?></th>
                </tr>
            </thead>
            <tbody>
                ${data.map(item => `
                    <tr data-country="${item.code}">
                        <td><span class="country-flag flag-icon flag-icon-${item.code.toLowerCase()}"></span> ${item.name}</td>
                        <td>${item.value}</td>
                    </tr>
                `).join('')}
            </tbody>
        </table>
    `;
    countriesMapChartEl.appendChild(dataTable);
    
    // Load the world map with interactive features
    const mapOptions = {
        element: mapContainer,
        responsive: true,
        geographyConfig: {
            highlightBorderColor: '#7e3ff2',
            highlightFillColor: '#9e72f4',
            popupTemplate: (geography, data) => {
                return `<div class="bocm-map-tooltip">
                    <strong>${geography.properties.name}</strong><br>
                    ${data ? data.value + ' active users' : 'No data available'}
                </div>`;
            },
            highlightBorderWidth: 1.5
        },
        fills: {
            defaultFill: '#e2e8f0',
            HIGH: '#7e3ff2',
            MEDIUM: '#9e72f4',
            LOW: '#bfa5f7',
            NONE: '#f8fafc'
        },
        data: {}
    };
    
    // Create a map highlighting data for countries
    data.forEach(item => {
        let fillKey = 'NONE';
        if (item.value > 0) {
            if (item.value > 50) fillKey = 'HIGH';
            else if (item.value > 10) fillKey = 'MEDIUM';
            else fillKey = 'LOW';
        }
        
        if (item.code) {
            mapOptions.data[item.code] = {
                fillKey: fillKey,
                value: item.value
            };
        }
    });
    
    // Add CSS for the world map display
    if (!document.querySelector('style#world-map-styles')) {
        const mapStyles = document.createElement('style');
        mapStyles.id = 'world-map-styles';
        mapStyles.textContent = `
            .bocm-map-container {
                position: relative;
                width: 100%;
                height: 300px;
                margin-bottom: 20px;
                background-color: #f8fafc;
                border-radius: 8px;
                overflow: hidden;
            }
            .bocm-map-data-table {
                margin-top: 10px;
            }
            .countries-data-table {
                width: 100%;
                border-collapse: collapse;
            }
            .countries-data-table th,
            .countries-data-table td {
                padding: 8px 12px;
                text-align: left;
                border-bottom: 1px solid #e2e8f0;
            }
            .countries-data-table th {
                font-weight: 500;
                color: #4a5568;
                background: #f8fafc;
            }
            .countries-data-table td {
                color: #2d3748;
            }
            .countries-data-table tr:hover {
                background-color: #f7fafc;
                cursor: pointer;
            }
            .bocm-map-tooltip {
                background-color: white;
                border-radius: 4px;
                padding: 5px 10px;
                box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
                font-size: 12px;
            }
            .country-flag {
                display: inline-block;
                width: 16px;
                height: 12px;
                margin-right: 6px;
                vertical-align: middle;
                background-size: cover;
            }
        `;
        document.head.appendChild(mapStyles);
    }
    
    // Use a map image as a simple solution
    const worldMap = document.createElement('img');
    worldMap.src = 'https://upload.wikimedia.org/wikipedia/commons/thumb/e/e4/BlankMap-World.svg/1280px-BlankMap-World.svg.png';
    worldMap.alt = 'World Map';
    worldMap.className = 'bocm-world-map-img';
    worldMap.style.cssText = 'width: 100%; height: 100%; object-fit: cover; opacity: 0.8;';
    mapContainer.appendChild(worldMap);
    
    // Add interactive country markers
    data.forEach(country => {
        if (country.value > 0) {
            const marker = document.createElement('div');
            marker.className = 'bocm-country-marker';
            marker.setAttribute('data-country', country.code);
            marker.setAttribute('title', `${country.name}: ${country.value} users`);
            
            // Size based on value
            const size = Math.max(10, Math.min(30, 10 + (country.value / 10)));
            
            marker.style.cssText = `
                position: absolute;
                width: ${size}px;
                height: ${size}px;
                background-color: #7e3ff2;
                border-radius: 50%;
                opacity: 0.7;
                transform: translate(-50%, -50%);
                z-index: 2;
                cursor: pointer;
                box-shadow: 0 0 0 2px white;
            `;
            
            // Set position based on country code
            const position = getCountryPosition(country.code);
            if (position) {
                marker.style.left = position.x + '%';
                marker.style.top = position.y + '%';
                mapContainer.appendChild(marker);
                
                // Add hover effect
                marker.addEventListener('mouseenter', () => {
                    marker.style.opacity = '1';
                    marker.style.boxShadow = '0 0 0 3px white, 0 0 10px rgba(0,0,0,0.5)';
                    
                    // Highlight corresponding table row
                    const tableRow = dataTable.querySelector(`tr[data-country="${country.code}"]`);
                    if (tableRow) tableRow.style.backgroundColor = '#EBF4FF';
                });
                
                marker.addEventListener('mouseleave', () => {
                    marker.style.opacity = '0.7';
                    marker.style.boxShadow = '0 0 0 2px white';
                    
                    // Remove highlight from table row
                    const tableRow = dataTable.querySelector(`tr[data-country="${country.code}"]`);
                    if (tableRow) tableRow.style.backgroundColor = '';
                });
            }
        }
    });
}

/**
 * Get ISO country code from country name
 */
function getCountryCode(countryName) {
    const countryCodes = {
        'United States': 'US',
        'India': 'IN',
        'Mexico': 'MX',
        'Canada': 'CA',
        'United Kingdom': 'GB',
        'Australia': 'AU',
        'Germany': 'DE',
        'France': 'FR',
        'Brazil': 'BR',
        'Japan': 'JP',
        'China': 'CN',
        'Russia': 'RU',
        'Italy': 'IT',
        'Spain': 'ES',
        'South Korea': 'KR',
        'Netherlands': 'NL',
        'Philippines': 'PH',
        'Indonesia': 'ID',
        'Singapore': 'SG',
        'Thailand': 'TH',
        'Malaysia': 'MY',
        'Vietnam': 'VN',
        'New Zealand': 'NZ',
        'Ireland': 'IE',
        'Sweden': 'SE',
        'Norway': 'NO',
        'Denmark': 'DK',
        'Finland': 'FI',
        'Poland': 'PL',
        'Switzerland': 'CH',
        'Belgium': 'BE',
        'Austria': 'AT',
        'Turkey': 'TR',
        'Saudi Arabia': 'SA',
        'United Arab Emirates': 'AE',
        'South Africa': 'ZA',
        'Israel': 'IL',
        'Argentina': 'AR',
        'Chile': 'CL',
        'Colombia': 'CO',
        'Peru': 'PE',
        'Egypt': 'EG',
        'Nigeria': 'NG',
        'Kenya': 'KE',
        'Morocco': 'MA',
        'Ghana': 'GH',
        'Pakistan': 'PK',
        'Bangladesh': 'BD',
        'Sri Lanka': 'LK',
        'Nepal': 'NP'
    };
    
    return countryCodes[countryName] || 'UN'; // UN for unknown
}

/**
 * Get approximate map position for a country
 */
function getCountryPosition(countryCode) {
    const positions = {
        'US': { x: 18, y: 40 },
        'IN': { x: 65, y: 50 },
        'MX': { x: 15, y: 47 },
        'CA': { x: 18, y: 30 },
        'GB': { x: 45, y: 30 },
        'AU': { x: 80, y: 70 },
        'DE': { x: 48, y: 32 },
        'FR': { x: 46, y: 35 },
        'BR': { x: 30, y: 65 },
        'JP': { x: 82, y: 40 },
        'CN': { x: 75, y: 42 },
        'RU': { x: 60, y: 30 },
        'IT': { x: 49, y: 38 },
        'ES': { x: 44, y: 38 },
        'KR': { x: 80, y: 43 },
        'NL': { x: 47, y: 31 },
        'PH': { x: 78, y: 50 },
        'ID': { x: 75, y: 58 },
        'SG': { x: 74, y: 55 },
        'TH': { x: 74, y: 50 },
        'MY': { x: 74, y: 53 },
        'VN': { x: 76, y: 48 },
        'NZ': { x: 90, y: 75 },
        'IE': { x: 42, y: 30 },
        'SE': { x: 50, y: 25 },
        'NO': { x: 48, y: 23 },
        'DK': { x: 48, y: 28 },
        'FI': { x: 53, y: 25 },
        'PL': { x: 52, y: 30 },
        'CH': { x: 47, y: 34 },
        'BE': { x: 46, y: 32 },
        'AT': { x: 49, y: 33 },
        'TR': { x: 55, y: 38 },
        'SA': { x: 58, y: 45 },
        'AE': { x: 60, y: 46 },
        'ZA': { x: 52, y: 70 },
        'IL': { x: 55, y: 42 },
        'AR': { x: 28, y: 75 },
        'CL': { x: 25, y: 70 },
        'CO': { x: 23, y: 53 },
        'PE': { x: 22, y: 60 },
        'EG': { x: 53, y: 45 },
        'NG': { x: 46, y: 52 },
        'KE': { x: 55, y: 55 },
        'MA': { x: 43, y: 42 },
        'GH': { x: 45, y: 52 },
        'PK': { x: 63, y: 45 },
        'BD': { x: 68, y: 48 },
        'LK': { x: 68, y: 54 },
        'NP': { x: 67, y: 46 }
    };
    
    return positions[countryCode] || null;
}

/**
 * Initialize operating system chart with real data
 */
function initOperatingSystemChart(analyticsData) {
    const osChartEl = document.querySelector('#osChart');
    if (!osChartEl) {
        return;
    }
    
    // Use default data if no real data available
    let data = [650, 320, 180, 90];
    let categories = ['Windows', 'Chrome OS', 'Macintosh', 'iOS'];
    
    if (analyticsData && analyticsData.operating_systems) {
        const osData = analyticsData.operating_systems;
        if (osData.data.length > 0 && osData.categories.length > 0) {
            data = osData.data;
            categories = osData.categories;
        }
    }
    
    const osChart = new ApexCharts(osChartEl, {
        series: [{
            name: 'Active Users',
            data: data
        }],
        chart: {
            type: 'bar',
            height: 350,
            toolbar: {
                show: false
            }
        },
        plotOptions: {
            bar: {
                horizontal: true,
                borderRadius: 4
            }
        },
        colors: ['#7e3ff2'],
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        }
    });
    
    osChart.render();
    window.osChart = osChart;
}

/**
 * Initialize browser chart with real data
 */
function initBrowserChart(analyticsData) {
    const browserChartEl = document.querySelector('#browserChart');
    if (!browserChartEl) {
        return;
    }
    
    // Default browser data
    let series = [
        {
            name: 'Chrome',
            data: [580, 600, 570, 620, 610, 640, 650]
        }, 
        {
            name: 'Edge',
            data: [220, 230, 210, 240, 230, 250, 260]
        }, 
        {
            name: 'Safari',
            data: [140, 150, 130, 160, 150, 170, 180]
        }
    ];
    let categories = ['Mar 15', 'Mar 16', 'Mar 17', 'Mar 18', 'Mar 19', 'Mar 20', 'Mar 21'];
    
    if (analyticsData && analyticsData.browsers) {
        const browserData = analyticsData.browsers;
        if (browserData.series.length > 0 && browserData.categories.length > 0) {
            series = browserData.series;
            categories = browserData.categories;
        }
    }
    
    const browserChart = new ApexCharts(browserChartEl, {
        series: series,
        chart: {
            type: 'line',
            height: 350,
            toolbar: {
                show: false
            }
        },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        colors: ['#7e3ff2', '#64748b', '#cbd5e0'],
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'right'
        }
    });
    
    browserChart.render();
    window.browserChart = browserChart;
}

/**
 * Initialize trends chart with real data
 */
function initTrendsChart(analyticsData) {
    const trendsChartEl = document.querySelector('#trendsChart');
    if (!trendsChartEl) {
        return;
    }
    
    // Default trends data
    let series = [
        {
            name: 'Users',
            data: [1200, 1300, 1250, 1400, 1350, 1500, 1600]
        }, 
        {
            name: 'Sessions',
            data: [1500, 1600, 1550, 1700, 1650, 1800, 1900]
        }, 
        {
            name: 'Page Views',
            data: [4500, 4800, 4600, 5100, 4900, 5400, 5700]
        }
    ];
    let categories = ['Mar 15', 'Mar 16', 'Mar 17', 'Mar 18', 'Mar 19', 'Mar 20', 'Mar 21'];
    
    if (analyticsData && analyticsData.trends) {
        const trendsData = analyticsData.trends;
        if (trendsData.series.length > 0 && trendsData.categories.length > 0) {
            series = trendsData.series;
            categories = trendsData.categories;
        }
    }
    
    const trendsChart = new ApexCharts(trendsChartEl, {
        series: series,
        chart: {
            type: 'bar',
            height: 350,
            toolbar: {
                show: false
            }
        },
        plotOptions: {
            bar: {
                borderRadius: 4
            }
        },
        colors: ['#7e3ff2', '#64748b', '#cbd5e0'],
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'right'
        }
    });
    
    trendsChart.render();
    window.trendsChart = trendsChart;
}

/**
 * Update tables with real data
 */
function updateTablesWithData(analyticsData) {
    if (!analyticsData) {
        return;
    }
    
    // Update events table
    if (analyticsData.events && analyticsData.events.length > 0) {
        const eventsTable = document.querySelector('.bocm-events-table table tbody');
        if (eventsTable) {
            eventsTable.innerHTML = '';
            
            // Limit to 10 events
            const eventsToShow = analyticsData.events.slice(0, 10);
            eventsToShow.forEach(event => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${event.name}</td>
                    <td>${event.count}</td>
                    <td>${event.users}</td>
                    <td>${event.value}</td>
                `;
                eventsTable.appendChild(row);
            });
        }
    }
    
    // Update landing pages table
    if (analyticsData.landing_pages && analyticsData.landing_pages.length > 0) {
        const landingPagesTable = document.querySelector('.bocm-landing-pages-table table tbody');
        if (landingPagesTable) {
            landingPagesTable.innerHTML = '';
            
            // Limit to 10 landing pages
            const pagesToShow = analyticsData.landing_pages.slice(0, 10);
            pagesToShow.forEach(page => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${page.page}</td>
                    <td>${page.users}</td>
                    <td>${page.new_users}</td>
                    <td>${page.sessions}</td>
                    <td>${page.bounce_rate}</td>
                `;
                landingPagesTable.appendChild(row);
            });
        }
    }
    
    // Update top pages table
    if (analyticsData.top_pages && analyticsData.top_pages.length > 0) {
        const topPagesTable = document.querySelector('.bocm-top-pages-table table tbody');
        if (topPagesTable) {
            topPagesTable.innerHTML = '';
            
            // Limit to 10 top pages
            const pagesToShow = analyticsData.top_pages.slice(0, 10);
            pagesToShow.forEach(page => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${page.page}</td>
                    <td>${page.views}</td>
                    <td>${page.unique_views}</td>
                    <td>${page.avg_time}</td>
                    <td>${page.bounce_rate}</td>
                `;
                topPagesTable.appendChild(row);
            });
        }
    }
}

/**
 * Initialize user types chart with real data
 */
function initUserTypesChart(analyticsData) {
    const userTypesChartEl = document.querySelector('#userTypesChart');
    if (!userTypesChartEl) {
        return;
    }
    
    // Default data if no real data is available
    let newUsers = 70;
    let returningUsers = 9;
    
    // Use real data if available
    if (analyticsData && analyticsData.summary) {
        const summary = analyticsData.summary;
        if (summary.new_users && summary.returning_users) {
            newUsers = summary.new_users.value || newUsers;
            returningUsers = summary.returning_users.value || returningUsers;
        }
    }
    
    // Create stats cards at the top
    const statsContainer = document.createElement('div');
    statsContainer.className = 'bocm-user-types-stats';
    statsContainer.innerHTML = `
        <div class="bocm-user-type-stat">
            <div class="bocm-user-type-label">
                <span class="bocm-user-type-icon"><i class="fas fa-user-plus"></i></span>
                <span class="bocm-user-type-text">${window.bocmData?.i18n?.new_users || 'New users'}</span>
            </div>
            <div class="bocm-user-type-value">${newUsers}</div>
        </div>
        <div class="bocm-user-type-stat">
            <div class="bocm-user-type-label">
                <span class="bocm-user-type-icon"><i class="fas fa-user-check"></i></span>
                <span class="bocm-user-type-text">${window.bocmData?.i18n?.returning_users || 'Returning users'}</span>
            </div>
            <div class="bocm-user-type-value">${returningUsers}</div>
        </div>
    `;
    
    // Parse analyticsData to create a time series chart
    const dailyData = {
        dates: [],
        newUsers: [],
        returningUsers: []
    };
    
    // If we have daily data, use it
    if (analyticsData && analyticsData.user_types && analyticsData.user_types.dates) {
        dailyData.dates = analyticsData.user_types.dates;
        dailyData.newUsers = analyticsData.user_types.new_users || [];
        dailyData.returningUsers = analyticsData.user_types.returning_users || [];
    } else {
        // Otherwise create sample data for the last 30 days
        const today = new Date();
        for (let i = 30; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            dailyData.dates.push(formatDate(date));
            
            // Create some sample data with a few spikes
            if (i === 20) { // Spike in new users
                dailyData.newUsers.push(15);
                dailyData.returningUsers.push(2);
            } else if (i === 12) { // Another spike
                dailyData.newUsers.push(8);
                dailyData.returningUsers.push(1);
            } else if (i === 5) { // Another spike
                dailyData.newUsers.push(7);
                dailyData.returningUsers.push(1);
            } else if (i === 8) { // Returning users spike
                dailyData.newUsers.push(2);
                dailyData.returningUsers.push(3);
            } else {
                dailyData.newUsers.push(Math.floor(Math.random() * 3));
                dailyData.returningUsers.push(Math.floor(Math.random() * 2));
            }
        }
    }
    
    // Clear existing content
    userTypesChartEl.innerHTML = '';
    userTypesChartEl.appendChild(statsContainer);
    
    // Create chart container
    const chartContainer = document.createElement('div');
    chartContainer.id = 'userTypesChartGraph';
    userTypesChartEl.appendChild(chartContainer);
    
    // Remove shimmer effect
    userTypesChartEl.classList.remove('shimmer');
    
    // Initialize the chart
    const userTypesChart = new ApexCharts(chartContainer, {
        series: [{
            name: window.bocmData?.i18n?.new_users || 'New users',
            data: dailyData.newUsers
        }],
        chart: {
            height: 250,
            type: 'area',
            toolbar: {
                show: false
            }
        },
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: 2
        },
        colors: ['#007bff'],
        fill: {
            type: 'gradient',
            gradient: {
                shadeIntensity: 1,
                opacityFrom: 0.7,
                opacityTo: 0.3,
                stops: [0, 90, 100]
            }
        },
        xaxis: {
            categories: dailyData.dates,
            labels: {
                formatter: function(val) {
                    // Format the date to be more readable
                    return formatDisplayDate(val);
                },
                style: {
                    colors: '#64748b'
                }
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b'
                }
            }
        },
        tooltip: {
            x: {
                format: 'dd MMM yyyy'
            }
        }
    });
    
    userTypesChart.render();
    window.userTypesChart = userTypesChart;
    
    // Add CSS for the user types stats
    if (!document.querySelector('style#user-types-styles')) {
        const userTypesStyles = document.createElement('style');
        userTypesStyles.id = 'user-types-styles';
        userTypesStyles.textContent = `
            .bocm-user-types-stats {
                display: flex;
                gap: 20px;
                margin-bottom: 15px;
            }
            .bocm-user-type-stat {
                display: flex;
                flex-direction: column;
                padding: 15px;
                background-color: #f8fafc;
                border-radius: 8px;
                flex: 1;
            }
            .bocm-user-type-label {
                display: flex;
                align-items: center;
                gap: 8px;
                margin-bottom: 8px;
                color: #64748b;
                font-size: 14px;
            }
            .bocm-user-type-icon {
                width: 24px;
                height: 24px;
                display: flex;
                align-items: center;
                justify-content: center;
                color: #007bff;
            }
            .bocm-user-type-value {
                font-size: 32px;
                font-weight: 600;
                color: #2d3748;
            }
        `;
        document.head.appendChild(userTypesStyles);
    }
}

/**
 * Format date for display in the X-axis
 */
function formatDisplayDate(dateStr) {
    // If the input is already in format 'Feb 23', 'Mar 02', etc. return as is
    if (typeof dateStr === 'string' && /^[A-Za-z]{3} \d{2}$/.test(dateStr)) {
        return dateStr;
    }
    
    // Otherwise, parse the date and format it
    const date = new Date(dateStr);
    if (isNaN(date.getTime())) return dateStr; // Return as is if invalid
    
    const month = date.toLocaleString('default', { month: 'short' });
    const day = date.getDate().toString().padStart(2, '0');
    return `${month} ${day}`;
}

/**
 * Format date to YYYY-MM-DD
 */
function formatDate(date) {
    const year = date.getFullYear();
    const month = (date.getMonth() + 1).toString().padStart(2, '0');
    const day = date.getDate().toString().padStart(2, '0');
    return `${year}-${month}-${day}`;
} 