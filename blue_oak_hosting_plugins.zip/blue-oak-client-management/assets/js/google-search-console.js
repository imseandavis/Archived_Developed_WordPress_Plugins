/**
 * Google Search Console Tab Functionality
 */

document.addEventListener('DOMContentLoaded', () => {
    initSearchConsoleTab();
});

/**
 * Initialize the Search Console tab functionality
 */
function initSearchConsoleTab() {
    // Check if search console data is available
    const searchConsoleData = window.searchConsoleData || null;
    
    // Check if there's an error in the data
    if (searchConsoleData && searchConsoleData.error) {
        console.error('Google Search Console data error:', searchConsoleData.error);
        displayErrorMessage(searchConsoleData.error);
        return;
    }
    
    // Update metrics with real data
    updateSearchMetrics(searchConsoleData);
    
    // Initialize the performance chart
    initSearchPerformanceChart(searchConsoleData);
    
    // Update tables with real data
    updateSearchTables(searchConsoleData);
    
    // Handle chart type changes
    const chartTypeButtons = document.querySelectorAll('.bocm-chart-type');
    chartTypeButtons.forEach(button => {
        button.addEventListener('click', function() {
            const chartType = this.dataset.type;
            const chartContainer = this.closest('.bocm-portal-card').querySelector('.bocm-chart-container');
            
            // Update active state
            this.closest('.bocm-card-actions').querySelectorAll('.bocm-chart-type').forEach(btn => {
                btn.classList.remove('active');
            });
            this.classList.add('active');

            // Update chart type if we have the chart object stored
            if (chartContainer.id === 'searchPerformanceChart' && window.searchPerformanceChart) {
                window.searchPerformanceChart.updateOptions({
                    chart: {
                        type: chartType
                    }
                });
                
                // Additional options specific to chart type
                if (chartType === 'line') {
                    window.searchPerformanceChart.updateOptions({
                        stroke: {
                            curve: 'smooth',
                            width: 3
                        },
                        markers: {
                            size: 4
                        }
                    });
                } else {
                    window.searchPerformanceChart.updateOptions({
                        stroke: {
                            width: 0
                        },
                        markers: {
                            size: 0
                        }
                    });
                }
                
                // Force redraw the chart after changing type
                setTimeout(() => {
                    window.searchPerformanceChart.render();
                }, 100);
            }
        });
    });

    // Handle date range changes
    document.getElementById('searchPerformanceRange').addEventListener('change', (e) => {
        const days = parseInt(e.target.value);
        
        // Show loading state
        e.target.disabled = true;
        const originalText = e.target.options[e.target.selectedIndex].text;
        e.target.options[e.target.selectedIndex].text = 'Loading...';
        
        // Make AJAX request to get new data
        fetchSearchConsoleData(days).then(response => {
            if (response.success) {
                // Update global data
                window.searchConsoleData = response.data;
                
                // Refresh all metrics and charts
                updateSearchMetrics(response.data);
                initSearchPerformanceChart(response.data);
                updateSearchTables(response.data);
                
                // Update chart title
                if (window.searchPerformanceChart) {
                    window.searchPerformanceChart.updateOptions({
                        title: {
                            text: `Last ${days} ${days === 1 ? 'Day' : 'Days'}`,
                        }
                    });
                }
                
                // Show success notification
                showNotification('Search Console data updated successfully for the last ' + days + ' days.', 'success');
                
                // Ensure all shimmer effects are removed after data update
                removeAllShimmerEffects();
            } else {
                // Show error notification
                showNotification('Error updating Search Console data: ' + (response.message || 'Unknown error'), 'error');
            }
        }).catch(error => {
            console.error('Error fetching Search Console data:', error);
            showNotification('Failed to update Search Console data. Please try again.', 'error');
        }).finally(() => {
            // Reset selector
            e.target.options[e.target.selectedIndex].text = originalText;
            e.target.disabled = false;
        });
    });

    // Remove shimmer from elements after data has loaded with a longer timeout
    // Increased from 1.5s to 3s to ensure data has time to load
    setTimeout(() => {
        removeAllShimmerEffects();
    }, 3000);
}

/**
 * Helper function to remove all shimmer effects
 */
function removeAllShimmerEffects() {
    document.querySelectorAll('.shimmer').forEach(element => {
        element.classList.remove('shimmer');
    });
}

/**
 * Fetch Search Console data via AJAX
 * 
 * @param {number} days Number of days to fetch data for
 * @returns {Promise} Promise that resolves with the response
 */
function fetchSearchConsoleData(days) {
    return new Promise((resolve, reject) => {
        // Create form data
        const formData = new FormData();
        formData.append('action', 'bocm_fetch_search_console_data');
        formData.append('days', days);
        formData.append('nonce', bocmData.nonce); // Assuming nonce is available in global object
        
        // Make AJAX request
        fetch(bocmData.ajax_url, {
            method: 'POST',
            credentials: 'same-origin',
            body: formData
        })
        .then(response => response.json())
        .then(resolve)
        .catch(reject);
    });
}

/**
 * Update search metrics with real data
 */
function updateSearchMetrics(searchConsoleData) {
    if (!searchConsoleData || !searchConsoleData.summary) {
        return;
    }
    
    const summary = searchConsoleData.summary;
    
    // Update clicks - target by icon
    const clicksCard = document.querySelector('.bocm-search-metric-card .bocm-search-metric-icon i.fa-mouse-pointer');
    if (clicksCard && summary.clicks) {
        const card = clicksCard.closest('.bocm-search-metric-card');
        const valueEl = card.querySelector('.bocm-search-metric-value');
        const changeEl = card.querySelector('.bocm-search-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.clicks.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = Math.abs(summary.clicks.change).toFixed(1) + '%';
            
            if (summary.clicks.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
        
        // Remove shimmer from this card
        card.classList.remove('shimmer');
    }
    
    // Update impressions - target by icon
    const impressionsCard = document.querySelector('.bocm-search-metric-card .bocm-search-metric-icon i.fa-eye');
    if (impressionsCard && summary.impressions) {
        const card = impressionsCard.closest('.bocm-search-metric-card');
        const valueEl = card.querySelector('.bocm-search-metric-value');
        const changeEl = card.querySelector('.bocm-search-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.impressions.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = Math.abs(summary.impressions.change).toFixed(1) + '%';
            
            if (summary.impressions.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
        
        // Remove shimmer from this card
        card.classList.remove('shimmer');
    }
    
    // Update CTR - target by icon
    const ctrCard = document.querySelector('.bocm-search-metric-card .bocm-search-metric-icon i.fa-percentage');
    if (ctrCard && summary.ctr) {
        const card = ctrCard.closest('.bocm-search-metric-card');
        const valueEl = card.querySelector('.bocm-search-metric-value');
        const changeEl = card.querySelector('.bocm-search-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.ctr.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = Math.abs(summary.ctr.change).toFixed(1) + '%';
            
            if (summary.ctr.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            }
        }
        
        // Remove shimmer from this card
        card.classList.remove('shimmer');
    }
    
    // Update position - target by icon
    const positionCard = document.querySelector('.bocm-search-metric-card .bocm-search-metric-icon i.fa-chart-line');
    if (positionCard && summary.position) {
        const card = positionCard.closest('.bocm-search-metric-card');
        const valueEl = card.querySelector('.bocm-search-metric-value');
        const changeEl = card.querySelector('.bocm-search-metric-change');
        
        if (valueEl) {
            valueEl.textContent = summary.position.value;
        }
        
        if (changeEl) {
            changeEl.querySelector('span').textContent = Math.abs(summary.position.change).toFixed(1);
            
            // For position, lower is better (higher in search results)
            if (summary.position.positive) {
                changeEl.classList.add('positive');
                changeEl.classList.remove('negative');
                changeEl.querySelector('i').className = 'fas fa-arrow-down';
            } else {
                changeEl.classList.add('negative');
                changeEl.classList.remove('positive');
                changeEl.querySelector('i').className = 'fas fa-arrow-up';
            }
        }
    }
}

/**
 * Initialize the search performance chart with real data
 */
function initSearchPerformanceChart(searchConsoleData) {
    const chartEl = document.querySelector("#searchPerformanceChart");
    if (!chartEl) {
        return;
    }
    
    // Use default data if no real data available
    let series = [
            {
                name: 'Clicks',
                data: [45, 52, 38, 24, 33, 26, 21, 20, 6, 8, 15, 10, 65, 23, 38, 46, 11, 32, 45, 42, 32, 38, 45, 56, 28, 37, 43, 51]
            },
            {
                name: 'Impressions',
                data: [350, 460, 350, 250, 420, 370, 280, 190, 390, 250, 420, 380, 430, 390, 520, 390, 450, 330, 560, 310, 530, 490, 350, 460, 350, 250, 420, 370]
            },
            {
                name: 'CTR',
                data: [7.8, 7.5, 8.9, 10.2, 6.8, 5.9, 6.5, 7.8, 1.2, 2.5, 3.2, 4.5, 11.2, 5.8, 7.2, 9.3, 2.4, 8.7, 7.1, 10.2, 5.2, 6.8, 10.2, 10.5, 6.8, 8.9, 8.7, 10.6]
            },
            {
                name: 'Position',
                data: [14, 13, 15, 14.5, 12, 10.5, 9.5, 11, 14, 15, 13, 12, 10, 9.5, 8.5, 9, 10, 11, 12, 13, 12, 11, 10, 9, 8.5, 9, 9.5, 10]
            }
    ];
    
    let categories = Array.from({ length: 28 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - 27 + i);
        return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
    });
    
    // Use real data if available
    if (searchConsoleData && searchConsoleData.performance) {
        if (searchConsoleData.performance.series && searchConsoleData.performance.categories) {
            series = searchConsoleData.performance.series;
            categories = searchConsoleData.performance.categories;
        }
    }
    
    const chartOptions = {
        series: series,
        chart: {
            height: 350,
            type: 'line',
            zoom: {
                enabled: false
            },
            toolbar: {
                show: false
            },
            fontFamily: 'Inter, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif',
        },
        colors: ['#7e3ff2', '#60a5fa', '#f97316', '#10b981'],
        dataLabels: {
            enabled: false
        },
        stroke: {
            curve: 'smooth',
            width: [3, 3, 3, 3]
        },
        title: {
            text: 'Last 28 Days',
            align: 'left',
            style: {
                fontSize: '14px',
                fontWeight: 'normal',
                color: '#64748b'
            }
        },
        grid: {
            borderColor: '#e2e8f0',
            row: {
                colors: ['#f8fafc', 'transparent'],
                opacity: 0.5
            },
        },
        markers: {
            size: 4,
            colors: ['#7e3ff2', '#60a5fa', '#f97316', '#10b981'],
            strokeColors: '#fff',
            strokeWidth: 2,
            hover: {
                size: 6,
            }
        },
        xaxis: {
            categories: categories,
            labels: {
                style: {
                    colors: '#64748b',
                    fontSize: '12px',
                    fontFamily: 'Inter, sans-serif',
                }
            },
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            }
        },
        yaxis: {
            labels: {
                style: {
                    colors: '#64748b',
                    fontSize: '12px',
                    fontFamily: 'Inter, sans-serif',
                }
            }
        },
        legend: {
            position: 'top',
            horizontalAlign: 'right',
            floating: true,
            offsetY: -25,
            offsetX: -5,
            fontFamily: 'Inter, sans-serif',
            fontSize: '13px',
            markers: {
                width: 10,
                height: 10,
                strokeWidth: 0,
                radius: 12,
                offsetX: -5
            },
            itemMargin: {
                horizontal: 10,
                vertical: 0
            },
            labels: {
                colors: '#475569'
            }
        },
        tooltip: {
            theme: 'light',
            marker: {
                show: true,
            },
            x: {
                show: true,
            },
            y: {
                formatter: function (value, { seriesIndex }) {
                    if (seriesIndex === 2) {
                        return value + '%';
                    }
                    if (seriesIndex === 3) {
                        return value.toFixed(1);
                    }
                    return value;
                }
            }
        }
    };

    // If chart already exists, destroy it first
    if (window.searchPerformanceChart) {
        try {
            // Some versions of ApexCharts use 'destroy' method
            if (typeof window.searchPerformanceChart.destroy === 'function') {
                window.searchPerformanceChart.destroy();
            } else {
                // For older versions that might not have the destroy method
                chartEl.innerHTML = '';
            }
        } catch (e) {
            console.warn('Could not properly clean up previous chart:', e);
            // Fallback: just clear the element content
            chartEl.innerHTML = '';
        }
    }
    
    const chart = new ApexCharts(chartEl, chartOptions);
    chart.render();
    window.searchPerformanceChart = chart;
    
    // Remove shimmer effect from chart container
    chartEl.classList.remove('shimmer');
}

/**
 * Update search tables with real data
 */
function updateSearchTables(searchConsoleData) {
    if (!searchConsoleData) {
        return;
    }
    
    // Update queries table
    if (searchConsoleData.queries && searchConsoleData.queries.length > 0) {
        const queriesTable = document.querySelector('.bocm-search-queries-table table tbody');
        if (queriesTable) {
            queriesTable.innerHTML = '';
            
            searchConsoleData.queries.forEach(query => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${query.query}</td>
                    <td>${query.clicks}</td>
                    <td>${query.impressions}</td>
                    <td>${query.ctr}</td>
                    <td>${query.position}</td>
                `;
                queriesTable.appendChild(row);
            });
            
            // Remove shimmer effect
            queriesTable.closest('.bocm-search-queries-table').classList.remove('shimmer');
        }
    }
    
    // Update pages table
    if (searchConsoleData.pages && searchConsoleData.pages.length > 0) {
        const pagesTable = document.querySelector('.bocm-search-pages-table table tbody');
        if (pagesTable) {
            pagesTable.innerHTML = '';
            
            searchConsoleData.pages.forEach(page => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${page.page}</td>
                    <td>${page.clicks}</td>
                    <td>${page.impressions}</td>
                    <td>${page.ctr}</td>
                    <td>${page.position}</td>
                `;
                pagesTable.appendChild(row);
            });
            
            // Remove shimmer effect
            pagesTable.closest('.bocm-search-pages-table').classList.remove('shimmer');
        }
    }
}

/**
 * Display a notification to the user
 * 
 * @param {string} message The notification message
 * @param {string} type The notification type (success, error, warning, info)
 */
function showNotification(message, type = 'info') {
    // Check if notification container exists, create if not
    let container = document.querySelector('.bocm-notifications');
    if (!container) {
        container = document.createElement('div');
        container.className = 'bocm-notifications';
        document.body.appendChild(container);
    }
    
    // Create notification element
    const notification = document.createElement('div');
    notification.className = `bocm-notification bocm-notification-${type}`;
    notification.innerHTML = `
        <div class="bocm-notification-content">
            <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
            <span>${message}</span>
        </div>
        <button class="bocm-notification-close"><i class="fas fa-times"></i></button>
    `;
    
    // Add notification to container
    container.appendChild(notification);
    
    // Add close button functionality
    notification.querySelector('.bocm-notification-close').addEventListener('click', function() {
        notification.classList.add('bocm-notification-hiding');
        setTimeout(() => {
            container.removeChild(notification);
            if (container.children.length === 0) {
                document.body.removeChild(container);
            }
        }, 300);
    });
    
    // Auto-remove after 5 seconds
    setTimeout(() => {
        if (notification.parentNode) {
            notification.classList.add('bocm-notification-hiding');
            setTimeout(() => {
                if (notification.parentNode) {
                    container.removeChild(notification);
                    if (container.children.length === 0) {
                        document.body.removeChild(container);
                    }
                }
            }, 300);
        }
    }, 5000);
}

/**
 * Display an error message in the dashboard
 */
function displayErrorMessage(errorMessage) {
    // Create a UI element to display the error
    const tabContent = document.querySelector('.bocm-tab-content');
    if (!tabContent) return;
    
    // Clear existing content
    tabContent.innerHTML = '';
    
    // Create error card
    const errorCard = document.createElement('div');
    errorCard.className = 'bocm-portal-card';
    errorCard.innerHTML = `
        <div class="bocm-card-header">
            <h3>Google Search Console Error</h3>
        </div>
        <div class="bocm-card-content">
            <p>There was an error loading your Google Search Console data:</p>
            <p><strong>${errorMessage}</strong></p>
            <p>Please try refreshing the page or contact your administrator if the issue persists.</p>
        </div>
    `;
    
    // Add the error card to the tab content
    tabContent.appendChild(errorCard);
} 