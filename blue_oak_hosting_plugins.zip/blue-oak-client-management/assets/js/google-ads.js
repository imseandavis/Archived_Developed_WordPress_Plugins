/**
 * Google Ads Tab JavaScript
 */

document.addEventListener('DOMContentLoaded', function() {
    initGoogleAdsTab();
});

/**
 * Initialize Google Ads tab functionality
 */
function initGoogleAdsTab() {
    // Initialize performance chart
    const performanceChartEl = document.querySelector('#adsPerformanceChart');
    if (performanceChartEl) {
        const performanceChart = new ApexCharts(performanceChartEl, {
            series: [{
                name: 'Clicks',
                data: [120, 150, 130, 180, 160, 200, 220]
            }, {
                name: 'Impressions',
                data: [2400, 2800, 2600, 3200, 3000, 3600, 4000]
            }, {
                name: 'Cost',
                data: [180, 220, 200, 260, 240, 300, 320]
            }],
            chart: {
                type: 'line',
                height: 350,
                toolbar: {
                    show: false
                }
            },
            stroke: {
                curve: 'smooth',
                width: 2
            },
            colors: ['#7e3ff2', '#64748b', '#cbd5e0'],
            xaxis: {
                categories: ['Mar 15', 'Mar 16', 'Mar 17', 'Mar 18', 'Mar 19', 'Mar 20', 'Mar 21'],
                labels: {
                    style: {
                        colors: '#64748b'
                    }
                }
            },
            yaxis: [
                {
                    title: {
                        text: 'Clicks',
                        style: {
                            color: '#7e3ff2'
                        }
                    },
                    labels: {
                        style: {
                            colors: '#64748b'
                        }
                    }
                },
                {
                    opposite: true,
                    title: {
                        text: 'Impressions',
                        style: {
                            color: '#64748b'
                        }
                    },
                    labels: {
                        style: {
                            colors: '#64748b'
                        }
                    }
                },
                {
                    opposite: true,
                    title: {
                        text: 'Cost ($)',
                        style: {
                            color: '#cbd5e0'
                        }
                    },
                    labels: {
                        style: {
                            colors: '#64748b'
                        }
                    }
                }
            ],
            legend: {
                position: 'top',
                horizontalAlign: 'right'
            }
        });
        performanceChart.render();
    }

    // Handle date range changes
    const dateRangeSelector = document.querySelector('#adsPerformanceRange');
    if (dateRangeSelector) {
        dateRangeSelector.addEventListener('change', (e) => {
            // Here you would typically fetch new data based on the selected date range
            console.log('Date range changed to:', e.target.value);
        });
    }

    // Remove shimmer effect from tables and cards after data loads
    setTimeout(() => {
        document.querySelectorAll('.bocm-ads-metric-card, .bocm-chart-container, .bocm-ads-campaigns-table, .bocm-ads-keywords-table').forEach(element => {
            element.classList.remove('shimmer');
        });
    }, 1000);
} 