1. Add "Blue Oak Client" role
2. Add Admin Menu Called "Client Management"
3. Add A Submenu Item Called "Settings"
4. Add A Field On The Settings Page Called "Uptime Robot Main API Key"
    - Add toast for when key is missing with instructions on where to find the main api key.
    - Add toast for when key is successfully added.
5. Add User Profile Section called "Blue Oak Settings"
6. Add Three Fields To The Section
    - Partner Account Group ID
    - Google Analytics Property ID
    - Reporting URL
    - Uptime Monitor (Dropdown)
7. Make Those Fields Read Only For Non-Admin Users
8. Add Those Three Fields To Create User Form
9. Add Admin Menu Called "Client Management"
10. Add A Submenu Item Called "Settings"
11. Add A Field On The Settings Page Called "Uptime Robot Main API Key"
    - Add toast for when key is missing with instructions on where to find the main api key.
    - Add toast for when key is successfully added.
