<?php
/**
 * PageSpeed Scanner
 *
 * Handles scanning websites with Google PageSpeed Insights API and storing results.
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * PageSpeed Scanner class
 */
class PageSpeed_Scanner {
    /**
     * Google PageSpeed Insights API URL
     * 
     * @var string
     */
    private string $api_url = 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed';
    
    /**
     * API Key for Google PageSpeed Insights
     * 
     * @var string|null
     */
    private ?string $api_key = null;
    
    /**
     * Initialize the class
     */
    public function __construct() {
        // Get API key from options
        $this->api_key = get_option('bocm_pagespeed_api_key', '');
        
        // Register hooks
        add_action('bocm_daily_cron', [$this, 'schedule_all_client_scans']);
        add_action('bocm_pagespeed_scan_single', [$this, 'scan_single_site'], 10, 2);
        add_action('bocm_pagespeed_scan_batch', [$this, 'scan_batch'], 10, 1);
        
        // Add a filter to ensure our cron runs daily
        add_filter('cron_schedules', [$this, 'add_cron_interval']);
        
        // Register the daily cron hook if not already scheduled
        if (!wp_next_scheduled('bocm_daily_cron')) {
            wp_schedule_event(strtotime('today 01:00 am'), 'bocm_daily', 'bocm_daily_cron');
        }
    }
    
    /**
     * Add custom cron interval
     *
     * @param array $schedules WP cron schedules
     * @return array Modified schedules
     */
    public function add_cron_interval(array $schedules): array {
        $schedules['bocm_daily'] = [
            'interval' => 86400, // 24 hours in seconds
            'display' => __('Once Daily', 'blue-oak-client-management')
        ];
        return $schedules;
    }
    
    /**
     * Schedule scans for all Blue Oak clients
     * 
     * This function finds all Blue Oak clients with a website URL
     * and schedules them for scanning in batches to avoid overloading
     * the server or hitting API rate limits.
     * 
     * @return void
     */
    public function schedule_all_client_scans(): void {
        // Skip if no API key is set
        if (empty($this->api_key)) {
            error_log('BOCM PageSpeed: No API key set, skipping scheduling of client scans');
            return;
        }
        
        // Get all users with the Blue Oak client role
        $users = get_users([
            'role' => 'bocm_client',
            'fields' => ['ID', 'user_url'],
        ]);
        
        $clients_to_scan = [];
        
        foreach ($users as $user) {
            if (!empty($user->user_url)) {
                $clients_to_scan[] = [
                    'user_id' => $user->ID,
                    'website_url' => $user->user_url,
                ];
            }
        }
        
        error_log('BOCM PageSpeed: Found ' . count($clients_to_scan) . ' clients with websites to scan');
        
        // Schedule batch processing of client scans
        // We process in batches of 5 clients every 15 minutes to avoid overloading
        $batch_size = 5;
        $batches = array_chunk($clients_to_scan, $batch_size);
        
        foreach ($batches as $index => $batch) {
            // Schedule each batch 15 minutes apart
            $delay = 15 * 60 * ($index + 1);
            wp_schedule_single_event(time() + $delay, 'bocm_pagespeed_scan_batch', [$batch]);
            error_log('BOCM PageSpeed: Scheduled batch ' . ($index + 1) . ' of ' . count($batches) . ' for processing in ' . $delay . ' seconds');
        }
    }
    
    /**
     * Process a batch of client scans
     * 
     * @param array $batch Array of client data (user_id and website_url)
     * @return void
     */
    public function scan_batch(array $batch): void {
        foreach ($batch as $client) {
            if (isset($client['user_id'], $client['website_url'])) {
                // Schedule immediate single scan for each client in the batch
                wp_schedule_single_event(time(), 'bocm_pagespeed_scan_single', [$client['user_id'], $client['website_url']]);
                error_log('BOCM PageSpeed: Scheduled immediate scan for user ID: ' . $client['user_id']);
            }
        }
    }
    
    /**
     * Scan a single website using Google PageSpeed Insights API
     * 
     * @param int $user_id The user ID
     * @param string $website_url The website URL to scan
     * @return bool True on success, false on failure
     */
    public function scan_single_site(int $user_id, string $website_url): bool {
        // Skip if no API key is set
        if (empty($this->api_key)) {
            error_log('BOCM PageSpeed: No API key set, skipping scan for user ID: ' . $user_id);
            return false;
        }
        
        // Sanitize and validate URL
        $website_url = esc_url_raw($website_url);
        if (empty($website_url)) {
            error_log('BOCM PageSpeed: Invalid URL for user ID: ' . $user_id);
            return false;
        }
        
        // Build API request URL
        $request_url = add_query_arg([
            'url' => $website_url,
            'strategy' => 'desktop',
            'category' => 'performance',
            'key' => $this->api_key,
        ], $this->api_url);
        
        error_log('BOCM PageSpeed: Scanning website for user ID: ' . $user_id . ', URL: ' . $website_url);
        
        // Make the API request
        $response = wp_remote_get($request_url, [
            'timeout' => 60, // Longer timeout for PageSpeed API
            'sslverify' => true,
        ]);
        
        // Check for errors
        if (is_wp_error($response)) {
            error_log('BOCM PageSpeed: API request failed for user ID: ' . $user_id . ', Error: ' . $response->get_error_message());
            return false;
        }
        
        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // Validate API response
        if (empty($data) || !isset($data['lighthouseResult'])) {
            error_log('BOCM PageSpeed: Invalid API response for user ID: ' . $user_id);
            return false;
        }
        
        // Extract performance score and other metrics
        $lighthouse_result = $data['lighthouseResult'];
        $categories = $lighthouse_result['categories'] ?? [];
        $audits = $lighthouse_result['audits'] ?? [];
        
        $performance_score = isset($categories['performance']['score']) ? 
            round($categories['performance']['score'] * 100) : 0;
        
        // Extract key metrics
        $page_size = isset($audits['total-byte-weight']['numericValue']) ? 
            round($audits['total-byte-weight']['numericValue'] / 1024 / 1024, 2) : 0;
        
        $first_contentful_paint = isset($audits['first-contentful-paint']['numericValue']) ? 
            round($audits['first-contentful-paint']['numericValue'] / 1000, 2) : 0;
        
        $largest_contentful_paint = isset($audits['largest-contentful-paint']['numericValue']) ? 
            round($audits['largest-contentful-paint']['numericValue'] / 1000, 2) : 0;
        
        $time_to_interactive = isset($audits['interactive']['numericValue']) ? 
            round($audits['interactive']['numericValue'] / 1000, 2) : 0;
        
        // Create today's data entry
        $current_scan = [
            'desktop_score' => $performance_score,
            'page_size' => $page_size,
            'first_contentful_paint' => $first_contentful_paint,
            'largest_contentful_paint' => $largest_contentful_paint,
            'time_to_interactive' => $time_to_interactive,
            'scanned_url' => $website_url,
            'timestamp' => time(),
            'date' => date('Y-m-d')
        ];
        
        // Get existing history data
        $history = get_user_meta($user_id, 'bocm_pagespeed_history', true);
        if (!is_array($history)) {
            $history = [];
        }
        
        // Add today's scan to history with date as key
        $today = date('Y-m-d');
        $history[$today] = $current_scan;
        
        // Keep only the last 7 days of data
        $dates_to_keep = [];
        for ($i = 0; $i < 7; $i++) {
            $dates_to_keep[date('Y-m-d', strtotime("-{$i} days"))] = true;
        }
        
        // Filter history to only keep the last 7 days
        $filtered_history = array_intersect_key($history, $dates_to_keep);
        
        // Store history data
        update_user_meta($user_id, 'bocm_pagespeed_history', $filtered_history);
        
        // Update current data (for backward compatibility)
        update_user_meta($user_id, 'bocm_pagespeed_data', $current_scan);
        update_user_meta($user_id, 'bocm_pagespeed_timestamp', time());
        
        error_log('BOCM PageSpeed: Saved scan results for user ID: ' . $user_id . 
                 ', Score: ' . $performance_score . 
                 ', FCP: ' . $first_contentful_paint . 's' .
                 ', LCP: ' . $largest_contentful_paint . 's' .
                 ', History entries: ' . count($filtered_history));
        
        return true;
    }
} 