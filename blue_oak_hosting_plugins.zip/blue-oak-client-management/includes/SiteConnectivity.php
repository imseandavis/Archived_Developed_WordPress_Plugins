<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Site connectivity helper
 * 
 * Provides methods for checking site accessibility with proper error handling and logging
 */
class SiteConnectivity {
    /**
     * Check if a site is accessible
     * 
     * @param string $url The URL to check
     * @param array $valid_codes Array of valid HTTP response codes (default [200])
     * @param int $timeout Timeout in seconds (default 5)
     * @return bool Whether the site is accessible
     */
    public static function is_site_accessible(string $url, array $valid_codes = [200], int $timeout = 5): bool {
        if (empty($url)) {
            error_log('BOCM SiteConnectivity: Empty URL provided for accessibility check');
            return false;
        }
        
        // Add scheme if not present
        if (!preg_match('/^https?:\/\//', $url)) {
            $url = 'https://' . $url;
        }
        
        error_log('BOCM SiteConnectivity: Checking accessibility for URL: ' . $url);
        
        // Get transient key for this URL
        $transient_key = 'bocm_site_check_' . md5($url);
        
        // Check if we have a cached result
        $cached_result = get_transient($transient_key);
        if ($cached_result !== false) {
            error_log('BOCM SiteConnectivity: Using cached accessibility result for ' . $url . ', result: ' . ($cached_result ? 'true' : 'false'));
            return (bool) $cached_result;
        }
        
        // Use wp_remote_head which is more reliable than get_headers
        $args = [
            'timeout' => $timeout,
            'redirection' => 0, // Don't follow redirects for head request
            'httpversion' => '1.1',
            'user-agent' => 'WordPress/' . get_bloginfo('version') . '; Blue Oak Client Management',
            'sslverify' => true
        ];
        
        $response = wp_remote_head($url, $args);
        
        // Check for WP_Error
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            error_log('BOCM SiteConnectivity: Failed to access ' . $url . ': ' . $error_message);
            
            // Cache the negative result for 5 minutes
            set_transient($transient_key, 0, 5 * MINUTE_IN_SECONDS);
            return false;
        }
        
        // Get the HTTP status code
        $status_code = wp_remote_retrieve_response_code($response);
        
        // Special case: If we get a 405 Method Not Allowed, try a GET request instead
        // Some servers don't allow HEAD requests
        if ($status_code === 405) {
            error_log('BOCM SiteConnectivity: HEAD request not allowed for ' . $url . ', trying GET request');
            
            $args['method'] = 'GET';
            $response = wp_remote_get($url, $args);
            
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                error_log('BOCM SiteConnectivity: Failed to access ' . $url . ' via GET: ' . $error_message);
                
                // Cache the negative result for 5 minutes
                set_transient($transient_key, 0, 5 * MINUTE_IN_SECONDS);
                return false;
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
        }
        
        // Now that we have status code, check if it matches any of the valid codes
        $is_accessible = in_array($status_code, $valid_codes, true);
        
        // Cache the result for 15 minutes
        set_transient($transient_key, (int) $is_accessible, 15 * MINUTE_IN_SECONDS);
        
        if ($is_accessible) {
            error_log('BOCM SiteConnectivity: URL ' . $url . ' is accessible (status code: ' . $status_code . ')');
        } else {
            error_log('BOCM SiteConnectivity: URL ' . $url . ' is not accessible (status code: ' . $status_code . ')');
        }
        
        return $is_accessible;
    }
    
    /**
     * Check if the WordPress admin area is accessible
     * 
     * @param string $site_url The site URL
     * @param int $timeout Timeout in seconds (default 5)
     * @return bool Whether the admin area is accessible
     */
    public static function is_admin_accessible(string $site_url, int $timeout = 5): bool {
        if (empty($site_url)) {
            return false;
        }
        
        // Add scheme if not present
        if (!preg_match('/^https?:\/\//', $site_url)) {
            $site_url = 'https://' . $site_url;
        }
        
        // Try to build the admin URL
        $admin_url = trailingslashit($site_url) . 'wp-admin/';
        
        // Admin URLs often involve redirects, so we consider these valid
        return self::is_site_accessible($admin_url, [200, 301, 302, 303, 307, 308], $timeout);
    }
} 