<?php
/**
 * Google Search Console tab view for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement\Views\Tabs;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>

<!-- Search Console Tab Content -->
<div class="bocm-tab-content">
    <!-- Performance Overview Card -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Performance Overview', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-search-metrics-grid">
            <div class="bocm-search-metric-card shimmer">
                <div class="bocm-search-metric-icon">
                    <i class="fas fa-mouse-pointer"></i>
                </div>
                <div class="bocm-search-metric-content">
                    <span class="bocm-search-metric-value">1,234</span>
                    <span class="bocm-search-metric-label"><?php _e('Total Clicks', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-search-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>12.5%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-search-metric-card shimmer">
                <div class="bocm-search-metric-icon">
                    <i class="fas fa-eye"></i>
                </div>
                <div class="bocm-search-metric-content">
                    <span class="bocm-search-metric-value">24,680</span>
                    <span class="bocm-search-metric-label"><?php _e('Impressions', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-search-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>8.3%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-search-metric-card shimmer">
                <div class="bocm-search-metric-icon">
                    <i class="fas fa-percentage"></i>
                </div>
                <div class="bocm-search-metric-content">
                    <span class="bocm-search-metric-value">5.0%</span>
                    <span class="bocm-search-metric-label"><?php _e('CTR', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-search-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>0.8%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-search-metric-card shimmer">
                <div class="bocm-search-metric-icon">
                    <i class="fas fa-chart-line"></i>
                </div>
                <div class="bocm-search-metric-content">
                    <span class="bocm-search-metric-value">12.4</span>
                    <span class="bocm-search-metric-label"><?php _e('Average Position', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-search-metric-change negative">
                        <i class="fas fa-arrow-down"></i>
                        <span>1.2</span>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Chart -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Search Performance', 'blue-oak-client-management'); ?></h3>
            <div class="bocm-card-actions">
                <button class="bocm-chart-type active" data-type="line">
                    <i class="fas fa-chart-line"></i>
                </button>
                <button class="bocm-chart-type" data-type="bar">
                    <i class="fas fa-chart-column"></i>
                </button>
                <div class="bocm-date-range-selector">
                    <select id="searchPerformanceRange">
                        <option value="7"><?php _e('Last 7 days', 'blue-oak-client-management'); ?></option>
                        <option value="28" selected><?php _e('Last 28 days', 'blue-oak-client-management'); ?></option>
                        <option value="90"><?php _e('Last 3 months', 'blue-oak-client-management'); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <div id="searchPerformanceChart" class="bocm-chart-container shimmer"></div>
    </div>

    <!-- Top Queries -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Top Search Queries', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-search-queries-table shimmer">
            <table class="bocm-table">
                <thead>
                    <tr>
                        <th><?php _e('Query', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Clicks', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Impressions', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('CTR', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Position', 'blue-oak-client-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>blue oak marketing</td>
                        <td>245</td>
                        <td>3,420</td>
                        <td>7.2%</td>
                        <td>1.8</td>
                    </tr>
                    <tr>
                        <td>website design services</td>
                        <td>189</td>
                        <td>4,567</td>
                        <td>4.1%</td>
                        <td>3.2</td>
                    </tr>
                    <tr>
                        <td>digital marketing agency</td>
                        <td>156</td>
                        <td>3,890</td>
                        <td>4.0%</td>
                        <td>4.5</td>
                    </tr>
                    <tr>
                        <td>seo services</td>
                        <td>134</td>
                        <td>2,980</td>
                        <td>4.5%</td>
                        <td>3.8</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top Pages -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Top Performing Pages', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-search-pages-table shimmer">
            <table class="bocm-table">
                <thead>
                    <tr>
                        <th><?php _e('Page', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Clicks', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Impressions', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('CTR', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Position', 'blue-oak-client-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>/</td>
                        <td>456</td>
                        <td>8,790</td>
                        <td>5.2%</td>
                        <td>2.3</td>
                    </tr>
                    <tr>
                        <td>/services/website-design/</td>
                        <td>234</td>
                        <td>5,670</td>
                        <td>4.1%</td>
                        <td>3.5</td>
                    </tr>
                    <tr>
                        <td>/services/seo/</td>
                        <td>189</td>
                        <td>4,560</td>
                        <td>4.1%</td>
                        <td>3.8</td>
                    </tr>
                    <tr>
                        <td>/about-us/</td>
                        <td>123</td>
                        <td>3,450</td>
                        <td>3.6%</td>
                        <td>4.2</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> 