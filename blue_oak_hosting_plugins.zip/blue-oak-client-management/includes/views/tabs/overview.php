<?php
/**
 * Overview tab template for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

use BlueOak\ClientManagement\SiteConnectivity;

// Get user data
$user = wp_get_current_user();
$website_url = $user->user_url;
$wp_admin_url = $website_url ? trailingslashit($website_url) . 'wp-admin/' : '';

// Check website URL accessibility with SiteConnectivity class
$website_active = false;
if (!empty($website_url)) {
    try {
        $website_active = SiteConnectivity::is_site_accessible($website_url);
        error_log('BOCM Overview: Website accessibility check: ' . $website_url . ', result: ' . ($website_active ? 'true' : 'false'));
    } catch (\Exception $e) {
        error_log('BOCM Overview: Error checking website accessibility: ' . $e->getMessage());
    }
}

// Check WordPress admin URL accessibility with SiteConnectivity class
$wp_admin_active = false;
if (!empty($website_url)) {
    try {
        $wp_admin_active = SiteConnectivity::is_admin_accessible($website_url);
        error_log('BOCM Overview: WordPress admin accessibility check: ' . $wp_admin_url . ', result: ' . ($wp_admin_active ? 'true' : 'false'));
    } catch (\Exception $e) {
        error_log('BOCM Overview: Error checking WordPress admin accessibility: ' . $e->getMessage());
    }
}

// Determine if buttons should be disabled
$website_disabled = empty($website_url) || !$website_active;
$wp_admin_disabled = empty($website_url);  // Only disable if no URL is set

// Initialize purchased products flags
$has_local_seo = false;
$has_reputation_management = false;
$has_social_marketing = false;
$has_ad_intelligence = false;

// Get purchases for service detection
$active_purchases = [];
$partner_account_group_id = get_user_meta($user->ID, 'bocm_partner_account_group_id', true);
if (!empty($partner_account_group_id)) {
    $vendasta_credentials = get_option('bocm_vendasta_service_account', '');
    if (!empty($vendasta_credentials)) {
        try {
            $vendasta = new Vendasta();
            $purchases = $vendasta->get_purchases($partner_account_group_id);
            
            error_log('BOCM Overview: Starting service detection for user: ' . $user->user_login . ' (ID: ' . $user->ID . ')');
            error_log('BOCM Overview: Found ' . count($purchases) . ' total purchases to evaluate');
            
            // Check for active services by SKU
            foreach ($purchases as $purchase) {
                // Only consider active or paid purchases
                if ($purchase['status'] === 'Paid' || $purchase['status'] === 'Active') {
                    $sku = $purchase['product_id'];
                    error_log('BOCM Overview: Evaluating active purchase, sku: ' . $sku . ', product: ' . $purchase['product_name'] . ', status: ' . $purchase['status']);
                    
                    // Check for specific services by SKU pattern
                    if (strpos($sku, 'MS') === 0) {
                        $has_local_seo = true;
                        error_log('BOCM Overview: ✓ Local SEO service detected via SKU: ' . $sku);
                    } elseif (strpos($sku, 'RM') === 0) {
                        $has_reputation_management = true;
                        error_log('BOCM Overview: ✓ Reputation Management service detected via SKU: ' . $sku);
                    } elseif (strpos($sku, 'SM') === 0) {
                        $has_social_marketing = true;
                        error_log('BOCM Overview: ✓ Social Marketing service detected via SKU: ' . $sku);
                    } elseif (strpos($sku, 'MP-94072e44d5364872b672d7ab4fc7a7e8') === 0 || 
                              strpos($sku, 'A-3QKQHBS3R6') === 0) {
                        $has_ad_intelligence = true;
                        error_log('BOCM Overview: ✓ Ad Intelligence service detected via SKU: ' . $sku);
                    } else {
                        error_log('BOCM Overview: ✗ SKU does not match any service pattern (MS, RM, SM, or Ad Intel), sku: ' . $sku);
                    }
                } else {
                    error_log('BOCM Overview: Skipping inactive purchase, sku: ' . $purchase['product_id'] . ', status: ' . $purchase['status']);
                }
            }
            
            // Log the final detection results
            error_log('BOCM Overview: Service detection results, local_seo: ' . ($has_local_seo ? 'YES' : 'NO') . ', reputation_management: ' . ($has_reputation_management ? 'YES' : 'NO') . ', social_marketing: ' . ($has_social_marketing ? 'YES' : 'NO') . ', ad_intelligence: ' . ($has_ad_intelligence ? 'YES' : 'NO'));
            
        } catch (\Exception $e) {
            error_log('BOCM Overview: Error getting purchases for service detection: ' . $e->getMessage());
        }
    } else {
        error_log('BOCM Overview: No Vendasta credentials found for service detection');
    }
} else {
    error_log('BOCM Overview: No Partner Account Group ID found for user ID: ' . $user->ID);
}
?>

<!-- Services Section -->
<div class="bocm-services-section">
    <div class="bocm-section-header">
        <h3><?php _e('Your Services', 'blue-oak-client-management'); ?></h3>
        <button id="bocm-purchase-history-btn" class="bocm-button">
            <i class="fas fa-history"></i> <?php _e('Purchase History', 'blue-oak-client-management'); ?>
        </button>
    </div>
    <div class="bocm-services-grid">
        <div class="bocm-service-item <?php echo $wp_admin_disabled ? 'disabled' : ''; ?>"
             <?php if (!$wp_admin_disabled): ?>
             data-url="<?php echo esc_url($wp_admin_url); ?>"
             <?php endif; ?>>
            <div class="bocm-service-icon">
                <i class="fas fa-server"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Website Hosting', 'blue-oak-client-management'); ?></span>
            <?php if ($wp_admin_disabled): ?>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
            <?php endif; ?>
        </div>
        <div class="bocm-service-item <?php echo !$has_local_seo ? 'disabled' : ''; ?>" 
             <?php if ($has_local_seo): ?>
             data-url="https://blue-oak-marketing.smblogin.com/account/location/<?php echo esc_attr($partner_account_group_id); ?>/listings/keyword-tracking"
             <?php endif; ?>>
            <div class="bocm-service-icon">
                <i class="fas fa-map-marker-alt"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Local SEO', 'blue-oak-client-management'); ?></span>
            <?php if (!$has_local_seo): ?>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
            <?php endif; ?>
        </div>
        <div class="bocm-service-item <?php echo !$has_reputation_management ? 'disabled' : ''; ?>"
             <?php if ($has_reputation_management): ?>
             data-url="https://blue-oak-marketing.smblogin.com/account/location/<?php echo esc_attr($partner_account_group_id); ?>/reputation/manage-reviews"
             <?php endif; ?>>
            <div class="bocm-service-icon">
                <i class="fas fa-star"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Reputation Management', 'blue-oak-client-management'); ?></span>
            <?php if (!$has_reputation_management): ?>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
            <?php endif; ?>
        </div>
        <div class="bocm-service-item <?php echo !$has_social_marketing ? 'disabled' : ''; ?>"
             <?php if ($has_social_marketing): ?>
             data-url="https://blue-oak-marketing.socialsmbs.com/account/<?php echo esc_attr($partner_account_group_id); ?>/overview"
             <?php endif; ?>>
            <div class="bocm-service-icon">
                <i class="fas fa-share-alt"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Social Marketing', 'blue-oak-client-management'); ?></span>
            <?php if (!$has_social_marketing): ?>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
            <?php endif; ?>
        </div>
        <div class="bocm-service-item <?php echo !$has_ad_intelligence ? 'disabled' : ''; ?>"
             <?php if ($has_ad_intelligence): ?>
             data-url="https://www.advertisingintelligence.io/business/<?php echo esc_attr($partner_account_group_id); ?>/overview"
             <?php endif; ?>>
            <div class="bocm-service-icon">
                <i class="fas fa-chart-line"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Ad Intelligence', 'blue-oak-client-management'); ?></span>
            <?php if (!$has_ad_intelligence): ?>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
            <?php endif; ?>
        </div>
        <div class="bocm-service-item disabled">
            <div class="bocm-service-icon">
                <i class="fas fa-pencil-alt"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Content Creation', 'blue-oak-client-management'); ?></span>
            <a href="<?php echo esc_url(add_query_arg('tab', 'upgrade', '#upgrade')); ?>" class="bocm-service-upgrade"><?php _e('Upgrade', 'blue-oak-client-management'); ?></a>
        </div>
        <div class="bocm-service-item" data-url="https://blue-oak-marketing.smblogin.com/login/">
            <div class="bocm-service-icon">
                <i class="fas fa-briefcase"></i>
            </div>
            <span class="bocm-service-name"><?php _e('Business App', 'blue-oak-client-management'); ?></span>
        </div>
    </div>
</div>

<!-- Score Cards -->
<div class="bocm-score-cards">
    <?php
    // Get monitor data
    $uptime_monitor_id = get_user_meta($user->ID, 'bocm_uptime_monitor_id', true);
    $monitor_data = null;
    $has_monitor = !empty($uptime_monitor_id); // Pre-set to true if we have a monitor ID
    $retry_attempts = 0;
    $max_retries = 3;
    
    // Log for debugging
    error_log('BOCM Overview: Uptime monitor ID for user ' . $user->ID . ': ' . ($uptime_monitor_id ?: 'Not set'));
    
    if (!empty($uptime_monitor_id)) {
        // Check if we have cached monitor data first
        $cache_key = 'bocm_uptime_monitor_' . $uptime_monitor_id;
        $cached_monitor = get_transient($cache_key);
        
        if ($cached_monitor !== false) {
            // Use cached data if available
            $monitor_data = $cached_monitor;
            $has_monitor = true;
            error_log('BOCM Overview: Using cached monitor data for ID ' . $uptime_monitor_id);
        } else {
            // Try to get monitors with retries
            while ($retry_attempts < $max_retries) {
                $monitors = $this->uptime_robot->get_monitors();
                
                // Log the monitor count
                error_log('BOCM Overview: Found ' . count($monitors) . ' monitors in total (attempt ' . ($retry_attempts + 1) . ')');
                
                if (!empty($monitors)) {
                    $monitor_data = current(array_filter($monitors, function($m) use ($uptime_monitor_id) {
                        return $m['id'] == $uptime_monitor_id;
                    }));
                    
                    if (!empty($monitor_data)) {
                        // We found our monitor, break out of retry loop
                        error_log('BOCM Overview: Monitor found on attempt ' . ($retry_attempts + 1));
                        
                        // Cache the monitor data using the configured cache duration
                        $cache_duration = get_option('bocm_uptimerobot_cache_duration', 10);
                        set_transient($cache_key, $monitor_data, $cache_duration * MINUTE_IN_SECONDS);
                        break;
                    }
                }
                
                // Only retry if we didn't find our monitor
                $retry_attempts++;
                
                if ($retry_attempts < $max_retries) {
                    // Small delay between retries (100ms)
                    usleep(100000);
                }
            }
        }
        
        // Log if we found the specific monitor
        error_log('BOCM Overview: Monitor found: ' . (!empty($monitor_data) ? 'Yes' : 'No') . ' after ' . $retry_attempts . ' attempts');
        if (!empty($monitor_data)) {
            error_log('BOCM Overview: Monitor data: ' . print_r([
                'name' => $monitor_data['name'],
                'status' => $monitor_data['status_text'],
                'custom_uptime_ratio' => $monitor_data['custom_uptime_ratio'] ?? 'Not available',
            ], true));
        }
    }

    // Calculate Uptime Score
    $uptime_score = 0;
    $uptime_grade = 'F';
    $custom_uptime_ratio = $monitor_data['custom_uptime_ratio'] ?? '';
    $monitor_status = $monitor_data['status'] ?? 0;
    $monitor_status_text = $monitor_data['status_text'] ?? '';
    
    // Log for debugging
    error_log('BOCM Overview: Uptime calculation - Custom ratio: ' . (is_string($custom_uptime_ratio) ? $custom_uptime_ratio : 'N/A') . ', Status: ' . $monitor_status . ' (' . $monitor_status_text . ')');
    
    // Handle both string and float values
    if (is_string($custom_uptime_ratio) && strpos($custom_uptime_ratio, '-') !== false) {
        // Handle string format with multiple values
        $valid_uptimes = array_filter(explode('-', $custom_uptime_ratio), function($value) {
            return (float)$value > 0.001;
        });
        if (!empty($valid_uptimes)) {
            $uptime_score = array_sum($valid_uptimes) / count($valid_uptimes);
        }
    } elseif (!empty($custom_uptime_ratio)) {
        // Single value
        $uptime_score = (float)$custom_uptime_ratio;
    }
    
    // Log calculated score
    error_log('BOCM Overview: Calculated uptime score: ' . $uptime_score);
    
    // Calculate grade based on uptime percentage
    $uptime_grade = match(true) {
        $uptime_score >= 99.9 => 'A',
        $uptime_score >= 99.5 => 'B',
        $uptime_score >= 99.2 => 'C',
        $uptime_score >= 99.0 => 'D',
        default => 'F',
    };

    // Determine display status
    $display_uptime_data = $has_monitor && !empty($monitor_data) && ($uptime_score > 0 || !empty($custom_uptime_ratio));
    $monitor_is_checking = $has_monitor && !empty($monitor_data) && $monitor_status == 1; // Status 1 means "Not Checked Yet"
    $monitor_is_initializing = $has_monitor && (empty($monitor_data) || $monitor_status == 0 || $uptime_score <= 0); // Status 0 means "Paused"
    $need_ajax_retry = $has_monitor && empty($monitor_data) && $retry_attempts >= $max_retries;
    $is_monitor_configured = !empty($uptime_monitor_id); // Added explicit check for configured monitor
    
    error_log('BOCM Overview: Display decision - Has monitor: ' . ($has_monitor ? 'Yes' : 'No') . 
              ', Display data: ' . ($display_uptime_data ? 'Yes' : 'No') . 
              ', Is checking: ' . ($monitor_is_checking ? 'Yes' : 'No') . 
              ', Is initializing: ' . ($monitor_is_initializing ? 'Yes' : 'No') . 
              ', Need AJAX retry: ' . ($need_ajax_retry ? 'Yes' : 'No') . 
              ', Is configured: ' . ($is_monitor_configured ? 'Yes' : 'No'));
    ?>
    
    <!-- Uptime Score Card -->
    <div class="bocm-score-card" id="bocm-uptime-card" data-monitor-id="<?php echo esc_attr($uptime_monitor_id); ?>" data-need-retry="<?php echo $need_ajax_retry ? 'true' : 'false'; ?>">
        <div class="bocm-score-header">
            <h3><?php _e('Uptime', 'blue-oak-client-management'); ?></h3>
            <?php if ($display_uptime_data): ?>
                <div class="bocm-grade <?php echo strtolower($uptime_grade); ?>">
                    <svg class="grade-hexagon" height="64" viewBox="0 0 64 64" width="64" xmlns="http://www.w3.org/2000/svg">
                        <path class="hex-bg" d="M 57.212 46.562 L 32.004 61.116 L 6.797 46.562 L 6.797 17.457 L 32.004 2.903 L 57.212 17.457 Z" stroke-width="5"></path>
                        <text x="50%" y="50%" text-anchor="middle" dy=".3em" class="grade-text"><?php echo $uptime_grade; ?></text>
                    </svg>
                </div>
            <?php else: ?>
                <div class="bocm-scanning shimmer">
                    <div class="bocm-scanning-spinner"></div>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($display_uptime_data): ?>
            <div class="bocm-score-value"><?php echo number_format($uptime_score, 2); ?>%</div>
            <div class="bocm-score-label"><?php _e('30-Day Uptime', 'blue-oak-client-management'); ?></div>
        <?php elseif ($monitor_is_checking): ?>
            <div class="bocm-score-value shimmer"><?php _e('Checking...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Monitor is being checked', 'blue-oak-client-management'); ?></div>
        <?php elseif ($monitor_is_initializing): ?>
            <div class="bocm-score-value shimmer"><?php _e('Initializing...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Collecting uptime data', 'blue-oak-client-management'); ?></div>
        <?php elseif ($has_monitor && empty($monitor_data)): ?>
            <div class="bocm-score-value shimmer"><?php _e('Connection issue', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Monitoring is active, please check back soon', 'blue-oak-client-management'); ?></div>
        <?php elseif ($need_ajax_retry): ?>
            <div class="bocm-score-value shimmer"><?php _e('Loading...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Fetching monitor data', 'blue-oak-client-management'); ?></div>
        <?php elseif ($is_monitor_configured): ?>
            <div class="bocm-score-value shimmer"><?php _e('Activating...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Monitor is configured but data is not yet available', 'blue-oak-client-management'); ?></div>
        <?php else: ?>
            <div class="bocm-score-value"><?php _e('Not configured', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('No uptime monitoring set up', 'blue-oak-client-management'); ?></div>
        <?php endif; ?>
    </div>
    
    <!-- Performance Card -->
    <div class="bocm-score-card">
        <div class="bocm-score-header">
            <h3><?php _e('Performance', 'blue-oak-client-management'); ?></h3>
            <?php
            // Check if we have recent PageSpeed data
            $pagespeed_data = get_user_meta($user->ID, 'bocm_pagespeed_data', true);
            $pagespeed_timestamp = get_user_meta($user->ID, 'bocm_pagespeed_timestamp', true);
            
            // Define what "fresh" data means - 1 week
            $data_fresh = !empty($pagespeed_timestamp) && ($pagespeed_timestamp > (time() - 7 * DAY_IN_SECONDS));
            
            // If the data is fresh and valid, calculate score and grade
            $performance_score = 0;
            $performance_grade = 'F';
            
            if ($data_fresh && !empty($pagespeed_data) && is_array($pagespeed_data)) {
                $performance_score = $pagespeed_data['desktop_score'] ?? 0;
                
                // Calculate grade based on performance score
                $performance_grade = match(true) {
                    $performance_score >= 90 => 'A',
                    $performance_score >= 80 => 'B',
                    $performance_score >= 70 => 'C',
                    $performance_score >= 60 => 'D',
                    default => 'F',
                };
            } else {
                // Data is not fresh or non-existent, schedule a scan
                if (!empty($website_url)) {
                    // Schedule a one-time scan
                    $next_scan = wp_next_scheduled('bocm_pagespeed_scan_single', [$user->ID, $website_url]);
                    if (!$next_scan) {
                        wp_schedule_single_event(time() + 60, 'bocm_pagespeed_scan_single', [$user->ID, $website_url]);
                        error_log('BOCM Overview: Scheduled on-demand PageSpeed scan, user_id: ' . $user->ID . ', url: ' . $website_url);
                    }
                }
            }
            ?>
            
            <?php if ($data_fresh): ?>
                <div class="bocm-grade <?php echo strtolower($performance_grade); ?>">
                    <svg class="grade-hexagon" height="64" viewBox="0 0 64 64" width="64" xmlns="http://www.w3.org/2000/svg">
                        <path class="hex-bg" d="M 57.212 46.562 L 32.004 61.116 L 6.797 46.562 L 6.797 17.457 L 32.004 2.903 L 57.212 17.457 Z" stroke-width="5"></path>
                        <text x="50%" y="50%" text-anchor="middle" dy=".3em" class="grade-text"><?php echo $performance_grade; ?></text>
                    </svg>
                </div>
            <?php else: ?>
                <div class="bocm-scanning">
                    <div class="bocm-scanning-spinner"></div>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if ($data_fresh): ?>
            <div class="bocm-score-value"><?php echo $performance_score; ?></div>
            <div class="bocm-score-label"><?php _e('PageSpeed Score', 'blue-oak-client-management'); ?></div>
        <?php else: ?>
            <div class="bocm-score-value"><?php _e('Scanning...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('Analyzing website speed', 'blue-oak-client-management'); ?></div>
        <?php endif; ?>
    </div>
    
    <!-- Security Score Card -->
    <div class="bocm-score-card">
        <div class="bocm-score-header">
            <h3><?php _e('Security', 'blue-oak-client-management'); ?></h3>
            <?php
            // Get Site Health information
            $site_health = get_transient('health-check-site-status-result');
            
            // If transient doesn't exist, calculate score
            if (false === $site_health) {
                if (class_exists('WP_Site_Health')) {
                    $health_check = new WP_Site_Health();
                    $health_check->get_site_status();
                    $site_health = get_transient('health-check-site-status-result');
                } else {
                    $site_health = array('percentage' => 0);
                }
            }
            
            // Calculate security grade based on site health score
            $security_score = $site_health['percentage'] ?? 0;
            $security_grade = match(true) {
                $security_score >= 90 => 'A',
                $security_score >= 80 => 'B',
                $security_score >= 70 => 'C',
                $security_score >= 60 => 'D',
                default => 'F',
            };
            ?>
            <div class="bocm-grade <?php echo strtolower($security_grade); ?>">
                <svg class="grade-hexagon" height="64" viewBox="0 0 64 64" width="64" xmlns="http://www.w3.org/2000/svg">
                    <path class="hex-bg" d="M 57.212 46.562 L 32.004 61.116 L 6.797 46.562 L 6.797 17.457 L 32.004 2.903 L 57.212 17.457 Z" stroke-width="5"></path>
                    <text x="50%" y="50%" text-anchor="middle" dy=".3em" class="grade-text"><?php echo $security_grade; ?></text>
                </svg>
            </div>
        </div>
        <div class="bocm-score-value"><?php echo $security_score; ?></div>
        <div class="bocm-score-label"><?php _e('Site Health Score', 'blue-oak-client-management'); ?></div>
    </div>
</div>

<!-- Purchase History Modal -->
<div id="bocm-purchase-modal" class="bocm-modal">
    <div class="bocm-modal-content">
        <div class="bocm-modal-header">
            <h3><?php _e('Your Purchase History', 'blue-oak-client-management'); ?></h3>
            <span class="bocm-modal-close">&times;</span>
        </div>
        <div class="bocm-modal-body">
            <?php
            // Get the user's Partner Account Group ID
            $partner_account_group_id = get_user_meta($user->ID, 'bocm_partner_account_group_id', true);
            
            if (empty($partner_account_group_id)) {
                // No Partner Account Group ID assigned
                ?>
                <div class="bocm-no-account-group">
                    <p><?php _e('No Partner Group ID Assigned. Please contact support.', 'blue-oak-client-management'); ?></p>
                    <?php if (current_user_can('manage_options')): ?>
                        <p class="bocm-error-details">
                            <?php _e('Admin Info: Partner Account Group ID not found in user metadata. Please go to Users → Edit User → Blue Oak Settings and assign a Partner Account Group ID.', 'blue-oak-client-management'); ?>
                        </p>
                    <?php endif; ?>
                </div>
                <?php
            } else {
                // Check if Vendasta is configured
                $vendasta_credentials = get_option('bocm_vendasta_service_account', '');
                
                if (empty($vendasta_credentials)) {
                    // Vendasta credentials not configured
                    ?>
                    <div class="bocm-purchases-error">
                        <p><?php _e('Purchase data is currently unavailable. Please contact support.', 'blue-oak-client-management'); ?></p>
                        <?php if (current_user_can('manage_options')): ?>
                            <p class="bocm-error-details"><?php _e('Vendasta API credentials not configured in plugin settings.', 'blue-oak-client-management'); ?></p>
                        <?php endif; ?>
                    </div>
                    <?php
                } else {
                    // Initialize Vendasta API
                    $vendasta = new Vendasta();
                    
                    try {
                        // Fetch purchases
                        $purchases = $vendasta->get_purchases($partner_account_group_id);
                        
                        if (empty($purchases)) {
                            // No purchases found
                            ?>
                            <div class="bocm-no-purchases">
                                <p><?php _e('No purchases found for your account.', 'blue-oak-client-management'); ?></p>
                                <?php if (current_user_can('manage_options')): ?>
                                    <p class="bocm-error-details">
                                        <?php _e('Admin Info: No purchase records found with this Partner Account Group ID. Ensure the ID matches a customer ID in your Vendasta account.', 'blue-oak-client-management'); ?>
                                    </p>
                                <?php endif; ?>
                            </div>
                            <?php
                        } else {
                            // Filter out duplicate SKUs and keep only the most recent one
                            $unique_purchases = [];
                            $seen_skus = [];
                            
                            // Sort purchases by date (newest first)
                            usort($purchases, function($a, $b) {
                                $date_a = strtotime($a['start_date'] ?? '0');
                                $date_b = strtotime($b['start_date'] ?? '0');
                                return $date_b - $date_a; // Newest first
                            });
                            
                            // Keep only the first occurrence of each SKU (which will be the most recent)
                            foreach ($purchases as $purchase) {
                                $sku = $purchase['product_id'];
                                if (!in_array($sku, $seen_skus)) {
                                    $seen_skus[] = $sku;
                                    $unique_purchases[] = $purchase;
                                }
                            }
                            
                            // Display purchases table with unique SKUs
                            ?>
                            <div class="bocm-purchases-table-wrapper">
                                <table class="bocm-purchases-table">
                                    <thead>
                                        <tr>
                                            <th><?php _e('Product', 'blue-oak-client-management'); ?></th>
                                            <th><?php _e('Status', 'blue-oak-client-management'); ?></th>
                                            <th><?php _e('Purchase Date', 'blue-oak-client-management'); ?></th>
                                            <th><?php _e('Price', 'blue-oak-client-management'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($unique_purchases as $purchase): ?>
                                            <?php 
                                            $status_class = 'active';
                                            if ($purchase['status'] === 'Paid') {
                                                $status_class = 'active';
                                            } elseif ($purchase['status'] === 'Cancelled' || $purchase['status'] === 'Canceled') {
                                                $status_class = 'cancelled';
                                            } elseif ($purchase['status'] === 'Pending') {
                                                $status_class = 'pending';
                                            } else {
                                                $status_class = strtolower($purchase['status']);
                                            }
                                            ?>
                                            <tr data-sku="<?php echo esc_attr($purchase['product_id']); ?>">
                                                <td><?php echo esc_html($purchase['product_name']); ?></td>
                                                <td>
                                                    <span class="bocm-purchase-status bocm-status-<?php echo esc_attr($status_class); ?>">
                                                        <?php echo esc_html($purchase['status']); ?>
                                                    </span>
                                                </td>
                                                <td><?php echo !empty($purchase['start_date']) ? esc_html(date_i18n(get_option('date_format'), strtotime($purchase['start_date']))) : '-'; ?></td>
                                                <td>
                                                    <?php 
                                                    if ($purchase['price'] > 0) {
                                                        $formatted_price = number_format($purchase['price'] / 100, 2); // Convert cents to dollars
                                                        echo '$' . esc_html($formatted_price) . ' ' . esc_html($purchase['currency']);
                                                    } else {
                                                        _e('Free', 'blue-oak-client-management');
                                                    }
                                                    ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php
                        }
                    } catch (\Exception $e) {
                        // Error fetching purchases
                        ?>
                        <div class="bocm-purchases-error">
                            <p><?php _e('Unable to retrieve purchase information. Please try again later.', 'blue-oak-client-management'); ?></p>
                            <?php if (current_user_can('manage_options')): ?>
                                <p class="bocm-error-details"><?php echo esc_html($e->getMessage()); ?></p>
                            <?php endif; ?>
                        </div>
                        <?php
                    }
                }
            }
            ?>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Uptime Card AJAX refresh functionality
    var $uptimeCard = $('#bocm-uptime-card');
    var monitorId = $uptimeCard.data('monitor-id');
    var needRetry = $uptimeCard.data('need-retry') === true;
    var retryCount = 0;
    var maxRetries = 3;
    var retryDelay = 2000; // 2 seconds
    
    function refreshUptimeData() {
        if (!monitorId) {
            console.log('No monitor ID found, skipping uptime refresh');
            return;
        }
        
        console.log('Refreshing uptime data via AJAX, attempt ' + (retryCount + 1));
        
        // Add loading indicators
        $uptimeCard.find('.bocm-score-value, .bocm-score-label').addClass('shimmer');
        
        $.ajax({
            url: ajaxurl || '/wp-admin/admin-ajax.php', // Use global ajaxurl if available
            type: 'POST',
            data: {
                action: 'bocm_refresh_uptime_data',
                user_id: <?php echo intval($user->ID); ?>,
                monitor_id: monitorId,
                nonce: '<?php echo wp_create_nonce('bocm_uptime_refresh'); ?>'
            },
            success: function(response) {
                console.log('Uptime refresh successful');
                if (response.success) {
                    // Update the card content
                    $uptimeCard.html(response.data.html);
                    
                    // Remove any retry timers
                    if (window.bocmUptimeRetryTimer) {
                        clearTimeout(window.bocmUptimeRetryTimer);
                    }
                } else {
                    console.error('Uptime refresh failed:', response.data.message);
                    
                    // Schedule a retry if we haven't hit the max retries
                    if (retryCount < maxRetries) {
                        retryCount++;
                        console.log('Scheduling retry ' + retryCount + ' in ' + (retryDelay / 1000) + ' seconds');
                        window.bocmUptimeRetryTimer = setTimeout(refreshUptimeData, retryDelay);
                        
                        // Increase delay for each retry (exponential backoff)
                        retryDelay *= 1.5;
                    } else {
                        console.error('Max retries reached, giving up');
                        $uptimeCard.find('.bocm-score-value').removeClass('shimmer').text('<?php _e('Error', 'blue-oak-client-management'); ?>');
                        $uptimeCard.find('.bocm-score-label').removeClass('shimmer').text('<?php _e('Could not load uptime data', 'blue-oak-client-management'); ?>');
                    }
                }
            },
            error: function(xhr, status, error) {
                console.error('AJAX error:', error);
                
                // Schedule a retry if we haven't hit the max retries
                if (retryCount < maxRetries) {
                    retryCount++;
                    console.log('Scheduling retry ' + retryCount + ' in ' + (retryDelay / 1000) + ' seconds');
                    window.bocmUptimeRetryTimer = setTimeout(refreshUptimeData, retryDelay);
                    
                    // Increase delay for each retry (exponential backoff)
                    retryDelay *= 1.5;
                } else {
                    console.error('Max retries reached, giving up');
                    $uptimeCard.find('.bocm-score-value').removeClass('shimmer').text('<?php _e('Error', 'blue-oak-client-management'); ?>');
                    $uptimeCard.find('.bocm-score-label').removeClass('shimmer').text('<?php _e('Could not load uptime data', 'blue-oak-client-management'); ?>');
                }
            }
        });
    }
    
    // Initialize uptime data refresh if needed
    if (needRetry && monitorId) {
        // Wait a short time before starting the AJAX refresh
        setTimeout(function() {
            refreshUptimeData();
        }, 500);
    }
});
</script> 