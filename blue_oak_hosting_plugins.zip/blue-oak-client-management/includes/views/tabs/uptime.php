<?php
/**
 * Uptime tab content for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Pass incident data to JavaScript
?>
<script>
    // Initialize incident data
    window.dayIncidents = <?php echo json_encode($day_incidents); ?>;
    window.weekIncidents = <?php echo json_encode($week_incidents); ?>;
    window.monthIncidents = <?php echo json_encode($month_incidents); ?>;
    window.ninetyDayIncidents = <?php echo json_encode(array_filter($logs, function($log) {
        return $log['datetime'] >= strtotime('-90 days') && $log['type'] === 1;
    })); ?>;
</script>

<!-- Uptime Period Cards -->
<div class="bocm-period-grid">
    <!-- Last 24 Hours -->
    <div class="bocm-portal-card">
        <h3><?php _e('Last 24 hours', 'blue-oak-client-management'); ?></h3>
        <div class="bocm-uptime-value"><?php echo number_format($day_uptime, 2); ?>%</div>
        <div class="bocm-incident-count"><?php printf(_n('%d incident', '%d incidents', count($day_incidents), 'blue-oak-client-management'), count($day_incidents)); ?></div>
    </div>

    <!-- Last 7 Days -->
    <div class="bocm-portal-card">
        <h3><?php _e('Last 7 days', 'blue-oak-client-management'); ?></h3>
        <div class="bocm-uptime-value"><?php echo number_format($week_uptime, 2); ?>%</div>
        <div class="bocm-incident-count"><?php printf(_n('%d incident', '%d incidents', count($week_incidents), 'blue-oak-client-management'), count($week_incidents)); ?></div>
    </div>

    <!-- Last 30 Days -->
    <div class="bocm-portal-card">
        <h3><?php _e('Last 30 days', 'blue-oak-client-management'); ?></h3>
        <div class="bocm-uptime-value"><?php echo number_format($month_uptime, 2); ?>%</div>
        <div class="bocm-incident-count"><?php printf(_n('%d incident', '%d incidents', count($month_incidents), 'blue-oak-client-management'), count($month_incidents)); ?></div>
    </div>

    <!-- Last 90 Days -->
    <div class="bocm-portal-card">
        <h3><?php _e('Last 90 days', 'blue-oak-client-management'); ?></h3>
        <div class="bocm-uptime-value"><?php echo number_format($ninety_day_uptime, 2); ?>%</div>
        <div class="bocm-incident-count"><?php 
            $ninety_day_incidents = array_filter($logs, function($log) {
                return $log['datetime'] >= strtotime('-90 days') && $log['type'] === 1;
            });
            printf(_n('%d incident', '%d incidents', count($ninety_day_incidents), 'blue-oak-client-management'), count($ninety_day_incidents));
        ?></div>
    </div>
</div>

<!-- Last 90 Days Uptime -->
<div class="bocm-portal-card">
    <div class="bocm-uptime-header">
        <h3><?php _e('Uptime', 'blue-oak-client-management'); ?> <span class="bocm-subtitle"><?php _e('Last 90 days', 'blue-oak-client-management'); ?></span></h3>
        <div class="bocm-last-check-info">
            <?php 
            if (is_array($monitor_data) && isset($monitor_data['last_check'])) {
                echo "Last checked: " . wp_date('F j, Y g:i A', $monitor_data['last_check']);
            } else {
                echo "Last checked: " . __('No data available', 'blue-oak-client-management');
            }
            ?>
            <span class="bocm-check-frequency"><?php _e('(Checked every 5 minutes)', 'blue-oak-client-management'); ?></span>
        </div>
    </div>
    <div class="bocm-90-days-chart">
        <?php 
        // Get daily uptime data for last 90 days
        $daily_uptimes = array();
        $api_error = false;
        
        if (empty($uptime_monitor_id)) {
            echo '<div class="bocm-error-message">' . __('No uptime monitor is configured for this account.', 'blue-oak-client-management') . '</div>';
        } else {
            try {
                $daily_uptimes = $this->uptime_robot->get_daily_uptime($uptime_monitor_id, 90);
                
                if (empty($daily_uptimes)) {
                    echo '<div class="bocm-error-message">' . __('Unable to retrieve uptime data at this time. This could be due to temporary API limits or network issues.', 'blue-oak-client-management') . '</div>';
                    $api_error = true;
                }
            } catch (Exception $e) {
                error_log('BOCM Uptime Tab Error: ' . $e->getMessage());
                echo '<div class="bocm-error-message">' . __('An error occurred while retrieving uptime data.', 'blue-oak-client-management') . '</div>';
                $api_error = true;
            }
        }
        
        if (!empty($daily_uptimes) && !$api_error): 
        ?>
        <svg width="100%" height="30" preserveAspectRatio="none">
            <?php
            $total_days = count($daily_uptimes);
            $bar_width = 6;
            $bar_spacing = 2;
            $total_width = ($bar_width + $bar_spacing) * $total_days;
            
            foreach ($daily_uptimes as $index => $day) {
                $x = $index * ($bar_width + $bar_spacing);
                $uptime = $day['uptime'];
                $date = wp_date('F j, Y', strtotime($day['date']));
                
                // Use grey for missing data (null or 0%), otherwise use normal color scheme
                $color = ($uptime === null || (float)$uptime <= 0.001) ? '#cbd5e0' : ($uptime >= 99.9 ? '#3bd671' : ($uptime >= 95 ? '#ffd050' : '#ff4d4d'));
                
                $tooltip_data = [
                    'date' => $date,
                    'uptime' => ($uptime === null || (float)$uptime <= 0.001) ? 'No Record' : number_format($uptime, 2) . '% uptime'
                ];
                
                printf(
                    '<rect height="30" width="%d" x="%d" y="0" fill="%s" rx="3" ry="3" data-tooltip="%s" style="cursor: pointer;"/>',
                    $bar_width,
                    $x,
                    $color,
                    esc_attr(json_encode($tooltip_data))
                );
            }
            ?>
        </svg>
        <?php endif; ?>
    </div>
</div>

<!-- Response Time Graph -->
<div class="bocm-portal-card">
    <div class="bocm-response-header">
        <div class="bocm-response-side">
            <h3><?php _e('Response time', 'blue-oak-client-management'); ?></h3>
        </div>
    </div>
    <?php 
    $response_times = array();
    $times = array();
    
    if (!empty($uptime_monitor_id)) {
        try {
            $response_times = $this->uptime_robot->get_response_times($uptime_monitor_id, 24);
            $times = array_map(function($rt) { return $rt['value']; }, $response_times);
        } catch (Exception $e) {
            error_log('BOCM Uptime Tab Error (Response Times): ' . $e->getMessage());
        }
    }
    
    if (empty($times)): 
    ?>
    <div class="bocm-error-message"><?php _e('No response time data available at this time.', 'blue-oak-client-management'); ?></div>
    <?php else: ?>
    <div class="bocm-response-stats">
        <div class="bocm-stat">
            <span class="bocm-stat-label"><?php _e('Average', 'blue-oak-client-management'); ?></span>
            <span class="bocm-stat-value"><?php echo !empty($times) ? round(array_sum($times) / count($times)) : '-'; ?> ms</span>
        </div>
        <div class="bocm-stat">
            <span class="bocm-stat-label"><?php _e('Min', 'blue-oak-client-management'); ?></span>
            <span class="bocm-stat-value"><?php echo !empty($times) ? min($times) : '-'; ?> ms</span>
        </div>
        <div class="bocm-stat">
            <span class="bocm-stat-label"><?php _e('Max', 'blue-oak-client-management'); ?></span>
            <span class="bocm-stat-value"><?php echo !empty($times) ? max($times) : '-'; ?> ms</span>
        </div>
    </div>
    <div id="responseTimeChart"></div>
    <?php endif; ?>
</div> 