<?php
/**
 * Google Ads tab view for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement\Views\Tabs;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>

<!-- Google Ads Tab Content -->
<div class="bocm-tab-content">
    <!-- Performance Overview Card -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Performance Overview', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-ads-metrics-grid">
            <div class="bocm-ads-metric-card shimmer">
                <div class="bocm-ads-metric-icon">
                    <i class="fas fa-eye"></i>
                </div>
                <div class="bocm-ads-metric-content">
                    <span class="bocm-ads-metric-value">12,345</span>
                    <span class="bocm-ads-metric-label"><?php _e('Impressions', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-ads-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>15.2%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-ads-metric-card shimmer">
                <div class="bocm-ads-metric-icon">
                    <i class="fas fa-mouse-pointer"></i>
                </div>
                <div class="bocm-ads-metric-content">
                    <span class="bocm-ads-metric-value">1,234</span>
                    <span class="bocm-ads-metric-label"><?php _e('Clicks', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-ads-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>8.7%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-ads-metric-card shimmer">
                <div class="bocm-ads-metric-icon">
                    <i class="fas fa-percentage"></i>
                </div>
                <div class="bocm-ads-metric-content">
                    <span class="bocm-ads-metric-value">10.2%</span>
                    <span class="bocm-ads-metric-label"><?php _e('CTR', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-ads-metric-change positive">
                        <i class="fas fa-arrow-up"></i>
                        <span>1.2%</span>
                    </span>
                </div>
            </div>
            <div class="bocm-ads-metric-card shimmer">
                <div class="bocm-ads-metric-icon">
                    <i class="fas fa-dollar-sign"></i>
                </div>
                <div class="bocm-ads-metric-content">
                    <span class="bocm-ads-metric-value">$2.45</span>
                    <span class="bocm-ads-metric-label"><?php _e('Average CPC', 'blue-oak-client-management'); ?></span>
                    <span class="bocm-ads-metric-change negative">
                        <i class="fas fa-arrow-down"></i>
                        <span>$0.15</span>
                    </span>
                </div>
            </div>
        </div>
    </div>

    <!-- Performance Chart -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Campaign Performance', 'blue-oak-client-management'); ?></h3>
            <div class="bocm-card-actions">
                <button class="bocm-chart-type active" data-type="line">
                    <i class="fas fa-chart-line"></i>
                </button>
                <button class="bocm-chart-type" data-type="bar">
                    <i class="fas fa-chart-column"></i>
                </button>
                <div class="bocm-date-range-selector">
                    <select id="adsPerformanceRange">
                        <option value="7"><?php _e('Last 7 days', 'blue-oak-client-management'); ?></option>
                        <option value="28" selected><?php _e('Last 28 days', 'blue-oak-client-management'); ?></option>
                        <option value="90"><?php _e('Last 3 months', 'blue-oak-client-management'); ?></option>
                    </select>
                </div>
            </div>
        </div>
        <div id="adsPerformanceChart" class="bocm-chart-container shimmer"></div>
    </div>

    <!-- Top Campaigns -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Top Performing Campaigns', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-ads-campaigns-table shimmer">
            <table class="bocm-table">
                <thead>
                    <tr>
                        <th><?php _e('Campaign', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Budget', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Clicks', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Impressions', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('CTR', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Avg. CPC', 'blue-oak-client-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Brand Awareness</td>
                        <td>$500/day</td>
                        <td>456</td>
                        <td>8,790</td>
                        <td>5.2%</td>
                        <td>$2.15</td>
                    </tr>
                    <tr>
                        <td>Website Design Services</td>
                        <td>$300/day</td>
                        <td>234</td>
                        <td>5,670</td>
                        <td>4.1%</td>
                        <td>$2.45</td>
                    </tr>
                    <tr>
                        <td>SEO Services</td>
                        <td>$250/day</td>
                        <td>189</td>
                        <td>4,560</td>
                        <td>4.1%</td>
                        <td>$2.65</td>
                    </tr>
                    <tr>
                        <td>Local Business</td>
                        <td>$200/day</td>
                        <td>123</td>
                        <td>3,450</td>
                        <td>3.6%</td>
                        <td>$2.85</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Top Keywords -->
    <div class="bocm-portal-card">
        <div class="bocm-card-header">
            <h3><?php _e('Top Keywords', 'blue-oak-client-management'); ?></h3>
        </div>
        <div class="bocm-ads-keywords-table shimmer">
            <table class="bocm-table">
                <thead>
                    <tr>
                        <th><?php _e('Keyword', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Match Type', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Clicks', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Impressions', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('CTR', 'blue-oak-client-management'); ?></th>
                        <th><?php _e('Avg. CPC', 'blue-oak-client-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>digital marketing agency</td>
                        <td>Phrase</td>
                        <td>245</td>
                        <td>3,420</td>
                        <td>7.2%</td>
                        <td>$2.35</td>
                    </tr>
                    <tr>
                        <td>website design services</td>
                        <td>Broad</td>
                        <td>189</td>
                        <td>4,567</td>
                        <td>4.1%</td>
                        <td>$2.45</td>
                    </tr>
                    <tr>
                        <td>seo company near me</td>
                        <td>Exact</td>
                        <td>156</td>
                        <td>3,890</td>
                        <td>4.0%</td>
                        <td>$2.65</td>
                    </tr>
                    <tr>
                        <td>local seo services</td>
                        <td>Phrase</td>
                        <td>134</td>
                        <td>2,980</td>
                        <td>4.5%</td>
                        <td>$2.85</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div> 