<?php
/**
 * Google Analytics tab view for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement\Views\Tabs;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

// Get the user's Google Analytics property ID
$user = wp_get_current_user();
$property_id = get_user_meta($user->ID, 'bocm_ga_property_id', true);

// Get property options to retrieve the property name
$ga_instance = new \BlueOak\ClientManagement\GoogleAnalytics();
$ga_options = $ga_instance->get_property_options();

// If property exists in options, extract the name (format is "Property Name (PropertyID)")
$property_name = '';
if (isset($ga_options[$property_id])) {
    // Extract property name from the format: "Property Name (PropertyID)"
    $option_string = $ga_options[$property_id];
    if (preg_match('/(.+) \([^)]+\)$/', $option_string, $matches)) {
        $property_name = $matches[1];
    }
}

// Default time period (30 days)
$default_period = 30;
?>

<!-- Google Analytics Tab Content -->
<div class="bocm-tab-content">
    <?php if (empty($property_id)): ?>
        <!-- No Google Analytics Property Configured -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Google Analytics Not Configured', 'blue-oak-client-management'); ?></h3>
            </div>
            <div class="bocm-card-content">
                <p><?php _e('No Google Analytics property has been configured for your account. Please contact your administrator to set up Google Analytics tracking for your website.', 'blue-oak-client-management'); ?></p>
            </div>
        </div>
    <?php else: ?>
        <!-- Global Date Range Filter -->
        <div class="bocm-portal-card bocm-date-filter-card">
            <div class="bocm-card-header">
                <h3><?php _e('Analytics Time Period', 'blue-oak-client-management'); ?></h3>
                <div class="bocm-global-date-range-selector">
                    <select id="bocmGlobalDateRange">
                        <option value="7"><?php _e('Last 7 days', 'blue-oak-client-management'); ?></option>
                        <option value="14"><?php _e('Last 14 days', 'blue-oak-client-management'); ?></option>
                        <option value="30" selected><?php _e('Last 30 days', 'blue-oak-client-management'); ?></option>
                        <option value="60"><?php _e('Last 60 days', 'blue-oak-client-management'); ?></option>
                        <option value="90"><?php _e('Last 90 days', 'blue-oak-client-management'); ?></option>
                    </select>
                    <button id="bocmUpdateAnalytics" class="bocm-button bocm-primary-button">
                        <i class="fas fa-sync-alt"></i> <?php _e('Update Data', 'blue-oak-client-management'); ?>
                    </button>
                </div>
            </div>
        </div>

        <!-- Summary Stats -->
        <div class="bocm-analytics-grid">
            <div class="bocm-portal-card">
                <div class="bocm-card-header">
                    <h3>
                        <?php _e('Summary Stats', 'blue-oak-client-management'); ?>
                    </h3>
                    <div class="bocm-ga-property-id" title="<?php esc_attr_e('Google Analytics Property', 'blue-oak-client-management'); ?>">
                        <?php 
                        echo esc_html($property_id);
                        if (!empty($property_name)) {
                            echo ' (' . esc_html($property_name) . ')';
                        }
                        ?>
                    </div>
                </div>
                <div class="bocm-analytics-summary-grid">
                    <div class="bocm-analytics-metric-card shimmer">
                        <div class="bocm-analytics-metric-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <div class="bocm-analytics-metric-content">
                            <span class="bocm-analytics-metric-value">1,234</span>
                            <span class="bocm-analytics-metric-label"><?php _e('Active Users', 'blue-oak-client-management'); ?></span>
                            <span class="bocm-analytics-metric-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>12.5%</span>
                            </span>
                        </div>
                    </div>
                    <div class="bocm-analytics-metric-card shimmer">
                        <div class="bocm-analytics-metric-icon">
                            <i class="fas fa-clock"></i>
                        </div>
                        <div class="bocm-analytics-metric-content">
                            <span class="bocm-analytics-metric-value">2:45</span>
                            <span class="bocm-analytics-metric-label"><?php _e('Avg. Session Duration', 'blue-oak-client-management'); ?></span>
                            <span class="bocm-analytics-metric-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>8.3%</span>
                            </span>
                        </div>
                    </div>
                    <div class="bocm-analytics-metric-card shimmer">
                        <div class="bocm-analytics-metric-icon">
                            <i class="fas fa-percent"></i>
                        </div>
                        <div class="bocm-analytics-metric-content">
                            <span class="bocm-analytics-metric-value">45.2%</span>
                            <span class="bocm-analytics-metric-label"><?php _e('Bounce Rate', 'blue-oak-client-management'); ?></span>
                            <span class="bocm-analytics-metric-change negative">
                                <i class="fas fa-arrow-down"></i>
                                <span>2.1%</span>
                            </span>
                        </div>
                    </div>
                    <div class="bocm-analytics-metric-card shimmer">
                        <div class="bocm-analytics-metric-icon">
                            <i class="fas fa-eye"></i>
                        </div>
                        <div class="bocm-analytics-metric-content">
                            <span class="bocm-analytics-metric-value">3.5</span>
                            <span class="bocm-analytics-metric-label"><?php _e('Pages/Session', 'blue-oak-client-management'); ?></span>
                            <span class="bocm-analytics-metric-change positive">
                                <i class="fas fa-arrow-up"></i>
                                <span>0.5</span>
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- User Types Chart -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('User Types', 'blue-oak-client-management'); ?></h3>
            </div>
            <div id="userTypesChart" class="bocm-chart-container shimmer"></div>
        </div>

        <!-- Device Category and Top Countries -->
        <div class="bocm-analytics-grid">
            <div class="bocm-portal-card">
                <div class="bocm-card-header">
                    <h3><?php _e('Device Category', 'blue-oak-client-management'); ?></h3>
                </div>
                <div id="deviceCategoryChart" class="bocm-chart-container shimmer"></div>
            </div>
            <div class="bocm-portal-card">
                <div class="bocm-card-header">
                    <h3><?php _e('Top Countries', 'blue-oak-client-management'); ?></h3>
                </div>
                <div id="topCountriesChart" class="bocm-chart-container shimmer"></div>
            </div>
        </div>

        <!-- Countries Map -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Active Users by Country', 'blue-oak-client-management'); ?></h3>
            </div>
            <div id="countriesMapChart" class="bocm-chart-container shimmer"></div>
        </div>

        <!-- Operating System and Browser -->
        <div class="bocm-analytics-grid">
            <div class="bocm-portal-card">
                <div class="bocm-card-header">
                    <h3><?php _e('Operating System', 'blue-oak-client-management'); ?></h3>
                </div>
                <div id="osChart" class="bocm-chart-container shimmer"></div>
            </div>
            <div class="bocm-portal-card">
                <div class="bocm-card-header">
                    <h3><?php _e('Browser', 'blue-oak-client-management'); ?></h3>
                </div>
                <div id="browserChart" class="bocm-chart-container shimmer"></div>
            </div>
        </div>

        <!-- Trends Chart -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Trends', 'blue-oak-client-management'); ?></h3>
                <div class="bocm-card-actions">
                    <button class="bocm-chart-type active" data-type="bar">
                        <i class="fas fa-chart-column"></i>
                    </button>
                    <button class="bocm-chart-type" data-type="line">
                        <i class="fas fa-chart-line"></i>
                    </button>
                    <div class="bocm-date-range-selector">
                        <select id="analyticsPerformanceRange">
                            <option value="7"><?php _e('Last 7 days', 'blue-oak-client-management'); ?></option>
                            <option value="14"><?php _e('Last 14 days', 'blue-oak-client-management'); ?></option>
                            <option value="30" selected><?php _e('Last 30 days', 'blue-oak-client-management'); ?></option>
                            <option value="60"><?php _e('Last 60 days', 'blue-oak-client-management'); ?></option>
                            <option value="90"><?php _e('Last 90 days', 'blue-oak-client-management'); ?></option>
                        </select>
                    </div>
                </div>
            </div>
            <div id="trendsChart" class="bocm-chart-container shimmer"></div>
        </div>

        <!-- Top Events -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Top Events', 'blue-oak-client-management'); ?></h3>
            </div>
            <div class="bocm-events-table shimmer">
                <table class="bocm-table">
                    <thead>
                        <tr>
                            <th><?php _e('Event Name', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Event Count', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Users', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Event Value', 'blue-oak-client-management'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>page_view</td>
                            <td>12,345</td>
                            <td>5,678</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>scroll</td>
                            <td>8,901</td>
                            <td>4,567</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>click</td>
                            <td>6,789</td>
                            <td>3,456</td>
                            <td>0</td>
                        </tr>
                        <tr>
                            <td>form_submit</td>
                            <td>2,345</td>
                            <td>2,123</td>
                            <td>0</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Landing Pages -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Landing Pages', 'blue-oak-client-management'); ?></h3>
            </div>
            <div class="bocm-landing-pages-table shimmer">
                <table class="bocm-table">
                    <thead>
                        <tr>
                            <th><?php _e('Page', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Users', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('New Users', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Sessions', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Bounce Rate', 'blue-oak-client-management'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>/</td>
                            <td>3,456</td>
                            <td>2,345</td>
                            <td>4,567</td>
                            <td>45.2%</td>
                        </tr>
                        <tr>
                            <td>/services</td>
                            <td>2,345</td>
                            <td>1,234</td>
                            <td>3,456</td>
                            <td>38.9%</td>
                        </tr>
                        <tr>
                            <td>/about</td>
                            <td>1,234</td>
                            <td>890</td>
                            <td>2,345</td>
                            <td>42.3%</td>
                        </tr>
                        <tr>
                            <td>/contact</td>
                            <td>890</td>
                            <td>567</td>
                            <td>1,234</td>
                            <td>35.6%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Top Pages -->
        <div class="bocm-portal-card">
            <div class="bocm-card-header">
                <h3><?php _e('Top Pages', 'blue-oak-client-management'); ?></h3>
            </div>
            <div class="bocm-top-pages-table shimmer">
                <table class="bocm-table">
                    <thead>
                        <tr>
                            <th><?php _e('Page', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Page Views', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Unique Views', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Avg. Time on Page', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Bounce Rate', 'blue-oak-client-management'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>/</td>
                            <td>5,678</td>
                            <td>4,567</td>
                            <td>2:34</td>
                            <td>45.2%</td>
                        </tr>
                        <tr>
                            <td>/services</td>
                            <td>3,456</td>
                            <td>2,345</td>
                            <td>3:12</td>
                            <td>38.9%</td>
                        </tr>
                        <tr>
                            <td>/about</td>
                            <td>2,345</td>
                            <td>1,890</td>
                            <td>2:45</td>
                            <td>42.3%</td>
                        </tr>
                        <tr>
                            <td>/contact</td>
                            <td>1,234</td>
                            <td>1,123</td>
                            <td>1:56</td>
                            <td>35.6%</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    <?php endif; ?>
</div> 