<?php
/**
 * Upgrade tab view for the client portal
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement\Views\Tabs;

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}
?>

<!-- Upgrade Tab Content -->
<div class="bocm-tab-content">
    <!-- Available Plans Card -->
    <div class="bocm-portal-card">
        <h3><?php _e('Available Plans', 'blue-oak-client-management'); ?></h3>
        <div class="bocm-card-content">
            <div class="bocm-plans-grid">
                <div class="bocm-plan-card">
                    <div class="bocm-plan-card-header">
                        <h4><?php _e('Standard', 'blue-oak-client-management'); ?></h4>
                        <div class="bocm-plan-card-price">
                            <span class="bocm-price-amount">$99</span>
                            <span class="bocm-price-period"><?php _e('/month', 'blue-oak-client-management'); ?></span>
                        </div>
                    </div>
                    <div class="bocm-plan-card-features">
                        <ul>
                            <li><i class="fas fa-check"></i> <?php _e('Managed Wordpress Site', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Uptime Monitoring (7 Days)', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Basic Google Analytics', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Basic Google Search Console', 'blue-oak-client-management'); ?></li>
                        </ul>
                    </div>
                    <div class="bocm-plan-card-footer">
                        <button class="bocm-button bocm-button-secondary"><?php _e('Current Plan', 'blue-oak-client-management'); ?></button>
                    </div>
                </div>
                <div class="bocm-plan-card featured">
                    <div class="bocm-plan-card-header">
                        <span class="bocm-featured-badge"><?php _e('Recommended', 'blue-oak-client-management'); ?></span>
                        <h4><?php _e('Premium', 'blue-oak-client-management'); ?></h4>
                        <div class="bocm-plan-card-price">
                            <span class="bocm-price-amount">$199</span>
                            <span class="bocm-price-period"><?php _e('/month', 'blue-oak-client-management'); ?></span>
                        </div>
                    </div>
                    <div class="bocm-plan-card-features">
                        <ul>
                            <li><i class="fas fa-check"></i> <?php _e('Managed Wordpress Site', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Uptime Monitoring (30 Days)', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Advanced Google Analytics', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Advanced Google Search Console', 'blue-oak-client-management'); ?></li>
                        </ul>
                    </div>
                    <div class="bocm-plan-card-footer">
                        <button class="bocm-button bocm-button-primary"><?php _e('Upgrade Now', 'blue-oak-client-management'); ?></button>
                    </div>
                </div>
                <div class="bocm-plan-card">
                    <div class="bocm-plan-card-header">
                        <h4><?php _e('Exclusive', 'blue-oak-client-management'); ?></h4>
                        <div class="bocm-plan-card-price">
                            <span class="bocm-price-amount">$299</span>
                            <span class="bocm-price-period"><?php _e('/month', 'blue-oak-client-management'); ?></span>
                        </div>
                    </div>
                    <div class="bocm-plan-card-features">
                        <ul>
                            <li><i class="fas fa-check"></i> <?php _e('Managed Wordpress Site', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Uptime Monitoring (365 Days)', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Full Google Analytics', 'blue-oak-client-management'); ?></li>
                            <li><i class="fas fa-check"></i> <?php _e('Full Google Search Console', 'blue-oak-client-management'); ?></li>
                        </ul>
                    </div>
                    <div class="bocm-plan-card-footer">
                        <button class="bocm-button bocm-button-primary"><?php _e('Upgrade Now', 'blue-oak-client-management'); ?></button>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div> 