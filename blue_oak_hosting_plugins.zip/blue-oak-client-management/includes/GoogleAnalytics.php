<?php
/**
 * Google Analytics integration class
 *
 * @package BlueOakClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

use Google\Client;
use Google\Service\AnalyticsData;
use Google\Service\AnalyticsData\RunReportRequest;
use Google\Service\AnalyticsData\RunReportResponse;
use Google\Service\AnalyticsData\DateRange;
use Google\Service\AnalyticsData\Dimension;
use Google\Service\AnalyticsData\Metric;
use Google\Service\AnalyticsData\OrderBy;
use Google\Service\AnalyticsData\Filter;
use Google\Service\AnalyticsData\FilterExpression;
use Google\Service\AnalyticsData\InListFilter;
use Google\Service\AnalyticsData\DimensionOrderBy;
use Google\Service\AnalyticsData\MetricOrderBy;
use Google\Service\Analytics;
use Google\ApiCore\ApiException;
use Google\Analytics\Admin\V1beta\Gapic\AnalyticsAdminServiceGapicClient;
use Exception;

/**
 * Class GoogleAnalytics
 * Handles integration with Google Analytics API
 */
class GoogleAnalytics {
    /**
     * Verify service account credentials by attempting to initialize the Google client
     *
     * @param array $credentials Service account credentials JSON data
     * @return bool True if credentials are valid, false otherwise
     */
    public function verify_credentials(array $credentials): bool {
        try {
            $client = new Client();
            $client->setAuthConfig($credentials);
            $client->addScope([
                'https://www.googleapis.com/auth/analytics.readonly',
                'https://www.googleapis.com/auth/analytics.edit'
            ]);

            // Initialize Analytics Admin API client
            $adminClient = new AnalyticsAdminServiceGapicClient([
                'credentials' => $credentials
            ]);
            
            // List accounts to verify credentials
            $accounts = $adminClient->listAccounts([]);
            $accounts->iterateAllElements()->current(); // Try to get first account
            
            return true;
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Verification Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get the stored service account credentials
     *
     * @return array|null Service account credentials or null if not set
     */
    public function get_credentials(): ?array {
        $credentials = get_option('bocm_ga_service_account', '');
        if (empty($credentials)) {
            error_log('BOCM Google Analytics: No credentials found in options');
            return null;
        }

        $json_data = json_decode($credentials, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('BOCM Google Analytics: Invalid JSON in credentials - ' . json_last_error_msg());
            return null;
        }

        return $json_data;
    }

    /**
     * Initialize Google Analytics client with stored credentials
     *
     * @return Client|null Google client instance or null if credentials are invalid
     */
    public function get_client(): ?Client {
        $credentials = $this->get_credentials();
        if ($credentials === null) {
            return null;
        }

        try {
            $client = new Client();
            $client->setAuthConfig($credentials);
            $client->addScope([
                'https://www.googleapis.com/auth/analytics.readonly',
                'https://www.googleapis.com/auth/analytics.edit'
            ]);
            return $client;
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Client Error: ' . $e->getMessage());
            return null;
        }
    }

    /**
     * Get available Google Analytics property options
     *
     * @return array Array of property options with IDs as keys and display names as values
     */
    public function get_property_options(): array {
        try {
            $credentials = $this->get_credentials();
            if ($credentials === null) {
                error_log('BOCM Google Analytics: No credentials available for property options');
                return ['' => __('No credentials found', 'blue-oak-client-management')];
            }
            
            // Initialize Analytics Admin API client
            $adminClient = new AnalyticsAdminServiceGapicClient([
                'credentials' => $credentials
            ]);
            
            // First, get the list of accounts
            $accounts = $adminClient->listAccounts([]);
            $accountIterator = $accounts->iterateAllElements();
            
            if (!$accountIterator->valid()) {
                error_log('BOCM Google Analytics: No accounts found');
                return ['' => __('No accounts found', 'blue-oak-client-management')];
            }
            
            // Get the first account
            $account = $accountIterator->current();
            $accountId = str_replace('accounts/', '', $account->getName());
            
            // Now list properties for this account
            $response = $adminClient->listProperties('parent:accounts/' . $accountId);
            $properties = iterator_to_array($response->iterateAllElements());
            
            if (empty($properties)) {
                error_log('BOCM Google Analytics: No properties found in response');
                return ['' => __('No properties found', 'blue-oak-client-management')];
            }

            $options = ['' => __('-- Select Property --', 'blue-oak-client-management')];
            
            foreach ($properties as $property) {
                $propertyId = $property->getName(); // Format: properties/123456789
                $displayName = $property->getDisplayName();
                
                // Extract the numeric ID from the property name
                $numericId = str_replace('properties/', '', $propertyId);
                
                $options[$numericId] = sprintf(
                    '%s (%s)',
                    $displayName,
                    $numericId
                );
            }

            return $options;
        } catch (ApiException $e) {
            error_log('BOCM Google Analytics Property List Error: ' . $e->getMessage());
            error_log('BOCM Google Analytics Error Code: ' . $e->getCode());
            return ['' => __('Error loading properties', 'blue-oak-client-management')];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics General Error: ' . $e->getMessage());
            error_log('BOCM Google Analytics Error Trace: ' . $e->getTraceAsString());
            return ['' => __('Error loading properties', 'blue-oak-client-management')];
        }
    }

    /**
     * Get analytics data for a specific property
     *
     * @param string $property_id The Google Analytics property ID
     * @param int $days The number of days to fetch data for (default: 28)
     * @return array The analytics data
     */
    public function get_analytics_data(string $property_id, int $days = 28): array {
        try {
            $client = $this->get_client();
            if ($client === null) {
                return ['error' => 'No valid Google Analytics client'];
            }

            // Initialize the Analytics Data API service
            $analytics_data = new AnalyticsData($client);
            
            // Format the property ID if needed
            if (strpos($property_id, 'properties/') !== 0) {
                $property_id = 'properties/' . $property_id;
            }
            
            // Add debug info for tracking date-related issues
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $this->log_debug('Processing Google Analytics data for property: ' . $property_id . ', days: ' . $days);
            }
            
            // Get basic metrics
            try {
                $summary = $this->get_summary_metrics($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Summary Metrics Error: ' . $e->getMessage());
                error_log('BOCM Google Analytics: ' . $e->getTraceAsString());
                $summary = [];
            }
            
            // Get device category breakdown
            try {
                $device_categories = $this->get_device_categories($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Device Categories Error: ' . $e->getMessage());
                $device_categories = [];
            }
            
            // Get top countries
            try {
                $countries = $this->get_top_countries($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Countries Error: ' . $e->getMessage());
                $countries = [];
            }
            
            // Get operating systems
            try {
                $operating_systems = $this->get_operating_systems($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Operating Systems Error: ' . $e->getMessage());
                $operating_systems = [];
            }
            
            // Get browsers
            try {
                $browsers = $this->get_browsers($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Browsers Error: ' . $e->getMessage());
                error_log('BOCM Google Analytics Browsers Error Trace: ' . $e->getTraceAsString());
                $browsers = [];
            }
            
            // Get trends data
            try {
                $trends = $this->get_trends_data($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Trends Error: ' . $e->getMessage());
                $trends = [];
            }
            
            // Get top events
            try {
                $events = $this->get_top_events($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Events Error: ' . $e->getMessage());
                $events = [];
            }
            
            // Get landing pages
            try {
                $landing_pages = $this->get_landing_pages($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Landing Pages Error: ' . $e->getMessage());
                $landing_pages = [];
            }
            
            // Get top pages
            try {
                $top_pages = $this->get_top_pages($analytics_data, $property_id, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Analytics Top Pages Error: ' . $e->getMessage());
                $top_pages = [];
            }
            
            return [
                'summary' => $summary,
                'device_categories' => $device_categories,
                'countries' => $countries,
                'operating_systems' => $operating_systems,
                'browsers' => $browsers,
                'trends' => $trends,
                'events' => $events,
                'landing_pages' => $landing_pages,
                'top_pages' => $top_pages
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Error: ' . $e->getMessage());
            error_log('BOCM Google Analytics Error Trace: ' . $e->getTraceAsString());
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Get summary metrics (active users, avg session duration, bounce rate, pages per session)
     *
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The summary metrics
     */
    private function get_summary_metrics(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            // Current period
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            
            // Create DateRange object properly
            $dateRange = new DateRange();
            $dateRange->setStartDate($days . 'daysAgo');
            $dateRange->setEndDate('today');
            $request->setDateRanges([$dateRange]);
            
            // Create Metric objects properly
            $activeUsers = new Metric();
            $activeUsers->setName('activeUsers');
            
            $avgSessionDuration = new Metric();
            $avgSessionDuration->setName('averageSessionDuration');
            
            $bounceRate = new Metric();
            $bounceRate->setName('bounceRate');
            
            $pagesPerSession = new Metric();
            $pagesPerSession->setName('screenPageViewsPerSession');
            
            $request->setMetrics([$activeUsers, $avgSessionDuration, $bounceRate, $pagesPerSession]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            // Previous period for comparison
            $prev_request = new RunReportRequest();
            $prev_request->setProperty($property_id);
            
            // Create DateRange object for previous period
            $prevDateRange = new DateRange();
            $prevDateRange->setStartDate(($days * 2) . 'daysAgo');
            $prevDateRange->setEndDate(($days + 1) . 'daysAgo');
            $prev_request->setDateRanges([$prevDateRange]);
            
            // Reuse the same metric objects
            $prev_request->setMetrics([$activeUsers, $avgSessionDuration, $bounceRate, $pagesPerSession]);
            
            $previous_response = $analytics_data->properties->runReport($property_id, $prev_request);

            $row = $response->getRows()[0] ?? null;
            $prev_row = $previous_response->getRows()[0] ?? null;

            if (!$row || !$prev_row) {
                return [];
            }

            $metrics = $row->getMetricValues();
            $prev_metrics = $prev_row->getMetricValues();

            $active_users = (int)$metrics[0]->getValue();
            $prev_active_users = (int)$prev_metrics[0]->getValue();
            $active_users_change = $this->calculate_percentage_change($active_users, $prev_active_users);

            $avg_session_duration = (float)$metrics[1]->getValue();
            $prev_avg_session_duration = (float)$prev_metrics[1]->getValue();
            
            // Ensure duration values are valid
            if (!is_numeric($avg_session_duration) || $avg_session_duration < 0) {
                $avg_session_duration = 0;
                error_log('BOCM Google Analytics: Invalid avg_session_duration value: ' . var_export($metrics[1]->getValue(), true));
            }
            
            if (!is_numeric($prev_avg_session_duration) || $prev_avg_session_duration < 0) {
                $prev_avg_session_duration = 0;
                error_log('BOCM Google Analytics: Invalid prev_avg_session_duration value: ' . var_export($prev_metrics[1]->getValue(), true));
            }
            
            $avg_session_duration_change = $this->calculate_percentage_change($avg_session_duration, $prev_avg_session_duration);

            $bounce_rate = (float)$metrics[2]->getValue();
            $prev_bounce_rate = (float)$prev_metrics[2]->getValue();
            $bounce_rate_change = $this->calculate_percentage_change($bounce_rate, $prev_bounce_rate) * -1; // Invert since lower is better

            $pages_per_session = (float)$metrics[3]->getValue();
            $prev_pages_per_session = (float)$prev_metrics[3]->getValue();
            $pages_per_session_change = $this->calculate_percentage_change($pages_per_session, $prev_pages_per_session);

            return [
                'active_users' => [
                    'value' => number_format($active_users),
                    'change' => $active_users_change,
                    'positive' => $active_users_change >= 0
                ],
                'avg_session_duration' => [
                    'value' => $this->format_duration($avg_session_duration),
                    'change' => number_format(abs($avg_session_duration_change), 1),
                    'positive' => $avg_session_duration_change >= 0
                ],
                'bounce_rate' => [
                    'value' => number_format($bounce_rate, 1) . '%',
                    'change' => number_format(abs($bounce_rate_change), 1),
                    'positive' => $bounce_rate_change >= 0
                ],
                'pages_per_session' => [
                    'value' => number_format($pages_per_session, 1),
                    'change' => number_format(abs($pages_per_session_change), 1),
                    'positive' => $pages_per_session_change >= 0
                ]
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Summary Metrics Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get device category breakdown (Desktop, Mobile, Tablet)
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The device categories data
     */
    private function get_device_categories(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'deviceCategory']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'activeUsers']),
            ]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $series = [];
            $labels = [];
            
            foreach ($response->getRows() as $row) {
                $labels[] = $row->getDimensionValues()[0]->getValue();
                $series[] = (int)$row->getMetricValues()[0]->getValue();
            }
            
            return [
                'series' => $series,
                'labels' => $labels
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Device Categories Error: ' . $e->getMessage());
            return [
                'series' => [],
                'labels' => []
            ];
        }
    }

    /**
     * Get top countries by active users
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The top countries data
     */
    private function get_top_countries(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'country']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'activeUsers']),
            ]);
            $request->setLimit(4);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('activeUsers');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $categories = [];
            $data = [];
            
            foreach ($response->getRows() as $row) {
                $categories[] = $row->getDimensionValues()[0]->getValue();
                $data[] = (int)$row->getMetricValues()[0]->getValue();
            }
            
            return [
                'categories' => $categories,
                'data' => $data
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Top Countries Error: ' . $e->getMessage());
            return [
                'categories' => [],
                'data' => []
            ];
        }
    }

    /**
     * Get top operating systems by active users
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The operating systems data
     */
    private function get_operating_systems(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'operatingSystem']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'activeUsers']),
            ]);
            $request->setLimit(4);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('activeUsers');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $categories = [];
            $data = [];
            
            foreach ($response->getRows() as $row) {
                $categories[] = $row->getDimensionValues()[0]->getValue();
                $data[] = (int)$row->getMetricValues()[0]->getValue();
            }
            
            return [
                'categories' => $categories,
                'data' => $data
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Operating Systems Error: ' . $e->getMessage());
            return [
                'categories' => [],
                'data' => []
            ];
        }
    }

    /**
     * Get browser data
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The browser data
     */
    private function get_browsers(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            // Get top browsers
            $browser_request = new RunReportRequest();
            $browser_request->setProperty($property_id);
            $browser_request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $browser_request->setDimensions([
                new Dimension(['name' => 'browser']),
            ]);
            $browser_request->setMetrics([
                new Metric(['name' => 'activeUsers']),
            ]);
            $browser_request->setLimit(3);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('activeUsers');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $browser_request->setOrderBys([$orderBy]);
            
            $browser_response = $analytics_data->properties->runReport($property_id, $browser_request);

            // Get top browsers over time
            $browsers = [];
            foreach ($browser_response->getRows() as $row) {
                $browsers[] = $row->getDimensionValues()[0]->getValue();
            }

            // If no browsers, return empty data
            if (empty($browsers)) {
                return [
                    'browsers' => [],
                    'categories' => [],
                    'series' => []
                ];
            }

            // Create filter expression for browsers
            $filter_expression = new FilterExpression([
                'filter' => new Filter([
                    'field_name' => 'browser',
                    'in_list_filter' => new InListFilter([
                        'values' => $browsers
                    ])
                ])
            ]);

            // Get last 7 days for chart
            $time_request = new RunReportRequest();
            $time_request->setProperty($property_id);
            $time_request->setDateRanges([
                new DateRange([
                    'start_date' => '7daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $time_request->setDimensions([
                new Dimension(['name' => 'date']),
                new Dimension(['name' => 'browser']),
            ]);
            $time_request->setMetrics([
                new Metric(['name' => 'activeUsers']),
            ]);
            $time_request->setDimensionFilter($filter_expression);
            
            $time_response = $analytics_data->properties->runReport($property_id, $time_request);

            // Organize data by date and browser
            $data_by_date = [];
            $data_by_browser = [];
            
            // Log initial data structure for debugging
            error_log('BOCM Google Analytics Browser Data: Starting to process time response rows. Row count: ' . 
                (is_countable($time_response->getRows()) ? count($time_response->getRows()) : 'unknown'));
            
            foreach ($time_response->getRows() as $row) {
                $date = $row->getDimensionValues()[0]->getValue();
                $browser = $row->getDimensionValues()[1]->getValue();
                $users = (int)$row->getMetricValues()[0]->getValue();
                
                // Log for debugging
                error_log('BOCM Google Analytics Browser Data: Processing row - Date: ' . var_export($date, true) . 
                    ', Browser: ' . var_export($browser, true) . 
                    ', Users: ' . var_export($users, true));
                
                if (!isset($data_by_date[$date])) {
                    $data_by_date[$date] = [];
                }
                $data_by_date[$date][$browser] = $users;
                
                if (!isset($data_by_browser[$browser])) {
                    $data_by_browser[$browser] = [];
                }
            }

            // Sort dates
            ksort($data_by_date);
            
            // Log date keys for debugging
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $this->log_debug('Browser date keys (' . count(array_keys($data_by_date)) . '): ' . 
                    json_encode(array_keys($data_by_date)));
            }
            
            // Format dates to human-readable
            $categories = [];
            foreach (array_keys($data_by_date) as $date_string) {
                // For debug tracking
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    $is_string = is_string($date_string);
                    $matches_pattern = $is_string ? (preg_match('/^\d{8}$/', $date_string) ? 'true' : 'false') : 'N/A';
                    
                    $this->log_debug('Processing browser date: ' . var_export($date_string, true) . 
                        ' (is_string: ' . ($is_string ? 'true' : 'false') . 
                        ', matches pattern: ' . $matches_pattern . ')');
                }
                
                // Ensure date_string is a string in the expected format (Ymd)
                if (is_string($date_string) && preg_match('/^\d{8}$/', $date_string)) {
                    $date = \DateTime::createFromFormat('Ymd', $date_string);
                    if ($date) {
                        $categories[] = $date->format('M d');
                    } else {
                        // Only log if the date format is invalid despite matching the pattern
                        error_log('BOCM Google Analytics: Could not parse date format: ' . var_export($date_string, true));
                        $categories[] = 'Unknown';
                    }
                } else {
                    // Log only if it's not a valid string format
                    if (!is_string($date_string)) {
                        error_log('BOCM Google Analytics: Unexpected date format (not a string): ' . var_export($date_string, true));
                    } elseif (!preg_match('/^\d{8}$/', $date_string)) {
                        error_log('BOCM Google Analytics: Unexpected date format (invalid pattern): ' . var_export($date_string, true));
                    }
                    $categories[] = 'Unknown';
                }
            }
            
            // Create series data
            $series = [];
            foreach ($browsers as $browser) {
                $data = [];
                foreach (array_keys($data_by_date) as $date) {
                    $data[] = $data_by_date[$date][$browser] ?? 0;
                }
                
                $series[] = [
                    'name' => $browser,
                    'data' => $data
                ];
            }
            
            return [
                'browsers' => $browsers,
                'categories' => $categories,
                'series' => $series
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Browsers Error: ' . $e->getMessage());
            return [
                'browsers' => [],
                'categories' => [],
                'series' => []
            ];
        }
    }

    /**
     * Get trends data for users, sessions, and page views
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The trends data
     */
    private function get_trends_data(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            // Use 7 days for trends chart
            $days_to_use = min($days, 7);
            
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days_to_use . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'date']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'activeUsers']),
                new Metric(['name' => 'sessions']),
                new Metric(['name' => 'screenPageViews']),
            ]);
            
            // Create OrderBy object properly
            $dimensionOrderBy = new DimensionOrderBy();
            $dimensionOrderBy->setDimensionName('date');
            
            $orderBy = new OrderBy();
            $orderBy->setDimension($dimensionOrderBy);
            $orderBy->setDesc(false);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $categories = [];
            $users = [];
            $sessions = [];
            $pageViews = [];
            
            foreach ($response->getRows() as $row) {
                $date = $row->getDimensionValues()[0]->getValue();
                
                // For debug tracking
                if (defined('WP_DEBUG') && WP_DEBUG) {
                    $is_string = is_string($date);
                    $matches_pattern = $is_string ? (preg_match('/^\d{8}$/', $date) ? 'true' : 'false') : 'N/A';
                    
                    $this->log_debug('Processing trend date: ' . var_export($date, true) . 
                        ' (is_string: ' . ($is_string ? 'true' : 'false') . 
                        ', matches pattern: ' . $matches_pattern . ')');
                }
                
                // Ensure date is a string in the expected format (Ymd)
                if (is_string($date) && preg_match('/^\d{8}$/', $date)) {
                    $date_obj = \DateTime::createFromFormat('Ymd', $date);
                    if ($date_obj) {
                        $categories[] = $date_obj->format('M d');
                    } else {
                        // Only log if the date format is invalid despite matching the pattern
                        error_log('BOCM Google Analytics: Could not parse date format in trends: ' . var_export($date, true));
                        $categories[] = 'Unknown';
                        continue;
                    }
                } else {
                    // Log only if it's not a valid string format
                    if (!is_string($date)) {
                        error_log('BOCM Google Analytics: Unexpected date format in trends (not a string): ' . var_export($date, true));
                    } elseif (!preg_match('/^\d{8}$/', $date)) {
                        error_log('BOCM Google Analytics: Unexpected date format in trends (invalid pattern): ' . var_export($date, true));
                    }
                    $categories[] = 'Unknown';
                    continue;
                }
                
                $metrics = $row->getMetricValues();
                $users[] = (int)$metrics[0]->getValue();
                $sessions[] = (int)$metrics[1]->getValue();
                $pageViews[] = (int)$metrics[2]->getValue();
            }
            
            return [
                'categories' => $categories,
                'series' => [
                    [
                        'name' => 'Users',
                        'data' => $users
                    ],
                    [
                        'name' => 'Sessions',
                        'data' => $sessions
                    ],
                    [
                        'name' => 'Page Views',
                        'data' => $pageViews
                    ]
                ]
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Trends Error: ' . $e->getMessage());
            return [
                'categories' => [],
                'series' => []
            ];
        }
    }

    /**
     * Get top events
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The top events data
     */
    private function get_top_events(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'eventName']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'eventCount']),
                new Metric(['name' => 'eventValue']),
                new Metric(['name' => 'totalUsers']),
            ]);
            $request->setLimit(4);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('eventCount');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $events = [];
            foreach ($response->getRows() as $row) {
                $event_name = $row->getDimensionValues()[0]->getValue();
                $metrics = $row->getMetricValues();
                
                $events[] = [
                    'name' => $event_name,
                    'count' => number_format((int)$metrics[0]->getValue()),
                    'users' => number_format((int)$metrics[2]->getValue()),
                    'value' => number_format((float)$metrics[1]->getValue())
                ];
            }
            
            return $events;
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Top Events Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get landing pages
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The landing pages data
     */
    private function get_landing_pages(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'landingPage']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'totalUsers']),
                new Metric(['name' => 'newUsers']),
                new Metric(['name' => 'sessions']),
                new Metric(['name' => 'bounceRate']),
            ]);
            $request->setLimit(4);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('sessions');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $landing_pages = [];
            foreach ($response->getRows() as $row) {
                $page = $row->getDimensionValues()[0]->getValue();
                $metrics = $row->getMetricValues();
                
                $landing_pages[] = [
                    'page' => $page,
                    'users' => number_format((int)$metrics[0]->getValue()),
                    'new_users' => number_format((int)$metrics[1]->getValue()),
                    'sessions' => number_format((int)$metrics[2]->getValue()),
                    'bounce_rate' => number_format((float)$metrics[3]->getValue(), 1) . '%'
                ];
            }
            
            return $landing_pages;
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Landing Pages Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get top pages
     * 
     * @param AnalyticsData $analytics_data The Analytics Data service instance
     * @param string $property_id The property ID
     * @param int $days The number of days
     * @return array The top pages data
     */
    private function get_top_pages(AnalyticsData $analytics_data, string $property_id, int $days): array {
        try {
            $request = new RunReportRequest();
            $request->setProperty($property_id);
            $request->setDateRanges([
                new DateRange([
                    'start_date' => $days . 'daysAgo',
                    'end_date' => 'today',
                ]),
            ]);
            $request->setDimensions([
                new Dimension(['name' => 'pagePath']),
            ]);
            $request->setMetrics([
                new Metric(['name' => 'screenPageViews']),
                new Metric(['name' => 'totalUsers']),
                new Metric(['name' => 'averageSessionDuration']),
                new Metric(['name' => 'bounceRate']),
            ]);
            $request->setLimit(4);
            
            // Create OrderBy object properly
            $metricOrderBy = new MetricOrderBy();
            $metricOrderBy->setMetricName('screenPageViews');
            
            $orderBy = new OrderBy();
            $orderBy->setMetric($metricOrderBy);
            $orderBy->setDesc(true);
            
            $request->setOrderBys([$orderBy]);
            
            $response = $analytics_data->properties->runReport($property_id, $request);

            $pages = [];
            foreach ($response->getRows() as $row) {
                $page = $row->getDimensionValues()[0]->getValue();
                $metrics = $row->getMetricValues();
                
                // Safely handle duration value
                $duration_value = (float)$metrics[2]->getValue();
                
                // Ensure duration is a valid number
                if (!is_numeric($duration_value) || $duration_value < 0) {
                    $duration_value = 0; // Default to zero if invalid
                    error_log('BOCM Google Analytics: Invalid duration value encountered: ' . var_export($metrics[2]->getValue(), true));
                }
                
                $pages[] = [
                    'page' => $page,
                    'views' => number_format((int)$metrics[0]->getValue()),
                    'unique_views' => number_format((int)$metrics[1]->getValue()),
                    'avg_time' => $this->format_duration($duration_value),
                    'bounce_rate' => number_format((float)$metrics[3]->getValue(), 1) . '%'
                ];
            }
            
            return $pages;
        } catch (Exception $e) {
            error_log('BOCM Google Analytics Top Pages Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Calculate percentage change between two values
     * 
     * @param float $current The current value
     * @param float $previous The previous value
     * @return float The percentage change
     */
    private function calculate_percentage_change(float $current, float $previous): float {
        if ($previous == 0) {
            return 0;
        }
        
        return (($current - $previous) / $previous) * 100;
    }

    /**
     * Format duration in seconds to minutes:seconds
     *
     * @param float $seconds Duration in seconds
     * @return string Formatted duration
     */
    private function format_duration(float $seconds): string {
        // Ensure seconds is a valid number
        if (!is_numeric($seconds) || $seconds < 0) {
            $seconds = 0;
        }
        
        // Calculate minutes and remaining seconds using integers to avoid deprecation warnings
        $total_seconds = intval($seconds); // Convert to integer safely, discarding fractional part
        $minutes = intdiv($total_seconds, 60); // Use intdiv for integer division
        $remaining_seconds = $total_seconds % 60; // Modulo operation with integers
        
        // Format the output
        return $minutes . ':' . str_pad((string)$remaining_seconds, 2, '0', STR_PAD_LEFT);
    }

    /**
     * Internal method for debug logging
     * 
     * @param string $message The debug message
     * @return void
     */
    private function log_debug(string $message): void {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('BOCM Google Analytics Debug: ' . $message);
        }
    }
} 