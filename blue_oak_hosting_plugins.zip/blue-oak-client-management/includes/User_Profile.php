<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handles user profile customizations
 */
class User_Profile {

    /**
     * The Uptime Robot API instance
     *
     * @var UptimeRobot
     */
    private UptimeRobot $uptime_robot;

    /**
     * The Google Analytics API instance
     *
     * @var GoogleAnalytics
     */
    private GoogleAnalytics $google_analytics;

    /**
     * The Google Search Console API instance
     *
     * @var GoogleSearchConsole
     */
    private GoogleSearchConsole $google_search_console;

    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        // Initialize AJAX hooks
        add_action('init', [$this, 'init_ajax_hooks']);
        
        // Register AJAX endpoints
        add_action('wp_ajax_bocm_refresh_uptime_data', [$this, 'ajax_refresh_uptime_data']);
        add_action('wp_ajax_nopriv_bocm_refresh_uptime_data', [$this, 'ajax_refresh_uptime_data']);
        
        // Load required dependencies
        require_once BOCM_PLUGIN_DIR . 'includes/UptimeRobot.php';
        require_once BOCM_PLUGIN_DIR . 'includes/GoogleAnalytics.php';
        require_once BOCM_PLUGIN_DIR . 'includes/GoogleSearchConsole.php';
        
        // Initialize API connections
        $this->uptime_robot = new UptimeRobot();
        $this->google_analytics = new GoogleAnalytics();
        $this->google_search_console = new GoogleSearchConsole();

        // Add the custom fields to user profile
        add_action('show_user_profile', [$this, 'add_custom_user_profile_fields']);
        add_action('edit_user_profile', [$this, 'add_custom_user_profile_fields']);
        
        // Add fields to create user form
        add_action('user_new_form', [$this, 'add_custom_user_creation_fields']);
        
        // Save the custom fields
        add_action('personal_options_update', [$this, 'save_custom_user_profile_fields']);
        add_action('edit_user_profile_update', [$this, 'save_custom_user_profile_fields']);
        add_action('user_register', [$this, 'save_custom_user_creation_fields']);

        // Add shortcode for client portal
        add_shortcode('blue_oak_client_portal', [$this, 'render_client_portal_shortcode']);

        // Add login redirect for Blue Oak clients
        add_filter('login_redirect', [$this, 'redirect_blue_oak_clients'], 10, 3);

        // Enqueue Font Awesome and other assets
        add_action('wp_enqueue_scripts', [$this, 'enqueue_assets']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_assets']);
    }

    /**
     * Enqueue assets
     *
     * @return void
     */
    public function enqueue_assets(): void {
        // Check if Font Awesome is already enqueued
        if (!wp_style_is('font-awesome', 'enqueued')) {
            wp_enqueue_style(
                'font-awesome',
                'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
                [],
                '6.5.1'
            );
        }

        // Get current tab
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'overview';

        // Enqueue common client portal styles and scripts
        wp_enqueue_style(
            'bocm-client-portal',
            BOCM_PLUGIN_URL . 'assets/css/client-portal.css',
            [],
            BOCM_VERSION
        );

        wp_enqueue_script(
            'bocm-client-portal',
            BOCM_PLUGIN_URL . 'assets/js/client-portal.js',
            ['jquery'],
            BOCM_VERSION,
            true
        );

        // Enqueue tab-specific assets
        $tabs = ['overview', 'uptime', 'analytics', 'ads', 'search-console', 'upgrade'];
        
        if (in_array($current_tab, $tabs)) {
            // Get the CSS file name (special cases for analytics, ads, and search-console)
            $css_filename = $current_tab;
            if ($current_tab === 'analytics') {
                $css_filename = 'google-analytics';
            } elseif ($current_tab === 'ads') {
                $css_filename = 'google-ads';
            } elseif ($current_tab === 'search-console') {
                $css_filename = 'google-search-console';
            }
            
            // Enqueue tab-specific CSS
            wp_enqueue_style(
                'bocm-' . $current_tab,
                BOCM_PLUGIN_URL . 'assets/css/' . $css_filename . '.css',
                ['bocm-client-portal'],
                BOCM_VERSION
            );

            // Get the JS file name (special cases for analytics, ads, and search-console)
            $js_filename = $current_tab;
            if ($current_tab === 'analytics') {
                $js_filename = 'google-analytics';
            } elseif ($current_tab === 'ads') {
                $js_filename = 'google-ads';
            } elseif ($current_tab === 'search-console') {
                $js_filename = 'google-search-console';
            }
            
            // Enqueue tab-specific JavaScript
            wp_enqueue_script(
                'bocm-' . $current_tab,
                BOCM_PLUGIN_URL . 'assets/js/' . $js_filename . '.js',
                ['jquery', 'bocm-client-portal'],
                BOCM_VERSION,
                true
            );
            
            // Add common AJAX data for all tabs
            wp_localize_script('bocm-' . $current_tab, 'bocmCommonData', [
                'ajax_url' => admin_url('admin-ajax.php'),
                'nonce' => wp_create_nonce('bocm_nonce')
            ]);
            
            // Add data for the Google Analytics tab
            if ($current_tab === 'analytics') {
                wp_localize_script('bocm-analytics', 'bocmData', [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('bocm_analytics_nonce')
                ]);
            }
            
            // Add data for the Google Search Console tab
            if ($current_tab === 'search-console') {
                wp_localize_script('bocm-search-console', 'bocmData', [
                    'ajax_url' => admin_url('admin-ajax.php'),
                    'nonce' => wp_create_nonce('bocm_search_console_nonce')
                ]);
            }
        }

        // Enqueue ApexCharts for tabs that need it
        if (in_array($current_tab, ['uptime', 'analytics', 'ads', 'search-console'])) {
            wp_enqueue_script(
                'apexcharts',
                'https://cdn.jsdelivr.net/npm/apexcharts',
                [],
                '3.45.1',
                true
            );
        }
    }

    /**
     * Render the Client Portal shortcode
     *
     * @return string
     */
    public function render_client_portal_shortcode(): string {
        // Check if user is logged in and is a Blue Oak client
        if (!is_user_logged_in()) {
            return sprintf(
                '<p>%s <a href="%s">%s</a></p>',
                __('Please log in to view your client portal.', 'blue-oak-client-management'),
                esc_url(wp_login_url(get_permalink())),
                __('Log in', 'blue-oak-client-management')
            );
        }

        $user = wp_get_current_user();
        if (!in_array('blue_oak_client', $user->roles)) {
            return __('You do not have permission to view this page.', 'blue-oak-client-management');
        }

        // Add ajaxurl for front-end AJAX
        add_action('wp_footer', function() {
            echo '<script type="text/javascript">
            /* <![CDATA[ */
            var ajaxurl = "' . admin_url('admin-ajax.php') . '";
            /* ]]> */
            </script>';
        });

        // Get current tab
        $current_tab = isset($_GET['tab']) ? sanitize_text_field($_GET['tab']) : 'overview';

        // Get monitor data - only if needed for current tab
        $uptime_monitor_id = get_user_meta($user->ID, 'bocm_uptime_monitor_id', true);
        $monitor_data = null;
        if (in_array($current_tab, ['overview', 'uptime']) && !empty($uptime_monitor_id)) {
            // Try to get cached monitor data first
            $cache_key = 'bocm_uptime_monitor_' . $uptime_monitor_id . '_tab';
            $cached_data = get_transient($cache_key);
            
            if ($cached_data !== false) {
                // Use cached data to avoid API calls
                error_log("BOCM Tab: Using cached uptime data for monitor $uptime_monitor_id");
                extract($cached_data); // Extracts $monitor_data, $day_uptime, $week_uptime, etc.
            } else {
                // Get monitor data from API
                $monitors = $this->uptime_robot->get_monitors();
                $monitor_data = current(array_filter($monitors, function($m) use ($uptime_monitor_id) {
                    return $m['id'] == $uptime_monitor_id;
                }));
                
                if (empty($monitor_data)) {
                    error_log("BOCM Tab: Failed to find monitor with ID $uptime_monitor_id");
                }

                // Initialize uptime variables
                $custom_uptime_ratio = $monitor_data['custom_uptime_ratio'] ?? '';
                if (is_string($custom_uptime_ratio) && strpos($custom_uptime_ratio, '-') !== false) {
                    $uptime_ratios = explode('-', $custom_uptime_ratio);
                    $day_uptime = isset($uptime_ratios[0]) && (float)$uptime_ratios[0] > 0.001 ? (float)$uptime_ratios[0] : 0;
                    $week_uptime = isset($uptime_ratios[1]) && (float)$uptime_ratios[1] > 0.001 ? (float)$uptime_ratios[1] : 0;
                    $month_uptime = isset($uptime_ratios[2]) && (float)$uptime_ratios[2] > 0.001 ? (float)$uptime_ratios[2] : 0;
                    $ninety_day_uptime = isset($uptime_ratios[3]) && (float)$uptime_ratios[3] > 0.001 ? (float)$uptime_ratios[3] : 0;
                } else {
                    $uptime_value = (float)$custom_uptime_ratio > 0.001 ? (float)$custom_uptime_ratio : 0;
                    $day_uptime = $week_uptime = $month_uptime = $ninety_day_uptime = $uptime_value;
                }

                // Get monitor logs and calculate incidents
                $logs = $this->uptime_robot->get_monitor_logs($uptime_monitor_id, 100);
                
                // Calculate incidents for each period
                $day_incidents = array_filter($logs, function($log) {
                    return $log['datetime'] >= strtotime('-24 hours') && $log['type'] === 1;
                });
                $week_incidents = array_filter($logs, function($log) {
                    return $log['datetime'] >= strtotime('-7 days') && $log['type'] === 1;
                });
                $month_incidents = array_filter($logs, function($log) {
                    return $log['datetime'] >= strtotime('-30 days') && $log['type'] === 1;
                });
                
                // Store data in cache using the configured cache duration
                $cache_data = compact('monitor_data', 'day_uptime', 'week_uptime', 'month_uptime', 
                    'ninety_day_uptime', 'logs', 'day_incidents', 'week_incidents', 'month_incidents');
                $cache_duration = get_option('bocm_uptimerobot_cache_duration', 10);
                set_transient($cache_key, $cache_data, $cache_duration * MINUTE_IN_SECONDS);
            }
        } else {
            // Initialize default values when no monitor data is available
            $monitor_data = null;
            $day_uptime = $week_uptime = $month_uptime = $ninety_day_uptime = 0;
            $day_incidents = $week_incidents = $month_incidents = [];
            $logs = [];
        }

        ob_start();
        ?>
        <div class="bocm-portal-container">
            <!-- Tab Navigation -->
            <div class="bocm-tabs">
                <a href="?tab=overview" class="bocm-tab <?php echo $current_tab === 'overview' ? 'active' : ''; ?>">
                    <?php _e('Overview', 'blue-oak-client-management'); ?>
                </a>
                <a href="?tab=uptime" class="bocm-tab <?php echo $current_tab === 'uptime' ? 'active' : ''; ?>">
                    <?php _e('Uptime', 'blue-oak-client-management'); ?>
                </a>
                <a href="?tab=analytics" class="bocm-tab <?php echo $current_tab === 'analytics' ? 'active' : ''; ?>">
                    <?php _e('Google Analytics', 'blue-oak-client-management'); ?>
                </a>
                <a href="?tab=ads" class="bocm-tab <?php echo $current_tab === 'ads' ? 'active' : ''; ?>">
                    <?php _e('Google Ads', 'blue-oak-client-management'); ?>
                </a>
                <a href="?tab=search-console" class="bocm-tab <?php echo $current_tab === 'search-console' ? 'active' : ''; ?>">
                    <?php _e('Google Search Console', 'blue-oak-client-management'); ?>
                </a>
                <a href="?tab=upgrade" class="bocm-tab <?php echo $current_tab === 'upgrade' ? 'active' : ''; ?>">
                    <?php _e('Upgrade', 'blue-oak-client-management'); ?>
                </a>
            </div>

            <?php if ($current_tab === 'overview'): ?>
                <!-- Overview Tab Content -->
                <div id="bocm-overview-tab" class="bocm-tab-content">
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/overview.php'; ?>
                </div>

            <?php elseif ($current_tab === 'uptime'): ?>
                <!-- Uptime Tab -->
                <div id="bocm-uptime-tab" class="bocm-tab-content">
                    <?php
                    // Prepare response time data for JavaScript
                    if (!empty($uptime_monitor_id)) {
                        $response_times = $this->uptime_robot->get_response_times($uptime_monitor_id, 24);
                        $times = array_map(function($rt) { return $rt['value']; }, $response_times);
                        $labels = array_map(function($rt) { 
                            return wp_date('H:i', $rt['datetime']); 
                        }, $response_times);
                        
                        echo '<script>window.responseData = ' . json_encode([
                            'times' => $times,
                            'labels' => $labels
                        ]) . ';</script>';
                    }
                    ?>
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/uptime.php'; ?>
                </div>

            <?php elseif ($current_tab === 'analytics'): ?>
                <!-- Google Analytics Tab -->
                <div id="bocm-google-analytics-tab" class="bocm-tab-content">
                    <?php
                    // Get the user's Google Analytics property ID
                    $property_id = get_user_meta($user->ID, 'bocm_ga_property_id', true);
                    
                    // If property ID exists, fetch analytics data and pass to JavaScript
                    if (!empty($property_id)) {
                        // Get analytics data for the past 30 days (default time period)
                        $analytics_data = $this->google_analytics->get_analytics_data($property_id, 30);
                        
                        // Only proceed if we have data (no errors)
                        if (!isset($analytics_data['error'])) {
                            // Create JSON-encoded string for JavaScript
                            echo '<script>window.analyticsData = ' . json_encode($analytics_data) . ';</script>';
                        } else {
                            // Log the error
                            error_log('BOCM Error fetching analytics data: ' . $analytics_data['error']);
                        }
                    }
                    ?>
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/google-analytics.php'; ?>
                </div>

            <?php elseif ($current_tab === 'ads'): ?>
                <!-- Google Ads Tab -->
                <div id="bocm-google-ads-tab" class="bocm-tab-content">
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/google-ads.php'; ?>
                </div>

            <?php elseif ($current_tab === 'search-console'): ?>
                <!-- Search Console Tab -->
                <div id="bocm-search-console-tab" class="bocm-tab-content">
                    <?php
                    // Get the user's Google Search Console site URL
                    $site_url = get_user_meta($user->ID, 'bocm_gsc_site_url', true);
                    
                    // If site URL exists, fetch search console data and pass to JavaScript
                    if (!empty($site_url)) {
                        // Get search console data for the past 28 days (default time period)
                        $search_console_data = $this->google_search_console->get_search_console_data($site_url, 28);
                        
                        // Only proceed if we have data (no errors)
                        if (!isset($search_console_data['error'])) {
                            // Create JSON-encoded string for JavaScript
                            echo '<script>window.searchConsoleData = ' . json_encode($search_console_data) . ';</script>';
                        } else {
                            // Log the error
                            error_log('BOCM Error fetching search console data: ' . $search_console_data['error']);
                            // Create JSON-encoded error object for JavaScript
                            echo '<script>window.searchConsoleData = ' . json_encode(['error' => $search_console_data['error']]) . ';</script>';
                        }
                    } else {
                        // No site URL configured
                        echo '<script>window.searchConsoleData = ' . json_encode(['error' => 'No Google Search Console site configured for this account.']) . ';</script>';
                    }
                    ?>
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/google-search-console.php'; ?>
                </div>

            <?php elseif ($current_tab === 'upgrade'): ?>
                <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/upgrade.php'; ?>

            <?php else: ?>
                <!-- Overview Tab -->
                <div id="bocm-overview-tab" class="bocm-tab-content">
                    <?php include BOCM_PLUGIN_DIR . 'includes/views/tabs/overview.php'; ?>
                </div>
            <?php endif; ?>

            <style>
                .bocm-portal-container {
                    max-width: 1200px;
                    margin: 0 auto;
                    padding: 20px;
                    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
                    background-color: rgb(34, 107, 135);
                }

                .bocm-uptime-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    margin-bottom: 15px;
                }

                .bocm-last-check-info {
                    font-size: 11px;
                    color: #64748b;
                    text-align: right;
                }

                .bocm-check-frequency {
                    display: block;
                    font-size: 10px;
                    color: #94a3b8;
                }

                body {
                    background-color: rgb(34, 107, 135);
                }
                .bocm-portal-grid {
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
                    gap: 20px;
                    margin-bottom: 20px;
                }
                .bocm-portal-stats {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                    margin-bottom: 20px;
                }
                .bocm-portal-card {
                    background: #fff;
                    border: 1px solid #e2e8f0;
                    border-radius: 8px;
                    padding: 20px;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                }
                .bocm-portal-card h3 {
                    margin: 0 0 15px;
                    font-size: 14px;
                    color: #4a5568;
                    font-weight: 500;
                    text-transform: uppercase;
                }
                .bocm-status-pill {
                    display: inline-flex;
                    align-items: center;
                    padding: 6px 12px;
                    border-radius: 20px;
                    font-size: 16px;
                    font-weight: 600;
                    margin-bottom: 15px;
                }
                .bocm-status-pill.up {
                    background-color: #def7ec;
                    color: #03543f;
                }
                .bocm-status-pill.down {
                    background-color: #fde8e8;
                    color: #9b1c1c;
                }
                .bocm-status-details {
                    border-top: 1px solid #e2e8f0;
                    padding-top: 15px;
                }
                .bocm-uptime-duration {
                    color: #718096;
                    font-size: 14px;
                }
                .bocm-uptime-bar {
                    height: 24px;
                    background: #edf2f7;
                    border-radius: 12px;
                    overflow: hidden;
                    margin-bottom: 10px;
                }
                .bocm-uptime-indicator {
                    height: 100%;
                    background: #48bb78;
                    border-radius: 12px;
                    transition: width 0.3s ease;
                }
                .bocm-uptime-stats {
                    color: #718096;
                    font-size: 14px;
                }
                .bocm-uptime-percentage {
                    font-size: 32px;
                    font-weight: 600;
                    color: #2d3748;
                    margin-bottom: 5px;
                }
                .bocm-response-stats {
                    display: flex;
                    gap: 20px;
                    margin-bottom: 20px;
                }
                .bocm-stat {
                    display: flex;
                    flex-direction: column;
                }
                .bocm-stat-label {
                    font-size: 14px;
                    color: #718096;
                    margin-bottom: 5px;
                }
                .bocm-stat-value {
                    font-size: 18px;
                    font-weight: 600;
                    color: #2d3748;
                }
                #responseTimeChart {
                    width: 100%;
                    height: 200px;
                    margin-top: 20px;
                }
                .bocm-subtitle {
                    color: #718096;
                    font-weight: normal;
                    font-size: 12px;
                    margin-left: 8px;
                }
                .bocm-90-days-chart {
                    margin-top: 20px;
                    overflow-x: auto;
                    position: relative;
                }
                .bocm-90-days-chart svg {
                    min-width: 720px;
                }
                .bocm-tooltip {
                    position: fixed;
                    background: #1a1c1e;
                    color: #fff;
                    padding: 8px 12px;
                    border-radius: 4px;
                    font-size: 13px;
                    pointer-events: none;
                    opacity: 0;
                    transition: opacity 0.2s;
                    transform: translate(-50%, -100%);
                    margin-top: -10px;
                    z-index: 100;
                    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
                    white-space: nowrap;
                }
                .bocm-tooltip::after {
                    content: '';
                    position: absolute;
                    bottom: -4px;
                    left: 50%;
                    transform: translateX(-50%) rotate(45deg);
                    width: 8px;
                    height: 8px;
                    background: #1a1c1e;
                }
                .bocm-tooltip .date {
                    opacity: 0.7;
                    font-size: 12px;
                    margin-bottom: 4px;
                }
                .bocm-tooltip .uptime {
                    font-weight: 600;
                }
                .bocm-response-header {
                    display: flex;
                    justify-content: space-between;
                    align-items: flex-start;
                    margin-bottom: 15px;
                    gap: 20px;
                }
                .bocm-response-side {
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                }

                .bocm-response-side:last-child {
                    align-items: flex-end;
                    text-align: right;
                }

                .bocm-response-side h3 {
                    margin: 0;
                    font-size: 14px;
                    color: #4a5568;
                    font-weight: 500;
                    text-transform: uppercase;
                }

                .bocm-status-info {
                    display: flex;
                    flex-direction: column;
                    gap: 8px;
                    align-items: flex-end;
                }
                .bocm-period-grid {
                    display: grid;
                    grid-template-columns: repeat(4, 1fr);
                    gap: 20px;
                    margin-top: 20px;
                }
                .bocm-period-grid .bocm-portal-card {
                    margin: 0;
                }
                .bocm-period-grid .bocm-uptime-value {
                    font-size: 24px;
                    font-weight: 600;
                    color: #2d3748;
                    margin: 10px 0 5px;
                    text-align: center;
                }
                .bocm-period-grid .bocm-incident-count {
                    color: #718096;
                    font-size: 14px;
                    text-align: center;
                }
                @media (max-width: 1200px) {
                    .bocm-period-grid {
                        grid-template-columns: repeat(2, 1fr);
                    }
                }
                @media (max-width: 640px) {
                    .bocm-period-grid {
                        grid-template-columns: 1fr;
                    }
                }

                /* Tab Styles */
                .bocm-tabs {
                    display: flex;
                    gap: 2px;
                    background: #f1f5f9;
                    padding: 4px;
                    border-radius: 8px;
                    margin-bottom: 20px;
                }

                .bocm-tab {
                    padding: 12px 24px;
                    color: #64748b;
                    text-decoration: none;
                    border-radius: 6px;
                    font-weight: 500;
                    transition: all 0.2s ease;
                }

                .bocm-tab:hover {
                    background: #e2e8f0;
                    color: #334155;
                }

                .bocm-tab.active {
                    background: #fff;
                    color: #0f172a;
                    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
                }

                .bocm-tab-content {
                    display: flex;
                    flex-direction: column;
                    gap: 20px;
                }

                @media (max-width: 640px) {
                    .bocm-tabs {
                        flex-direction: column;
                        gap: 4px;
                    }

                    .bocm-tab {
                        text-align: center;
                    }
                }

                .bocm-action-buttons {
                    display: grid;
                    grid-template-columns: repeat(3, 1fr);
                    gap: 20px;
                    margin-top: 20px;
                }

                .bocm-action-button {
                    display: flex;
                    align-items: center;
                    gap: 12px;
                    padding: 16px 24px;
                    background: #ffffff;
                    border: 2px solid #e2e8f0;
                    border-radius: 12px;
                    color: #1e293b;
                    text-decoration: none;
                    font-weight: 600;
                    font-size: 15px;
                    transition: all 0.3s ease;
                    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.05);
                }

                .bocm-action-button:not(.disabled):hover {
                    background: #f8fafc;
                    border-color: #7e3ff2;
                    transform: translateY(-2px);
                    box-shadow: 0 4px 12px rgba(126, 63, 242, 0.15);
                }

                .bocm-action-button:not(.disabled):active {
                    transform: translateY(0);
                }

                .bocm-button-icon {
                    display: flex;
                    align-items: center;
                    justify-content: center;
                    width: 36px;
                    height: 36px;
                    background: #f1f5f9;
                    border-radius: 10px;
                    color: #7e3ff2;
                    font-size: 18px;
                    transition: all 0.3s ease;
                }

                .bocm-action-button:not(.disabled):hover .bocm-button-icon {
                    background: #7e3ff2;
                    color: #ffffff;
                }

                .bocm-button-arrow {
                    margin-left: auto;
                    font-size: 14px;
                    color: #94a3b8;
                    transition: all 0.3s ease;
                }

                .bocm-action-button:not(.disabled):hover .bocm-button-arrow {
                    color: #7e3ff2;
                }

                .bocm-action-button.disabled {
                    cursor: not-allowed;
                    opacity: 0.7;
                }

                .bocm-button-disabled-message {
                    display: none;
                }

                .bocm-action-button.disabled .bocm-button-disabled-message {
                    display: inline-block;
                    margin-left: 8px;
                    font-size: 12px;
                    color: #64748b;
                }

                @media (max-width: 1024px) {
                    .bocm-action-buttons {
                        grid-template-columns: 1fr;
                    }
                }

                .bocm-card-content {
                    display: flex;
                    flex-direction: column;
                    gap: 24px;
                }

                .bocm-card-section {
                    border-bottom: 1px solid #e2e8f0;
                    padding-bottom: 20px;
                }

                .bocm-card-section:last-child {
                    border-bottom: none;
                    padding-bottom: 0;
                }

                .bocm-card-section h4 {
                    font-size: 16px;
                    font-weight: 600;
                    color: #2d3748;
                    margin: 0 0 12px;
                }

                .bocm-card-section p {
                    color: #718096;
                    font-size: 14px;
                    line-height: 1.5;
                    margin: 0;
                }

                .bocm-metric-list {
                    list-style: none;
                    margin: 0;
                    padding: 0;
                    display: grid;
                    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
                    gap: 12px;
                }

                .bocm-metric-list li {
                    color: #4a5568;
                    font-size: 14px;
                    padding: 8px 12px;
                    background: #f7fafc;
                    border-radius: 6px;
                    display: flex;
                    align-items: center;
                }

                .bocm-metric-list li::before {
                    content: "•";
                    color: #7e3ff2;
                    font-size: 18px;
                    margin-right: 8px;
                }

                /* Remove Font Awesome import as it's now properly enqueued */
            </style>

            <!-- ApexCharts for Response Time -->
            <script src="https://cdn.jsdelivr.net/npm/apexcharts"></script>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Add custom fields to user creation form
     *
     * @return void
     */
    public function add_custom_user_creation_fields(): void {
        // Only show for administrators
        if (!current_user_can('manage_options')) {
            return;
        }

        $this->render_blue_oak_fields();
    }

    /**
     * Add custom fields to user profile
     *
     * @param \WP_User $user The user object.
     * @return void
     */
    public function add_custom_user_profile_fields(\WP_User $user): void {
        // Only show these fields for Blue Oak Client role
        if (!in_array('blue_oak_client', $user->roles) && !current_user_can('manage_options')) {
            return;
        }

        $this->render_blue_oak_fields($user);
    }

    /**
     * Render Blue Oak fields
     *
     * @param \WP_User|null $user The user object or null for new user.
     * @return void
     */
    public function render_blue_oak_fields(?\WP_User $user = null): void {
        // Check if current user is an admin
        $is_admin = current_user_can('manage_options');

        // Get API options if admin
        $monitor_options = $is_admin ? $this->uptime_robot->get_monitor_options() : [];
        $ga_options = $is_admin ? $this->google_analytics->get_property_options() : [];
        ?>
        </br></br>
        <h2><?php _e('Blue Oak Settings', 'blue-oak-client-management'); ?></h2>
        <table class="form-table">
            <tr>
                <th>
                    <label for="bocm_partner_account_group_id">
                        <?php _e('Partner Account Group ID', 'blue-oak-client-management'); ?>
                    </label>
                </th>
                <td>
                    <?php if ($is_admin): ?>
                        <?php
                        $vendasta = new Vendasta();
                        $account_groups = $vendasta->get_account_group_options();
                        ?>
                        <select name="bocm_partner_account_group_id" 
                                id="bocm_partner_account_group_id" 
                                class="regular-text">
                            <?php foreach ($account_groups as $value => $label): ?>
                                <option value="<?php echo esc_attr($value); ?>" 
                                        <?php selected($user ? get_user_meta($user->ID, 'bocm_partner_account_group_id', true) : '', $value); ?>>
                                    <?php echo esc_html($label); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                        <p class="description">
                            <?php _e('Select the Partner Account Group ID for this client.', 'blue-oak-client-management'); ?>
                        </p>
                    <?php else: ?>
                        <p>
                            <?php 
                            if ($user) {
                                $group_id = get_user_meta($user->ID, 'bocm_partner_account_group_id', true);
                                $vendasta = new Vendasta();
                                $account_groups = $vendasta->get_account_group_options();
                                echo esc_html($account_groups[$group_id] ?? $group_id);
                            }
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="bocm_ga_property_id">
                        <?php _e('Google Analytics Property', 'blue-oak-client-management'); ?>
                    </label>
                </th>
                <td>
                    <?php if ($is_admin): ?>
                        <?php if (!empty($ga_options)): ?>
                            <select name="bocm_ga_property_id" 
                                    id="bocm_ga_property_id" 
                                    class="regular-text">
                                <?php foreach ($ga_options as $id => $name): ?>
                                    <option value="<?php echo esc_attr($id); ?>" 
                                            <?php echo $user ? selected(get_user_meta($user->ID, 'bocm_ga_property_id', true), $id, false) : ''; ?>>
                                        <?php echo esc_html($name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php _e('Select the Google Analytics property for this client.', 'blue-oak-client-management'); ?>
                            </p>
                        <?php else: ?>
                            <p class="description">
                                <?php _e('Please add your Google Analytics API Key in the plugin settings to view available properties.', 'blue-oak-client-management'); ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=blue-oak-client-management-settings')); ?>">
                                    <?php _e('Go to Settings', 'blue-oak-client-management'); ?> →
                                </a>
                            </p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p>
                            <?php
                            if ($user) {
                                $property_id = get_user_meta($user->ID, 'bocm_ga_property_id', true);
                                if (!empty($property_id)) {
                                    echo esc_html($ga_options[$property_id] ?? $property_id);
                                }
                            }
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="bocm_gsc_site_url">
                        <?php _e('Google Search Console Site', 'blue-oak-client-management'); ?>
                    </label>
                </th>
                <td>
                    <?php if ($is_admin): ?>
                        <?php 
                        // Debug information
                        error_log('BOCM User Profile: Getting GSC site options for dropdown');
                        $gsc_options = $this->google_search_console->get_site_options(); 
                        
                        // Log what we got back
                        error_log('BOCM User Profile: Got ' . count($gsc_options) . ' GSC site options');
                        error_log('BOCM User Profile: First option key: ' . array_key_first($gsc_options));
                        
                        if (!empty($gsc_options) && count($gsc_options) > 1): // More than just the placeholder
                        ?>
                            <select name="bocm_gsc_site_url" 
                                    id="bocm_gsc_site_url" 
                                    class="regular-text">
                                <?php foreach ($gsc_options as $url => $name): ?>
                                    <option value="<?php echo esc_attr($url); ?>" 
                                            <?php echo $user ? selected(get_user_meta($user->ID, 'bocm_gsc_site_url', true), $url, false) : ''; ?>>
                                        <?php echo esc_html($name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php _e('Select the Google Search Console site for this client.', 'blue-oak-client-management'); ?>
                            </p>
                        <?php else: ?>
                            <p class="description">
                                <?php 
                                // Debug what went wrong
                                if (empty($gsc_options)) {
                                    error_log('BOCM User Profile: GSC options array is empty');
                                } else {
                                    error_log('BOCM User Profile: Only found placeholder in GSC options, count: ' . count($gsc_options));
                                }
                                
                                _e('Please add your Google Search Console service account credentials in the plugin settings to view available sites.', 'blue-oak-client-management'); 
                                ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=blue-oak-client-management-settings&tab=google-search-console')); ?>"><?php _e('Go to Settings →', 'blue-oak-client-management'); ?></a>
                            </p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p>
                            <?php
                            if ($user) {
                                $site_url = get_user_meta($user->ID, 'bocm_gsc_site_url', true);
                                if (!empty($site_url)) {
                                    $gsc_options = $this->google_search_console->get_site_options();
                                    echo esc_html($gsc_options[$site_url] ?? $site_url);
                                }
                            }
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="bocm_reporting_url">
                        <?php _e('Reporting URL', 'blue-oak-client-management'); ?>
                    </label>
                </th>
                <td>
                    <?php if ($is_admin): ?>
                        <input type="url" 
                               name="bocm_reporting_url" 
                               id="bocm_reporting_url" 
                               value="<?php echo $user ? esc_url(get_user_meta($user->ID, 'bocm_reporting_url', true)) : ''; ?>" 
                               class="regular-text" />
                        <p class="description">
                            <?php _e('Enter the reporting dashboard URL for this client.', 'blue-oak-client-management'); ?>
                        </p>
                    <?php else: ?>
                        <p>
                            <?php 
                            if ($user) {
                                $reporting_url = get_user_meta($user->ID, 'bocm_reporting_url', true);
                                if (!empty($reporting_url)) {
                                    echo sprintf(
                                        '<a href="%1$s" target="_blank">%2$s</a>',
                                        esc_url($reporting_url),
                                        esc_html($reporting_url)
                                    );
                                }
                            }
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>
                    <label for="bocm_uptime_monitor_id">
                        <?php _e('Uptime Monitor', 'blue-oak-client-management'); ?>
                    </label>
                </th>
                <td>
                    <?php if ($is_admin): ?>
                        <?php if (!empty($monitor_options)): ?>
                            <select name="bocm_uptime_monitor_id" 
                                    id="bocm_uptime_monitor_id" 
                                    class="regular-text">
                                <?php foreach ($monitor_options as $id => $name): ?>
                                    <option value="<?php echo esc_attr($id); ?>" 
                                            <?php echo $user ? selected(get_user_meta($user->ID, 'bocm_uptime_monitor_id', true), $id, false) : ''; ?>>
                                        <?php echo esc_html($name); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <p class="description">
                                <?php _e('Select the Uptime Robot monitor for this client.', 'blue-oak-client-management'); ?>
                            </p>
                        <?php else: ?>
                            <p class="description">
                                <?php _e('Please add your Uptime Robot API Key in the plugin settings to view available monitors.', 'blue-oak-client-management'); ?>
                                <a href="<?php echo esc_url(admin_url('admin.php?page=blue-oak-client-management-settings')); ?>">
                                    <?php _e('Go to Settings', 'blue-oak-client-management'); ?> →
                                </a>
                            </p>
                        <?php endif; ?>
                    <?php else: ?>
                        <p>
                            <?php
                            if ($user) {
                                $monitor_id = get_user_meta($user->ID, 'bocm_uptime_monitor_id', true);
                                if (!empty($monitor_id)) {
                                    $monitors = $this->uptime_robot->get_monitors();
                                    $monitor = current(array_filter($monitors, function($m) use ($monitor_id) {
                                        return $m['id'] == $monitor_id;
                                    }));
                                    if ($monitor) {
                                        echo esc_html(sprintf(
                                            '%s (%s)',
                                            $monitor['name'],
                                            $monitor['url']
                                        ));
                                    }
                                }
                            }
                            ?>
                        </p>
                    <?php endif; ?>
                </td>
            </tr>
        </table>
        <?php
    }

    /**
     * Save custom user profile fields
     *
     * @param int $user_id The user ID.
     * @return bool|void
     */
    public function save_custom_user_profile_fields(int $user_id) {
        // Only allow administrators to save these fields
        if (!current_user_can('manage_options')) {
            return false;
        }

        if (!current_user_can('edit_user', $user_id)) {
            return false;
        }

        // Verify the nonce
        check_admin_referer('update-user_' . $user_id);

        $this->save_fields($user_id);
    }

    /**
     * Save custom user creation fields
     *
     * @param int $user_id The user ID.
     * @return void
     */
    public function save_custom_user_creation_fields(int $user_id): void {
        // Only allow administrators to save these fields
        if (!current_user_can('manage_options')) {
            return;
        }

        $this->save_fields($user_id);
    }

    /**
     * Save the custom fields
     *
     * @param int $user_id The user ID.
     * @return void
     */
    private function save_fields(int $user_id): void {
        // Save Partner Account Group ID
        if (isset($_POST['bocm_partner_account_group_id'])) {
            update_user_meta(
                $user_id,
                'bocm_partner_account_group_id',
                sanitize_text_field($_POST['bocm_partner_account_group_id'])
            );
        }

        // Save Google Analytics Property ID
        if (isset($_POST['bocm_ga_property_id'])) {
            update_user_meta(
                $user_id,
                'bocm_ga_property_id',
                sanitize_text_field($_POST['bocm_ga_property_id'])
            );
        }

        // Save Google Search Console Site URL
        if (isset($_POST['bocm_gsc_site_url'])) {
            update_user_meta(
                $user_id,
                'bocm_gsc_site_url',
                esc_url_raw($_POST['bocm_gsc_site_url'])
            );
        }

        // Save Reporting URL
        if (isset($_POST['bocm_reporting_url'])) {
            update_user_meta(
                $user_id,
                'bocm_reporting_url',
                esc_url_raw($_POST['bocm_reporting_url'])
            );
        }

        // Save Uptime Monitor ID
        if (isset($_POST['bocm_uptime_monitor_id'])) {
            update_user_meta(
                $user_id,
                'bocm_uptime_monitor_id',
                sanitize_text_field($_POST['bocm_uptime_monitor_id'])
            );
        }
    }

    /**
     * Render the Account Partner ID field
     *
     * @param WP_User $user The user object
     * @return void
     */
    public function render_account_partner_id_field(WP_User $user): void {
        $value = get_user_meta($user->ID, 'bocm_account_partner_id', true);
        $vendasta = new Vendasta();
        $account_groups = $vendasta->get_account_groups();
        ?>
        <select name="bocm_account_partner_id" id="bocm_account_partner_id" class="regular-text">
            <option value=""><?php _e('Select an Account Group', 'blue-oak-client-management'); ?></option>
            <?php if (!empty($account_groups)): ?>
                <?php foreach ($account_groups as $group): ?>
                    <option value="<?php echo esc_attr($group['id']); ?>" <?php selected($value, $group['id']); ?>>
                        <?php echo esc_html($group['name']); ?>
                    </option>
                <?php endforeach; ?>
            <?php else: ?>
                <option value="" disabled><?php _e('No account groups available. Please check your Vendasta service account credentials.', 'blue-oak-client-management'); ?></option>
            <?php endif; ?>
        </select>
        <p class="description">
            <?php _e('Select the Vendasta Account Group this user belongs to.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * Redirect Blue Oak clients to the client portal after login
     *
     * @param string   $redirect_to URL to redirect to.
     * @param string   $requested_redirect_to The requested redirect URL.
     * @param WP_User|WP_Error $user WP_User if the user is authenticated, WP_Error otherwise.
     * @return string
     */
    public function redirect_blue_oak_clients(string $redirect_to, string $requested_redirect_to, $user): string {
        // Check if user is a Blue Oak client
        if ($user instanceof \WP_User && in_array('blue_oak_client', $user->roles)) {
            // If there's a specific redirect requested, honor it
            if (!empty($requested_redirect_to)) {
                return $requested_redirect_to;
            }
            // Otherwise redirect to the client portal
            return home_url('/client-portal/');
        }
        return $redirect_to;
    }

    /**
     * Fetch Google Analytics data via AJAX
     */
    public function fetch_analytics_data(): void {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_analytics_nonce')) {
            wp_send_json_error(['message' => 'Invalid security token. Please refresh the page.']);
            return;
        }
        
        // Get current user
        $user_id = get_current_user_id();
        if (!$user_id) {
            wp_send_json_error(['message' => 'You must be logged in to perform this action.']);
            return;
        }
        
        // Get days parameter with default of 30
        $days = isset($_POST['days']) ? intval($_POST['days']) : 30;
        
        // Validate days (between 1 and 90)
        if ($days < 1 || $days > 90) {
            $days = 30; // Reset to default if out of range
        }
        
        // Get property ID
        $property_id = get_user_meta($user_id, 'bocm_ga_property_id', true);
        if (empty($property_id)) {
            wp_send_json_error(['message' => 'No Google Analytics property configured for this account.']);
            return;
        }
        
        // Fetch the data
        $analytics_data = $this->google_analytics->get_analytics_data($property_id, $days);
        
        // Check for errors
        if (isset($analytics_data['error'])) {
            wp_send_json_error(['message' => $analytics_data['error']]);
            return;
        }
        
        // Return the data
        wp_send_json_success($analytics_data);
    }

    /**
     * Initialize AJAX hooks
     */
    public function init_ajax_hooks(): void {
        add_action('wp_ajax_bocm_fetch_analytics_data', [$this, 'fetch_analytics_data']);
        add_action('wp_ajax_bocm_fetch_search_console_data', [$this, 'fetch_search_console_data']);
    }

    /**
     * Fetch Google Search Console data via AJAX
     *
     * @return void
     */
    public function fetch_search_console_data(): void {
        // Check nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_search_console_nonce')) {
            wp_send_json_error(['message' => 'Invalid security token sent.']);
            return;
        }
        
        // Check user permissions
        if (!current_user_can('read')) {
            wp_send_json_error(['message' => 'You do not have permission to access this data.']);
            return;
        }
        
        // Get the user ID
        $user_id = get_current_user_id();
        
        // Check days parameter
        $days = isset($_POST['days']) ? (int)$_POST['days'] : 28;
        
        // Validate days
        if ($days < 1 || $days > 90) {
            $days = 28; // Reset to default if invalid
        }
        
        // Get the site URL from user meta
        $site_url = get_user_meta($user_id, 'bocm_gsc_site_url', true);
        if (empty($site_url)) {
            wp_send_json_error(['message' => 'No Google Search Console site configured for this account.']);
            return;
        }
        
        // Fetch the data
        $search_console_data = $this->google_search_console->get_search_console_data($site_url, $days);
        
        // Check for errors
        if (isset($search_console_data['error'])) {
            wp_send_json_error(['message' => $search_console_data['error']]);
            return;
        }
        
        // Return the data
        wp_send_json_success($search_console_data);
    }

    /**
     * AJAX endpoint to refresh uptime data
     */
    public function ajax_refresh_uptime_data(): void {
        // Security check - verify user is logged in or nonce for guests
        if (!is_user_logged_in() && !check_ajax_referer('bocm_uptime_refresh', 'nonce', false)) {
            wp_send_json_error([
                'message' => __('Security check failed.', 'blue-oak-client-management')
            ]);
            return;
        }
        
        // Get the user ID from the request
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        
        // If no user ID provided, use current user
        if (empty($user_id) && is_user_logged_in()) {
            $user_id = get_current_user_id();
        }
        
        // Verify user exists
        $user = get_user_by('id', $user_id);
        if (!$user) {
            wp_send_json_error([
                'message' => __('Invalid user ID.', 'blue-oak-client-management')
            ]);
            return;
        }
        
        // Get monitor data with retries
        $uptime_monitor_id = get_user_meta($user_id, 'bocm_uptime_monitor_id', true);
        $monitor_data = null;
        $has_monitor = false;
        $retry_attempts = 0;
        $max_retries = 3;
        $started_at = microtime(true);
        $timeout = 10; // 10 second timeout for all retries combined
        
        error_log('BOCM AJAX: Refreshing uptime data for user ' . $user_id . ', monitor: ' . $uptime_monitor_id);
        
        if (!empty($uptime_monitor_id)) {
            // Try to get monitors with retries
            while ($retry_attempts < $max_retries && (microtime(true) - $started_at) < $timeout) {
                $monitors = $this->uptime_robot->get_monitors();
                
                // Log the monitor count
                error_log('BOCM AJAX: Found ' . count($monitors) . ' monitors in total (attempt ' . ($retry_attempts + 1) . ')');
                
                if (!empty($monitors)) {
                    $monitor_data = current(array_filter($monitors, function($m) use ($uptime_monitor_id) {
                        return $m['id'] == $uptime_monitor_id;
                    }));
                    $has_monitor = !empty($monitor_data);
                    
                    if ($has_monitor) {
                        // We found our monitor, break out of retry loop
                        error_log('BOCM AJAX: Monitor found on attempt ' . ($retry_attempts + 1));
                        
                        // Cache the monitor data for 5 minutes
                        $cache_key = 'bocm_uptime_monitor_' . $uptime_monitor_id;
                        $cache_duration = get_option('bocm_uptimerobot_cache_duration', 10);
                        set_transient($cache_key, $monitor_data, $cache_duration * MINUTE_IN_SECONDS);
                        
                        break;
                    }
                }
                
                // Only retry if we didn't find our monitor
                $retry_attempts++;
                
                if ($retry_attempts < $max_retries) {
                    // Small delay between retries (100ms)
                    usleep(100000);
                }
            }
        }
        
        if (!$has_monitor && !empty($uptime_monitor_id)) {
            wp_send_json_error([
                'message' => __('Monitor not found after multiple attempts.', 'blue-oak-client-management'),
                'monitor_id' => $uptime_monitor_id,
                'attempts' => $retry_attempts
            ]);
            return;
        }
        
        // Calculate Uptime Score
        $uptime_score = 0;
        $uptime_grade = 'F';
        $custom_uptime_ratio = $monitor_data['custom_uptime_ratio'] ?? '';
        $monitor_status = $monitor_data['status'] ?? 0;
        $monitor_status_text = $monitor_data['status_text'] ?? '';
        
        // Handle both string and float values
        if (is_string($custom_uptime_ratio) && strpos($custom_uptime_ratio, '-') !== false) {
            // Handle string format with multiple values
            $valid_uptimes = array_filter(explode('-', $custom_uptime_ratio), function($value) {
                return (float)$value > 0.001;
            });
            if (!empty($valid_uptimes)) {
                $uptime_score = array_sum($valid_uptimes) / count($valid_uptimes);
            }
        } elseif (!empty($custom_uptime_ratio)) {
            // Single value
            $uptime_score = (float)$custom_uptime_ratio;
        }
        
        // Calculate grade based on uptime percentage
        $uptime_grade = match(true) {
            $uptime_score >= 99.9 => 'A',
            $uptime_score >= 99.5 => 'B',
            $uptime_score >= 99.2 => 'C',
            $uptime_score >= 99.0 => 'D',
            default => 'F',
        };
        
        // Determine display status
        $display_uptime_data = $has_monitor && !empty($monitor_data) && ($uptime_score > 0 || !empty($custom_uptime_ratio));
        $monitor_is_checking = $has_monitor && !empty($monitor_data) && $monitor_status == 1; // Status 1 means "Not Checked Yet"
        $monitor_is_initializing = $has_monitor && (empty($monitor_data) || $monitor_status == 0 || $uptime_score <= 0); // Status 0 means "Paused"
        $is_monitor_configured = !empty($uptime_monitor_id); // Added explicit check for configured monitor
        
        error_log('BOCM AJAX: Display decision - Has monitor: ' . ($has_monitor ? 'Yes' : 'No') . 
                ', Display data: ' . ($display_uptime_data ? 'Yes' : 'No') . 
                ', Is checking: ' . ($monitor_is_checking ? 'Yes' : 'No') . 
                ', Is initializing: ' . ($monitor_is_initializing ? 'Yes' : 'No') . 
                ', Is configured: ' . ($is_monitor_configured ? 'Yes' : 'No'));
        
        // Prepare HTML for the response
        ob_start();
        ?>
        <div class="bocm-score-header">
            <h3><?php _e('Uptime', 'blue-oak-client-management'); ?></h3>
            <?php if ($display_uptime_data): ?>
                <div class="bocm-grade <?php echo strtolower($uptime_grade); ?>">
                    <svg class="grade-hexagon" height="64" viewBox="0 0 64 64" width="64" xmlns="http://www.w3.org/2000/svg">
                        <path class="hex-bg" d="M 57.212 46.562 L 32.004 61.116 L 6.797 46.562 L 6.797 17.457 L 32.004 2.903 L 57.212 17.457 Z" stroke-width="5"></path>
                        <text x="50%" y="50%" text-anchor="middle" dy=".3em" class="grade-text"><?php echo $uptime_grade; ?></text>
                    </svg>
                </div>
            <?php else: ?>
                <div class="bocm-scanning">
                    <div class="bocm-scanning-spinner"></div>
                </div>
            <?php endif; ?>
        </div>
        <?php if ($display_uptime_data): ?>
            <div class="bocm-score-value"><?php echo number_format($uptime_score, 2); ?>%</div>
            <div class="bocm-score-label"><?php _e('30-Day Uptime', 'blue-oak-client-management'); ?></div>
        <?php elseif ($monitor_is_checking): ?>
            <div class="bocm-score-value"><?php _e('Checking...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('Monitor is being checked', 'blue-oak-client-management'); ?></div>
        <?php elseif ($monitor_is_initializing): ?>
            <div class="bocm-score-value"><?php _e('Initializing...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('Collecting uptime data', 'blue-oak-client-management'); ?></div>
        <?php elseif ($has_monitor && empty($monitor_data)): ?>
            <div class="bocm-score-value"><?php _e('Connection issue', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('Monitoring is active, please check back soon', 'blue-oak-client-management'); ?></div>
        <?php elseif ($is_monitor_configured): ?>
            <div class="bocm-score-value shimmer"><?php _e('Activating...', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label shimmer"><?php _e('Monitor is configured but data is not yet available', 'blue-oak-client-management'); ?></div>
        <?php else: ?>
            <div class="bocm-score-value"><?php _e('Not configured', 'blue-oak-client-management'); ?></div>
            <div class="bocm-score-label"><?php _e('No uptime monitoring set up', 'blue-oak-client-management'); ?></div>
        <?php endif; ?>
        <?php
        $html = ob_get_clean();
        
        wp_send_json_success([
            'html' => $html,
            'has_monitor' => $has_monitor,
            'uptime_score' => $uptime_score,
            'uptime_grade' => $uptime_grade,
            'monitor_status' => $monitor_status,
            'monitor_status_text' => $monitor_status_text,
            'is_monitor_configured' => $is_monitor_configured
        ]);
    }
} 