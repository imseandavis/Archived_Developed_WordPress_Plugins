<?php
declare(strict_types=1);

namespace BlueOak\ClientManagement;

class Namecheap {
    private string $api_key;
    private string $api_user;
    private string $client_ip;
    private string $api_url;
    private bool $sandbox_mode;

    public function __construct(?string $api_key = null) {
        $this->api_key = $api_key ?? get_option('bocm_namecheap_api_key', '');
        $this->api_user = get_option('bocm_namecheap_username', '');
        $this->client_ip = $this->get_client_ip();
        $this->sandbox_mode = (bool)get_option('bocm_namecheap_sandbox_mode', true);
        $this->api_url = $this->sandbox_mode 
            ? 'https://api.sandbox.namecheap.com/xml.response'
            : 'https://api.namecheap.com/xml.response';
    }

    /**
     * Log API request and response
     *
     * @param string $command The API command being executed
     * @param array $params The parameters being sent
     * @param string $response The API response
     * @return void
     */
    private function log_api_request(string $command, array $params, string $response): void {
        $log_message = sprintf(
            "[Namecheap API] Command: %s\nRequest URL: %s\nRequest Params: %s\nResponse: %s\n",
            $command,
            add_query_arg($params, $this->api_url),
            wp_json_encode($params, JSON_PRETTY_PRINT),
            $response
        );
        
        error_log($log_message);
    }

    /**
     * Make an API request with logging
     *
     * @param array $params API parameters
     * @return array|WP_Error Response from wp_remote_get
     */
    private function make_api_request(array $params): array|WP_Error {
        $command = $params['Command'] ?? 'unknown';
        $max_retries = 2;
        $attempt = 0;
        
        while ($attempt <= $max_retries) {
            $response = wp_remote_get(add_query_arg($params, $this->api_url), [
                'timeout' => 10,
                'sslverify' => true
            ]);
            
            if (is_wp_error($response)) {
                // Check if it's a timeout error
                if ($response->get_error_code() === 'http_request_failed' && 
                    strpos($response->get_error_message(), 'Operation timed out') !== false) {
                    $attempt++;
                    if ($attempt <= $max_retries) {
                        // Log retry attempt
                        error_log(sprintf(
                            "[Namecheap API] Timeout on attempt %d/%d, retrying...",
                            $attempt,
                            $max_retries
                        ));
                        continue;
                    }
                }
                
                $this->log_api_request($command, $params, $response->get_error_message());
                return $response;
            }

            $body = wp_remote_retrieve_body($response);
            $this->log_api_request($command, $params, $body);
            
            return $response;
        }
        
        // If we get here, all retries failed
        $error = new \WP_Error(
            'timeout',
            'Unable To Determine Domain Availability'
        );
        $this->log_api_request($command, $params, $error->get_error_message());
        return $error;
    }

    /**
     * Verify the API key by making a test request
     *
     * @param string|null $api_key Optional API key to verify (if not provided, uses stored key)
     * @return array Response containing verification status
     */
    public function verify_api_key(?string $api_key = null): array {
        // Use provided API key if available, otherwise use stored key
        $key_to_verify = $api_key ?? $this->api_key;
        
        // Log the values being used
        error_log(sprintf(
            "[Namecheap API Debug] Verifying API key with:\nApiUser: %s\nApiKey: %s\nClientIp: %s",
            $this->api_user,
            $key_to_verify ? 'Set' : 'Not Set',
            $this->client_ip
        ));

        if (empty($key_to_verify)) {
            return [
                'is_valid' => false,
                'message' => 'API key is not set'
            ];
        }

        if (empty($this->api_user)) {
            return [
                'is_valid' => false,
                'message' => 'Username is not set'
            ];
        }

        // Store original API URL
        $original_url = $this->api_url;
        
        // Temporarily set to production URL for verification
        $this->api_url = 'https://api.namecheap.com/xml.response';
        
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $key_to_verify,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.domains.getList'
        ];

        $response = $this->make_api_request($params);
        
        // Restore original API URL
        $this->api_url = $original_url;
        
        if (is_wp_error($response)) {
            return [
                'is_valid' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'is_valid' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        // Check API response status
        if ((string)$xml['Status'] !== 'OK') {
            return [
                'is_valid' => false,
                'message' => 'API returned error status: ' . (string)$xml['Status']
            ];
        }

        // Check for error response
        if (isset($xml->Errors) && count($xml->Errors->Error) > 0) {
            return [
                'is_valid' => false,
                'message' => (string)$xml->Errors->Error
            ];
        }

        // Check if we got a valid domain list response
        if (!isset($xml->CommandResponse->DomainGetListResult)) {
            return [
                'is_valid' => false,
                'message' => 'Invalid API response format'
            ];
        }

        return [
            'is_valid' => true,
            'message' => 'API key verified successfully'
        ];
    }

    /**
     * Check domain availability
     *
     * @param string $domain Domain name to check
     * @return array Response containing availability status and price if available
     */
    public function check_domain(string $domain): array {
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $this->api_key,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.domains.check',
            'DomainList' => $domain
        ];

        $response = $this->make_api_request($params);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'success' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        $domain_info = $xml->CommandResponse->DomainCheckResult;
        $is_available = (string)$domain_info['Available'] === 'true';
        
        // Get pricing information if domain is available
        $price_info = [];
        if ($is_available) {
            $price_info = $this->get_domain_pricing($domain);
        }
        
        $result = [
            'success' => true,
            'available' => $is_available,
            'price' => $price_info['success'] ? sprintf('$%s %s', ceil($price_info['price'] / 10) * 10, $price_info['currency']) : '',
            'domain' => (string)$domain_info['Domain']
        ];
        
        return $result;
    }

    /**
     * Purchase a domain
     *
     * @param string $domain Domain name to purchase
     * @param array $contact_info Contact information for domain registration
     * @return array Response containing purchase status
     */
    public function purchase_domain(string $domain, array $contact_info): array {
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $this->api_key,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.domains.create',
            'DomainName' => $domain,
            'Years' => 1,
            'AddFreeWhoisguard' => 'yes',
            'WGEnabled' => 'yes',
            'GenerateAdminSecurePassword' => 'true',
            'TechContactFirstName' => $contact_info['tech_first_name'],
            'TechContactLastName' => $contact_info['tech_last_name'],
            'TechContactAddress1' => $contact_info['tech_address'],
            'TechContactCity' => $contact_info['tech_city'],
            'TechContactStateProvince' => $contact_info['tech_state'],
            'TechContactPostalCode' => $contact_info['tech_postal_code'],
            'TechContactCountry' => $contact_info['tech_country'],
            'TechContactEmailAddress' => $contact_info['tech_email'],
            'TechContactPhone' => $contact_info['tech_phone'],
            'AdminContactFirstName' => $contact_info['admin_first_name'],
            'AdminContactLastName' => $contact_info['admin_last_name'],
            'AdminContactAddress1' => $contact_info['admin_address'],
            'AdminContactCity' => $contact_info['admin_city'],
            'AdminContactStateProvince' => $contact_info['admin_state'],
            'AdminContactPostalCode' => $contact_info['admin_postal_code'],
            'AdminContactCountry' => $contact_info['admin_country'],
            'AdminContactEmailAddress' => $contact_info['admin_email'],
            'AdminContactPhone' => $contact_info['admin_phone'],
            'RegistrantContactFirstName' => $contact_info['registrant_first_name'],
            'RegistrantContactLastName' => $contact_info['registrant_last_name'],
            'RegistrantContactAddress1' => $contact_info['registrant_address'],
            'RegistrantContactCity' => $contact_info['registrant_city'],
            'RegistrantContactStateProvince' => $contact_info['registrant_state'],
            'RegistrantContactPostalCode' => $contact_info['registrant_postal_code'],
            'RegistrantContactCountry' => $contact_info['registrant_country'],
            'RegistrantContactEmailAddress' => $contact_info['registrant_email'],
            'RegistrantContactPhone' => $contact_info['registrant_phone']
        ];

        $response = $this->make_api_request($params);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'success' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        return [
            'success' => true,
            'domain' => (string)$xml->CommandResponse->DomainCreateResult['Domain'],
            'registered' => (string)$xml->CommandResponse->DomainCreateResult['Registered'],
            'order_id' => (string)$xml->CommandResponse->DomainCreateResult['OrderId'],
            'transaction_id' => (string)$xml->CommandResponse->DomainCreateResult['TransactionId']
        ];
    }

    /**
     * Renew a domain
     *
     * @param string $domain Domain name to renew
     * @param int $years Number of years to renew for
     * @return array Response containing renewal status
     */
    public function renew_domain(string $domain, int $years = 1): array {
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $this->api_key,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.domains.renew',
            'DomainName' => $domain,
            'Years' => $years
        ];

        $response = $this->make_api_request($params);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'success' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        return [
            'success' => true,
            'domain' => (string)$xml->CommandResponse->DomainRenewResult['Domain'],
            'renewed' => (string)$xml->CommandResponse->DomainRenewResult['Renewed'],
            'order_id' => (string)$xml->CommandResponse->DomainRenewResult['OrderId'],
            'transaction_id' => (string)$xml->CommandResponse->DomainRenewResult['TransactionId'],
            'expiration_date' => (string)$xml->CommandResponse->DomainRenewResult['ExpirationDate']
        ];
    }

    /**
     * Get client IP address
     *
     * @return string Client IP address
     */
    private function get_client_ip(): string {
        $ip = '';
        
        if (isset($_SERVER['HTTP_CLIENT_IP'])) {
            $ip = $_SERVER['HTTP_CLIENT_IP'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_X_FORWARDED'])) {
            $ip = $_SERVER['HTTP_X_FORWARDED'];
        } elseif (isset($_SERVER['HTTP_FORWARDED_FOR'])) {
            $ip = $_SERVER['HTTP_FORWARDED_FOR'];
        } elseif (isset($_SERVER['HTTP_FORWARDED'])) {
            $ip = $_SERVER['HTTP_FORWARDED'];
        } elseif (isset($_SERVER['REMOTE_ADDR'])) {
            $ip = $_SERVER['REMOTE_ADDR'];
        }

        return filter_var($ip, FILTER_VALIDATE_IP);
    }

    /**
     * Get domain pricing information
     *
     * @param string $domain Domain name to check pricing for
     * @return array Response containing pricing information
     */
    public function getPricing(string $domain): array {
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $this->api_key,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.domains.getPricing',
            'ProductType' => 'DOMAIN',
            'ProductName' => $domain,
            'ProductCategory' => 'domains'
        ];

        $response = $this->make_api_request($params);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'success' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        // Check for error response
        if (isset($xml->Errors)) {
            return [
                'success' => false,
                'message' => (string)$xml->Errors->Error
            ];
        }

        $pricing = $xml->CommandResponse->DomainGetPricingResult;
        
        return [
            'success' => true,
            'domain' => (string)$pricing['Domain'],
            'price' => (string)$pricing['Price'],
            'currency' => (string)$pricing['Currency'],
            'period' => (string)$pricing['Period'],
            'available' => (string)$pricing['Available'] === 'true'
        ];
    }

    /**
     * Get pricing information for a domain TLD
     *
     * @param string $domain Domain name to get pricing for
     * @return array Response containing pricing information
     */
    public function get_domain_pricing(string $domain): array {
        // Extract TLD from domain
        $tld = substr($domain, strrpos($domain, '.') + 1);
        
        $params = [
            'ApiUser' => $this->api_user,
            'ApiKey' => $this->api_key,
            'UserName' => $this->api_user,
            'ClientIp' => $this->client_ip,
            'Command' => 'namecheap.users.getPricing',
            'ProductType' => 'DOMAIN',
            'ProductCategory' => 'DOMAINS',
            'ActionName' => 'RENEW',
            'ProductName' => $tld
        ];

        $response = $this->make_api_request($params);
        
        if (is_wp_error($response)) {
            return [
                'success' => false,
                'message' => $response->get_error_message()
            ];
        }

        $body = wp_remote_retrieve_body($response);
        $xml = simplexml_load_string($body);

        if (!$xml) {
            return [
                'success' => false,
                'message' => 'Failed to parse API response'
            ];
        }

        // Check for error response
        if (isset($xml->Errors) && count($xml->Errors->Error) > 0) {
            return [
                'success' => false,
                'message' => (string)$xml->Errors->Error
            ];
        }

        // Get the pricing information
        $pricing = $xml->CommandResponse->UserGetPricingResult;
        
        // Find the registration price for 1 year
        $registration_price = '';
        $currency = '';
        
        // Look for the registration price in the register category
        if (isset($pricing->ProductType)) {
            foreach ($pricing->ProductType as $product_type) {
                if ((string)$product_type['Name'] === 'domains') {
                    if (isset($product_type->ProductCategory)) {
                        foreach ($product_type->ProductCategory as $category) {
                            if ((string)$category['Name'] === 'renew') {
                                if (isset($category->Product)) {
                                    foreach ($category->Product as $product) {
                                        if ((string)$product['Name'] === $tld) {
                                            if (isset($product->Price)) {
                                                foreach ($product->Price as $price) {
                                                    if ((string)$price['Duration'] === '1') {
                                                        $registration_price = (string)$price['Price'];
                                                        $currency = (string)$price['Currency'];
                                                        break 2;
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        if (empty($registration_price)) {
            return [
                'success' => false,
                'message' => 'Could not find pricing information'
            ];
        }

        return [
            'success' => true,
            'price' => $registration_price,
            'currency' => $currency,
            'tld' => $tld
        ];
    }
} 