<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handle admin-specific functionality
 */
class Admin {
    /**
     * Initialize the class
     */
    public function __construct() {
        // Add user profile fields
        add_action('show_user_profile', [$this, 'add_client_profile_fields']);
        add_action('edit_user_profile', [$this, 'add_client_profile_fields']);
        
        // Save user profile fields
        add_action('personal_options_update', [$this, 'save_client_profile_fields']);
        add_action('edit_user_profile_update', [$this, 'save_client_profile_fields']);
        
        // Add admin menu
        add_action('admin_menu', [$this, 'register_settings_menu']);
    }

    /**
     * Add client profile extra fields
     */
    public function add_client_profile_fields(\WP_User $user): void {
        // Google Analytics
        $property_id = get_user_meta($user->ID, 'bocm_ga_property_id', true);
        
        // Get property options from Google Analytics instance
        $ga_instance = new GoogleAnalytics();
        $ga_property_options = $ga_instance->get_property_options();
        
        // Google Search Console
        $site_url = get_user_meta($user->ID, 'bocm_gsc_site_url', true);
        
        // Get site options from Google Search Console instance
        $gsc_instance = new GoogleSearchConsole();
        $gsc_site_options = $gsc_instance->get_site_options();
        
        // Uptime Robot
        $monitor_id = get_user_meta($user->ID, 'bocm_uptime_monitor_id', true);
        
        // Get monitors from Uptime Robot instance
        $uptime_robot = new UptimeRobot();
        $uptime_monitors = $uptime_robot->get_monitor_options();
        
        // Google Ads
        $customer_id = get_user_meta($user->ID, 'bocm_ads_customer_id', true);
        
        ?>
        <h2><?php _e('Blue Oak Client Management Settings', 'blue-oak-client-management'); ?></h2>
        <table class="form-table">
            <?php if (current_user_can('administrator')): ?>
            <tr>
                <th><label for="bocm_uptime_monitor_id"><?php _e('Uptime Robot Monitor', 'blue-oak-client-management'); ?></label></th>
                <td>
                    <select name="bocm_uptime_monitor_id" id="bocm_uptime_monitor_id">
                        <option value=""><?php _e('-- Select Monitor --', 'blue-oak-client-management'); ?></option>
                        <?php foreach ($uptime_monitors as $id => $name): ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($monitor_id, $id); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php _e('Select the Uptime Robot monitor to show in the client portal.', 'blue-oak-client-management'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="bocm_ga_property_id"><?php _e('Google Analytics Property', 'blue-oak-client-management'); ?></label></th>
                <td>
                    <select name="bocm_ga_property_id" id="bocm_ga_property_id">
                        <option value=""><?php _e('-- Select Property --', 'blue-oak-client-management'); ?></option>
                        <?php foreach ($ga_property_options as $id => $name): ?>
                            <option value="<?php echo esc_attr($id); ?>" <?php selected($property_id, $id); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php _e('Select the Google Analytics property to show in the client portal.', 'blue-oak-client-management'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="bocm_gsc_site_url"><?php _e('Google Search Console Site', 'blue-oak-client-management'); ?></label></th>
                <td>
                    <select name="bocm_gsc_site_url" id="bocm_gsc_site_url">
                        <option value=""><?php _e('-- Select Site --', 'blue-oak-client-management'); ?></option>
                        <?php foreach ($gsc_site_options as $url => $name): ?>
                            <option value="<?php echo esc_attr($url); ?>" <?php selected($site_url, $url); ?>><?php echo esc_html($name); ?></option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php _e('Select the Google Search Console site to show in the client portal.', 'blue-oak-client-management'); ?></p>
                </td>
            </tr>
            <tr>
                <th><label for="bocm_ads_customer_id"><?php _e('Google Ads Customer ID', 'blue-oak-client-management'); ?></label></th>
                <td>
                    <input type="text" name="bocm_ads_customer_id" id="bocm_ads_customer_id" value="<?php echo esc_attr($customer_id); ?>" class="regular-text" />
                    <p class="description"><?php _e('Enter the Google Ads customer ID in the format: 123-456-7890', 'blue-oak-client-management'); ?></p>
                </td>
            </tr>
            <?php endif; ?>
        </table>
        <?php
    }

    /**
     * Save client profile extra fields
     */
    public function save_client_profile_fields(int $user_id): void {
        if (!current_user_can('edit_user', $user_id)) {
            return;
        }

        // Update Google Analytics property ID
        if (isset($_POST['bocm_ga_property_id'])) {
            update_user_meta($user_id, 'bocm_ga_property_id', sanitize_text_field($_POST['bocm_ga_property_id']));
        }
        
        // Update Google Search Console site URL
        if (isset($_POST['bocm_gsc_site_url'])) {
            update_user_meta($user_id, 'bocm_gsc_site_url', sanitize_text_field($_POST['bocm_gsc_site_url']));
        }
        
        // Update Uptime Robot monitor ID
        if (isset($_POST['bocm_uptime_monitor_id'])) {
            update_user_meta($user_id, 'bocm_uptime_monitor_id', sanitize_text_field($_POST['bocm_uptime_monitor_id']));
        }
        
        // Update Google Ads customer ID
        if (isset($_POST['bocm_ads_customer_id'])) {
            update_user_meta($user_id, 'bocm_ads_customer_id', sanitize_text_field($_POST['bocm_ads_customer_id']));
        }
    }

    /**
     * Register settings menu
     */
    public function register_settings_menu(): void {
        add_menu_page(
            __('Blue Oak Client Management', 'blue-oak-client-management'),
            __('Blue Oak CM', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-client-management',
            [$this, 'render_settings_page'],
            'dashicons-groups',
            30
        );
        
        add_submenu_page(
            'blue-oak-client-management',
            __('Uptime Robot Settings', 'blue-oak-client-management'),
            __('Uptime Robot', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-uptime-robot',
            [$this, 'render_uptime_settings_page']
        );
        
        add_submenu_page(
            'blue-oak-client-management',
            __('Google Analytics Settings', 'blue-oak-client-management'),
            __('Google Analytics', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-google-analytics',
            [$this, 'render_google_analytics_settings_page']
        );
        
        add_submenu_page(
            'blue-oak-client-management',
            __('Google Search Console Settings', 'blue-oak-client-management'),
            __('Search Console', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-google-search-console',
            [$this, 'render_google_search_console_settings_page']
        );
    }
    
    /**
     * Render Google Search Console settings page
     */
    public function render_google_search_console_settings_page(): void {
        // Check user capability
        if (!current_user_can('manage_options')) {
            return;
        }
        
        // Process form submission
        if (isset($_POST['bocm_gsc_submit']) && check_admin_referer('bocm_gsc_settings', 'bocm_gsc_nonce')) {
            // Handle service account file upload
            if (isset($_FILES['bocm_gsc_service_account']) && !empty($_FILES['bocm_gsc_service_account']['tmp_name'])) {
                $file_content = file_get_contents($_FILES['bocm_gsc_service_account']['tmp_name']);
                
                // Validate JSON format
                $json_data = json_decode($file_content, true);
                if ($json_data === null) {
                    add_settings_error(
                        'bocm_gsc_settings',
                        'invalid_json',
                        __('The uploaded file is not a valid JSON file.', 'blue-oak-client-management'),
                        'error'
                    );
                } else {
                    // Verify credentials with API
                    $gsc = new GoogleSearchConsole();
                    if ($gsc->verify_credentials($json_data)) {
                        // Save service account credentials
                        update_option('bocm_gsc_service_account', $file_content);
                        add_settings_error(
                            'bocm_gsc_settings',
                            'settings_updated',
                            __('Google Search Console settings updated successfully.', 'blue-oak-client-management'),
                            'success'
                        );
                    } else {
                        add_settings_error(
                            'bocm_gsc_settings',
                            'invalid_credentials',
                            __('The service account credentials are invalid or do not have sufficient permissions.', 'blue-oak-client-management'),
                            'error'
                        );
                    }
                }
            }
        }
        
        // Get available sites
        $gsc = new GoogleSearchConsole();
        $site_options = $gsc->get_site_options();
        
        // Check if credentials are set
        $credentials = get_option('bocm_gsc_service_account', '');
        $has_credentials = !empty($credentials);
        
        // Output settings page
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php settings_errors('bocm_gsc_settings'); ?>
            
            <div class="bocm-admin-content">
                <div class="bocm-admin-column main-column">
                    <div class="card">
                        <h2><?php _e('Google Search Console Settings', 'blue-oak-client-management'); ?></h2>
                        <p><?php _e('Configure your Google Search Console API credentials to display search data in the client portal.', 'blue-oak-client-management'); ?></p>
                        
                        <form method="post" enctype="multipart/form-data">
                            <?php wp_nonce_field('bocm_gsc_settings', 'bocm_gsc_nonce'); ?>
                            
                            <table class="form-table">
                                <tr>
                                    <th scope="row"><?php _e('Service Account JSON', 'blue-oak-client-management'); ?></th>
                                    <td>
                                        <input type="file" name="bocm_gsc_service_account" id="bocm_gsc_service_account" accept=".json" />
                                        <?php if ($has_credentials): ?>
                                            <p class="description success">
                                                <span class="dashicons dashicons-yes"></span>
                                                <?php _e('Credentials are configured.', 'blue-oak-client-management'); ?>
                                            </p>
                                        <?php else: ?>
                                            <p class="description">
                                                <?php _e('Upload your Google Search Console service account JSON file.', 'blue-oak-client-management'); ?>
                                            </p>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            </table>
                            
                            <p class="submit">
                                <input type="submit" name="bocm_gsc_submit" class="button button-primary" value="<?php _e('Save Settings', 'blue-oak-client-management'); ?>" />
                            </p>
                        </form>
                        
                        <?php if ($has_credentials && !empty($site_options)): ?>
                            <div class="bocm-sites-list">
                                <h3><?php _e('Available Search Console Sites', 'blue-oak-client-management'); ?></h3>
                                <table class="wp-list-table widefat fixed striped">
                                    <thead>
                                        <tr>
                                            <th><?php _e('Site URL', 'blue-oak-client-management'); ?></th>
                                            <th><?php _e('Site Type', 'blue-oak-client-management'); ?></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($site_options as $url => $name): ?>
                                            <tr>
                                                <td><?php echo esc_html($url); ?></td>
                                                <td><?php echo esc_html($name); ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
                
                <div class="bocm-admin-column sidebar-column">
                    <div class="card">
                        <h2><?php _e('Setup Instructions', 'blue-oak-client-management'); ?></h2>
                        <ol>
                            <li><?php _e('Create a service account in the Google Cloud Console.', 'blue-oak-client-management'); ?></li>
                            <li><?php _e('Grant the service account access to the Search Console API.', 'blue-oak-client-management'); ?></li>
                            <li><?php _e('Download the service account JSON credentials file.', 'blue-oak-client-management'); ?></li>
                            <li><?php _e('Upload the JSON file using the form on this page.', 'blue-oak-client-management'); ?></li>
                            <li><?php _e('Add the service account email as a user to your Search Console properties.', 'blue-oak-client-management'); ?></li>
                        </ol>
                    </div>
                    
                    <div class="card">
                        <h2><?php _e('Need Help?', 'blue-oak-client-management'); ?></h2>
                        <p><?php _e('For more detailed instructions on setting up the Google Search Console integration, please refer to our documentation.', 'blue-oak-client-management'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Render Google Analytics settings page
     */
    public function render_google_analytics_settings_page(): void {
        // Implement similar to the Google Search Console page
        echo '<div class="wrap"><h1>' . esc_html(get_admin_page_title()) . '</h1>';
        echo '<p>Google Analytics settings page content will go here.</p>';
        echo '</div>';
    }

    /**
     * Render Uptime Robot settings page
     */
    public function render_uptime_settings_page(): void {
        // Implement similar to the Google Search Console page
        echo '<div class="wrap"><h1>' . esc_html(get_admin_page_title()) . '</h1>';
        echo '<p>Uptime Robot settings page content will go here.</p>';
        echo '</div>';
    }

    /**
     * Render main settings page
     */
    public function render_settings_page(): void {
        // Implement main settings page
        echo '<div class="wrap"><h1>' . esc_html(get_admin_page_title()) . '</h1>';
        echo '<p>Main settings page content will go here.</p>';
        echo '</div>';
    }
} 