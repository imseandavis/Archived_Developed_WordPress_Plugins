<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Fired during plugin activation
 */
class Activator {

    /**
     * Initialize plugin on activation
     *
     * @return void
     */
    public static function activate(): void {
        // Create necessary database tables
        self::create_tables();
        
        // Create custom roles
        self::create_roles();
        
        // Set default options
        self::set_default_options();
        
        // Set up PageSpeed scanning
        self::setup_pagespeed();
        
        // Set version
        update_option('bocm_version', BOCM_VERSION);
    }

    /**
     * Create plugin database tables
     *
     * @return void
     */
    private static function create_tables(): void {
        global $wpdb;
        
        $charset_collate = $wpdb->get_charset_collate();

        // Add table creation SQL here when needed
    }

    /**
     * Create custom roles and capabilities
     *
     * @return void
     */
    private static function create_roles(): void {
        // Remove the role if it exists (to ensure clean installation)
        remove_role('blue_oak_client');

        // Add the Blue Oak Client role with subscriber-level capabilities
        add_role(
            'blue_oak_client',
            __('Blue Oak Client', 'blue-oak-client-management'),
            [
                'read' => true,                      // Can read posts
                'edit_profile' => true,              // Can edit their profile
            ]
        );

        // Add custom capabilities to administrator role
        $admin_role = get_role('administrator');
        if ($admin_role instanceof \WP_Role) {
            $admin_role->add_cap('bocm_manage_clients');
            $admin_role->add_cap('bocm_manage_settings');
        }
    }

    /**
     * Set default plugin options
     *
     * @return void
     */
    private static function set_default_options(): void {
        // Add default options here when needed
        add_option('bocm_client_role_created', true);
        
        // Set default Uptime Robot cache duration
        add_option('bocm_uptimerobot_cache_duration', 10);
    }
    
    /**
     * Setup PageSpeed scanning functionality
     *
     * @return void
     */
    private static function setup_pagespeed(): void {
        // Add default options
        add_option('bocm_pagespeed_api_key', '');
        
        // Set up daily cron schedule for PageSpeed scans
        if (!wp_next_scheduled('bocm_daily_cron')) {
            wp_schedule_event(strtotime('today 01:00 am'), 'bocm_daily', 'bocm_daily_cron');
        }
        
        // Ensure user meta exists for current clients
        $users = get_users([
            'role' => 'blue_oak_client',
            'fields' => ['ID'],
        ]);
        
        foreach ($users as $user) {
            if (!metadata_exists('user', $user->ID, 'bocm_pagespeed_timestamp')) {
                add_user_meta($user->ID, 'bocm_pagespeed_timestamp', '');
            }
            
            if (!metadata_exists('user', $user->ID, 'bocm_pagespeed_data')) {
                add_user_meta($user->ID, 'bocm_pagespeed_data', []);
            }
        }
    }

    /**
     * Remove custom roles and capabilities
     * 
     * @return void
     */
    public static function remove_roles(): void {
        remove_role('blue_oak_client');
        
        // Remove custom capabilities from administrator role
        $admin_role = get_role('administrator');
        if ($admin_role instanceof \WP_Role) {
            $admin_role->remove_cap('bocm_view_dashboard');
            $admin_role->remove_cap('bocm_submit_requests');
            $admin_role->remove_cap('bocm_view_documents');
            $admin_role->remove_cap('bocm_message_staff');
            $admin_role->remove_cap('bocm_manage_clients');
            $admin_role->remove_cap('bocm_manage_settings');
        }
    }
} 