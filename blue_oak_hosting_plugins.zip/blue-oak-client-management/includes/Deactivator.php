<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Fired during plugin deactivation
 */
class Deactivator {

    /**
     * Clean up plugin data on deactivation
     *
     * @return void
     */
    public static function deactivate(): void {
        // Note: By default, we don't remove roles on deactivation
        // to prevent data loss. Roles will only be removed if specifically
        // requested through plugin settings.
        
        if (get_option('bocm_remove_roles_on_deactivate', false)) {
            require_once BOCM_PLUGIN_DIR . 'includes/class-activator.php';
            Activator::remove_roles();
            delete_option('bocm_client_role_created');
        }
        
        // Clean up PageSpeed scanning
        self::cleanup_pagespeed();
    }
    
    /**
     * Clean up PageSpeed scanning functionality
     *
     * @return void
     */
    private static function cleanup_pagespeed(): void {
        // Clear scheduled cron events
        $timestamp = wp_next_scheduled('bocm_daily_cron');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'bocm_daily_cron');
        }
        
        // Note: We don't delete user meta or options to preserve data
        
        // Log deactivation
        error_log('BOCM PageSpeed: Plugin deactivated, cron jobs cleared');
    }
} 