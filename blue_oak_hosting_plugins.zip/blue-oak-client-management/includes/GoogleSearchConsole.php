<?php
/**
 * Google Search Console integration class
 *
 * @package BlueOakClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

use Google\Client;
use Google\Service\SearchConsole;
use Google\Service\SearchConsole\SearchAnalyticsQueryRequest;
use Exception;

/**
 * Class GoogleSearchConsole
 * Handles integration with Google Search Console API
 */
class GoogleSearchConsole {
    /**
     * Verify service account credentials by attempting to initialize the Google client
     *
     * @param array $credentials Service account credentials JSON data
     * @return bool True if credentials are valid, false otherwise
     */
    public function verify_credentials(array $credentials): bool {
        try {
            $client = new Client();
            $client->setAuthConfig($credentials);
            $client->addScope('https://www.googleapis.com/auth/webmasters.readonly');
            
            // Initialize Search Console API client
            $search_console = new SearchConsole($client);
            
            // Try to list sites to verify credentials
            $sites = $search_console->sites->listSites();
            $sites->getSiteEntry(); // Try to get sites
            
            return true;
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Verification Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get the stored service account credentials
     *
     * @return array|null Service account credentials or null if not set
     */
    public function get_credentials(): ?array {
        $credentials = get_option('bocm_gsc_service_account', '');
        if (empty($credentials)) {
            error_log('BOCM Google Search Console: No credentials found in options');
            return null;
        }

        // Debug the raw credentials
        error_log('BOCM Google Search Console: Retrieved raw credentials from options');
        
        $json_data = json_decode($credentials, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('BOCM Google Search Console: Invalid JSON in credentials - ' . json_last_error_msg());
            return null;
        }

        // Debug the parsed credentials
        if (isset($json_data['client_email'])) {
            error_log('BOCM Google Search Console: Successfully parsed credentials for service account: ' . $json_data['client_email']);
        } else {
            error_log('BOCM Google Search Console: Credentials parsed but missing client_email field');
        }

        return $json_data;
    }

    /**
     * Initialize Google Search Console client with stored credentials
     *
     * @return Client|null Google client instance or null if credentials are invalid
     */
    public function get_client(): ?Client {
        $credentials = $this->get_credentials();
        if ($credentials === null) {
            error_log('BOCM Google Search Console: Failed to get credentials in get_client method');
            return null;
        }

        try {
            error_log('BOCM Google Search Console: Initializing client with credentials');
            $client = new Client();
            $client->setAuthConfig($credentials);
            $client->addScope('https://www.googleapis.com/auth/webmasters.readonly');
            error_log('BOCM Google Search Console: Client initialized successfully');
            return $client;
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Client Error: ' . $e->getMessage());
            error_log('BOCM Google Search Console Client Error Stack: ' . $e->getTraceAsString());
            return null;
        }
    }

    /**
     * Clear any cached site data and force a refresh
     * This should be called when credentials are updated
     *
     * @return void
     */
    public function clear_cached_sites(): void {
        // This method is maintained for backwards compatibility
        // but no longer does anything since we're fetching fresh data each time
        error_log('BOCM Google Search Console: No site list caching is enabled');
    }

    /**
     * Get available Google Search Console site options
     *
     * @return array Array of site options with URLs as keys and display names as values
     */
    public function get_site_options(): array {
        try {
            // Get credentials and check validity first
            $credentials = $this->get_credentials();
            if ($credentials !== null) {
                $valid = $this->verify_credentials($credentials);
                error_log('BOCM Google Search Console: Credentials verification result: ' . ($valid ? 'Valid' : 'Invalid'));
            }
            
            $client = $this->get_client();
            if ($client === null) {
                error_log('BOCM Google Search Console: No valid client for site options');
                return ['' => __('No credentials found', 'blue-oak-client-management')];
            }
            
            // Initialize Search Console API client
            $search_console = new SearchConsole($client);
            
            // Debug information
            error_log('BOCM Google Search Console: Fetching fresh site list from API');
            
            // Get the list of sites
            $sites = $search_console->sites->listSites();
            $site_entries = $sites->getSiteEntry();
            
            if (empty($site_entries)) {
                error_log('BOCM Google Search Console: No sites found in API response');
                return ['' => __('No sites found', 'blue-oak-client-management')];
            }
            
            // Debug information
            error_log('BOCM Google Search Console: Found ' . count($site_entries) . ' sites');
            
            $options = ['' => __('-- Select Site --', 'blue-oak-client-management')];
            
            foreach ($site_entries as $site) {
                $site_url = $site->getSiteUrl();
                // Debug information
                error_log('BOCM Google Search Console: Processing site: ' . $site_url);
                
                // Clean up URL for display (remove protocol, trailing slash)
                $display_url = preg_replace('#^https?://#', '', rtrim($site_url, '/'));
                
                $options[$site_url] = $display_url;
            }

            // No longer caching the results
            error_log('BOCM Google Search Console: Returning fresh site list with ' . count($options) . ' sites');

            return $options;
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Site List Error: ' . $e->getMessage());
            error_log('BOCM Google Search Console Site List Error Stack: ' . $e->getTraceAsString());
            return ['' => __('Error loading sites', 'blue-oak-client-management')];
        }
    }

    /**
     * Get search console data for a specific site
     *
     * @param string $site_url The Google Search Console site URL
     * @param int $days The number of days to fetch data for (default: 28)
     * @return array The search console data
     */
    public function get_search_console_data(string $site_url, int $days = 28): array {
        try {
            $client = $this->get_client();
            if ($client === null) {
                return ['error' => 'No valid Google Search Console client'];
            }

            // Initialize the Search Console API service
            $search_console = new SearchConsole($client);
            
            // Add debug info for tracking date-related issues
            if (defined('WP_DEBUG') && WP_DEBUG) {
                $this->log_debug('Processing Google Search Console data for site: ' . $site_url . ', days: ' . $days);
            }
            
            // Get summary metrics
            try {
                $summary = $this->get_summary_metrics($search_console, $site_url, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Search Console Summary Metrics Error: ' . $e->getMessage());
                error_log('BOCM Google Search Console: ' . $e->getTraceAsString());
                $summary = [];
            }
            
            // Get performance data over time
            try {
                $performance = $this->get_performance_data($search_console, $site_url, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Search Console Performance Error: ' . $e->getMessage());
                $performance = [];
            }
            
            // Get top queries
            try {
                $queries = $this->get_top_queries($search_console, $site_url, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Search Console Queries Error: ' . $e->getMessage());
                $queries = [];
            }
            
            // Get top pages
            try {
                $pages = $this->get_top_pages($search_console, $site_url, $days);
            } catch (Exception $e) {
                error_log('BOCM Google Search Console Pages Error: ' . $e->getMessage());
                $pages = [];
            }
            
            return [
                'summary' => $summary,
                'performance' => $performance,
                'queries' => $queries,
                'pages' => $pages
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Error: ' . $e->getMessage());
            error_log('BOCM Google Search Console Error Trace: ' . $e->getTraceAsString());
            return ['error' => $e->getMessage()];
        }
    }

    /**
     * Get summary metrics (clicks, impressions, CTR, position)
     *
     * @param SearchConsole $search_console The Search Console service instance
     * @param string $site_url The site URL
     * @param int $days The number of days
     * @return array The summary metrics
     */
    private function get_summary_metrics(SearchConsole $search_console, string $site_url, int $days): array {
        try {
            // Current period
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-$days days"));
            
            $request = new SearchAnalyticsQueryRequest();
            $request->setStartDate($start_date);
            $request->setEndDate($end_date);
            $request->setDimensions([]);
            $request->setRowLimit(1);
            
            $response = $search_console->searchanalytics->query($site_url, $request);
            $rows = $response->getRows();
            
            if (empty($rows)) {
                return [];
            }
            
            $current_row = $rows[0];
            
            // Previous period (for comparison)
            $prev_end_date = date('Y-m-d', strtotime("-$days days"));
            $prev_start_date = date('Y-m-d', strtotime("-" . ($days * 2) . " days"));
            
            $prev_request = new SearchAnalyticsQueryRequest();
            $prev_request->setStartDate($prev_start_date);
            $prev_request->setEndDate($prev_end_date);
            $prev_request->setDimensions([]);
            $prev_request->setRowLimit(1);
            
            $prev_response = $search_console->searchanalytics->query($site_url, $prev_request);
            $prev_rows = $prev_response->getRows();
            
            $prev_row = !empty($prev_rows) ? $prev_rows[0] : null;
            
            // Calculate metrics
            $clicks = (int)$current_row->getClicks();
            $prev_clicks = $prev_row ? (int)$prev_row->getClicks() : 0;
            $clicks_change = $this->calculate_percentage_change($clicks, $prev_clicks);
            
            $impressions = (int)$current_row->getImpressions();
            $prev_impressions = $prev_row ? (int)$prev_row->getImpressions() : 0;
            $impressions_change = $this->calculate_percentage_change($impressions, $prev_impressions);
            
            $ctr = (float)$current_row->getCtr() * 100; // Convert to percentage
            $prev_ctr = $prev_row ? (float)$prev_row->getCtr() * 100 : 0;
            $ctr_change = $this->calculate_percentage_change($ctr, $prev_ctr);
            
            $position = (float)$current_row->getPosition();
            $prev_position = $prev_row ? (float)$prev_row->getPosition() : 0;
            $position_change = $this->calculate_percentage_change($position, $prev_position) * -1; // Invert since lower is better
            
            return [
                'clicks' => [
                    'value' => number_format($clicks),
                    'change' => $clicks_change,
                    'positive' => $clicks_change >= 0
                ],
                'impressions' => [
                    'value' => number_format($impressions),
                    'change' => $impressions_change,
                    'positive' => $impressions_change >= 0
                ],
                'ctr' => [
                    'value' => number_format($ctr, 1) . '%',
                    'change' => $ctr_change,
                    'positive' => $ctr_change >= 0
                ],
                'position' => [
                    'value' => number_format($position, 1),
                    'change' => abs($position_change),
                    'positive' => $position_change >= 0
                ]
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Summary Metrics Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get performance data over time (clicks, impressions, CTR, position)
     *
     * @param SearchConsole $search_console The Search Console service instance
     * @param string $site_url The site URL
     * @param int $days The number of days
     * @return array The performance data
     */
    private function get_performance_data(SearchConsole $search_console, string $site_url, int $days): array {
        try {
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-$days days"));
            
            $request = new SearchAnalyticsQueryRequest();
            $request->setStartDate($start_date);
            $request->setEndDate($end_date);
            $request->setDimensions(['date']);
            $request->setRowLimit(min($days, 90)); // Limit to 90 days max
            
            $response = $search_console->searchanalytics->query($site_url, $request);
            $rows = $response->getRows();
            
            if (empty($rows)) {
                return [];
            }
            
            $categories = [];
            $clicks = [];
            $impressions = [];
            $ctr = [];
            $position = [];
            
            foreach ($rows as $row) {
                $date_value = $row->getKeys()[0];
                $date_obj = \DateTime::createFromFormat('Y-m-d', $date_value);
                $formatted_date = $date_obj ? $date_obj->format('M d') : 'Unknown';
                
                $categories[] = $formatted_date;
                $clicks[] = (int)$row->getClicks();
                $impressions[] = (int)$row->getImpressions();
                $ctr[] = round((float)$row->getCtr() * 100, 1); // Convert to percentage
                $position[] = round((float)$row->getPosition(), 1);
            }
            
            // Reverse arrays to get chronological order
            $categories = array_reverse($categories);
            $clicks = array_reverse($clicks);
            $impressions = array_reverse($impressions);
            $ctr = array_reverse($ctr);
            $position = array_reverse($position);
            
            return [
                'categories' => $categories,
                'series' => [
                    [
                        'name' => 'Clicks',
                        'data' => $clicks
                    ],
                    [
                        'name' => 'Impressions',
                        'data' => $impressions
                    ],
                    [
                        'name' => 'CTR',
                        'data' => $ctr
                    ],
                    [
                        'name' => 'Position',
                        'data' => $position
                    ]
                ]
            ];
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Performance Error: ' . $e->getMessage());
            return [
                'categories' => [],
                'series' => []
            ];
        }
    }

    /**
     * Get top search queries
     *
     * @param SearchConsole $search_console The Search Console service instance
     * @param string $site_url The site URL
     * @param int $days The number of days
     * @return array The top queries data
     */
    private function get_top_queries(SearchConsole $search_console, string $site_url, int $days): array {
        try {
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-$days days"));
            
            $request = new SearchAnalyticsQueryRequest();
            $request->setStartDate($start_date);
            $request->setEndDate($end_date);
            $request->setDimensions(['query']);
            $request->setRowLimit(10); // Get top 10 queries
            
            $response = $search_console->searchanalytics->query($site_url, $request);
            $rows = $response->getRows();
            
            if (empty($rows)) {
                return [];
            }
            
            $queries = [];
            
            foreach ($rows as $row) {
                $query_text = $row->getKeys()[0];
                
                $queries[] = [
                    'query' => $query_text,
                    'clicks' => number_format((int)$row->getClicks()),
                    'impressions' => number_format((int)$row->getImpressions()),
                    'ctr' => number_format((float)$row->getCtr() * 100, 1) . '%',
                    'position' => number_format((float)$row->getPosition(), 1)
                ];
            }
            
            return $queries;
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Top Queries Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Get top pages
     *
     * @param SearchConsole $search_console The Search Console service instance
     * @param string $site_url The site URL
     * @param int $days The number of days
     * @return array The top pages data
     */
    private function get_top_pages(SearchConsole $search_console, string $site_url, int $days): array {
        try {
            $end_date = date('Y-m-d');
            $start_date = date('Y-m-d', strtotime("-$days days"));
            
            $request = new SearchAnalyticsQueryRequest();
            $request->setStartDate($start_date);
            $request->setEndDate($end_date);
            $request->setDimensions(['page']);
            $request->setRowLimit(10); // Get top 10 pages
            
            $response = $search_console->searchanalytics->query($site_url, $request);
            $rows = $response->getRows();
            
            if (empty($rows)) {
                return [];
            }
            
            $pages = [];
            
            foreach ($rows as $row) {
                $page_url = $row->getKeys()[0];
                // Extract the path from the URL
                $page_path = parse_url($page_url, PHP_URL_PATH) ?: $page_url;
                
                $pages[] = [
                    'page' => $page_path,
                    'clicks' => number_format((int)$row->getClicks()),
                    'impressions' => number_format((int)$row->getImpressions()),
                    'ctr' => number_format((float)$row->getCtr() * 100, 1) . '%',
                    'position' => number_format((float)$row->getPosition(), 1)
                ];
            }
            
            return $pages;
        } catch (Exception $e) {
            error_log('BOCM Google Search Console Top Pages Error: ' . $e->getMessage());
            return [];
        }
    }

    /**
     * Calculate percentage change between two values
     * 
     * @param float $current The current value
     * @param float $previous The previous value
     * @return float The percentage change
     */
    private function calculate_percentage_change(float $current, float $previous): float {
        if ($previous == 0) {
            return 0;
        }
        
        return (($current - $previous) / $previous) * 100;
    }

    /**
     * Internal method for debug logging
     * 
     * @param string $message The debug message
     * @return void
     */
    private function log_debug(string $message): void {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('BOCM Google Search Console Debug: ' . $message);
        }
    }
} 