<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handles Uptime Robot API interactions
 */
class UptimeRobot {
    /**
     * The API key
     *
     * @var string
     */
    private string $api_key;

    /**
     * The API base URL
     *
     * @var string
     */
    private string $api_url = 'https://api.uptimerobot.com/v2/';

    /**
     * Initialize the class
     * 
     * @param string|null $api_key Optional API key to use instead of the stored one
     */
    public function __construct(?string $api_key = null) {
        $this->api_key = $api_key ?? get_option('bocm_uptimerobot_api_key', '');
    }

    /**
     * Verify if the API key is valid and determine its type
     *
     * @param string|null $api_key Optional API key to verify instead of stored key
     * @return array{is_valid: bool, type: string} Array with validation result and key type
     */
    public function verify_api_key(?string $api_key = null): array {
        $key_to_verify = $api_key ?? $this->api_key;
        $result = [
            'is_valid' => false,
            'type' => 'invalid'
        ];

        if (empty($key_to_verify)) {
            return $result;
        }

        // First try getAccountDetails to check if it's a read-write key
        $account_response = wp_remote_post($this->api_url . 'getAccountDetails', [
            'body' => [
                'api_key' => $key_to_verify,
                'format' => 'json',
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($account_response)) {
            // Removed error logging for getAccountDetails errors as these are expected for read-only keys
        } else {
            $body = wp_remote_retrieve_body($account_response);
            $data = json_decode($body, true);
            
            // Remove error logging for getAccountDetails response
            
            if (isset($data['stat']) && $data['stat'] === 'ok') {
                return [
                    'is_valid' => true,
                    'type' => 'read-write'
                ];
            }
        }

        // If getAccountDetails failed, try getMonitors to check if it's a read-only key
        $monitors_response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $key_to_verify,
                'format' => 'json',
                'logs' => 0,
                'limit' => 1,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($monitors_response)) {
            // Only log genuine errors, not expected behavior for key type detection
            return $result;
        }

        $body = wp_remote_retrieve_body($monitors_response);
        $data = json_decode($body, true);
        
        // Remove debug logging for key verification
        
        if (isset($data['stat']) && $data['stat'] === 'ok') {
            return [
                'is_valid' => true,
                'type' => 'read-only'
            ];
        }

        return $result;
    }

    /**
     * Get monitor status text
     *
     * @param int $status Status code
     * @return string Human readable status
     */
    private function get_monitor_status_text(int $status): string {
        return match ($status) {
            0 => __('Paused', 'blue-oak-client-management'),
            1 => __('Not Checked Yet', 'blue-oak-client-management'),
            2 => __('Up', 'blue-oak-client-management'),
            8 => __('Seems Down', 'blue-oak-client-management'),
            9 => __('Down', 'blue-oak-client-management'),
            default => __('Unknown', 'blue-oak-client-management'),
        };
    }

    /**
     * Get log type text
     *
     * @param int $type Log type code
     * @return string Human readable type
     */
    private function get_log_type_text(int $type): string {
        return match ($type) {
            1 => __('Down', 'blue-oak-client-management'),
            2 => __('Up', 'blue-oak-client-management'),
            99 => __('Paused', 'blue-oak-client-management'),
            98 => __('Started', 'blue-oak-client-management'),
            default => __('Unknown', 'blue-oak-client-management'),
        };
    }

    /**
     * Get all monitors
     *
     * @return array Array of monitors data or empty array on failure
     */
    public function get_monitors(): array {
        if (empty($this->api_key)) {
            return [];
        }

        // Check for cached data first
        $cache_key = 'bocm_uptime_monitors_' . md5($this->api_key);
        $cached_data = get_transient($cache_key);
        
        if ($cached_data !== false) {
            error_log('Using cached monitors data');
            return $cached_data;
        }

        $response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $this->api_key,
                'format' => 'json',
                'logs' => 0,
                'custom_uptime_ratios' => '1-7-30',
                'response_times' => 1,
                'response_times_average' => 1,
                'all_time_uptime_ratio' => 1,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            error_log('Uptime Robot API Error: ' . $response->get_error_message());
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // More detailed logging for failed responses
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('Uptime Robot API Error: Received response code ' . $response_code);
            error_log('API Response Body: ' . substr($body, 0, 1000) . '...');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        // Check for a valid response
        if (!isset($data['stat']) || $data['stat'] !== 'ok') {
            error_log('Uptime Robot API Error: Invalid response status - ' . ($data['stat'] ?? 'unknown status'));
            
            // If we have error details, log them
            if (isset($data['error'])) {
                error_log('API Error Details: ' . print_r($data['error'], true));
            }
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        if (!isset($data['monitors']) || !is_array($data['monitors'])) {
            error_log('Uptime Robot API Error: No monitors in response');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        $result = array_map(function($monitor) {
            $status = (int)($monitor['status'] ?? 0);
            return [
                'id' => $monitor['id'],
                'name' => $monitor['friendly_name'],
                'url' => $monitor['url'],
                'type' => $monitor['type'],
                'status' => $status,
                'status_text' => $this->get_monitor_status_text($status),
                'is_up' => $status === 2,
                'custom_uptime_ratio' => isset($monitor['custom_uptime_ratio']) ? (float)$monitor['custom_uptime_ratio'] : 0.0,
                'average_response_time' => isset($monitor['average_response_time']) ? (int)$monitor['average_response_time'] : 0,
                'last_check' => isset($monitor['last_check_timestamp']) ? (int)$monitor['last_check_timestamp'] : time(),
            ];
        }, $data['monitors']);

        // Get configured cache duration from settings (default to 10 minutes if not set)
        $cache_duration = get_option('bocm_uptimerobot_cache_duration', 10);
        
        // Cache the result for the configured duration
        // Also keep a 6-hour fallback for emergencies
        set_transient($cache_key, $result, $cache_duration * MINUTE_IN_SECONDS);
        set_transient($cache_key . '_fallback', $result, 6 * HOUR_IN_SECONDS);

        return $result;
    }

    /**
     * Get monitor options for select field
     *
     * @return array Array of monitor options
     */
    public function get_monitor_options(): array {
        $monitors = $this->get_monitors();
        $options = ['' => __('-- Select Monitor --', 'blue-oak-client-management')];

        foreach ($monitors as $monitor) {
            $options[$monitor['id']] = sprintf(
                '%s (%s)',
                $monitor['name'],
                $monitor['url']
            );
        }

        return $options;
    }

    /**
     * Get monitor logs for a specific monitor
     *
     * @param string $monitor_id The monitor ID to get logs for
     * @param int    $limit     The number of logs to retrieve (default: 10)
     * @return array Array of monitor logs or empty array on failure
     */
    public function get_monitor_logs(string $monitor_id, int $limit = 10): array {
        if (empty($this->api_key)) {
            return [];
        }

        $response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $this->api_key,
                'format' => 'json',
                'monitors' => $monitor_id,
                'logs' => 1,
                'limit' => $limit,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            error_log('Uptime Robot API Error: ' . $response->get_error_message());
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!isset($data['monitors'][0]['logs']) || !is_array($data['monitors'][0]['logs'])) {
            return [];
        }

        return array_map(function($log) {
            $type = (int)($log['type'] ?? 0);
            return [
                'type' => $type,
                'type_text' => $this->get_log_type_text($type),
                'datetime' => (int)$log['datetime'],
                'duration' => isset($log['duration']) ? (int)$log['duration'] : 0,
                'reason' => $log['reason'] ?? '',
            ];
        }, $data['monitors'][0]['logs']);
    }

    /**
     * Get response times for a specific monitor
     *
     * @param string $monitor_id The monitor ID to get response times for
     * @param int    $hours     The number of hours of data to retrieve
     * @return array Array of response times or empty array on failure
     */
    public function get_response_times(string $monitor_id, int $hours = 24): array {
        if (empty($this->api_key)) {
            return [];
        }

        $response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $this->api_key,
                'format' => 'json',
                'monitors' => $monitor_id,
                'response_times' => 1,
                'response_times_limit' => $hours,
                'custom_response_times' => $hours,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            error_log('Uptime Robot API Error: ' . $response->get_error_message());
            return [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!isset($data['monitors'][0]['response_times']) || !is_array($data['monitors'][0]['response_times'])) {
            return [];
        }

        return array_map(function($rt) {
            return [
                'datetime' => (int)$rt['datetime'],
                'value' => (int)$rt['value']
            ];
        }, $data['monitors'][0]['response_times']);
    }

    /**
     * Get daily uptime data for a specific monitor
     *
     * @param string $monitor_id The monitor ID to get uptime data for
     * @param int    $days      The number of days of data to retrieve
     * @return array Array of daily uptime data or empty array on failure
     */
    public function get_daily_uptime(string $monitor_id, int $days = 90): array {
        if (empty($this->api_key)) {
            return [];
        }

        // Check for cached data first
        $cache_key = 'bocm_uptime_daily_' . $monitor_id . '_' . $days;
        $cached_data = get_transient($cache_key);
        
        if ($cached_data !== false) {
            error_log('Using cached uptime data for monitor ' . $monitor_id);
            return $cached_data;
        }

        // Create custom uptime ranges for each day using timestamps
        $ranges = [];
        $now = time();
        
        for ($i = $days - 1; $i >= 0; $i--) {
            $start = strtotime("-$i days 00:00:00");
            $end = strtotime("-$i days 23:59:59");
            
            // Ensure we don't request future dates
            if ($start > $now) {
                continue;
            }
            
            $ranges[] = $start . '_' . $end;
        }

        $custom_ranges = implode('-', $ranges);
        
        // Only log if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Uptime Robot API Request - Custom Ranges: ' . $custom_ranges);
        }

        $response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $this->api_key,
                'format' => 'json',
                'monitors' => $monitor_id,
                'custom_uptime_ranges' => $custom_ranges,
            ],
            'timeout' => 30, // Increased timeout for larger requests
        ]);

        if (is_wp_error($response)) {
            error_log('Uptime Robot API Error: ' . $response->get_error_message());
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        // More detailed logging for failed responses
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('Uptime Robot API Error: Received response code ' . $response_code);
            error_log('API Response Body: ' . substr($body, 0, 1000) . '...');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        // Only log detailed responses if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Uptime Robot API Response: ' . print_r($data, true));
        }

        // More comprehensive check for valid response structure
        if (!isset($data['stat']) || $data['stat'] !== 'ok') {
            error_log('Uptime Robot API Error: Unsuccessful API response - ' . ($data['stat'] ?? 'unknown status'));
            
            // If we have error details, log them
            if (isset($data['error'])) {
                error_log('API Error Details: ' . print_r($data['error'], true));
            }
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        if (!isset($data['monitors']) || !is_array($data['monitors']) || empty($data['monitors'])) {
            error_log('Uptime Robot API Error: No monitors in response');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        if (!isset($data['monitors'][0]['custom_uptime_ranges']) || !is_string($data['monitors'][0]['custom_uptime_ranges'])) {
            error_log('Uptime Robot API Error: No custom uptime ranges in response');
            error_log('API Response Body: ' . substr($body, 0, 1000) . '...');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        $uptimes = explode('-', $data['monitors'][0]['custom_uptime_ranges']);
        
        // Only log parsed uptimes if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Parsed uptimes: ' . print_r($uptimes, true));
        }

        // Create the return array with dates and uptimes
        $result = [];
        $current_day = $days - 1;
        
        foreach ($uptimes as $uptime) {
            $date = strtotime("-$current_day days");
            $result[] = [
                'date' => date('Y-m-d', $date),
                'uptime' => (float)$uptime
            ];
            $current_day--;
        }

        // Cache the result for 1 hour (also keep a 24-hour fallback version)
        set_transient($cache_key, $result, 1 * HOUR_IN_SECONDS);
        set_transient($cache_key . '_fallback', $result, 24 * HOUR_IN_SECONDS);

        return $result;
    }

    /**
     * Get uptime ranges for a monitor
     *
     * @param string $monitor_id The monitor ID to get uptime for
     * @param array $ranges An array of custom ranges to check (e.g., ['1', '7', '30'])
     * @return array Array of uptime percentages for each range or empty array on failure
     */
    public function get_uptime_ranges(string $monitor_id, array $ranges = ['1', '7', '30']): array {
        if (empty($this->api_key)) {
            return [];
        }
        
        // Check for cached data first
        $cache_key = 'bocm_uptime_ranges_' . $monitor_id . '_' . implode('_', $ranges);
        $cached_data = get_transient($cache_key);
        
        if ($cached_data !== false) {
            error_log('Using cached uptime ranges for monitor ' . $monitor_id);
            return $cached_data;
        }
        
        // Convert ranges to format expected by API
        $custom_ranges = implode('-', $ranges);
        
        // For debugging, only log if WP_DEBUG is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Uptime Robot API Request - Custom Ranges: ' . $custom_ranges);
        }
        
        $response = wp_remote_post($this->api_url . 'getMonitors', [
            'body' => [
                'api_key' => $this->api_key,
                'format' => 'json',
                'monitors' => $monitor_id,
                'custom_uptime_ratios' => $custom_ranges,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            error_log('Uptime Robot API Error: ' . $response->get_error_message());
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);
        
        // More detailed logging for failed responses
        $response_code = wp_remote_retrieve_response_code($response);
        if ($response_code !== 200) {
            error_log('Uptime Robot API Error: Received response code ' . $response_code);
            error_log('API Response Body: ' . substr($body, 0, 1000) . '...');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }
        
        // Only log detailed responses if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Uptime Robot API Response: ' . print_r($data, true));
        }
        
        // More comprehensive check for valid response structure
        if (!isset($data['stat']) || $data['stat'] !== 'ok') {
            error_log('Uptime Robot API Error: Unsuccessful API response - ' . ($data['stat'] ?? 'unknown status'));
            
            // If we have error details, log them
            if (isset($data['error'])) {
                error_log('API Error Details: ' . print_r($data['error'], true));
            }
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }
        
        if (!isset($data['monitors']) || !is_array($data['monitors']) || empty($data['monitors'])) {
            error_log('Uptime Robot API Error: No monitors in response');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }
        
        if (!isset($data['monitors'][0]['custom_uptime_ratio'])) {
            error_log('Uptime Robot API Error: No custom uptime ranges in response');
            error_log('API Response Body: ' . substr($body, 0, 1000) . '...');
            
            // Try to get cached data as fallback
            $cached_fallback = get_transient($cache_key . '_fallback');
            return $cached_fallback !== false ? $cached_fallback : [];
        }
        
        $uptimes = array_combine($ranges, explode('-', $data['monitors'][0]['custom_uptime_ratio']));
        
        // Only log parsed uptimes if debugging is enabled
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log('Parsed uptimes: ' . print_r($uptimes, true));
        }
        
        // Cache the result for 1 hour (also keep a 24-hour fallback version)
        set_transient($cache_key, $uptimes, 1 * HOUR_IN_SECONDS);
        set_transient($cache_key . '_fallback', $uptimes, 24 * HOUR_IN_SECONDS);
        
        return $uptimes;
    }
} 