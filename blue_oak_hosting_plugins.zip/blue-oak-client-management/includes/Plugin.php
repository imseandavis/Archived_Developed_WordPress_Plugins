<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * The core plugin class
 */
class Plugin {

    /**
     * The user profile instance
     *
     * @var User_Profile
     */
    private User_Profile $user_profile;

    /**
     * The admin menu instance
     *
     * @var Admin_Menu
     */
    private Admin_Menu $admin_menu;
    
    /**
     * The PageSpeed scanner instance
     *
     * @var PageSpeed_Scanner
     */
    private PageSpeed_Scanner $pagespeed_scanner;
    
    /**
     * The PageSpeed admin instance
     *
     * @var PageSpeed_Admin
     */
    private PageSpeed_Admin $pagespeed_admin;

    /**
     * The shortcodes instance
     *
     * @var Shortcodes
     */
    private Shortcodes $shortcodes;

    /**
     * Initialize the plugin
     */
    public function __construct() {
        $this->load_dependencies();
        $this->set_locale();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    /**
     * Load required dependencies
     *
     * @return void
     */
    private function load_dependencies(): void {
        // Load User Profile class
        require_once BOCM_PLUGIN_DIR . 'includes/User_Profile.php';
        $this->user_profile = new User_Profile();

        // Load Admin Menu class
        require_once BOCM_PLUGIN_DIR . 'includes/Admin_Menu.php';
        $this->admin_menu = new Admin_Menu();
        
        // Load PageSpeed Scanner class
        require_once BOCM_PLUGIN_DIR . 'includes/PageSpeed_Scanner.php';
        $this->pagespeed_scanner = new PageSpeed_Scanner();
        
        // Load PageSpeed Admin class
        require_once BOCM_PLUGIN_DIR . 'includes/PageSpeed_Admin.php';
        $this->pagespeed_admin = new PageSpeed_Admin();

        // Load Shortcodes class
        require_once BOCM_PLUGIN_DIR . 'includes/shortcodes.php';
        $this->shortcodes = new Shortcodes();
    }

    /**
     * Set the locale for internationalization
     *
     * @return void
     */
    private function set_locale(): void {
        add_action('plugins_loaded', function() {
            load_plugin_textdomain(
                'blue-oak-client-management',
                false,
                dirname(BOCM_PLUGIN_BASENAME) . '/languages/'
            );
        });
    }

    /**
     * Register all of the hooks related to the admin area
     *
     * @return void
     */
    private function define_admin_hooks(): void {
        // Admin hooks will be added here
    }

    /**
     * Register all of the hooks related to the public-facing functionality
     *
     * @return void
     */
    private function define_public_hooks(): void {
        // Public hooks will be added here
    }

    /**
     * Run the plugin
     *
     * @return void
     */
    public function run(): void {
        // Plugin execution code will go here
    }
} 