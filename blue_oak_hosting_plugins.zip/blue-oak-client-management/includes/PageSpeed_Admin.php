<?php
/**
 * PageSpeed Admin
 *
 * Handles admin interface for the PageSpeed scanner.
 *
 * @package BlueOak\ClientManagement
 */

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * PageSpeed Admin class
 */
class PageSpeed_Admin {
    /**
     * Initialize the class
     */
    public function __construct() {
        // Register admin hooks
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        
        // Register AJAX actions for manual scans
        add_action('wp_ajax_bocm_run_pagespeed_scan', [$this, 'ajax_run_scan']);
        add_action('wp_ajax_bocm_run_all_pagespeed_scans', [$this, 'ajax_run_all_scans']);
        add_action('wp_ajax_bocm_schedule_pagespeed_scans', [$this, 'ajax_schedule_scans']);
        add_action('wp_ajax_bocm_get_pagespeed_history', [$this, 'ajax_get_pagespeed_history']);
        add_action('wp_ajax_bocm_test_ajax', [$this, 'ajax_test']); // Test AJAX endpoint
    }
    
    /**
     * Register settings
     * 
     * @return void
     */
    public function register_settings(): void {
        register_setting(
            'blue-oak-client-management', // Changed to use the main plugin settings group
            'bocm_pagespeed_api_key',
            [
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default' => '',
            ]
        );
    }
    
    /**
     * Enqueue admin scripts
     * 
     * @param string $hook The current admin page.
     * @return void
     */
    public function enqueue_admin_scripts(string $hook): void {
        // Only load on the plugin settings page
        if ('toplevel_page_blue-oak-client-management' !== $hook && 
            'blue-oak-client-management_page_blue-oak-client-management-settings' !== $hook) {
            return;
        }
        
        wp_enqueue_style(
            'bocm-admin-css',
            BOCM_PLUGIN_URL . 'assets/css/admin.css',
            [],
            BOCM_VERSION
        );
        
        // Enqueue the main admin.js
        wp_enqueue_script(
            'bocm-admin-js',
            BOCM_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            BOCM_VERSION,
            true
        );
        
        // Enqueue PageSpeed specific JS
        wp_enqueue_script(
            'bocm-pagespeed-admin-js',
            BOCM_PLUGIN_URL . 'assets/js/pagespeed-admin.js',
            ['jquery', 'bocm-admin-js'],
            BOCM_VERSION,
            true
        );
        
        // Localize script data for the main admin script
        wp_localize_script('bocm-admin-js', 'bocmAdminData', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bocm_admin_nonce'),
            'processing_text' => __('Processing...', 'blue-oak-client-management'),
            'scan_text' => __('Scanning...', 'blue-oak-client-management'),
            'scheduling_text' => __('Scheduling...', 'blue-oak-client-management'),
            'success_text' => __('Completed', 'blue-oak-client-management'),
            'error_text' => __('Error', 'blue-oak-client-management'),
        ]);
        
        // Localize script data for PageSpeed admin
        wp_localize_script('bocm-pagespeed-admin-js', 'bocmPageSpeed', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bocm_admin_nonce'),
            'running' => __('Running...', 'blue-oak-client-management'),
            'success' => __('Success', 'blue-oak-client-management'),
            'error' => __('Error', 'blue-oak-client-management'),
        ]);
    }
    
    /**
     * AJAX handler for running a manual scan
     * 
     * @return void
     */
    public function ajax_run_scan(): void {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_admin_nonce')) {
            wp_send_json_error(['message' => __('Invalid security token', 'blue-oak-client-management')]);
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'blue-oak-client-management')]);
            return;
        }
        
        // Get parameters
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        $url = isset($_POST['url']) ? sanitize_url($_POST['url']) : '';
        
        // Validate parameters
        if (empty($user_id) || empty($url)) {
            wp_send_json_error(['message' => __('Missing required parameters', 'blue-oak-client-management')]);
            return;
        }
        
        // Run the scan
        $scanner = new PageSpeed_Scanner();
        $result = $scanner->scan_single_site($user_id, $url);
        
        if ($result) {
            // Get updated data
            $pagespeed_data = get_user_meta($user_id, 'bocm_pagespeed_data', true);
            
            wp_send_json_success([
                'message' => __('Scan completed successfully', 'blue-oak-client-management'),
                'scan_data' => $pagespeed_data,
            ]);
        } else {
            wp_send_json_error(['message' => __('Scan failed. Check error logs.', 'blue-oak-client-management')]);
        }
    }
    
    /**
     * AJAX handler for running all scans
     * 
     * @return void
     */
    public function ajax_run_all_scans(): void {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_admin_nonce')) {
            wp_send_json_error(['message' => __('Invalid security token', 'blue-oak-client-management')]);
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'blue-oak-client-management')]);
            return;
        }
        
        // Get all client users with website URLs
        $users = get_users([
            'role' => 'blue_oak_client',
            'fields' => ['ID', 'user_url'],
        ]);
        
        $processed_count = 0;
        $scanner = new PageSpeed_Scanner();
        
        foreach ($users as $user) {
            if (!empty($user->user_url)) {
                $scanner->scan_single_site($user->ID, $user->user_url);
                $processed_count++;
            }
        }
        
        if ($processed_count > 0) {
            wp_send_json_success([
                'message' => sprintf(
                    __('Processed %d client websites successfully', 'blue-oak-client-management'),
                    $processed_count
                ),
            ]);
        } else {
            wp_send_json_error(['message' => __('No client websites found to scan', 'blue-oak-client-management')]);
        }
    }
    
    /**
     * AJAX handler for scheduling scans
     * 
     * @return void
     */
    public function ajax_schedule_scans(): void {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_admin_nonce')) {
            wp_send_json_error(['message' => __('Invalid security token', 'blue-oak-client-management')]);
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'blue-oak-client-management')]);
            return;
        }
        
        // Clear any existing schedule
        $timestamp = wp_next_scheduled('bocm_daily_cron');
        if ($timestamp) {
            wp_unschedule_event($timestamp, 'bocm_daily_cron');
        }
        
        // Schedule the daily cron event for the next run
        $next_run = strtotime('tomorrow 01:00 am');
        wp_schedule_event($next_run, 'bocm_daily', 'bocm_daily_cron');
        
        // Trigger an immediate run as well
        do_action('bocm_daily_cron');
        
        wp_send_json_success([
            'message' => sprintf(
                __('Scans scheduled successfully. Next run: %s', 'blue-oak-client-management'),
                date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $next_run)
            ),
        ]);
    }
    
    /**
     * AJAX handler for retrieving PageSpeed history data
     * 
     * @return void
     */
    public function ajax_get_pagespeed_history(): void {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'bocm_admin_nonce')) {
            wp_send_json_error(['message' => __('Invalid security token', 'blue-oak-client-management')]);
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Permission denied', 'blue-oak-client-management')]);
            return;
        }
        
        // Get parameters
        $user_id = isset($_POST['user_id']) ? intval($_POST['user_id']) : 0;
        
        // Validate parameters
        if (empty($user_id)) {
            wp_send_json_error(['message' => __('Missing required parameters', 'blue-oak-client-management')]);
            return;
        }
        
        // Get history data
        $history_data = get_user_meta($user_id, 'bocm_pagespeed_history', true);
        
        if (!empty($history_data) && is_array($history_data)) {
            wp_send_json_success([
                'message' => __('History data retrieved successfully', 'blue-oak-client-management'),
                'history' => $history_data,
            ]);
        } else {
            wp_send_json_error(['message' => __('No history data available', 'blue-oak-client-management')]);
        }
    }

    /**
     * Simple AJAX test endpoint
     *
     * @return void
     */
    public function ajax_test(): void {
        wp_send_json_success([
            'message' => 'AJAX is working correctly',
            'time' => current_time('mysql'),
            'test' => true
        ]);
    }
} 