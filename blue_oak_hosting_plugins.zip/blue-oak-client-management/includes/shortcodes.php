<?php
declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handles shortcode functionality
 */
class Shortcodes {
    private Namecheap $namecheap;

    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        $this->namecheap = new Namecheap();
        
        add_shortcode('bocm_domain_checker', [$this, 'render_domain_checker']);
        add_action('wp_enqueue_scripts', [$this, 'enqueue_scripts']);
        add_action('wp_ajax_check_domain', [$this, 'ajax_check_domain']);
        add_action('wp_ajax_nopriv_check_domain', [$this, 'ajax_check_domain']);
    }

    /**
     * Enqueue required scripts and styles
     *
     * @return void
     */
    public function enqueue_scripts(): void {
        wp_enqueue_style(
            'bocm-domain-checker',
            BOCM_PLUGIN_URL . 'assets/css/domain-checker.css',
            [],
            BOCM_VERSION
        );

        wp_enqueue_script(
            'bocm-domain-checker',
            BOCM_PLUGIN_URL . 'assets/js/domain-checker.js',
            ['jquery'],
            BOCM_VERSION,
            true
        );

        wp_localize_script('bocm-domain-checker', 'bocmDomainChecker', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bocm_domain_checker_nonce'),
            'checking_text' => __('Checking domain availability...', 'blue-oak-client-management'),
            'error_text' => __('An error occurred. Please try again.', 'blue-oak-client-management'),
            'available_text' => __('Domain is available!', 'blue-oak-client-management'),
            'unavailable_text' => __('Domain is not available.', 'blue-oak-client-management'),
            'buy_now_text' => __('Buy Now', 'blue-oak-client-management'),
            'buy_button_url' => get_option('bocm_namecheap_buy_button_url', 'https://www.namecheap.com/domains/registration/results/?domain={domain}'),
        ]);
    }

    /**
     * Render the domain checker form
     *
     * @param array $atts Shortcode attributes
     * @return string HTML output
     */
    public function render_domain_checker(array $atts = []): string {
        ob_start();
        ?>
        <div class="bocm-domain-checker">
            <form id="bocm-domain-checker-form" class="bocm-domain-checker-form">
                <div class="bocm-domain-checker-input-group">
                    <input type="text" 
                           id="bocm-domain-input" 
                           name="domain" 
                           placeholder="<?php esc_attr_e('Enter domain name (e.g., example.com)', 'blue-oak-client-management'); ?>"
                           required
                    />
                    <button type="submit" class="bocm-domain-checker-button">
                        <?php esc_html_e('Check Availability', 'blue-oak-client-management'); ?>
                    </button>
                </div>
                <div id="bocm-domain-checker-result" class="bocm-domain-checker-result"></div>
            </form>
        </div>
        <?php
        return ob_get_clean();
    }

    /**
     * Handle AJAX domain check request
     *
     * @return void
     */
    public function ajax_check_domain(): void {
        check_ajax_referer('bocm_domain_checker_nonce', 'nonce');

        $domain = sanitize_text_field($_POST['domain'] ?? '');
        
        if (empty($domain)) {
            wp_send_json_error([
                'message' => __('Please enter a domain name.', 'blue-oak-client-management')
            ]);
        }

        $result = $this->namecheap->check_domain($domain);

        if (!$result['success']) {
            wp_send_json_error([
                'message' => $result['message']
            ]);
        }

        wp_send_json_success([
            'available' => $result['available'],
            'price' => $result['price'],
            'domain' => $result['domain']
        ]);
    }
} 