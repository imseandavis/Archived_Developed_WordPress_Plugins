<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handles Vendasta API interactions
 */
class Vendasta {
    /**
     * The API base URL
     *
     * @var string
     */
    private string $api_url = 'https://prod.apigateway.co/platform';

    /**
     * The service account credentials
     *
     * @var array|null
     */
    private ?array $credentials = null;

    /**
     * The access token
     *
     * @var string|null
     */
    private ?string $access_token = null;

    /**
     * Initialize the class
     */
    public function __construct() {
        $this->credentials = $this->get_credentials();
    }

    /**
     * Get the stored service account credentials
     *
     * @return array|null Service account credentials or null if not set
     */
    private function get_credentials(): ?array {
        $credentials = get_option('bocm_vendasta_service_account', '');
        if (empty($credentials)) {
            error_log('BOCM Vendasta: No credentials found in options');
            return null;
        }

        $credentials = json_decode($credentials, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            error_log('BOCM Vendasta: Invalid JSON in credentials - ' . json_last_error_msg());
            return null;
        }

        return $credentials;
    }

    /**
     * Verify the service account credentials
     *
     * @param array $credentials Service account credentials JSON data
     * @return bool True if credentials are valid, false otherwise
     */
    public function verify_credentials(array $credentials): bool {
        try {
            // Get an access token to verify credentials
            $this->get_access_token($credentials);
            return true;
        } catch (\Exception $e) {
            error_log('BOCM Vendasta: Verification Error: ' . $e->getMessage());
            return false;
        }
    }

    /**
     * Get an access token for API authentication
     *
     * @param array $credentials Service account credentials
     * @return string The access token
     * @throws \Exception If token request fails
     */
    private function get_access_token(array $credentials): string {
        if ($this->access_token !== null) {
            return $this->access_token;
        }

        if (!isset($credentials['token_uri'])) {
            throw new \Exception('No token_uri found in credentials');
        }

        $jwt = $this->generate_jwt($credentials);
        
        $response = wp_remote_post($credentials['token_uri'], [
            'headers' => [
                'Content-Type' => 'application/x-www-form-urlencoded',
            ],
            'body' => [
                'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
                'assertion' => $jwt,
            ],
            'timeout' => 15,
        ]);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($response_code !== 200) {
            throw new \Exception(sprintf(
                'OAuth request failed with status code %d: %s',
                $response_code,
                $body
            ));
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Failed to parse OAuth response: ' . json_last_error_msg());
        }

        if (!isset($data['access_token'])) {
            throw new \Exception('No access token in OAuth response');
        }

        $this->access_token = $data['access_token'];
        return $this->access_token;
    }

    /**
     * Get all account groups
     *
     * @param array|null $credentials Optional credentials to use instead of stored ones
     * @return array Array of account groups
     * @throws \Exception If API request fails
     */
    public function get_account_groups(?array $credentials = null): array {
        $creds = $credentials ?? $this->credentials;
        if ($creds === null) {
            throw new \Exception('No credentials available');
        }

        $access_token = $this->get_access_token($creds);
        
        // Get the Partner ID from settings
        $partner_id = get_option('bocm_vendasta_partner_id', '');
        
        // Partner ID is required
        if (empty($partner_id)) {
            throw new \Exception('Vendasta Partner ID is required');
        }
        
        // Build query parameters
        $query_params = [
            'filter[businessPartner.id]' => $partner_id,
            'fields[businessLocations]' => 'name',
            'page[limit]' => 100
        ];

        $url = $this->api_url . '/businessLocations?' . http_build_query($query_params);

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Accept' => 'application/vnd.api+json'
            ],
            'timeout' => 30,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            throw new \Exception($response->get_error_message());
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);

        if ($response_code !== 200) {
            throw new \Exception(sprintf(
                'API request failed with status code %d: %s',
                $response_code,
                $body
            ));
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new \Exception('Failed to parse API response: ' . json_last_error_msg());
        }

        if (!isset($data['data']) || !is_array($data['data'])) {
            throw new \Exception('Invalid response structure from Vendasta API');
        }

        return array_map(function($business) {
            return [
                'id' => $business['id'],
                'name' => $business['attributes']['name'] ?? '',
                'description' => $business['attributes']['description'] ?? '',
            ];
        }, $data['data']);
    }

    /**
     * Generate a JWT token for API authentication
     *
     * @param array $credentials Service account credentials
     * @return string JWT token
     */
    private function generate_jwt(array $credentials): string {
        // Create JWT header
        $header = [
            'alg' => 'RS256',
            'typ' => 'JWT',
            'kid' => $credentials['assertionHeaderData']['kid'] ?? null,
            'aud' => $credentials['assertionPayloadData']['aud'] ?? null,
        ];

        // Get current Unix timestamp
        $time = time();
        $exp = $time + (10 * 60); // 10 minutes expiry

        // Create JWT claims
        $payload = [
            'iat' => $time,
            'exp' => $exp,
            'iss' => $credentials['assertionPayloadData']['iss'] ?? $credentials['client_email'],
            'sub' => $credentials['assertionPayloadData']['sub'] ?? $credentials['client_email'],
            'scope' => 'profile financial email business partner:read',
        ];

        // Convert header and payload to Base64URL
        $header_encoded = $this->base64url_encode(json_encode($header));
        $payload_encoded = $this->base64url_encode(json_encode($payload));

        // Create signature using RS256
        $data_to_sign = "$header_encoded.$payload_encoded";
        $signature = '';
        openssl_sign(
            $data_to_sign,
            $signature,
            $credentials['private_key'],
            OPENSSL_ALGO_SHA256
        );
        $signature_encoded = $this->base64url_encode($signature);

        return "$header_encoded.$payload_encoded.$signature_encoded";
    }

    /**
     * Base64URL encode a string
     *
     * @param string $data The data to encode
     * @return string The Base64URL encoded string
     */
    private function base64url_encode(string $data): string {
        return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
    }

    /**
     * Get account group options for select field
     *
     * @return array Array of account group options
     */
    public function get_account_group_options(): array {
        try {
            $groups = $this->get_account_groups();
            $options = ['' => __('-- Select Account Group --', 'blue-oak-client-management')];

            foreach ($groups as $group) {
                $options[$group['id']] = sprintf(
                    '%s (%s)',
                    $group['name'],
                    $group['id']
                );
            }

            return $options;
        } catch (\Exception $e) {
            error_log('BOCM Vendasta: Account Groups Error: ' . $e->getMessage());
            return ['' => __('Error loading account groups', 'blue-oak-client-management')];
        }
    }

    /**
     * Get purchases for a specific Partner Account Group ID
     *
     * @param string $account_group_id The Partner Account Group ID
     * @return array Array of purchases
     * @throws \Exception If API request fails
     */
    public function get_purchases(string $account_group_id): array {
        // Log the start of the purchase retrieval process with the ID
        error_log('BOCM Vendasta: Starting purchase retrieval for Partner Account Group ID: ' . $account_group_id);
        
        if (empty($account_group_id)) {
            error_log('BOCM Vendasta: Empty Partner Account Group ID provided');
            throw new \Exception('Partner Account Group ID is required');
        }

        if ($this->credentials === null) {
            error_log('BOCM Vendasta: No credentials available for API call');
            throw new \Exception('No credentials available');
        }

        try {
            $access_token = $this->get_access_token($this->credentials);
            error_log('BOCM Vendasta: Successfully obtained access token');
        } catch (\Exception $e) {
            error_log('BOCM Vendasta: Failed to get access token: ' . $e->getMessage());
            throw $e;
        }
        
        // Get the Partner ID from settings
        $partner_id = get_option('bocm_vendasta_partner_id', '');
        error_log('BOCM Vendasta: Using Partner ID: ' . $partner_id);
        
        // Build query parameters with the correct filter param
        $query_params = [
            'filter[partner.id]' => $partner_id,
            'page[limit]' => 99
        ];
        
        $url = $this->api_url . '/purchases?' . http_build_query($query_params);
        error_log('BOCM Vendasta: Making API request to URL: ' . $url);

        // Log the request parameters
        error_log('BOCM Vendasta: Request parameters: ' . print_r($query_params, true));

        $response = wp_remote_get($url, [
            'headers' => [
                'Authorization' => 'Bearer ' . $access_token,
                'Accept' => 'application/vnd.api+json'
            ],
            'timeout' => 30,
            'sslverify' => true
        ]);

        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            error_log('BOCM Vendasta: API request failed with WP_Error: ' . $error_message);
            throw new \Exception($error_message);
        }

        $response_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log('BOCM Vendasta: API response code: ' . $response_code);
        
        // Log a sample of the response body (not the whole thing as it could be very large)
        $body_excerpt = substr($body, 0, 500) . (strlen($body) > 500 ? '...' : '');
        error_log('BOCM Vendasta: API response body (excerpt): ' . $body_excerpt);

        if ($response_code !== 200) {
            error_log('BOCM Vendasta: API request failed with status code ' . $response_code . ': ' . $body);
            throw new \Exception(sprintf(
                'API request failed with status code %d: %s',
                $response_code,
                $body
            ));
        }

        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $error_message = 'Failed to parse API response: ' . json_last_error_msg();
            error_log('BOCM Vendasta: ' . $error_message);
            throw new \Exception($error_message);
        }

        if (!isset($data['data']) || !is_array($data['data'])) {
            error_log('BOCM Vendasta: No purchase data found in API response or invalid response structure');
            return []; // No purchases found or invalid response structure
        }

        error_log('BOCM Vendasta: Successfully retrieved ' . count($data['data']) . ' purchases from API');

        $purchases = [];
        $user_account_group_id = $account_group_id;
        
        error_log('BOCM Vendasta: Filtering purchases for customer ID: ' . $user_account_group_id);
        
        $matched_items = 0;
        $total_line_items = 0;
        
        foreach ($data['data'] as $purchase) {
            $attributes = $purchase['attributes'] ?? [];
            $lineItems = $attributes['lineItems'] ?? [];
            
            // Skip if no line items
            if (empty($lineItems)) {
                continue;
            }
            
            // Process each line item as a separate purchase
            foreach ($lineItems as $lineItem) {
                $total_line_items++;
                $sku = $lineItem['sku'] ?? 'no-sku';
                
                // Log the comparison for debugging with SKU information
                error_log('BOCM Vendasta: Comparing line item - SKU: ' . $sku . ', customerId: ' . ($lineItem['customerId'] ?? 'null') . ' with user account group ID: ' . $user_account_group_id);
                
                // Only include line items for the current user's account ID
                if (isset($lineItem['customerId']) && $lineItem['customerId'] === $user_account_group_id) {
                    $matched_items++;
                    $purchases[] = [
                        'id' => $purchase['id'] ?? '',
                        'product_name' => $this->get_product_name_from_sku($sku),
                        'product_id' => $sku,
                        'status' => isset($attributes['statusCode']) ? ucfirst($attributes['statusCode']) : 'Unknown',
                        'start_date' => $attributes['createdAt'] ?? '',
                        'end_date' => '', // Not provided in the sample response
                        'price' => $lineItem['unitAmount'] ?? 0,
                        'currency' => $attributes['currencyCode'] ?? 'USD',
                    ];
                    
                    // Log when we find a match with SKU details
                    error_log('BOCM Vendasta: ✓ Match found - SKU: ' . $sku . ' (' . $this->get_product_name_from_sku($sku) . '), Status: ' . (isset($attributes['statusCode']) ? ucfirst($attributes['statusCode']) : 'Unknown'));
                }
            }
        }
        
        error_log('BOCM Vendasta: Found ' . $matched_items . ' matching line items out of ' . $total_line_items . ' total line items');
        error_log('BOCM Vendasta: Returning ' . count($purchases) . ' filtered purchases');
        
        return $purchases;
    }
    
    /**
     * Get product name from SKU
     *
     * @param string $sku The product SKU
     * @return string The human-readable product name
     */
    private function get_product_name_from_sku(string $sku): string {
        $product_mapping = [
            'RM:EDITION-F7JZ5TV8' => 'Reputation Management (Standard)',
            'RM' => 'Reputation Management (Pro)',
            'RM:EDITION-JFRPLQPN' => 'Reputation Management (Premium)',
            'SM' => 'Social Marketing (Standard)',
            'SM:EDITION-FVGBNLVZ' => 'Social Marketing (Pro)',
            'MS' => 'Local SEO (Standard)',
            'MS:EDITION-CFH5CKHC' => 'Local SEO (Pro)',
            'EDITION-D7X8PWSW' => 'Website Hosting (Standard)',
            'EDITION-R4QJ2H8P' => 'Website Hosting (Premium)',
            'EDITION-N4NZKH73' => 'Website Hosting (Exclusive)',
            'EDITION-6J8MQDMG' => 'Website Monitoring (Standard)',
            'EDITION-RLLFL3Q6' => 'Website Monitoring (Premium)',
            'MP-ee4ea04e553a4b1780caf7aad7be07cd:EDITION-VFNL43ZF' => 'Cloud Website (Standard)',
            'MP-ee4ea04e553a4b1780caf7aad7be07cd' => 'Cloud Website (Pro)',
            'MP-94072e44d5364872b672d7ab4fc7a7e8' => 'Advertising Intelligence',
            'A-3QKQHBS3R6' => 'Ad Intel Add-On: Advanced Reporting'
        ];
        
        return $product_mapping[$sku] ?? $sku;
    }
} 