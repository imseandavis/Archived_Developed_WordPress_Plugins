<?php

declare(strict_types=1);

namespace BlueOak\ClientManagement;

/**
 * Handles admin menu and settings
 */
class Admin_Menu {

    private array $client_sites;
    private $pagination_args = [];
    private int $items_per_page;

    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        // Make sure required classes are available
        require_once BOCM_PLUGIN_DIR . 'includes/UptimeRobot.php';
        require_once BOCM_PLUGIN_DIR . 'includes/GoogleAnalytics.php';
        require_once BOCM_PLUGIN_DIR . 'includes/GoogleSearchConsole.php';
        require_once BOCM_PLUGIN_DIR . 'includes/Vendasta.php';
        require_once BOCM_PLUGIN_DIR . 'includes/Namecheap.php';
        
        add_action('admin_menu', [$this, 'add_menu_pages']);
        add_action('admin_init', [$this, 'register_settings']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_scripts']);
        add_action('admin_notices', [$this, 'display_api_key_notices']);
    }

    /**
     * Enqueue admin scripts and styles
     *
     * @param string $hook The current admin page
     * @return void
     */
    public function enqueue_admin_scripts(string $hook): void {
        if ('toplevel_page_blue-oak-client-management' !== $hook && 
            'blue-oak-client-management_page_blue-oak-client-management-settings' !== $hook) {
            return;
        }

        // Add Dashicons for indicators
        wp_enqueue_style('dashicons');

        // Enqueue ApexCharts for graphs and sparklines
        wp_enqueue_script(
            'apexcharts',
            BOCM_PLUGIN_URL . 'assets/js/apexcharts.min.js',
            [],
            '3.37.0',
            true
        );

        // Enqueue our custom JS
        wp_enqueue_script(
            'bocm-admin',
            BOCM_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery', 'apexcharts'],
            BOCM_VERSION,
            true
        );

        // Pass data to JS
        wp_localize_script('bocm-admin', 'bocmAdminData', [
            'ajaxurl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('bocm_admin_nonce'),
            'processing_text' => __('Processing...', 'blue-oak-client-management'),
            'scan_text' => __('Scanning...', 'blue-oak-client-management'),
            'scheduling_text' => __('Scheduling...', 'blue-oak-client-management'),
            'success_text' => __('Completed', 'blue-oak-client-management'),
            'error_text' => __('Error', 'blue-oak-client-management'),
        ]);
    }

    /**
     * Display API key related notices
     *
     * @return void
     */
    public function display_api_key_notices(): void {
        $screen = get_current_screen();
        
        // Only show on our plugin pages
        if (!isset($screen->id) || (strpos($screen->id, 'blue-oak-client-management') === false)) {
            return;
        }
        
        // Check for Uptime Robot API key
        $uptimerobot_api_key = get_option('bocm_uptimerobot_api_key', '');
        if (empty($uptimerobot_api_key)) {
            add_settings_error(
                'bocm_messages',
                'bocm_uptimerobot_missing',
                sprintf(
                    __('Uptime Robot API key is missing. <a href="%s">Set up your API key</a> to enable uptime monitoring for your clients.', 'blue-oak-client-management'),
                    admin_url('admin.php?page=blue-oak-client-management-settings&tab=uptime-robot')
                ),
                'warning'
            );
        }
        
        // Check for Google Analytics service account
        $ga_service_account = get_option('bocm_ga_service_account', '');
        if (empty($ga_service_account)) {
            add_settings_error(
                'bocm_messages',
                'bocm_ga_missing',
                sprintf(
                    __('Google Analytics service account credentials are missing. <a href="%s">Set up your credentials</a> to enable analytics for your clients.', 'blue-oak-client-management'),
                    admin_url('admin.php?page=blue-oak-client-management-settings&tab=google-analytics')
                ),
                'warning'
            );
        }
        
        // Check for Google Search Console service account
        $gsc_service_account = get_option('bocm_gsc_service_account', '');
        if (empty($gsc_service_account)) {
            add_settings_error(
                'bocm_messages',
                'bocm_gsc_missing',
                sprintf(
                    __('Google Search Console service account credentials are missing. <a href="%s">Set up your credentials</a> to enable search performance data for your clients.', 'blue-oak-client-management'),
                    admin_url('admin.php?page=blue-oak-client-management-settings&tab=google-search-console')
                ),
                'warning'
            );
        }
        
        // Check for PageSpeed API key - only do this if on the PageSpeed tab
        $pagespeed_api_key = get_option('bocm_pagespeed_api_key', '');
        if (empty($pagespeed_api_key)) {
            add_settings_error(
                'bocm_messages',
                'bocm_pagespeed_missing',
                sprintf(
                    __('Google PageSpeed Insights API key is missing. <a href="%s" target="_blank">Get an API key</a> to enable website performance scanning.', 'blue-oak-client-management'),
                    'https://developers.google.com/speed/docs/insights/v5/get-started'
                ),
                'warning'
            );
        }
    }

    /**
     * Add menu and submenu pages
     *
     * @return void
     */
    public function add_menu_pages(): void {
        // Add main menu page
        add_menu_page(
            __('Client Management', 'blue-oak-client-management'),
            __('Client Management', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-client-management',
            [$this, 'render_main_page'],
            'dashicons-groups',
            30
        );

        // Add settings submenu page
        add_submenu_page(
            'blue-oak-client-management',
            __('Settings', 'blue-oak-client-management'),
            __('Settings', 'blue-oak-client-management'),
            'manage_options',
            'blue-oak-client-management-settings',
            [$this, 'render_settings_page']
        );
    }

    /**
     * Register settings
     *
     * @return void
     */
    public function register_settings(): void {
        // Register setting for general options
        register_setting(
            'bocm-general-settings-group',
            'bocm_remove_roles_on_deactivate',
            [
                'type' => 'boolean',
                'sanitize_callback' => function($value) {
                    return (bool) $value;
                },
                'default' => false,
            ]
        );

        // Register setting for Uptime Robot API key
        register_setting(
            'bocm-uptime-robot-settings-group',
            'bocm_uptimerobot_api_key',
            [
                'sanitize_callback' => function($value) {
                    $value = sanitize_text_field($value);
                    $old_value = get_option('bocm_uptimerobot_api_key', '');
                    
                    // Only validate if the value is changing
                    if ($value !== $old_value) {
                        // Skip validation if empty (allow clearing the API key)
                        if (empty($value)) {
                            return '';
                        }
                        
                        // Validate the API key
                        $uptime_robot = new UptimeRobot($value);
                        try {
                            $result = $uptime_robot->verify_api_key($value);
                            
                            if (!$result['is_valid']) {
                                add_settings_error(
                                    'bocm_uptimerobot_api_key',
                                    'invalid-key',
                                    __('The Uptime Robot API key appears to be invalid.', 'blue-oak-client-management'),
                                    'error'
                                );
                                return $old_value;
                            }
                        } catch (\Exception $e) {
                            add_settings_error(
                                'bocm_uptimerobot_api_key',
                                'verification-error',
                                sprintf(
                                    /* translators: %s: Error message */
                                    __('Error verifying Uptime Robot API key: %s', 'blue-oak-client-management'),
                                    $e->getMessage()
                                ),
                                'error'
                            );
                            return $old_value;
                        }
                    }
                    
                    return $value;
                }
            ]
        );
        
        // Register Uptime Robot cache duration setting
        register_setting(
            'bocm-uptime-robot-settings-group',
            'bocm_uptimerobot_cache_duration',
            [
                'sanitize_callback' => function($value) {
                    // Convert to integer and ensure it's within valid range
                    $value = (int) $value;
                    $valid_values = [5, 10, 15, 30, 60];
                    
                    if (!in_array($value, $valid_values)) {
                        add_settings_error(
                            'bocm_uptimerobot_cache_duration',
                            'invalid-duration',
                            __('Invalid cache duration specified. Using default value of 10 minutes.', 'blue-oak-client-management'),
                            'error'
                        );
                        return 10; // Default value
                    }
                    
                    return $value;
                },
                'default' => 10
            ]
        );

        // Register setting for Google Analytics service account
        register_setting(
            'bocm-ga-settings-group',
            'bocm_ga_service_account',
            [
                'type' => 'string',
                'sanitize_callback' => function($value) {
                    // Skip verification if the value is empty or unchanged
                    $old_value = get_option('bocm_ga_service_account', '');
                    if (empty($value) || $value === $old_value) {
                        return $value;
                    }
                    
                    // Validate JSON format
                    if (!empty($value)) {
                        $json_data = json_decode($value, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                add_settings_error(
                                'bocm_ga_service_account',
                                'invalid-json',
                                sprintf(
                                    /* translators: %s: JSON error message */
                                    __('Invalid JSON format for Google Analytics service account credentials: %s', 'blue-oak-client-management'),
                                    json_last_error_msg()
                                ),
                    'error'
                );
                            return $old_value;
            }

            // Validate required fields
            $required_fields = ['type', 'project_id', 'private_key_id', 'private_key', 'client_email', 'client_id'];
            foreach ($required_fields as $field) {
                if (!isset($json_data[$field])) {
                    add_settings_error(
                                    'bocm_ga_service_account',
                                    'missing-field',
                        sprintf(
                            /* translators: %s: Missing field name */
                            __('Missing required field in Google Analytics credentials: %s', 'blue-oak-client-management'),
                            $field
                        ),
                        'error'
                    );
                                return $old_value;
                }
            }

            // Validate service account type
            if ($json_data['type'] !== 'service_account') {
                add_settings_error(
                                'bocm_ga_service_account',
                                'invalid-type',
                    __('Invalid credentials: Not a service account', 'blue-oak-client-management'),
                    'error'
                );
                            return $old_value;
            }

            // Verify credentials
                        try {
            $google_analytics = new GoogleAnalytics();
                            $is_valid = $google_analytics->verify_credentials($json_data);
                            
                            if ($is_valid) {
            add_settings_error(
                'bocm_messages',
                'bocm_ga_credentials_valid',
                sprintf(
                    /* translators: %s: Service account email */
                                        __('Google Analytics service account verified successfully (%s)', 'blue-oak-client-management'),
                    $json_data['client_email']
                ),
                'success'
            );
                            } else {
                                add_settings_error(
                                    'bocm_ga_service_account',
                                    'invalid-credentials',
                                    __('Unable to verify Google Analytics service account credentials', 'blue-oak-client-management'),
                                    'error'
                                );
                                return $old_value;
                            }
        } catch (\Exception $e) {
            add_settings_error(
                                'bocm_ga_service_account',
                                'verification-error',
                                sprintf(
                                    /* translators: %s: Error message */
                                    __('Error verifying Google Analytics credentials: %s', 'blue-oak-client-management'),
                                    $e->getMessage()
                                ),
                'error'
            );
                            return $old_value;
                        }
                    }
                    
                    return $value;
                },
                'default' => '',
            ]
        );

        // Register settings for Vendasta
        register_setting(
            'bocm-vendasta-settings-group',
            'bocm_vendasta_service_account',
            [
                'type' => 'string',
                'sanitize_callback' => function($value) {
                    // Skip verification if the value is empty or unchanged
                    $old_value = get_option('bocm_vendasta_service_account', '');
                    if (empty($value) || $value === $old_value) {
                        return $value;
                    }
                    
                    // Validate JSON format
                    if (!empty($value)) {
                        $json_data = json_decode($value, true);
            if (json_last_error() !== JSON_ERROR_NONE) {
                add_settings_error(
                                'bocm_vendasta_service_account',
                                'invalid-json',
                                sprintf(
                                    /* translators: %s: JSON error message */
                                    __('Invalid JSON format for Vendasta service account credentials: %s', 'blue-oak-client-management'),
                                    json_last_error_msg()
                                ),
                    'error'
                );
                            return $old_value;
            }

            // Validate required fields
                        $required_fields = ['type', 'client_email', 'private_key', 'token_uri'];
            foreach ($required_fields as $field) {
                if (!isset($json_data[$field])) {
                    add_settings_error(
                                    'bocm_vendasta_service_account',
                                    'missing-field',
                        sprintf(
                            /* translators: %s: Missing field name */
                            __('Missing required field in Vendasta credentials: %s', 'blue-oak-client-management'),
                            $field
                        ),
                        'error'
                    );
                                return $old_value;
                            }
                        }
                        
                        // Get partner ID for verification
                        $partner_id = get_option('bocm_vendasta_partner_id', '');
                        if (!empty($partner_id)) {
                            // Only verify if we have a valid partner ID
                            try {
                                $vendasta = new Vendasta();
                                $is_valid = $vendasta->verify_credentials($json_data);
                                
                                if ($is_valid) {
                add_settings_error(
                    'bocm_messages',
                                        'bocm_vendasta_credentials_valid',
                                        sprintf(
                                            /* translators: %s: Service account email */
                                            __('Vendasta service account verified successfully (%s)', 'blue-oak-client-management'),
                                            $json_data['client_email']
                                        ),
                                        'success'
                                    );
                                } else {
                                    add_settings_error(
                                        'bocm_vendasta_service_account',
                                        'invalid-credentials',
                                        __('Unable to verify Vendasta service account credentials', 'blue-oak-client-management'),
                    'error'
                );
                                    return $old_value;
            }
                            } catch (\Exception $e) {
                add_settings_error(
                                    'bocm_vendasta_service_account',
                                    'verification-error',
                                    sprintf(
                                        /* translators: %s: Error message */
                                        __('Error verifying Vendasta credentials: %s', 'blue-oak-client-management'),
                                        $e->getMessage()
                                    ),
                    'error'
                );
                                return $old_value;
                            }
                        }
                    }
                    
                    return $value;
                },
                'default' => '',
            ]
        );

        register_setting(
            'bocm-vendasta-settings-group',
            'bocm_vendasta_partner_id',
            [
                'type' => 'string',
                'sanitize_callback' => 'sanitize_text_field',
                'default' => '',
            ]
        );
        
        // Register setting for PageSpeed API key
        register_setting(
            'bocm-pagespeed-settings-group',
            'bocm_pagespeed_api_key',
            [
                'type' => 'string',
                'sanitize_callback' => function($value) {
                    $value = sanitize_text_field($value);
                    
                    // Skip verification if the value is empty or unchanged
                    $old_value = get_option('bocm_pagespeed_api_key', '');
                    if (empty($value) || $value === $old_value) {
                        return $value;
                    }
                    
                    // Verify the API key
                    try {
                        // Test URL for verification
                        $test_url = 'https://www.example.com';
                        
                        // Build the API request URL
                        $api_url = add_query_arg([
                            'url' => urlencode($test_url),
                            'key' => $value,
                            'strategy' => 'desktop',
                            'category' => 'performance',
                        ], 'https://www.googleapis.com/pagespeedonline/v5/runPagespeed');
                        
                        // Make the API request
                        $response = wp_remote_get($api_url, [
                            'timeout' => 30,
                            'sslverify' => true,
                        ]);
                        
                        if (is_wp_error($response)) {
            add_settings_error(
                                'bocm_pagespeed_api_key',
                                'request-error',
                sprintf(
                                    /* translators: %s: Error message */
                                    __('PageSpeed API request error: %s', 'blue-oak-client-management'),
                                    $response->get_error_message()
                                ),
                                'error'
                            );
                            return $old_value;
                        }
                        
                        $response_code = wp_remote_retrieve_response_code($response);
                        $body = wp_remote_retrieve_body($response);
                        $data = json_decode($body, true);
                        
                        // Check if the API response is valid
                        if ($response_code === 200 && isset($data['lighthouseResult'])) {
                            add_settings_error(
                                'bocm_messages',
                                'bocm_pagespeed_key_valid',
                                __('PageSpeed API key verified successfully', 'blue-oak-client-management'),
                'success'
            );
                        } else {
                            $error_message = isset($data['error']['message']) ? 
                                $data['error']['message'] : 
                                __('Invalid PageSpeed API key or API request failed', 'blue-oak-client-management');
                            
                            add_settings_error(
                                'bocm_pagespeed_api_key',
                                'invalid-key',
                                sprintf(
                                    /* translators: %s: Error message */
                                    __('PageSpeed API key verification failed: %s', 'blue-oak-client-management'),
                                    $error_message
                                ),
                                'error'
                            );
                            return $old_value;
                        }
        } catch (\Exception $e) {
            add_settings_error(
                            'bocm_pagespeed_api_key',
                            'verification-error',
                            sprintf(
                                /* translators: %s: Error message */
                                __('Error verifying PageSpeed API key: %s', 'blue-oak-client-management'),
                                $e->getMessage()
                            ),
                'error'
            );
                        return $old_value;
                    }
                    
                    return $value;
                },
                'default' => '',
            ]
        );

        // Add settings section for General
        add_settings_section(
            'bocm_general_settings_section',
            __('General Settings', 'blue-oak-client-management'),
            [$this, 'render_settings_section'],
            'bocm-general-settings'
        );

        // Add settings field for removing roles on deactivation
        add_settings_field(
            'bocm_remove_roles_on_deactivate',
            __('Plugin Deactivation', 'blue-oak-client-management'),
            [$this, 'render_remove_roles_field'],
            'bocm-general-settings',
            'bocm_general_settings_section'
        );

        // Add settings section for Uptime Robot
        add_settings_section(
            'bocm_uptime_robot_settings_section',
            __('Uptime Robot Settings', 'blue-oak-client-management'),
            [$this, 'render_uptime_robot_settings_section'],
            'bocm-uptime-robot-settings'
        );

        // Add settings field for Uptime Robot API key
        add_settings_field(
            'bocm_uptimerobot_api_key',
            __('API Key', 'blue-oak-client-management'),
            [$this, 'render_uptimerobot_api_key_field'],
            'bocm-uptime-robot-settings',
            'bocm_uptime_robot_settings_section'
        );

        // Add settings field for Uptime Robot cache duration
        add_settings_field(
            'bocm_uptimerobot_cache_duration',
            __('Cache Duration', 'blue-oak-client-management'),
            [$this, 'render_uptimerobot_cache_duration_field'],
            'bocm-uptime-robot-settings',
            'bocm_uptime_robot_settings_section'
        );

        // Add settings section for Google Analytics
        add_settings_section(
            'bocm_ga_settings_section',
            __('Google Analytics Settings', 'blue-oak-client-management'),
            [$this, 'render_ga_settings_section'],
            'bocm-ga-settings'
        );

        // Add settings field for Google Analytics service account
        add_settings_field(
            'bocm_ga_service_account',
            __('Service Account Credentials', 'blue-oak-client-management'),
            [$this, 'render_google_analytics_field'],
            'bocm-ga-settings',
            'bocm_ga_settings_section'
        );

        // Register setting for Google Search Console service account
        register_setting(
            'bocm-gsc-settings-group',
            'bocm_gsc_service_account',
            [
                'type' => 'string',
                'sanitize_callback' => function($value) {
                    $value = sanitize_textarea_field($value);
                    
                    // Skip verification if the value is empty or unchanged
                    $old_value = get_option('bocm_gsc_service_account', '');
                    if (empty($value) || $value === $old_value) {
                        return $value;
                    }
                    
                    // Try to decode the JSON
                    $json_data = json_decode($value, true);
                    if (json_last_error() !== JSON_ERROR_NONE) {
                        add_settings_error(
                            'bocm_gsc_service_account',
                            'invalid_json',
                            __('Google Search Console credentials must be valid JSON.', 'blue-oak-client-management'),
                            'error'
                        );
                        return $old_value;
                    }
                    
                    // Verify credentials
                    try {
                        $google_search_console = new GoogleSearchConsole();
                        $is_valid = $google_search_console->verify_credentials($json_data);
                        
                        if ($is_valid) {
                            add_settings_error(
                                'bocm_messages',
                                'bocm_gsc_credentials_valid',
                                __('Google Search Console credentials verified successfully.', 'blue-oak-client-management'),
                                'success'
                            );
                            
                            // Clear cached site list to force refresh
                            $google_search_console->clear_cached_sites();
                        } else {
                            add_settings_error(
                                'bocm_gsc_service_account',
                                'invalid_credentials',
                                __('Google Search Console credentials verification failed. Please check your service account JSON.', 'blue-oak-client-management'),
                                'error'
                            );
                            return $old_value;
                        }
                    } catch (\Exception $e) {
                        add_settings_error(
                            'bocm_gsc_service_account',
                            'verification_error',
                            sprintf(
                                __('Error verifying Google Search Console credentials: %s', 'blue-oak-client-management'),
                                $e->getMessage()
                            ),
                            'error'
                        );
                        return $old_value;
                    }
                    
                    return $value;
                },
                'default' => '',
            ]
        );

        // Add settings section for Google Search Console
        add_settings_section(
            'bocm_gsc_settings_section',
            __('Google Search Console Settings', 'blue-oak-client-management'),
            [$this, 'render_gsc_settings_section'],
            'bocm-gsc-settings'
        );

        // Add settings field for Google Search Console service account
        add_settings_field(
            'bocm_gsc_service_account',
            __('Service Account Credentials', 'blue-oak-client-management'),
            [$this, 'render_google_search_console_field'],
            'bocm-gsc-settings',
            'bocm_gsc_settings_section'
        );

        // Add settings section for Vendasta
        add_settings_section(
            'bocm_vendasta_settings_section',
            __('Vendasta Settings', 'blue-oak-client-management'),
            [$this, 'render_vendasta_settings_section'],
            'bocm-vendasta-settings'
        );
        
        // Add settings field for Vendasta Partner ID - moved above service account
        add_settings_field(
            'bocm_vendasta_partner_id',
            __('Partner ID', 'blue-oak-client-management'),
            [$this, 'render_vendasta_partner_id_field'],
            'bocm-vendasta-settings',
            'bocm_vendasta_settings_section'
        );

        // Add settings field for Vendasta service account
        add_settings_field(
            'bocm_vendasta_service_account',
            __('Service Account Credentials', 'blue-oak-client-management'),
            [$this, 'render_vendasta_field'],
            'bocm-vendasta-settings',
            'bocm_vendasta_settings_section'
        );

        // Add settings section for PageSpeed
        add_settings_section(
            'bocm_pagespeed_settings_section',
            __('Google PageSpeed Insights Settings', 'blue-oak-client-management'),
            [$this, 'render_pagespeed_settings_section'],
            'bocm-pagespeed-settings'
        );
        
        // Add settings field for PageSpeed API key
        add_settings_field(
            'bocm_pagespeed_api_key',
            __('API Key', 'blue-oak-client-management'),
            [$this, 'render_pagespeed_api_key_field'],
            'bocm-pagespeed-settings',
            'bocm_pagespeed_settings_section'
        );

        // Register Namecheap settings
        register_setting('bocm-namecheap-settings-group', 'bocm_namecheap_api_key');
        register_setting('bocm-namecheap-settings-group', 'bocm_namecheap_username');
        register_setting('bocm-namecheap-settings-group', 'bocm_namecheap_sandbox_mode');
        register_setting('bocm-namecheap-settings-group', 'bocm_namecheap_buy_button_url');

        add_settings_section(
            'bocm_namecheap_settings_section',
            __('Namecheap Settings', 'blue-oak-client-management'),
            [$this, 'render_namecheap_settings_section'],
            'bocm-namecheap-settings'
        );

        add_settings_field(
            'bocm_namecheap_api_key',
            __('API Key', 'blue-oak-client-management'),
            [$this, 'render_namecheap_api_key_field'],
            'bocm-namecheap-settings',
            'bocm_namecheap_settings_section'
        );

        add_settings_field(
            'bocm_namecheap_username',
            __('Username', 'blue-oak-client-management'),
            [$this, 'render_namecheap_username_field'],
            'bocm-namecheap-settings',
            'bocm_namecheap_settings_section'
        );

        add_settings_field(
            'bocm_namecheap_sandbox_mode',
            __('Sandbox Mode', 'blue-oak-client-management'),
            [$this, 'render_namecheap_sandbox_mode_field'],
            'bocm-namecheap-settings',
            'bocm_namecheap_settings_section'
        );

        add_settings_field(
            'bocm_namecheap_buy_button_url',
            __('Domain Buy It Now Button Link', 'blue-oak-client-management'),
            [$this, 'render_namecheap_buy_button_url_field'],
            'bocm-namecheap-settings',
            'bocm_namecheap_settings_section'
        );
    }

    /**
     * Render Namecheap settings section
     *
     * @return void
     */
    public function render_namecheap_settings_section(): void {
        echo '<p>' . esc_html__('Configure your Namecheap API credentials to enable domain management features.', 'blue-oak-client-management') . '</p>';
    }

    /**
     * Render Namecheap API key field
     *
     * @return void
     */
    public function render_namecheap_api_key_field(): void {
        $api_key = get_option('bocm_namecheap_api_key', '');
        $key_type = '';
        $key_valid = false;
        $key_color = '#6c757d'; // Default gray
        $has_error = false;
        
        // Check if there are any error notices for Namecheap
        $settings_errors = get_settings_errors('bocm_namecheap_api_key');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                break;
            }
        }
        
        // If we have an API key, check its validity
        if (!empty($api_key) && !$has_error) {
            try {
                $namecheap = new Namecheap();
                $result = $namecheap->verify_api_key();
                
                if ($result['is_valid']) {
                    $key_valid = true;
                    $key_type = 'Valid Key';
                    $key_color = '#28a745'; // Green for valid key
                } else {
                    $key_type = 'Invalid Key';
                    $key_color = '#dc3545'; // Red for invalid key
                }
            } catch (\Exception $e) {
                $key_type = 'Error';
                $key_color = '#dc3545'; // Red for error
            }
        }
        
        // Output the required CSS styles
        $this->output_api_field_styles();
        ?>
        
        <div class="bocm-api-key-container" id="namecheap-container">
            <input type="password" 
                   name="bocm_namecheap_api_key" 
                   id="bocm_namecheap_api_key" 
                   value="<?php echo esc_attr($api_key); ?>" 
                   class="regular-text bocm-api-key-input"
                   placeholder="Enter Namecheap API Key" />
            <span class="bocm-api-key-button" style="background-color: <?php echo esc_attr($key_color); ?>; border-color: <?php echo esc_attr($key_color); ?>;">
                <?php echo esc_html($key_type ?: 'No Key'); ?>
            </span>
        </div>
        
        <p class="description" style="margin-top: 10px;">
            <?php _e('Enter your Namecheap API key. The key will be verified when you save settings.', 'blue-oak-client-management'); ?>
        </p>

        <!-- JavaScript to handle error notices and update the button accordingly -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Check for error notices on the page that might indicate invalid credentials
                const checkForErrors = function() {
                    const hasErrorNotice = $('.notice-error').filter(function() {
                        return $(this).text().indexOf('Namecheap API') !== -1 || 
                               $(this).text().indexOf('Namecheap key') !== -1;
                    }).length > 0;
                    
                    if (hasErrorNotice) {
                        // Update the button to show invalid status
                        const keyButton = $('#namecheap-container .bocm-api-key-button');
                        if (keyButton.length > 0) {
                            keyButton.text('Invalid Key');
                            keyButton.css({
                                'background-color': '#dc3545',
                                'border-color': '#dc3545'
                            });
                        }
                    }
                };
                
                // Run on page load
                checkForErrors();
            });
        </script>
        <?php
    }

    /**
     * Render Namecheap username field
     *
     * @return void
     */
    public function render_namecheap_username_field(): void {
        $username = get_option('bocm_namecheap_username', '');
        ?>
        <input type="text" 
               name="bocm_namecheap_username" 
               value="<?php echo esc_attr($username); ?>" 
               class="regular-text"
        />
        <p class="description">
            <?php esc_html_e('Enter your Namecheap username.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * Render Namecheap sandbox mode field
     *
     * @return void
     */
    public function render_namecheap_sandbox_mode_field(): void {
        $sandbox_mode = get_option('bocm_namecheap_sandbox_mode', true);
        ?>
        <label>
            <input type="checkbox" 
                   name="bocm_namecheap_sandbox_mode" 
                   value="1" 
                   <?php checked($sandbox_mode); ?>
            />
            <?php esc_html_e('Enable sandbox mode for testing', 'blue-oak-client-management'); ?>
        </label>
        <p class="description">
            <?php esc_html_e('When enabled, all API calls will be made to the sandbox environment. Disable this for production use.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * Render Namecheap Buy Button URL field
     *
     * @return void
     */
    public function render_namecheap_buy_button_url_field(): void {
        $buy_button_url = get_option('bocm_namecheap_buy_button_url', 'https://www.namecheap.com/domains/registration/results/?domain={domain}');
        ?>
        <input type="text" 
               name="bocm_namecheap_buy_button_url" 
               value="<?php echo esc_attr($buy_button_url); ?>" 
               class="regular-text"
        />
        <p class="description">
            <?php esc_html_e('URL for the Buy It Now button. Use {domain} as a placeholder for the domain name.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * CSS Styles for API Key Fields
     * These styles are used by multiple field rendering methods
     */
    private function output_api_field_styles(): void {
        ?>
        <style>
            .bocm-api-key-container {
                display: flex;
                align-items: stretch;
                width: 100%;
                max-width: 500px;
                margin-bottom: 10px;
            }
            
            .bocm-api-key-input {
                flex-grow: 1;
                border-top-right-radius: 0;
                border-bottom-right-radius: 0;
                border-right: none;
                padding: 0 8px;
                height: 40px;
                font-size: 14px;
            }
            
            .bocm-api-key-button {
                display: flex;
                align-items: center;
                justify-content: center;
                padding: 6px 12px;
                font-size: 14px;
                font-weight: 500;
                color: #fff;
                border-top-right-radius: 4px;
                border-bottom-right-radius: 4px;
                background-color: #007cba;
                border: 1px solid #007cba;
                cursor: pointer;
                text-decoration: none;
                transition: all 0.3s ease;
            }
            
            .bocm-api-key-button:hover {
                background-color: #006ba1;
                border-color: #006ba1;
                color: #fff;
            }
            
            .bocm-credentials-pill {
                display: inline-flex;
                align-items: center;
                background-color: #28a745;
                color: white;
                padding: 4px 12px;
                border-radius: 16px;
                font-size: 13px;
                margin-top: 10px;
                margin-bottom: 10px;
            }
            
            .bocm-credentials-pill .dashicons {
                margin-right: 6px;
                font-size: 16px;
                width: 16px;
                height: 16px;
            }
            
            .bocm-available-sites {
                margin-top: 20px;
                background: #f9f9f9;
                padding: 15px;
                border-radius: 5px;
                border: 1px solid #e5e5e5;
            }
            
            .bocm-available-sites h4 {
                margin-top: 0;
                margin-bottom: 15px;
                color: #23282d;
            }
            
            /* Modal styles */
            .bocm-modal {
                display: none;
                position: fixed;
                z-index: 1000;
                left: 0;
                top: 0;
                width: 100%;
                height: 100%;
                overflow: auto;
                background-color: rgba(0,0,0,0.4);
            }
            
            .bocm-modal-content {
                background-color: #fefefe;
                margin: 5% auto;
                padding: 0;
                border: 1px solid #ddd;
                border-radius: 4px;
                width: 80%;
                max-width: 800px;
                box-shadow: 0 4px 8px rgba(0,0,0,0.1);
                animation: bocmFadeIn 0.3s;
            }
            
            .bocm-modal-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                padding: 15px 20px;
                border-bottom: 1px solid #e5e5e5;
            }
            
            .bocm-modal-header h3 {
                margin: 0;
                font-size: 1.2em;
                color: #23282d;
            }
            
            .bocm-modal-close {
                color: #aaa;
                font-size: 24px;
                font-weight: bold;
                cursor: pointer;
            }
            
            .bocm-modal-close:hover {
                color: #555;
            }
            
            .bocm-modal-body {
                padding: 20px;
                max-height: 60vh;
                overflow-y: auto;
            }
            
            .bocm-modal-footer {
                padding: 15px 20px;
                border-top: 1px solid #e5e5e5;
                text-align: right;
            }
            
            @keyframes bocmFadeIn {
                from {opacity: 0; transform: translateY(-20px);}
                to {opacity: 1; transform: translateY(0);}
            }
        </style>
        <?php
    }

    /**
     * Render the main admin page
     *
     * @return void
     */
    public function render_main_page(): void {
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php 
            // Display all settings errors/notices
            settings_errors(); 
            ?>
            
            <p><?php _e('Welcome to Blue Oak Client Management. Use the menu on the left to manage your client settings.', 'blue-oak-client-management'); ?></p>
            
            <?php
            // Get all users with Blue Oak Client role
            $clients = get_users(['role' => 'blue_oak_client']);
            if (!empty($clients)) {
                ?>
                <h2><?php _e('Client Overview', 'blue-oak-client-management'); ?></h2>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php _e('Client Name', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Email', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Partner Account Group ID', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('GA Property ID', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Uptime Monitor', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Reporting URL', 'blue-oak-client-management'); ?></th>
                            <th><?php _e('Actions', 'blue-oak-client-management'); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($clients as $client) { 
                            $uptime_monitor_id = get_user_meta($client->ID, 'bocm_uptime_monitor_id', true);
                            $reporting_url = get_user_meta($client->ID, 'bocm_reporting_url', true);
                            
                            // Get monitor name if available
                            $uptime_robot = new UptimeRobot();
                            $monitor_options = $uptime_robot->get_monitor_options();
                            $monitor_name = $monitor_options[$uptime_monitor_id] ?? $uptime_monitor_id;
                        ?>
                            <tr>
                                <td><?php echo esc_html($client->display_name); ?></td>
                                <td><?php echo esc_html($client->user_email); ?></td>
                                <td><?php echo esc_html(get_user_meta($client->ID, 'bocm_partner_account_group_id', true)); ?></td>
                                <td><?php echo esc_html(get_user_meta($client->ID, 'bocm_ga_property_id', true)); ?></td>
                                <td><?php echo esc_html($monitor_name); ?></td>
                                <td>
                                    <?php if (!empty($reporting_url)): ?>
                                        <a href="<?php echo esc_url($reporting_url); ?>" target="_blank">
                                            <?php echo esc_html($reporting_url); ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <a href="<?php echo esc_url(get_edit_user_link($client->ID)); ?>" class="button button-secondary">
                                        <?php _e('Edit', 'blue-oak-client-management'); ?>
                                    </a>
                                </td>
                            </tr>
                        <?php } ?>
                    </tbody>
                </table>
                <?php
            } else {
                ?>
                <div class="notice notice-info inline">
                    <p>
                        <?php _e('No Blue Oak Clients have been registered yet.', 'blue-oak-client-management'); ?>
                        <a href="<?php echo esc_url(admin_url('user-new.php')); ?>" class="button button-primary" style="margin-left: 10px;">
                            <?php _e('Add New Client', 'blue-oak-client-management'); ?>
                        </a>
                    </p>
                </div>
                <div class="bocm-no-clients-info" style="margin-top: 20px; padding: 20px; background-color: #fff; border: 1px solid #ccd0d4; border-radius: 4px; box-shadow: 0 1px 1px rgba(0,0,0,.04);">
                    <h3><?php _e('How to add Blue Oak Clients', 'blue-oak-client-management'); ?></h3>
                    <ol style="margin-left: 20px;">
                        <li><?php _e('Go to <strong>Users → Add New</strong> in the WordPress admin menu', 'blue-oak-client-management'); ?></li>
                        <li><?php _e('Fill in the client\'s information and set their role to <strong>Blue Oak Client</strong>', 'blue-oak-client-management'); ?></li>
                        <li><?php _e('Click the <strong>Blue Oak Settings</strong> section to configure their services', 'blue-oak-client-management'); ?></li>
                        <li><?php _e('Set up their Partner Account Group ID, Google Analytics, Uptime Monitor, and other settings', 'blue-oak-client-management'); ?></li>
                        <li><?php _e('Click <strong>Add New User</strong> to complete the process', 'blue-oak-client-management'); ?></li>
                    </ol>
                    <p><?php _e('After adding a client, they will be able to log in and access their client portal.', 'blue-oak-client-management'); ?></p>
                </div>
                <?php
            }
            ?>
        </div>
        <?php
    }

    /**
     * Render the settings page
     *
     * @return void
     */
    public function render_settings_page(): void {
        // Get the active tab, default to general
        $active_tab = isset($_GET['tab']) ? sanitize_key($_GET['tab']) : 'general';
        
        ?>
        <div class="wrap">
            <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
            
            <?php 
            // Display all settings errors/notices
            settings_errors(); 
            ?>
            
            <h2 class="nav-tab-wrapper">
                <a href="?page=blue-oak-client-management-settings&tab=general" class="nav-tab <?php echo $active_tab === 'general' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('General', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=uptime-robot" class="nav-tab <?php echo $active_tab === 'uptime-robot' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Uptime Robot', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=google-analytics" class="nav-tab <?php echo $active_tab === 'google-analytics' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Google Analytics', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=google-search-console" class="nav-tab <?php echo $active_tab === 'google-search-console' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Google Search Console', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=vendasta" class="nav-tab <?php echo $active_tab === 'vendasta' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Vendasta', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=pagespeed" class="nav-tab <?php echo $active_tab === 'pagespeed' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('PageSpeed', 'blue-oak-client-management'); ?>
                </a>
                <a href="?page=blue-oak-client-management-settings&tab=namecheap" class="nav-tab <?php echo $active_tab === 'namecheap' ? 'nav-tab-active' : ''; ?>">
                    <?php _e('Namecheap', 'blue-oak-client-management'); ?>
                </a>
            </h2>
            
            <form action="options.php" method="post">
                <?php
                // Use the appropriate settings group based on active tab
                switch ($active_tab) {
                    case 'uptime-robot':
                        settings_fields('bocm-uptime-robot-settings-group');
                        do_settings_sections('bocm-uptime-robot-settings');
                        break;
                    case 'google-analytics':
                        settings_fields('bocm-ga-settings-group');
                        do_settings_sections('bocm-ga-settings');
                        break;
                    case 'google-search-console':
                        settings_fields('bocm-gsc-settings-group');
                        do_settings_sections('bocm-gsc-settings');
                        break;
                    case 'vendasta':
                        settings_fields('bocm-vendasta-settings-group');
                        do_settings_sections('bocm-vendasta-settings');
                        break;
                    case 'pagespeed':
                        settings_fields('bocm-pagespeed-settings-group');
                        do_settings_sections('bocm-pagespeed-settings');
                        
                        // If we're on the PageSpeed tab, show the client scan table and schedule info
                        if ($active_tab === 'pagespeed') {
                            $this->render_pagespeed_client_table();
                        }
                        break;
                    case 'namecheap':
                        settings_fields('bocm-namecheap-settings-group');
                        do_settings_sections('bocm-namecheap-settings');
                        break;
                    default: // 'general'
                        settings_fields('bocm-general-settings-group');
                        do_settings_sections('bocm-general-settings');
                        break;
                }
                
                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    /**
     * Render the settings section description
     *
     * @return void
     */
    public function render_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure general settings for the Blue Oak Client Management plugin.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * Render the Uptime Robot settings section description
     *
     * @return void
     */
    public function render_uptime_robot_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure Uptime Robot integration to monitor your clients\' websites.', 'blue-oak-client-management'); ?>
        </p>
        <p>
            <?php _e('The cache duration setting controls how long uptime data is stored before being refreshed. Lower values provide more up-to-date information but may increase API usage.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }
    
    /**
     * Render the Google Analytics settings section description
     *
     * @return void
     */
    public function render_ga_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure Google Analytics integration to track and display analytics data for your clients.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }
    
    /**
     * Render the Google Search Console settings section description
     *
     * @return void
     */
    public function render_gsc_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure Google Search Console integration to monitor and display search performance data for your clients.', 'blue-oak-client-management'); ?>
        </p>
        <p>
            <a href="https://developers.google.com/search/apis/search-console-api/getting-started" target="_blank"><?php _e('Learn how to set up a service account', 'blue-oak-client-management'); ?></a>
        </p>
        <?php
    }
    
    /**
     * Render the Vendasta settings section description
     *
     * @return void
     */
    public function render_vendasta_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure Vendasta integration to manage client purchases and services.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }
    
    /**
     * Render the PageSpeed settings section description
     *
     * @return void
     */
    public function render_pagespeed_settings_section(): void {
        ?>
        <p>
            <?php _e('Configure Google PageSpeed Insights integration to analyze and track your clients\' website performance.', 'blue-oak-client-management'); ?>
        </p>
        <p>
            <a href="https://developers.google.com/speed/docs/insights/v5/get-started" target="_blank"><?php _e('Learn how to get an API key', 'blue-oak-client-management'); ?></a>
        </p>
        <?php
    }

    /**
     * Render the remove roles setting field
     *
     * @return void
     */
    public function render_remove_roles_field(): void {
        $value = get_option('bocm_remove_roles_on_deactivate', false);
        ?>
        <label>
            <input type="checkbox" 
                   name="bocm_remove_roles_on_deactivate" 
                   value="1" 
                   <?php checked($value, true); ?> />
            <?php _e('Remove custom roles and capabilities when the plugin is deactivated', 'blue-oak-client-management'); ?>
        </label>
        <p class="description">
            <?php _e('Warning: This will remove all Blue Oak Client roles and their associated data upon plugin deactivation.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }

    /**
     * Render the Uptime Robot API key field
     *
     * @return void
     */
    public function render_uptimerobot_api_key_field(): void {
        $api_key = get_option('bocm_uptimerobot_api_key', '');
        $key_type = '';
        $key_valid = false;
        $key_color = '#6c757d'; // Default gray
        $has_error = false;
        
        // Check if there are any error notices for Uptime Robot
        $settings_errors = get_settings_errors('bocm_uptimerobot_api_key');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the API key on refresh
                $api_key = '';
                break;
            }
        }
        
        // If we have an API key, check its type
        if (!empty($api_key) && !$has_error) {
            $uptime_robot = new UptimeRobot();
            $result = $uptime_robot->verify_api_key();
            if ($result['is_valid']) {
                $key_valid = true;
                if ($result['type'] === 'read-write') {
                    $key_type = 'Read-Write Key';
                    $key_color = '#28a745'; // Green for read-write
                } else {
                    $key_type = 'Read-Only Key';
                    $key_color = '#ffc107'; // Yellow/orange for read-only
                }
            } else {
                $key_type = 'Invalid Key';
                $key_color = '#dc3545'; // Red for invalid
            }
        }
        
        // Output the required CSS styles
        $this->output_api_field_styles();
        ?>
        
        <div class="bocm-api-key-container" id="uptimerobot-container">
            <input type="text" 
                   name="bocm_uptimerobot_api_key" 
                   id="bocm_uptimerobot_api_key" 
                   value="<?php echo esc_attr($api_key); ?>" 
                   class="regular-text bocm-api-key-input"
                   placeholder="Enter Uptime Robot API Key" />
            <span class="bocm-api-key-button" style="background-color: <?php echo esc_attr($key_color); ?>; border-color: <?php echo esc_attr($key_color); ?>;">
                <?php echo esc_html($key_type ?: 'No Key'); ?>
                </span>
        </div>
        
        <p class="description" style="margin-top: 10px;">
            <?php _e('Enter your Uptime Robot API key to monitor client websites. The key will be verified when you save settings.', 'blue-oak-client-management'); ?><br>
            <?php _e('For full functionality, a Read-Write API key is recommended.', 'blue-oak-client-management'); ?>
        </p>

        <!-- JavaScript to handle error notices and update the button accordingly -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Check for error notices on the page that might indicate invalid credentials
                const checkForErrors = function() {
                    const hasErrorNotice = $('.notice-error').filter(function() {
                        return $(this).text().indexOf('Uptime Robot API') !== -1 || 
                               $(this).text().indexOf('Uptime Robot key') !== -1;
                    }).length > 0;
                    
                    if (hasErrorNotice) {
                        // Update the button to show invalid status
                        const keyButton = $('#uptimerobot-container .bocm-api-key-button');
                        if (keyButton.length > 0) {
                            keyButton.text('Invalid Key');
                            keyButton.css({
                                'background-color': '#dc3545',
                                'border-color': '#dc3545'
                            });
                        }
                        
                        // Clear the input if there are errors
                        $('#bocm_uptimerobot_api_key').val('');
                    }
                };
                
                // Run on page load
                checkForErrors();
            });
        </script>
        <?php
    }

    /**
     * Render the Google Analytics service account field
     *
     * @return void
     */
    public function render_google_analytics_field(): void {
        $credentials = get_option('bocm_ga_service_account', '');
        $email = '';
        $is_valid = false;
        $has_error = false;
        
        // Check if there are any error notices for Google Analytics
        $settings_errors = get_settings_errors('bocm_ga_service_account');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the credentials on refresh
                $credentials = '';
                break;
            }
        }
        
        // If credentials are set, try to extract the email
        if (!empty($credentials)) {
            $json_data = json_decode($credentials, true);
            if (json_last_error() === JSON_ERROR_NONE && isset($json_data['client_email'])) {
                $email = $json_data['client_email'];
                
                // Check if credentials are valid by attempting to verify them
                if (!$has_error) {
                    try {
                        $google_analytics = new GoogleAnalytics();
                        $is_valid = $google_analytics->verify_credentials($json_data);
                    } catch (\Exception $e) {
                        // Verification failed
                        $is_valid = false;
                    }
                }
            }
        }
        
        // Output the required CSS styles for the pill
        $this->output_api_field_styles();
        ?>
        
        <textarea name="bocm_ga_service_account" 
                  id="bocm_ga_service_account" 
                  class="large-text code" 
                  rows="10"><?php echo esc_textarea($credentials); ?></textarea>
        
        <p class="description">
            <?php _e('Enter your Google Analytics service account credentials JSON.', 'blue-oak-client-management'); ?>
        </p>
        <p class="description">
            <?php _e('Make sure the service account has been added to your Google Analytics properties with appropriate permissions.', 'blue-oak-client-management'); ?>
        </p>
        
        <?php if ($has_error && !empty($email)) : ?>
            <div class="bocm-credentials-pill" style="background-color: #dc3545;">
                <span class="dashicons dashicons-warning"></span>
                <?php echo esc_html__('Invalid credentials:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
        <?php elseif ($is_valid && !empty($email)) : ?>
            <div class="bocm-credentials-pill">
                <span class="dashicons dashicons-yes-alt"></span>
                <?php echo esc_html__('Valid account:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
            
            <?php 
            // Get property information for modal display
            $google_analytics = new GoogleAnalytics();
            $property_options = $google_analytics->get_property_options();
            
            // Show button regardless of property count since we now have helpful guidance
            ?>
            <button type="button" class="button" id="bocm-view-ga-properties" style="margin-top: 10px;">
                <?php _e('View Available Properties', 'blue-oak-client-management'); ?>
            </button>
            
            <!-- Modal HTML structure -->
            <div id="bocm-ga-properties-modal" class="bocm-modal">
                <div class="bocm-modal-content">
                    <div class="bocm-modal-header">
                        <h3><?php _e('Available Google Analytics Properties', 'blue-oak-client-management'); ?></h3>
                        <span class="bocm-modal-close">&times;</span>
                    </div>
                    <div class="bocm-modal-body">
                        <p><?php _e('The following properties are available through your Google Analytics account. You can select these properties when configuring client profiles.', 'blue-oak-client-management'); ?></p>
                        
                        <?php if (count($property_options) <= 1): ?>
                        <div class="notice notice-warning inline">
                            <p>
                                <strong><?php _e('No properties found.', 'blue-oak-client-management'); ?></strong> 
                                <?php _e('To add properties, make sure your service account email has been granted access to your Google Analytics properties.', 'blue-oak-client-management'); ?>
                            </p>
                            <p>
                                <?php _e('Steps to add properties:', 'blue-oak-client-management'); ?>
                                <ol>
                                    <li><?php _e('Go to <a href="https://analytics.google.com/" target="_blank">Google Analytics</a>', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Select your property', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Go to Admin > Account Access Management', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Click the + button to add users', 'blue-oak-client-management'); ?></li>
                                    <li><?php printf(__('Add your service account email: <code>%s</code>', 'blue-oak-client-management'), esc_html($email)); ?></li>
                                    <li><?php _e('Select "Viewer" or higher permission', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Save your changes', 'blue-oak-client-management'); ?></li>
                                </ol>
                            </p>
                        </div>
                        <?php else: ?>
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Property ID', 'blue-oak-client-management'); ?></th>
                                    <th><?php _e('Property Name', 'blue-oak-client-management'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($property_options as $id => $name): 
                                    if (empty($id)) continue; // Skip the empty option
                                ?>
                                    <tr>
                                        <td><?php echo esc_html($id); ?></td>
                                        <td><?php echo esc_html($name); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                    <div class="bocm-modal-footer">
                        <button type="button" class="button bocm-modal-close-btn"><?php _e('Close', 'blue-oak-client-management'); ?></button>
                    </div>
                </div>
            </div>
            
            <script>
                jQuery(document).ready(function($) {
                    // GA Properties Modal
                    const gaModal = $("#bocm-ga-properties-modal");
                    const gaBtn = $("#bocm-view-ga-properties");
                    const gaCloseBtn = gaModal.find(".bocm-modal-close, .bocm-modal-close-btn");
                    
                    gaBtn.on("click", function() {
                        gaModal.css("display", "block");
                    });
                    
                    gaCloseBtn.on("click", function() {
                        gaModal.css("display", "none");
                    });
                    
                    $(window).on("click", function(e) {
                        if ($(e.target).is(gaModal)) {
                            gaModal.css("display", "none");
                        }
                    });
                    
                    // Check for error notices on the page that might indicate invalid credentials
                    const checkForErrors = function() {
                        const hasErrorNotice = $('.notice-error').filter(function() {
                            return $(this).text().indexOf('Google Analytics') !== -1;
                        }).length > 0;
                        
                        if (hasErrorNotice) {
                            // If we have a credentials pill, update it to show error state
                            const $pill = $('.bocm-credentials-pill');
                            if ($pill.length > 0) {
                                $pill.css('background-color', '#dc3545')
                                     .find('.dashicons')
                                     .removeClass('dashicons-yes-alt')
                                     .addClass('dashicons-warning');
                                $pill.find('span.dashicons').next().text('<?php echo esc_js(__('Invalid credentials:', 'blue-oak-client-management')); ?> ');
                            }
                            
                            // Hide the view properties button if it exists
                            $('#bocm-view-ga-properties').hide();
                            
                            // Clear the textarea if there are errors
                            $('#bocm_ga_service_account').val('');
                        }
                    };
                    
                    // Run on page load
                    checkForErrors();
                });
            </script>
        <?php endif; ?>
        <?php
    }

    /**
     * Render the Google Search Console service account field
     *
     * @return void
     */
    public function render_google_search_console_field(): void {
        $credentials = get_option('bocm_gsc_service_account', '');
        $email = '';
        $is_valid = false;
        $has_error = false;
        
        // Check if there are any error notices for Google Search Console
        $settings_errors = get_settings_errors('bocm_gsc_service_account');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the credentials on refresh
                $credentials = '';
                break;
            }
        }
        
        // If credentials are set, try to extract the email
        if (!empty($credentials)) {
            $json_data = json_decode($credentials, true);
            if (json_last_error() === JSON_ERROR_NONE && isset($json_data['client_email'])) {
                $email = $json_data['client_email'];
                
                // Check if credentials are valid by attempting to verify them
                if (!$has_error) {
                    try {
                        $google_search_console = new GoogleSearchConsole();
                        $is_valid = $google_search_console->verify_credentials($json_data);
                    } catch (\Exception $e) {
                        // Verification failed
                        $is_valid = false;
                    }
                }
            }
        }
        
        // Output the required CSS styles for the pill
        $this->output_api_field_styles();
        ?>
        
        <textarea name="bocm_gsc_service_account" 
                  id="bocm_gsc_service_account" 
                  class="large-text code" 
                  rows="10"><?php echo esc_textarea($credentials); ?></textarea>
        
        <p class="description">
            <?php _e('Enter your Google Search Console service account credentials JSON.', 'blue-oak-client-management'); ?>
        </p>
        <p class="description">
            <?php _e('Make sure the service account has been added to your Search Console properties with appropriate permissions.', 'blue-oak-client-management'); ?>
        </p>
        
        <?php if ($has_error && !empty($email)) : ?>
            <div class="bocm-credentials-pill" style="background-color: #dc3545;">
                <span class="dashicons dashicons-warning"></span>
                <?php echo esc_html__('Invalid credentials:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
        <?php elseif ($is_valid && !empty($email)) : ?>
            <div class="bocm-credentials-pill">
                <span class="dashicons dashicons-yes-alt"></span>
                <?php echo esc_html__('Valid account:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
            
            <?php 
            // Get site information for modal display - we'll always get fresh data now
            $google_search_console = new GoogleSearchConsole();
            $site_options = $google_search_console->get_site_options();
            
            // Show button regardless of site count since we now have helpful guidance
            ?>
            <button type="button" class="button" id="bocm-view-gsc-sites" style="margin-top: 10px;">
                <?php _e('View Available Sites', 'blue-oak-client-management'); ?>
            </button>
            
            <!-- Modal HTML structure -->
            <div id="bocm-gsc-sites-modal" class="bocm-modal">
                <div class="bocm-modal-content">
                    <div class="bocm-modal-header">
                        <h3><?php _e('Available Search Console Sites', 'blue-oak-client-management'); ?></h3>
                        <span class="bocm-modal-close">&times;</span>
                    </div>
                    <div class="bocm-modal-body">
                        <p><?php _e('The following sites are available through your Google Search Console account. You can select these sites when configuring client profiles.', 'blue-oak-client-management'); ?></p>
                        
                        <?php if (count($site_options) <= 1): ?>
                        <div class="notice notice-warning inline">
                            <p>
                                <strong><?php _e('No sites found.', 'blue-oak-client-management'); ?></strong> 
                                <?php _e('To add sites, make sure your service account email has been granted access to your Search Console properties.', 'blue-oak-client-management'); ?>
                            </p>
                            <p>
                                <?php _e('Steps to add sites:', 'blue-oak-client-management'); ?>
                                <ol>
                                    <li><?php _e('Go to <a href="https://search.google.com/search-console" target="_blank">Google Search Console</a>', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Select your property', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Go to Settings > Users and permissions', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Click "Add User"', 'blue-oak-client-management'); ?></li>
                                    <li><?php printf(__('Add your service account email: <code>%s</code>', 'blue-oak-client-management'), esc_html($email)); ?></li>
                                    <li><?php _e('Select "Owner" or "Full" permission', 'blue-oak-client-management'); ?></li>
                                    <li><?php _e('Save your changes', 'blue-oak-client-management'); ?></li>
                                </ol>
                            </p>
                        </div>
                        <?php else: ?>
                        <table class="widefat striped">
                            <thead>
                                <tr>
                                    <th><?php _e('Site URL', 'blue-oak-client-management'); ?></th>
                                    <th><?php _e('Display Name', 'blue-oak-client-management'); ?></th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($site_options as $url => $name): 
                                    if (empty($url)) continue; // Skip the empty option
                                ?>
                                    <tr>
                                        <td><?php echo esc_html($url); ?></td>
                                        <td><?php echo esc_html($name); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        <?php endif; ?>
                    </div>
                    <div class="bocm-modal-footer">
                        <button type="button" class="button bocm-modal-close-btn"><?php _e('Close', 'blue-oak-client-management'); ?></button>
                    </div>
                </div>
            </div>
            
            <script>
                jQuery(document).ready(function($) {
                    // GSC Sites Modal
                    const gscModal = $("#bocm-gsc-sites-modal");
                    const gscBtn = $("#bocm-view-gsc-sites");
                    const gscCloseBtn = gscModal.find(".bocm-modal-close, .bocm-modal-close-btn");
                    
                    gscBtn.on("click", function() {
                        gscModal.css("display", "block");
                    });
                    
                    gscCloseBtn.on("click", function() {
                        gscModal.css("display", "none");
                    });
                    
                    $(window).on("click", function(e) {
                        if ($(e.target).is(gscModal)) {
                            gscModal.css("display", "none");
                        }
                    });
                    
                    // Check for error notices on the page that might indicate invalid credentials
                    const checkForErrors = function() {
                        const hasErrorNotice = $('.notice-error').filter(function() {
                            return $(this).text().indexOf('Google Search Console') !== -1 || 
                                   $(this).text().indexOf('Search Console credentials') !== -1;
                        }).length > 0;
                        
                        if (hasErrorNotice) {
                            // If we have a credentials pill, update it to show error state
                            const $pill = $('.bocm-credentials-pill');
                            if ($pill.length > 0) {
                                $pill.css('background-color', '#dc3545')
                                     .find('.dashicons')
                                     .removeClass('dashicons-yes-alt')
                                     .addClass('dashicons-warning');
                                $pill.find('span.dashicons').next().text('<?php echo esc_js(__('Invalid credentials:', 'blue-oak-client-management')); ?> ');
                            }
                            
                            // Hide the view sites button if it exists
                            $('#bocm-view-gsc-sites').hide();
                        }
                    };
                    
                    // Run on page load
                    checkForErrors();
                });
            </script>
        <?php endif; ?>
        <?php
    }

    /**
     * Render the Vendasta service account field
     *
     * @return void
     */
    public function render_vendasta_field(): void {
        $credentials = get_option('bocm_vendasta_service_account', '');
        $email = '';
        $is_valid = false;
        $has_error = false;
        
        // Check if there are any error notices for Vendasta
        $settings_errors = get_settings_errors('bocm_vendasta_service_account');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the credentials on refresh
                $credentials = '';
                break;
            }
        }
        
        // If credentials are set, try to extract the email
        if (!empty($credentials)) {
            $json_data = json_decode($credentials, true);
            if (json_last_error() === JSON_ERROR_NONE && isset($json_data['client_email'])) {
                $email = $json_data['client_email'];
                
                // Check if credentials are valid by attempting to verify them
                // Only check validity if we have a partner ID that's not empty
                if (!$has_error) {
                    $partner_id = get_option('bocm_vendasta_partner_id', '');
                    if (!empty($partner_id)) {
                        try {
                            $vendasta = new Vendasta();
                            $is_valid = $vendasta->verify_credentials($json_data);
                        } catch (\Exception $e) {
                            // Verification failed
                            $is_valid = false;
                        }
                    }
                }
            }
        }
        
        // Output the required CSS styles for the pill
        $this->output_api_field_styles();
        ?>
        
        <textarea name="bocm_vendasta_service_account" 
                  id="bocm_vendasta_service_account" 
                  class="large-text code" 
                  rows="10"><?php echo esc_textarea($credentials); ?></textarea>
        
        <?php if ($has_error && !empty($email)) : ?>
            <div class="bocm-credentials-pill" style="background-color: #dc3545;">
                <span class="dashicons dashicons-warning"></span>
                <?php echo esc_html__('Invalid credentials:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
        <?php elseif ($is_valid && !empty($email)) : ?>
            <div class="bocm-credentials-pill">
                <span class="dashicons dashicons-yes-alt"></span>
                <?php echo esc_html__('Valid account:', 'blue-oak-client-management'); ?> 
                <?php echo esc_html($email); ?>
            </div>
        <?php elseif (!empty($email)) : ?>
            <div class="bocm-credentials-pill" style="background-color: #6c757d;">
                <span class="dashicons dashicons-info"></span>
                <?php echo esc_html($email); ?>
            </div>
        <?php endif; ?>
        
        <script>
            jQuery(document).ready(function($) {
                // Check for error notices on the page that might indicate invalid credentials
                const checkForErrors = function() {
                    const hasErrorNotice = $('.notice-error').filter(function() {
                        return $(this).text().indexOf('Vendasta') !== -1 || 
                               $(this).text().indexOf('service account credentials') !== -1;
                    }).length > 0;
                    
                    if (hasErrorNotice) {
                        // If we have a credentials pill, update it to show error state
                        const $pill = $('.bocm-credentials-pill');
                        if ($pill.length > 0) {
                            $pill.css('background-color', '#dc3545')
                                 .find('.dashicons')
                                 .removeClass('dashicons-yes-alt dashicons-info')
                                 .addClass('dashicons-warning');
                            $pill.find('span.dashicons').next().text('<?php echo esc_js(__('Invalid credentials:', 'blue-oak-client-management')); ?> ');
                        }
                        
                        // Clear the textarea if there are errors
                        $('#bocm_vendasta_service_account').val('');
                    }
                };
                
                // Run on page load
                checkForErrors();
            });
        </script>
        <?php
    }
    
    /**
     * Render the Vendasta Partner ID field
     *
     * @return void
     */
    public function render_vendasta_partner_id_field(): void {
        $partner_id = get_option('bocm_vendasta_partner_id', '');
        $key_type = '';
        $key_valid = false;
        $key_color = '#6c757d'; // Default gray
        $has_error = false;
        
        // Check if there are any error notices for Vendasta Partner ID
        $settings_errors = get_settings_errors('bocm_vendasta_partner_id');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the Partner ID on refresh
                $partner_id = '';
                break;
            }
        }
        
        // If the partner ID is set, assume it's valid
        if (!empty($partner_id) && !$has_error) {
            $key_valid = true;
            $key_type = 'Valid ID';
            $key_color = '#28a745'; // Green for valid key
        }
        
        // Output the required CSS styles
        $this->output_api_field_styles();
        ?>
        
        <div class="bocm-api-key-container" id="vendasta-container">
            <input type="text" 
                   name="bocm_vendasta_partner_id" 
                   id="bocm_vendasta_partner_id" 
                   value="<?php echo esc_attr($partner_id); ?>" 
                   class="regular-text bocm-api-key-input"
                   placeholder="Enter Vendasta Partner ID" />
            <span class="bocm-api-key-button" style="background-color: <?php echo esc_attr($key_color); ?>; border-color: <?php echo esc_attr($key_color); ?>;">
                <?php echo esc_html($key_type ?: 'No ID'); ?>
                </span>
        </div>
        
        <p class="description" style="margin-top: 10px;">
            <?php _e('Enter your Vendasta Partner ID. This is required for the Vendasta integration to work properly.', 'blue-oak-client-management'); ?>
        </p>
        
        <!-- JavaScript to handle error notices for Vendasta Partner ID -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Check for error notices on the page that might indicate invalid credentials
                const checkForErrors = function() {
                    const hasErrorNotice = $('.notice-error, .notice-warning').filter(function() {
                        return $(this).text().indexOf('Vendasta Partner ID') !== -1 || 
                               $(this).text().indexOf('Vendasta credentials') !== -1;
                    }).length > 0;
                    
                    if (hasErrorNotice) {
                        // Update the button to show invalid status
                        const keyButton = $('#vendasta-container .bocm-api-key-button');
                        if (keyButton.length > 0) {
                            keyButton.text('Invalid ID');
                            keyButton.css({
                                'background-color': '#dc3545',
                                'border-color': '#dc3545'
                            });
                        }
                        
                        // Clear the input if there are errors
                        $('#bocm_vendasta_partner_id').val('');
                    }
                };
                
                // Run on page load
                checkForErrors();
            });
        </script>
        <?php
    }

    /**
     * Render the PageSpeed API key field
     *
     * @return void
     */
    public function render_pagespeed_api_key_field(): void {
        $api_key = get_option('bocm_pagespeed_api_key', '');
        $key_type = '';
        $key_valid = false;
        $key_color = '#6c757d'; // Default gray
        $has_error = false;
        
        // Check if there are any error notices for PageSpeed
        $settings_errors = get_settings_errors('bocm_pagespeed_api_key');
        foreach ($settings_errors as $error) {
            if ($error['type'] === 'error') {
                $has_error = true;
                // If there's an error, don't display the API key on refresh
                $api_key = '';
                break;
            }
        }
        
        // If we have an API key, check its validity
        if (!empty($api_key) && !$has_error) {
            // For simplicity, we assume it's valid if it's set (actual validation happens on save)
            $key_valid = true;
            $key_type = 'Valid Key';
            $key_color = '#28a745'; // Green for valid key
        }
        
        // Output the required CSS styles
        $this->output_api_field_styles();
        ?>
        
        <div class="bocm-api-key-container" id="pagespeed-container">
            <input type="text" 
                   name="bocm_pagespeed_api_key" 
                   id="bocm_pagespeed_api_key" 
                   value="<?php echo esc_attr($api_key); ?>" 
                   class="regular-text bocm-api-key-input"
                   placeholder="Enter PageSpeed API Key" />
            <span class="bocm-api-key-button" style="background-color: <?php echo esc_attr($key_color); ?>; border-color: <?php echo esc_attr($key_color); ?>;">
                <?php echo esc_html($key_type ?: 'No Key'); ?>
            </span>
        </div>
        
        <p class="description" style="margin-top: 10px;">
            <?php _e('Enter your Google PageSpeed Insights API key to enable website performance scanning. The key will be verified when you save settings.', 'blue-oak-client-management'); ?>
        </p>

        <!-- JavaScript to handle error notices and update the button accordingly -->
        <script type="text/javascript">
            jQuery(document).ready(function($) {
                // Check for error notices on the page that might indicate invalid credentials
                const checkForErrors = function() {
                    const hasErrorNotice = $('.notice-error').filter(function() {
                        return $(this).text().indexOf('PageSpeed API') !== -1 || 
                               $(this).text().indexOf('PageSpeed key') !== -1;
                    }).length > 0;
                    
                    if (hasErrorNotice) {
                        // Update the button to show invalid status
                        const keyButton = $('#pagespeed-container .bocm-api-key-button');
                        if (keyButton.length > 0) {
                            keyButton.text('Invalid Key');
                            keyButton.css({
                                'background-color': '#dc3545',
                                'border-color': '#dc3545'
                            });
                        }
                        
                        // Clear the input if there are errors
                        $('#bocm_pagespeed_api_key').val('');
                    }
                };
                
                // Run on page load
                checkForErrors();
            });
        </script>
        <?php
    }

    /**
     * Render the PageSpeed client table with scan results
     *
     * @return void
     */
    public function render_pagespeed_client_table(): void {
        // Get all clients with website URLs
        $clients = get_users([
            'role' => 'blue_oak_client',
            'fields' => ['ID', 'display_name', 'user_email', 'user_url'],
        ]);
        
        // Filter to only include clients with URLs
        $clients_with_urls = array_filter($clients, function($client) {
            return !empty($client->user_url);
        });
        
        ?>
        <hr>
        <h2><?php echo esc_html__('Client Website Performance', 'blue-oak-client-management'); ?></h2>
        
        <?php if (empty($clients_with_urls)) : ?>
            <p><?php echo esc_html__('No clients with website URLs found.', 'blue-oak-client-management'); ?></p>
        <?php else : ?>
            <p><?php echo esc_html__('The table below shows PageSpeed results for all clients with website URLs. We keep a 7-day rolling history of scan results. You can run manual scans or view the latest results.', 'blue-oak-client-management'); ?></p>
            
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th><?php echo esc_html__('Client', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('Website', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('Last Scan', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('Desktop Score', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('7-Day Trend', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('Page Size', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('FCP', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('LCP', 'blue-oak-client-management'); ?></th>
                        <th><?php echo esc_html__('Actions', 'blue-oak-client-management'); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($clients_with_urls as $client) : 
                        $pagespeed_data = get_user_meta($client->ID, 'bocm_pagespeed_data', true);
                        $history_data = get_user_meta($client->ID, 'bocm_pagespeed_history', true);
                        $timestamp = get_user_meta($client->ID, 'bocm_pagespeed_timestamp', true);
                        $has_data = !empty($pagespeed_data) && is_array($pagespeed_data);
                        
                        // Format timestamp
                        $last_scan = !empty($timestamp) ? 
                            human_time_diff(intval($timestamp), current_time('timestamp')) . ' ' . __('ago', 'blue-oak-client-management') : 
                            __('Never', 'blue-oak-client-management');
                        
                        // Get performance metrics
                        $desktop_score = $has_data ? $pagespeed_data['desktop_score'] : '-';
                        $page_size = $has_data ? $pagespeed_data['page_size'] . ' MB' : '-';
                        $fcp = $has_data ? $pagespeed_data['first_contentful_paint'] . 's' : '-';
                        $lcp = $has_data ? $pagespeed_data['largest_contentful_paint'] . 's' : '-';
                        
                        // Determine score class
                        $score_class = '';
                        if ($has_data) {
                            if ($desktop_score >= 90) {
                                $score_class = 'score-excellent';
                            } elseif ($desktop_score >= 70) {
                                $score_class = 'score-good';
                            } elseif ($desktop_score >= 50) {
                                $score_class = 'score-average';
                            } else {
                                $score_class = 'score-poor';
                            }
                        }
                        
                        // Prepare trend data
                        $trend_html = '-';
                        $trend_diff = '';
                        if (is_array($history_data) && count($history_data) > 1) {
                            $scores = [];
                            $dates = [];
                            
                            // Sort by date
                            ksort($history_data);
                            
                            foreach ($history_data as $date => $data) {
                                if (isset($data['desktop_score'])) {
                                    $scores[] = $data['desktop_score'];
                                    $dates[] = date_i18n('M j', strtotime($date));
                                }
                            }
                            
                            // Only show trend if we have multiple data points
                            if (count($scores) > 1) {
                                $change = end($scores) - reset($scores);
                                $change_class = $change >= 0 ? 'positive-change' : 'negative-change';
                                $change_prefix = $change >= 0 ? '+' : '';
                                $trend_diff = "<span class='{$change_class}'>{$change_prefix}{$change}</span>";
                                
                                $chart_id = 'sparkline-' . $client->ID;
                                $trend_html = "<div id='{$chart_id}' class='bocm-sparkline'></div>";
                                
                                // Add data attributes for the ApexCharts initialization
                                $trend_html .= sprintf(
                                    "<div class='sparkline-data' 
                                          data-target='%s' 
                                          data-series='%s' 
                                          data-labels='%s'
                                          data-change='%s'></div>",
                                    esc_attr($chart_id),
                                    esc_attr(json_encode($scores)),
                                    esc_attr(json_encode($dates)),
                                    esc_attr($change)
                                );
                            }
                        }
                    ?>
                    <tr>
                        <td><?php echo esc_html($client->display_name); ?></td>
                        <td><a href="<?php echo esc_url($client->user_url); ?>" target="_blank"><?php echo esc_url($client->user_url); ?></a></td>
                        <td><?php echo esc_html($last_scan); ?></td>
                        <td class="<?php echo esc_attr($score_class); ?>"><?php echo esc_html($desktop_score); ?></td>
                        <td><?php echo $trend_html; ?> <?php echo $trend_diff; ?></td>
                        <td><?php echo esc_html($page_size); ?></td>
                        <td><?php echo esc_html($fcp); ?></td>
                        <td><?php echo esc_html($lcp); ?></td>
                        <td>
                            <button type="button" class="button run-scan" data-user-id="<?php echo esc_attr((string) $client->ID); ?>" data-url="<?php echo esc_url($client->user_url); ?>">
                                <?php echo esc_html__('Run Scan', 'blue-oak-client-management'); ?>
                            </button>
                            <span class="scan-status"></span>
                            <?php if (is_array($history_data) && !empty($history_data)) : ?>
                            <button type="button" class="button view-history" data-user-id="<?php echo esc_attr((string) $client->ID); ?>">
                                <?php echo esc_html__('History', 'blue-oak-client-management'); ?>
                            </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            
            <p>
                <button type="button" class="button button-primary run-all-scans">
                    <?php echo esc_html__('Run All Scans', 'blue-oak-client-management'); ?>
                </button>
                <span class="all-scans-status"></span>
            </p>
            
            <style>
                .score-excellent {
                    background-color: #d4edda;
                    color: #155724;
                    font-weight: bold;
                }
                .score-good {
                    background-color: #fff3cd;
                    color: #856404;
                    font-weight: bold;
                }
                .score-average {
                    background-color: #fff3cd;
                    color: #856404;
                }
                .score-poor {
                    background-color: #f8d7da;
                    color: #721c24;
                }
                .bocm-sparkline {
                    display: inline-block;
                    min-width: 70px;
                    height: 30px;
                    vertical-align: middle;
                }
                .positive-change {
                    color: #28a745;
                    font-weight: bold;
                    margin-left: 5px;
                }
                .negative-change {
                    color: #dc3545;
                    font-weight: bold;
                    margin-left: 5px;
                }
                .sparkline-data {
                    display: none;
                }
            </style>
            
            <!-- Initialize ApexCharts sparklines -->
            <script>
                jQuery(document).ready(function($) {
                    // Initialize all sparklines using ApexCharts
                    $('.sparkline-data').each(function() {
                        const $data = $(this);
                        const targetId = $data.data('target');
                        const seriesData = $data.data('series');
                        const labelsData = $data.data('labels');
                        const change = $data.data('change');
                        
                        // Create the sparkline
                        const options = {
                            series: [{
                                name: 'Score',
                                data: seriesData
                            }],
                            chart: {
                                type: 'line',
                                height: 30,
                                width: 100,
                                sparkline: {
                                    enabled: true
                                },
                                animations: {
                                    enabled: false
                                }
                            },
                            stroke: {
                                curve: 'straight',
                                width: 2
                            },
                            colors: [change >= 0 ? '#28a745' : '#dc3545'],
                            tooltip: {
                                fixed: {
                                    enabled: false
                                },
                                x: {
                                    show: true,
                                    formatter: function (index) {
                                        return labelsData[index];
                                    }
                                },
                                y: {
                                    title: {
                                        formatter: function() {
                                            return 'Score:';
                                        }
                                    }
                                },
                                marker: {
                                    show: false
                                }
                            }
                        };
                        
                        // Create the chart
                        const chart = new ApexCharts(document.querySelector('#' + targetId), options);
                        chart.render();
                    });
                });
            </script>
            <?php endif; ?>
        
        <hr>
        
        <h2><?php echo esc_html__('Schedule Information', 'blue-oak-client-management'); ?></h2>
        <p>
            <?php 
                $next_run = wp_next_scheduled('bocm_daily_cron');
                if ($next_run) {
                    echo sprintf(
                        esc_html__('Next scheduled scan: %s', 'blue-oak-client-management'),
                        date_i18n(get_option('date_format') . ' ' . get_option('time_format'), $next_run)
                    );
                } else {
                    echo esc_html__('Daily scans are not currently scheduled.', 'blue-oak-client-management');
                }
            ?>
        </p>
        
        <p>
            <button type="button" class="button schedule-now">
                <?php echo esc_html__('Schedule Scans Now', 'blue-oak-client-management'); ?>
            </button>
            <span class="schedule-status"></span>
        </p>
        <?php
    }

    /**
     * Render the Uptime Robot cache duration field
     *
     * @return void
     */
    public function render_uptimerobot_cache_duration_field(): void {
        $cache_duration = get_option('bocm_uptimerobot_cache_duration', 10);
        ?>
        <select name="bocm_uptimerobot_cache_duration" id="bocm_uptimerobot_cache_duration" class="regular-text">
            <option value="5" <?php selected($cache_duration, 5); ?>><?php _e('5 minutes (Most frequent updates, higher API usage)', 'blue-oak-client-management'); ?></option>
            <option value="10" <?php selected($cache_duration, 10); ?>><?php _e('10 minutes (Frequent updates)', 'blue-oak-client-management'); ?></option>
            <option value="15" <?php selected($cache_duration, 15); ?>><?php _e('15 minutes (Balanced)', 'blue-oak-client-management'); ?></option>
            <option value="30" <?php selected($cache_duration, 30); ?>><?php _e('30 minutes (Less frequent updates, lower API usage)', 'blue-oak-client-management'); ?></option>
            <option value="60" <?php selected($cache_duration, 60); ?>><?php _e('60 minutes (Infrequent updates, minimal API usage)', 'blue-oak-client-management'); ?></option>
        </select>
        <p class="description">
            <?php _e('How long to cache Uptime Robot data before refreshing from the API. Shorter durations provide more up-to-date information but increase API usage.', 'blue-oak-client-management'); ?>
        </p>
        <?php
    }
} 