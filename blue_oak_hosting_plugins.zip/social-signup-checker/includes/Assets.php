<?php
declare(strict_types=1);

namespace SocialSignupChecker;

class Assets {
    /**
     * Enqueue plugin assets
     */
    public static function enqueue(): void {
        // Register and enqueue CSS
        wp_register_style(
            'social-signup-checker',
            SSC_PLUGIN_URL . 'assets/css/style.css',
            [],
            SSC_VERSION
        );
        wp_enqueue_style('social-signup-checker');

        // Register and enqueue JavaScript
        wp_register_script(
            'social-signup-checker',
            SSC_PLUGIN_URL . 'assets/js/script.js',
            ['jquery'],
            SSC_VERSION,
            true
        );
        wp_enqueue_script('social-signup-checker');

        // Localize script with AJAX URL and nonce
        wp_localize_script('social-signup-checker', 'sscData', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('ssc_check_username'),
            'pluginUrl' => SSC_PLUGIN_URL
        ]);
    }
} 