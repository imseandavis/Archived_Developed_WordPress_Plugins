<?php
declare(strict_types=1);

namespace SocialSignupChecker;

class Shortcode {
    /**
     * Render the social signup checker shortcode
     *
     * @param array $atts Shortcode attributes
     * @return string Rendered HTML
     */
    public static function render(array $atts = []): string {
        // Enqueue required assets
        wp_enqueue_style('social-signup-checker');
        wp_enqueue_script('social-signup-checker');

        // Start output buffering
        ob_start();
        ?>
        <div class="ssc-container">
            <form id="ssc-form" class="ssc-form" method="post">
                <?php wp_nonce_field('ssc_check_username', 'ssc_nonce'); ?>
                <div class="ssc-form-group">
                    <label for="ssc-username"><?php esc_html_e('Enter your brand name:', 'social-signup-checker'); ?></label>
                    <input type="text" id="ssc-username" name="username" required 
                           placeholder="<?php esc_attr_e('e.g., mybrand', 'social-signup-checker'); ?>">
                    <button type="submit" class="ssc-button">
                        <?php esc_html_e('Check Availability', 'social-signup-checker'); ?>
                    </button>
                </div>
            </form>
            
            <div id="ssc-results" class="ssc-results" style="display: none;">
                <h3><?php esc_html_e('Availability Results', 'social-signup-checker'); ?></h3>
                <div class="ssc-platforms"></div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
} 