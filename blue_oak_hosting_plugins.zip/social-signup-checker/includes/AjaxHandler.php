<?php
declare(strict_types=1);

namespace SocialSignupChecker;

class AjaxHandler {
    /**
     * Initialize the AJAX handler
     */
    public static function init(): void {
        add_action('wp_ajax_ssc_check_username', [self::class, 'checkUsername']);
        add_action('wp_ajax_nopriv_ssc_check_username', [self::class, 'checkUsername']);
    }

    /**
     * Handle the AJAX request to check username availability
     */
    public static function checkUsername(): void {
        // Verify nonce
        if (!isset($_POST['nonce']) || !wp_verify_nonce($_POST['nonce'], 'ssc_check_username')) {
            wp_send_json_error(['message' => 'Invalid nonce']);
        }

        // Get and sanitize username
        $username = sanitize_text_field($_POST['username'] ?? '');
        if (empty($username)) {
            wp_send_json_error(['message' => 'Username is required']);
        }

        // Check availability on different platforms
        $availability = [
            'twitter' => self::checkTwitter($username),
            'facebook' => self::checkFacebook($username),
            'instagram' => self::checkInstagram($username),
            'linkedin' => self::checkLinkedIn($username),
            'github' => self::checkGitHub($username),
            'youtube' => self::checkYouTube($username),
        ];

        wp_send_json_success([
            'username' => $username,
            'availability' => $availability,
        ]);
    }

    /**
     * Check Twitter username availability
     */
    private static function checkTwitter(string $username): array {
        $url = "https://x.com/{$username}";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
                'Cache-Control' => 'max-age=0'
            ]
        ];
        
        error_log("X Check - URL: {$url}");
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            error_log("X Check - Error: " . $response->get_error_message());
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => $response->get_error_message(),
                'debug' => [
                    'url' => $url,
                    'error' => $response->get_error_message()
                ]
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log("X Check - Status Code: {$status_code}");
        error_log("X Check - Response Body Length: " . strlen($body));
        
        // Check for rate limiting or blocked requests
        if (strpos($body, 'rate limit') !== false) {
            error_log("X Check - Rate Limited");
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => 'Rate limited. Please try again later.',
                'debug' => [
                    'url' => $url,
                    'status_code' => $status_code,
                    'rate_limited' => true
                ]
            ];
        }

        // X shows "This account doesn't exist" for non-existent accounts
        $available = strpos($body, "This account doesn't exist") !== false;
        error_log("X Check - Available: " . ($available ? 'true' : 'false'));

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
            'debug' => [
                'url' => $url,
                'status_code' => $status_code,
                'body_length' => strlen($body),
                'found_unavailable_text' => strpos($body, "This account doesn't exist") !== false,
                'response_headers' => wp_remote_retrieve_headers($response)
            ]
        ];
    }

    /**
     * Check Facebook username availability
     */
    private static function checkFacebook(string $username): array {
        $url = "https://www.facebook.com/{$username}";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
                'Cache-Control' => 'max-age=0'
            ]
        ];
        
        error_log("Facebook Check - URL: {$url}");
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            error_log("Facebook Check - Error: " . $response->get_error_message());
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => $response->get_error_message(),
                'debug' => [
                    'url' => $url,
                    'error' => $response->get_error_message()
                ]
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log("Facebook Check - Status Code: {$status_code}");
        error_log("Facebook Check - Response Body Length: " . strlen($body));
        
        // Check for rate limiting or blocked requests
        if (strpos($body, 'rate limit') !== false) {
            error_log("Facebook Check - Rate Limited");
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => 'Rate limited. Please try again later.',
                'debug' => [
                    'url' => $url,
                    'status_code' => $status_code,
                    'rate_limited' => true
                ]
            ];
        }

        // Facebook returns 404 for non-existent pages
        $available = $status_code === 404;
        error_log("Facebook Check - Available: " . ($available ? 'true' : 'false'));

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
            'debug' => [
                'url' => $url,
                'status_code' => $status_code,
                'body_length' => strlen($body),
                'response_headers' => wp_remote_retrieve_headers($response)
            ]
        ];
    }

    /**
     * Check Instagram username availability
     */
    private static function checkInstagram(string $username): array {
        $url = "https://www.instagram.com/{$username}/";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
                'Cache-Control' => 'max-age=0'
            ]
        ];
        
        error_log("Instagram Check - URL: {$url}");
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            error_log("Instagram Check - Error: " . $response->get_error_message());
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => $response->get_error_message(),
                'debug' => [
                    'url' => $url,
                    'error' => $response->get_error_message()
                ]
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        
        error_log("Instagram Check - Status Code: {$status_code}");
        error_log("Instagram Check - Response Body Length: " . strlen($body));
        
        // Check for rate limiting or blocked requests
        if (strpos($body, 'rate limit') !== false) {
            error_log("Instagram Check - Rate Limited");
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => 'Rate limited. Please try again later.',
                'debug' => [
                    'url' => $url,
                    'status_code' => $status_code,
                    'rate_limited' => true
                ]
            ];
        }

        // Instagram returns 404 for non-existent accounts
        $available = $status_code === 404;
        error_log("Instagram Check - Available: " . ($available ? 'true' : 'false'));

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
            'debug' => [
                'url' => $url,
                'status_code' => $status_code,
                'body_length' => strlen($body),
                'response_headers' => wp_remote_retrieve_headers($response)
            ]
        ];
    }

    /**
     * Check LinkedIn username availability
     */
    private static function checkLinkedIn(string $username): array {
        $url = "https://www.linkedin.com/in/{$username}/";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
                'Cache-Control' => 'max-age=0'
            ]
        ];
        
        error_log("LinkedIn Check - URL: {$url}");
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            error_log("LinkedIn Check - Error: " . $response->get_error_message());
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => $response->get_error_message(),
                'debug' => [
                    'url' => $url,
                    'error' => $response->get_error_message()
                ]
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $headers = wp_remote_retrieve_headers($response);
        
        error_log("LinkedIn Check - Status Code: {$status_code}");
        error_log("LinkedIn Check - Response Body Length: " . strlen($body));
        
        // Check for rate limiting or blocked requests
        if (strpos($body, 'rate limit') !== false) {
            error_log("LinkedIn Check - Rate Limited");
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => 'Rate limited. Please try again later.',
                'debug' => [
                    'url' => $url,
                    'status_code' => $status_code,
                    'rate_limited' => true
                ]
            ];
        }

        // LinkedIn returns a JavaScript redirect to authwall for non-existent profiles
        $available = strpos($body, 'window.location.href = "https://" + domain + "/authwall') !== false;
        error_log("LinkedIn Check - Available: " . ($available ? 'true' : 'false'));

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
            'debug' => [
                'url' => $url,
                'status_code' => $status_code,
                'body_length' => strlen($body),
                'headers' => $headers,
                'has_authwall_redirect' => strpos($body, 'window.location.href = "https://" + domain + "/authwall') !== false
            ]
        ];
    }

    /**
     * Check GitHub username availability
     */
    private static function checkGitHub(string $username): array {
        $url = "https://github.com/{$username}";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
            ]
        ];
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        $available = $status_code === 404;

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
        ];
    }

    /**
     * Check YouTube username availability
     */
    private static function checkYouTube(string $username): array {
        $url = "https://www.youtube.com/@{$username}";
        $args = [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
                'Accept' => 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
                'Accept-Language' => 'en-US,en;q=0.5',
                'Connection' => 'keep-alive',
                'Upgrade-Insecure-Requests' => '1',
                'Cache-Control' => 'max-age=0'
            ]
        ];
        
        error_log("YouTube Check - URL: {$url}");
        $response = wp_remote_get($url, $args);
        
        if (is_wp_error($response)) {
            error_log("YouTube Check - Error: " . $response->get_error_message());
            return [
                'available' => false,
                'suggestion' => self::generateSuggestion($username),
                'error' => $response->get_error_message(),
                'debug' => [
                    'url' => $url,
                    'error' => $response->get_error_message()
                ]
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);
        error_log("YouTube Check - Status Code: {$status_code}");

        // YouTube returns 404 for non-existent channels
        $available = $status_code === 404;
        error_log("YouTube Check - Available: " . ($available ? 'true' : 'false'));

        return [
            'available' => $available,
            'suggestion' => $available ? '' : self::generateSuggestion($username),
            'debug' => [
                'url' => $url,
                'status_code' => $status_code
            ]
        ];
    }

    /**
     * Generate a suggestion for an unavailable username
     */
    private static function generateSuggestion(string $username): string {
        $suffixes = ['official', 'app', 'inc', 'hq', 'pro', 'official'];
        $suffix = $suffixes[array_rand($suffixes)];
        $suggestion = $username . $suffix;
        error_log("Generated suggestion: {$suggestion}");
        return $suggestion;
    }
} 