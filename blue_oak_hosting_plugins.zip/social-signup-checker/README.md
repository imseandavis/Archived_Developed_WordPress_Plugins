# Social Signup Checker

A WordPress plugin that allows users to check the availability of their brand name across various social media platforms and provides direct signup links.

## Features

- Check username availability across multiple social media platforms:
  - Twitter
  - Facebook
  - Instagram
  - LinkedIn
  - GitHub
- Provides alternative username suggestions when the desired username is taken
- Direct signup links for available usernames
- Modern, responsive design
- AJAX-powered for instant results

## Installation

1. Download the plugin zip file
2. Go to WordPress admin panel > Plugins > Add New
3. Click "Upload Plugin" and select the downloaded zip file
4. Click "Install Now" and then "Activate"

## Usage

Add the shortcode `[social_signup_checker]` to any page or post where you want the username checker to appear.

Example:
```php
[social_signup_checker]
```

## Requirements

- WordPress 5.0 or higher
- PHP 7.4 or higher
- Modern web browser with JavaScript enabled

## Security

- All user inputs are properly sanitized
- Nonce verification for form submissions
- Secure AJAX endpoints
- No sensitive data is stored

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

## License

This plugin is licensed under the GPL v2 or later.

## Credits

- Icons are from various sources and are used for demonstration purposes only
- Built with WordPress coding standards and best practices 