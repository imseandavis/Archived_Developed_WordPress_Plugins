<?php
/**
 * Plugin Name: Social Signup Checker
 * Plugin URI: https://example.com/social-signup-checker
 * Description: Check social media username availability and provide signup links
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://example.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: social-signup-checker
 */

declare(strict_types=1);

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('SSC_VERSION', '1.0.0');
define('SSC_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('SSC_PLUGIN_URL', plugin_dir_url(__FILE__));

// Autoloader for plugin classes
spl_autoload_register(function ($class) {
    $prefix = 'SocialSignupChecker\\';
    $base_dir = SSC_PLUGIN_DIR . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize the plugin
function ssc_init() {
    // Load text domain for translations
    load_plugin_textdomain('social-signup-checker', false, dirname(plugin_basename(__FILE__)) . '/languages');
    
    // Register shortcode
    add_shortcode('social_signup_checker', ['SocialSignupChecker\Shortcode', 'render']);
    
    // Initialize AJAX handler
    \SocialSignupChecker\AjaxHandler::init();
    
    // Enqueue scripts and styles
    add_action('wp_enqueue_scripts', ['SocialSignupChecker\Assets', 'enqueue']);
}
add_action('plugins_loaded', 'ssc_init'); 