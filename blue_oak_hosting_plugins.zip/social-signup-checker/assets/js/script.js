jQuery(document).ready(function($) {
    const form = $('#ssc-form');
    const results = $('#ssc-results');
    const platforms = $('.ssc-platforms');

    form.on('submit', function(e) {
        e.preventDefault();
        
        const username = $('#ssc-username').val();
        const nonce = $('#ssc_nonce').val();

        // Show loading state
        results.show();
        platforms.html('<div class="ssc-loading">Checking availability...</div>');

        // Make AJAX request
        $.ajax({
            url: sscData.ajaxUrl,
            type: 'POST',
            data: {
                action: 'ssc_check_username',
                username: username,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    displayResults(response.data);
                } else {
                    platforms.html(`<div class="ssc-error">${response.data.message}</div>`);
                }
            },
            error: function() {
                platforms.html('<div class="ssc-error">An error occurred. Please try again.</div>');
            }
        });
    });

    function displayResults(data) {
        let html = '';
        
        // Define social media platforms
        const platformData = {
            twitter: {
                name: 'X',
                icon: 'https://cdn-icons-png.flaticon.com/512/5969/5969020.png',
                signupUrl: 'https://x.com/signup',
                checkUrl: `https://x.com/${data.username}`
            },
            facebook: {
                name: 'Facebook',
                icon: 'https://cdn-icons-png.flaticon.com/512/124/124010.png',
                signupUrl: 'https://www.facebook.com/signup',
                checkUrl: `https://www.facebook.com/${data.username}`
            },
            instagram: {
                name: 'Instagram',
                icon: 'https://cdn-icons-png.flaticon.com/512/174/174855.png',
                signupUrl: 'https://www.instagram.com/accounts/emailsignup/',
                checkUrl: `https://www.instagram.com/${data.username}`
            },
            linkedin: {
                name: 'LinkedIn',
                icon: 'https://cdn-icons-png.flaticon.com/512/174/174857.png',
                signupUrl: 'https://www.linkedin.com/signup',
                checkUrl: `https://www.linkedin.com/in/${data.username}`
            },
            github: {
                name: 'GitHub',
                icon: 'https://cdn-icons-png.flaticon.com/512/25/25231.png',
                signupUrl: 'https://github.com/signup',
                checkUrl: `https://github.com/${data.username}`
            },
            youtube: {
                name: 'YouTube',
                icon: 'https://cdn-icons-png.flaticon.com/512/1384/1384060.png',
                signupUrl: 'https://accounts.google.com/signup/v2/createaccount?service=youtube',
                checkUrl: `https://www.youtube.com/@${data.username}`
            }
        };

        // Generate HTML for each platform
        Object.entries(platformData).forEach(([key, platform]) => {
            const availability = data.availability[key];
            const statusClass = availability.available ? 'available' : 'unavailable';
            const hasError = availability.error ? 'error' : '';
            
            html += `
                <div class="ssc-platform ${statusClass} ${hasError}">
                    <img src="${platform.icon}" 
                         alt="${platform.name}" 
                         class="ssc-platform-icon">
                    <div class="ssc-platform-info">
                        <div class="ssc-platform-name">${platform.name}</div>
                        <div class="ssc-platform-status ${statusClass}">
                            ${availability.available ? 'Available' : 'Taken'}
                        </div>
                        ${availability.error ? `
                            <div class="ssc-error-message">
                                ${availability.error}
                            </div>
                        ` : availability.available ? `
                            <a href="${platform.signupUrl}" 
                               target="_blank" 
                               class="ssc-signup-button">
                                Sign Up
                            </a>
                        ` : `
                            <div class="ssc-suggestion">
                                Suggested: ${availability.suggestion}
                            </div>
                        `}
                        ${availability.debug ? `
                            <div class="ssc-debug-info">
                                <details>
                                    <summary>Debug Info</summary>
                                    <pre>${JSON.stringify(availability.debug, null, 2)}</pre>
                                </details>
                            </div>
                        ` : ''}
                    </div>
                </div>
            `;
        });

        platforms.html(html);
    }
}); 