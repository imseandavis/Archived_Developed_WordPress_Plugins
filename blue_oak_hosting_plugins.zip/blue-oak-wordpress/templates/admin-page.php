<?php
/**
 * Admin page template for Blue Oak Hosting Panel
 *
 * @package BlueOakHostingPanel
 */

if (!defined('ABSPATH')) {
    exit;
}
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <div class="bohp-admin-container">
        <div class="bohp-admin-grid">
            <!-- Server Status Card -->
            <div class="bohp-card">
                <h2><?php esc_html_e('Server Status', 'blue-oak-hosting-panel'); ?></h2>
                <div class="bohp-card-content">
                    <p><?php esc_html_e('Loading server status...', 'blue-oak-hosting-panel'); ?></p>
                </div>
            </div>

            <!-- Resource Usage Card -->
            <div class="bohp-card">
                <h2><?php esc_html_e('Resource Usage', 'blue-oak-hosting-panel'); ?></h2>
                <div class="bohp-card-content">
                    <p><?php esc_html_e('Loading resource usage...', 'blue-oak-hosting-panel'); ?></p>
                </div>
            </div>

            <!-- Backup Status Card -->
            <div class="bohp-card">
                <h2><?php esc_html_e('Backup Status', 'blue-oak-hosting-panel'); ?></h2>
                <div class="bohp-card-content">
                    <p><?php esc_html_e('Loading backup status...', 'blue-oak-hosting-panel'); ?></p>
                </div>
            </div>

            <!-- Security Status Card -->
            <div class="bohp-card">
                <h2><?php esc_html_e('Security Status', 'blue-oak-hosting-panel'); ?></h2>
                <div class="bohp-card-content">
                    <p><?php esc_html_e('Loading security status...', 'blue-oak-hosting-panel'); ?></p>
                </div>
            </div>
        </div>
    </div>
</div> 