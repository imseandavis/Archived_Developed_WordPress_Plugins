# Blue Oak Hosting Panel

A comprehensive hosting management panel for WordPress sites.

## Description

Blue Oak Hosting Panel is a powerful WordPress plugin designed to provide hosting management capabilities directly from your WordPress dashboard.

## Features

- Hosting management interface
- Server status monitoring
- Resource usage tracking
- Backup management
- Security monitoring

## Requirements

- WordPress 5.8 or higher
- PHP 7.4 or higher

## Installation

1. Upload the `blue-oak-hosting-panel` folder to the `/wp-content/plugins/` directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Go to the Blue Oak Hosting Panel settings page to configure the plugin

## Development

### Directory Structure

```
blue-oak-hosting-panel/
├── assets/           # CSS, JS, and image files
├── includes/         # Core plugin classes
├── languages/        # Translation files
├── templates/        # Template files
├── blue-oak-hosting-panel.php  # Main plugin file
└── README.md
```

### Building Assets

```bash
# Install dependencies
npm install

# Build assets
npm run build
```

## License

This plugin is licensed under the GPL v2 or later.

## Support

For support, please visit [https://blueoakhosting.com](https://blueoakhosting.com) 