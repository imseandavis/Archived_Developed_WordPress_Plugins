<?php
declare(strict_types=1);

namespace BlueOakHostingPanel;

/**
 * Admin class to handle the plugin's admin interface
 */
class Admin {
    /**
     * Initialize the admin interface
     */
    public function __construct() {
        add_action('admin_menu', [$this, 'add_admin_menu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueue_admin_assets']);
        add_action('admin_head', [$this, 'add_menu_icon_css']);
    }

    /**
     * Add the admin menu items
     */
    public function add_admin_menu(): void {
        add_menu_page(
            __('Blue Oak Hosting Panel', 'blue-oak-hosting-panel'),
            __('Blue Oak', 'blue-oak-hosting-panel'),
            'manage_options',
            'blue-oak-hosting-panel',
            [$this, 'render_admin_page'],
            'dashicons-admin-generic',
            1
        );
    }

    /**
     * Add custom CSS for the menu icon
     */
    public function add_menu_icon_css(): void {
        ?>
        <style>
            #adminmenu .toplevel_page_blue-oak-hosting-panel .wp-menu-image::before {
                font-family: "Font Awesome 6 Brands";
                content: "\f18c"; /* fa-pagelines unicode */
                font-size: 18px;
                line-height: 1.3;
            }
        </style>
        <?php
    }

    /**
     * Enqueue admin assets
     *
     * @param string $hook The current admin page.
     */
    public function enqueue_admin_assets(string $hook): void {
        if ('toplevel_page_blue-oak-hosting-panel' !== $hook) {
            return;
        }

        // Enqueue Font Awesome
        wp_enqueue_style(
            'font-awesome',
            'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css',
            [],
            '6.5.1'
        );

        wp_enqueue_style(
            'blue-oak-hosting-panel-admin',
            BOHP_PLUGIN_URL . 'assets/css/admin.css',
            [],
            BOHP_VERSION
        );

        wp_enqueue_script(
            'blue-oak-hosting-panel-admin',
            BOHP_PLUGIN_URL . 'assets/js/admin.js',
            ['jquery'],
            BOHP_VERSION,
            true
        );
    }

    /**
     * Render the admin page
     */
    public function render_admin_page(): void {
        if (!current_user_can('manage_options')) {
            wp_die(__('You do not have sufficient permissions to access this page.', 'blue-oak-hosting-panel'));
        }

        include BOHP_PLUGIN_DIR . 'templates/admin-page.php';
    }
} 