<?php
/**
 * Plugin Name: Blue Oak Hosting Panel
 * Plugin URI: https://blueoakhosting.com
 * Description: A comprehensive hosting management panel for WordPress sites.
 * Version: 1.0.0
 * Author: Blue Oak Hosting
 * Author URI: https://blueoakhosting.com
 * Text Domain: blue-oak-hosting-panel
 * Domain Path: /languages
 * Requires at least: 5.8
 * Requires PHP: 7.4
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 *
 * @package BlueOakHostingPanel
 */

declare(strict_types=1);

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('BOHP_VERSION', '1.0.0');
define('BOHP_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('BOHP_PLUGIN_URL', plugin_dir_url(__FILE__));
define('BOHP_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Autoloader for plugin classes
spl_autoload_register(function ($class) {
    $prefix = 'BlueOakHostingPanel\\';
    $base_dir = BOHP_PLUGIN_DIR . 'includes/';

    $len = strlen($prefix);
    if (strncmp($prefix, $class, $len) !== 0) {
        return;
    }

    $relative_class = substr($class, $len);
    $file = $base_dir . str_replace('\\', '/', $relative_class) . '.php';

    if (file_exists($file)) {
        require $file;
    }
});

// Initialize the plugin
function bohp_init() {
    // Load text domain for internationalization
    load_plugin_textdomain(
        'blue-oak-hosting-panel',
        false,
        dirname(BOHP_PLUGIN_BASENAME) . '/languages/'
    );

    // Initialize the admin interface
    if (is_admin()) {
        new \BlueOakHostingPanel\Admin();
    }
}
add_action('plugins_loaded', 'bohp_init');

// Activation hook
register_activation_hook(__FILE__, function() {
    // Activation tasks will go here
    flush_rewrite_rules();
});

// Deactivation hook
register_deactivation_hook(__FILE__, function() {
    // Cleanup tasks will go here
    flush_rewrite_rules();
}); 