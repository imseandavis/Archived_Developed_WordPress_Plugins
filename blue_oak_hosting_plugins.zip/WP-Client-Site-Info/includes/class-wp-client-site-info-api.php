<?php

require_once ABSPATH . 'wp-admin/includes/plugin.php';

class WP_Client_Site_Info_API {
    public function check_permission() {
        // Only allow administrators to access the API
        return current_user_can('manage_options');
    }

    public function get_system_info($request) {
        global $wpdb;

        $info = array(
            'wordpress' => $this->get_wordpress_info(),
            'php' => $this->get_php_info(),
            'database' => $this->get_database_info(),
            'server' => $this->get_server_info(),
            'plugins' => $this->get_plugins_info(),
            'themes' => $this->get_themes_info(),
        );

        return rest_ensure_response($info);
    }

    private function get_wordpress_info() {
        global $wp_version;

        return array(
            'version' => $wp_version,
            'multisite' => is_multisite(),
            'memory_limit' => WP_MEMORY_LIMIT,
            'debug_mode' => WP_DEBUG,
            'language' => get_locale(),
            'timezone' => wp_timezone_string(),
            'site_url' => get_site_url(),
            'home_url' => get_home_url(),
        );
    }

    private function get_php_info() {
        return array(
            'version' => PHP_VERSION,
            'memory_limit' => ini_get('memory_limit'),
            'max_execution_time' => ini_get('max_execution_time'),
            'post_max_size' => ini_get('post_max_size'),
            'upload_max_filesize' => ini_get('upload_max_filesize'),
            'max_input_vars' => ini_get('max_input_vars'),
            'display_errors' => ini_get('display_errors'),
            'extensions' => get_loaded_extensions(),
        );
    }

    private function get_database_info() {
        global $wpdb;

        return array(
            'version' => $wpdb->get_var("SELECT VERSION()"),
            'charset' => $wpdb->charset,
            'collate' => $wpdb->collate,
            'table_prefix' => $wpdb->prefix,
            'tables' => $wpdb->get_results("SHOW TABLES LIKE '{$wpdb->prefix}%'", ARRAY_N),
        );
    }

    private function get_server_info() {
        return array(
            'software' => $_SERVER['SERVER_SOFTWARE'],
            'os' => PHP_OS,
            'server_name' => $_SERVER['SERVER_NAME'],
            'server_protocol' => $_SERVER['SERVER_PROTOCOL'],
            'server_port' => $_SERVER['SERVER_PORT'],
            'document_root' => $_SERVER['DOCUMENT_ROOT'],
            'http_host' => $_SERVER['HTTP_HOST'],
            'http_user_agent' => $_SERVER['HTTP_USER_AGENT'],
        );
    }

    private function get_plugins_info() {
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        $plugin_info = array();

        foreach ($plugins as $plugin_path => $plugin_data) {
            $plugin_info[$plugin_path] = array(
                'name' => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'description' => $plugin_data['Description'],
                'author' => $plugin_data['Author'],
                'is_active' => in_array($plugin_path, $active_plugins),
            );
        }

        return $plugin_info;
    }

    private function get_themes_info() {
        $themes = wp_get_themes();
        $theme_info = array();
        $current_theme = wp_get_theme();

        foreach ($themes as $theme_slug => $theme) {
            $theme_info[$theme_slug] = array(
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'description' => $theme->get('Description'),
                'author' => $theme->get('Author'),
                'is_active' => ($theme_slug === $current_theme->get_stylesheet()),
            );
        }

        return $theme_info;
    }
} 