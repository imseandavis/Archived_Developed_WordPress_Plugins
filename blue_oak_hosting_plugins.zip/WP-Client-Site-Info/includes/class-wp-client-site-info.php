<?php

class WP_Client_Site_Info {
    protected $loader;
    protected $plugin_name;
    protected $version;

    public function __construct() {
        $this->version = WP_CLIENT_SITE_INFO_VERSION;
        $this->plugin_name = 'wp-client-site-info';
        
        $this->load_dependencies();
        $this->define_admin_hooks();
        $this->define_public_hooks();
    }

    private function load_dependencies() {
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-wp-client-site-info-loader.php';
        require_once plugin_dir_path(dirname(__FILE__)) . 'includes/class-wp-client-site-info-api.php';
        
        $this->loader = new WP_Client_Site_Info_Loader();
    }

    private function define_admin_hooks() {
        // Add admin menu
        add_action('admin_menu', array($this, 'add_plugin_admin_menu'));
    }

    private function define_public_hooks() {
        // Register REST API endpoints
        add_action('rest_api_init', array($this, 'register_rest_routes'));
    }

    public function run() {
        $this->loader->run();
    }

    public function add_plugin_admin_menu() {
        add_menu_page(
            'Site Information',
            'Site Information',
            'manage_options',
            $this->plugin_name,
            array($this, 'display_plugin_admin_page'),
            'dashicons-info',
            100
        );
    }

    public function display_plugin_admin_page() {
        include_once plugin_dir_path(dirname(__FILE__)) . 'admin/partials/wp-client-site-info-admin-display.php';
    }

    public function register_rest_routes() {
        $api = new WP_Client_Site_Info_API();
        
        register_rest_route('wp-client-site-info/v1', '/system-info', array(
            'methods' => 'GET',
            'callback' => array($api, 'get_system_info'),
            'permission_callback' => array($api, 'check_permission'),
        ));
    }
} 