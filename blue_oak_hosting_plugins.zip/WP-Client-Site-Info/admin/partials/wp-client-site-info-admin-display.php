<?php
// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

$api = new WP_Client_Site_Info_API();
$system_info = $api->get_system_info(null)->get_data();
?>

<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>
    
    <div class="card">
        <h2>WordPress Information</h2>
        <table class="widefat">
            <tbody>
                <?php foreach ($system_info['wordpress'] as $key => $value): ?>
                    <tr>
                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></strong></td>
                        <td><?php echo esc_html(is_bool($value) ? ($value ? 'Yes' : 'No') : $value); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>PHP Information</h2>
        <table class="widefat">
            <tbody>
                <?php foreach ($system_info['php'] as $key => $value): ?>
                    <tr>
                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></strong></td>
                        <td>
                            <?php 
                            if (is_array($value)) {
                                echo esc_html(implode(', ', $value));
                            } else {
                                echo esc_html($value);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>Database Information</h2>
        <table class="widefat">
            <tbody>
                <?php foreach ($system_info['database'] as $key => $value): ?>
                    <tr>
                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></strong></td>
                        <td>
                            <?php 
                            if (is_array($value)) {
                                echo esc_html(implode(', ', array_column($value, 0)));
                            } else {
                                echo esc_html($value);
                            }
                            ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>Server Information</h2>
        <table class="widefat">
            <tbody>
                <?php foreach ($system_info['server'] as $key => $value): ?>
                    <tr>
                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $key))); ?></strong></td>
                        <td><?php echo esc_html($value); ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>Active Plugins</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Plugin Name</th>
                    <th>Version</th>
                    <th>Description</th>
                    <th>Author</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($system_info['plugins'] as $plugin): ?>
                    <?php if ($plugin['is_active']): ?>
                        <tr>
                            <td><?php echo esc_html($plugin['name']); ?></td>
                            <td><?php echo esc_html($plugin['version']); ?></td>
                            <td><?php echo esc_html($plugin['description']); ?></td>
                            <td><?php echo esc_html($plugin['author']); ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>Theme Information</h2>
        <table class="widefat">
            <thead>
                <tr>
                    <th>Theme Name</th>
                    <th>Version</th>
                    <th>Description</th>
                    <th>Author</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($system_info['themes'] as $theme): ?>
                    <tr>
                        <td><?php echo esc_html($theme['name']); ?></td>
                        <td><?php echo esc_html($theme['version']); ?></td>
                        <td><?php echo esc_html($theme['description']); ?></td>
                        <td><?php echo esc_html($theme['author']); ?></td>
                        <td><?php echo $theme['is_active'] ? '<span class="dashicons dashicons-yes" style="color: green;"></span> Active' : 'Inactive'; ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <div class="card">
        <h2>API Endpoint</h2>
        <p>The system information is also available via the REST API at:</p>
        <code><?php echo esc_url(rest_url('wp-client-site-info/v1/system-info')); ?></code>
        <p><strong>Note:</strong> API access is restricted to administrators only.</p>
    </div>
</div>

<style>
.card {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 4px;
    margin-top: 20px;
    padding: 20px;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
}

.card h2 {
    margin-top: 0;
    padding-bottom: 12px;
    border-bottom: 1px solid #eee;
}

.widefat {
    border-spacing: 0;
    width: 100%;
    clear: both;
    margin: 0;
}

.widefat td {
    padding: 8px 10px;
    vertical-align: middle;
    line-height: 1.4em;
}

.widefat thead th {
    padding: 8px 10px;
    line-height: 1.4em;
    font-weight: 600;
    text-align: left;
    border-bottom: 1px solid #e1e1e1;
}
</style> 