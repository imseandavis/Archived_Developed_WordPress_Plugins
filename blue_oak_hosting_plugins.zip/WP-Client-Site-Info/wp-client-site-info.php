<?php
/**
 * Plugin Name: WP Client Site Info
 * Plugin URI: https://github.com/yourusername/wp-client-site-info
 * Description: Gathers WordPress, PHP, database, and web server information and makes it available via API.
 * Version: 1.0.0
 * Author: Your Name
 * Author URI: https://yourwebsite.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wp-client-site-info
 * Domain Path: /languages
 */

// If this file is called directly, abort.
if (!defined('WPINC')) {
    die;
}

// Define plugin constants
define('WP_CLIENT_SITE_INFO_VERSION', '1.0.0');
define('WP_CLIENT_SITE_INFO_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('WP_CLIENT_SITE_INFO_PLUGIN_URL', plugin_dir_url(__FILE__));

// Include required files
require_once WP_CLIENT_SITE_INFO_PLUGIN_DIR . 'includes/class-wp-client-site-info.php';

// Initialize the plugin
function run_wp_client_site_info() {
    $plugin = new WP_Client_Site_Info();
    $plugin->run();
}
run_wp_client_site_info(); 