<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Main plugin class. Singleton.
 */
class Plugin {

    /** @var Plugin|null */
    private static $instance = null;

    /** @var LanguageManager|null */
    private $language_manager = null;

    /** @var TranslationManager|null */
    private $translation_manager = null;

    /** @var StringTranslation|null */
    private $string_translation = null;

    /** @var LanguageSwitcher|null */
    private $language_switcher = null;

    /** @var Admin\AdminController|null */
    private $admin_controller = null;

    /** @var FrontEnd\FrontController|null */
    private $front_controller = null;

    /** @var api\ProviderManager|null */
    private $provider_manager = null;

    /** @var cache\CacheManager|null */
    private $cache_manager = null;

    /** @var ConflictDetector|null */
    private $conflict_detector = null;

    /** @var URLManager|null */
    private $url_manager = null;

    /**
     * Get singleton instance.
     */
    public static function get_instance(): self {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    private function __construct() {}

    /**
     * Run the plugin.
     */
    public function run(): void {
        // Check for conflicts first.
        $this->conflict_detector = new ConflictDetector();
        if ( $this->conflict_detector->has_conflicts() ) {
            $this->conflict_detector->register_admin_notice();
            return; // Do not load any functionality.
        }

        $this->load_textdomain();
        $this->init_components();
        $this->register_hooks();
    }

    /**
     * Load plugin textdomain.
     */
    private function load_textdomain(): void {
        load_plugin_textdomain( 'wptranslate', false, dirname( WPTRANSLATE_PLUGIN_BASENAME ) . '/languages/' );
    }

    /**
     * Initialize all plugin components.
     */
    private function init_components(): void {
        $this->cache_manager      = new cache\CacheManager();
        $this->language_manager   = new LanguageManager( $this->cache_manager );
        $this->provider_manager   = new api\ProviderManager();
        $this->translation_manager = new TranslationManager(
            $this->language_manager,
            $this->provider_manager,
            $this->cache_manager
        );
        $this->string_translation = new StringTranslation( $this->language_manager, $this->cache_manager );
        $this->url_manager        = new URLManager( $this->language_manager );
        $this->language_switcher  = new LanguageSwitcher( $this->language_manager, $this->url_manager );

        if ( is_admin() ) {
            $this->admin_controller = new Admin\AdminController( $this );
        }

        $this->front_controller = new FrontEnd\FrontController( $this );
    }

    /**
     * Register plugin-wide hooks.
     */
    private function register_hooks(): void {
        add_action( 'init', array( $this->url_manager, 'register_rewrite_rules' ) );
        add_action( 'init', array( $this, 'register_roles_and_capabilities' ) );
        add_filter( 'query_vars', array( $this->url_manager, 'add_query_vars' ) );
        add_action( 'template_redirect', array( $this->url_manager, 'detect_language' ) );
        add_filter( 'pre_get_posts', array( $this->translation_manager, 'filter_posts_by_language' ) );
        add_filter( 'the_content', array( $this->front_controller, 'filter_content' ) );
        add_filter( 'the_title', array( $this->front_controller, 'filter_title' ), 10, 2 );
        add_action( 'wp_head', array( $this->front_controller, 'output_hreflang_tags' ) );

        // String translation hooks.
        add_filter( 'gettext', array( $this->string_translation, 'filter_gettext' ), 10, 3 );
        add_filter( 'gettext_with_context', array( $this->string_translation, 'filter_gettext_with_context' ), 10, 4 );
        add_filter( 'ngettext', array( $this->string_translation, 'filter_ngettext' ), 10, 5 );

        // REST API.
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );

        // Auto-translate on publish.
        add_action( 'transition_post_status', array( $this, 'maybe_auto_translate_on_publish' ), 10, 3 );

        // Cron events.
        add_action( 'wptranslate_process_queue', array( $this->translation_manager, 'process_queue' ) );
        add_action( 'wptranslate_analyze_corrections', array( $this->translation_manager, 'analyze_corrections' ) );
    }

    /**
     * Register custom roles and capabilities.
     */
    public function register_roles_and_capabilities(): void {
        $roles_version = get_option( 'wptranslate_roles_version', '0' );

        // Always ensure admin has all capabilities (cheap in-memory check).
        $admin = get_role( 'administrator' );
        if ( $admin ) {
            $caps = array(
                'wptranslate_manage_languages',
                'wptranslate_translate_posts',
                'wptranslate_edit_translations',
                'wptranslate_submit_translations',
                'wptranslate_assign_translations',
                'wptranslate_review_translations',
                'wptranslate_publish_translations',
                'wptranslate_manage_translators',
                'wptranslate_manage_settings',
                'wptranslate_manage_glossary',
            );
            foreach ( $caps as $cap ) {
                if ( ! $admin->has_cap( $cap ) ) {
                    $admin->add_cap( $cap );
                }
            }
        }

        // Only create/update custom roles on version change.
        if ( $roles_version === WPTRANSLATE_VERSION ) {
            return;
        }

        // Translator role.
        remove_role( 'wptranslate_translator' );
        add_role(
            'wptranslate_translator',
            __( 'Translator', 'wptranslate' ),
            array(
                'read'                         => true,
                'edit_posts'                   => true,
                'upload_files'                 => true,
                'wptranslate_translate_posts'   => true,
                'wptranslate_edit_translations' => true,
                'wptranslate_submit_translations' => true,
            )
        );

        // Translation Manager role.
        remove_role( 'wptranslate_translation_manager' );
        add_role(
            'wptranslate_translation_manager',
            __( 'Translation Manager', 'wptranslate' ),
            array(
                'read'                              => true,
                'edit_posts'                        => true,
                'edit_others_posts'                 => true,
                'publish_posts'                     => true,
                'upload_files'                      => true,
                'wptranslate_translate_posts'        => true,
                'wptranslate_edit_translations'      => true,
                'wptranslate_submit_translations'    => true,
                'wptranslate_assign_translations'    => true,
                'wptranslate_review_translations'    => true,
                'wptranslate_publish_translations'   => true,
                'wptranslate_manage_translators'     => true,
                'wptranslate_manage_glossary'        => true,
            )
        );

        update_option( 'wptranslate_roles_version', WPTRANSLATE_VERSION );
    }

    /**
     * Register REST API routes.
     */
    /**
     * Auto-translate a post to all languages when it's first published.
     *
     * @param string   $new_status New post status.
     * @param string   $old_status Old post status.
     * @param \WP_Post $post       Post object.
     */
    public function maybe_auto_translate_on_publish( string $new_status, string $old_status, \WP_Post $post ): void {
        // Only trigger when transitioning TO 'publish' from a non-publish state.
        if ( 'publish' !== $new_status || 'publish' === $old_status ) {
            return;
        }

        // Check if auto-translate is enabled.
        if ( ! get_option( 'wptranslate_auto_translate_on_publish', false ) ) {
            return;
        }

        // Check if this post type is enabled for translation.
        $enabled_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );
        if ( ! in_array( $post->post_type, $enabled_types, true ) ) {
            return;
        }

        // Don't auto-translate translation posts (only originals in default language).
        $post_language = $this->translation_manager->get_post_language( $post->ID );
        $default_lang  = $this->language_manager->get_default_language();
        if ( $post_language && $post_language !== $default_lang ) {
            return;
        }

        // Don't re-translate if translations already exist.
        $existing = $this->translation_manager->get_all_translations( $post->ID );
        $active_languages = $this->language_manager->get_active_languages();

        foreach ( $active_languages as $lang ) {
            if ( $lang['code'] === $default_lang ) {
                continue;
            }

            // Skip if translation already exists.
            if ( isset( $existing[ $lang['code'] ] ) ) {
                continue;
            }

            // Queue translation job instead of translating synchronously (avoids timeout on publish).
            $this->translation_manager->queue_translation_job( array(
                'element_id'   => $post->ID,
                'element_type' => 'post',
                'source_lang'  => $default_lang,
                'target_lang'  => $lang['code'],
                'priority'     => 5,
            ) );
        }

        // Trigger the queue processor.
        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time(), 'wptranslate_process_queue' );
        }
    }

    public function register_rest_routes(): void {
        $rest_controller = new api\RestController( $this );
        $rest_controller->register_routes();
    }

    // Getters for components.

    public function get_language_manager(): LanguageManager {
        return $this->language_manager;
    }

    public function get_translation_manager(): TranslationManager {
        return $this->translation_manager;
    }

    public function get_string_translation(): StringTranslation {
        return $this->string_translation;
    }

    public function get_language_switcher(): LanguageSwitcher {
        return $this->language_switcher;
    }

    public function get_provider_manager(): api\ProviderManager {
        return $this->provider_manager;
    }

    public function get_cache_manager(): cache\CacheManager {
        return $this->cache_manager;
    }

    public function get_url_manager(): URLManager {
        return $this->url_manager;
    }

    public function get_conflict_detector(): ConflictDetector {
        return $this->conflict_detector;
    }
}
