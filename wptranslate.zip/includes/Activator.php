<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin activation handler.
 */
class Activator {

    /**
     * Run on plugin activation.
     */
    public static function activate(): void {
        // Check for conflicting plugins.
        $conflicts = ConflictDetector::check_on_activation();
        if ( ! empty( $conflicts ) ) {
            $names = implode( ', ', $conflicts );
            wp_die(
                sprintf(
                    /* translators: %s: plugin names */
                    esc_html__( 'WPTranslate cannot be activated while the following translation plugin(s) are active: %s. Please deactivate them first. You can migrate your existing translations after activating WPTranslate using the import tool under WPTranslate → Tools.', 'wptranslate' ),
                    esc_html( $names )
                ),
                esc_html__( 'Plugin Activation Error', 'wptranslate' ),
                array( 'back_link' => true )
            );
        }

        // Check PHP version.
        if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
            wp_die(
                esc_html__( 'WPTranslate requires PHP 7.4 or higher.', 'wptranslate' ),
                esc_html__( 'Plugin Activation Error', 'wptranslate' ),
                array( 'back_link' => true )
            );
        }

        // Create database tables.
        self::create_tables();

        // Set default options.
        self::set_default_options();

        // Add the site's default language automatically.
        self::add_default_language();

        // Schedule cron events.
        self::schedule_cron_events();

        // Flush rewrite rules.
        flush_rewrite_rules();

        // Flag that we need to register roles on next load.
        delete_option( 'wptranslate_roles_version' );
    }

    /**
     * Create all custom database tables.
     */
    private static function create_tables(): void {
        global $wpdb;

        $charset_collate = $wpdb->get_charset_collate();

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        // Languages table.
        $table_name = $wpdb->prefix . 'wpt_languages';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            code varchar(10) NOT NULL,
            name varchar(100) NOT NULL,
            native_name varchar(100) NOT NULL DEFAULT '',
            locale varchar(20) NOT NULL DEFAULT '',
            flag varchar(10) NOT NULL DEFAULT '',
            is_default tinyint(1) NOT NULL DEFAULT 0,
            is_active tinyint(1) NOT NULL DEFAULT 1,
            sort_order int(11) NOT NULL DEFAULT 0,
            rtl tinyint(1) NOT NULL DEFAULT 0,
            date_format varchar(20) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY code (code),
            KEY is_active (is_active),
            KEY sort_order (sort_order)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translations table.
        $table_name = $wpdb->prefix . 'wpt_translations';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            element_id bigint(20) unsigned NOT NULL,
            element_type varchar(60) NOT NULL DEFAULT 'post',
            language_code varchar(10) NOT NULL,
            source_language_code varchar(10) NOT NULL DEFAULT '',
            trid bigint(20) unsigned NOT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY element_lang (element_id, element_type, language_code),
            KEY trid (trid),
            KEY language_code (language_code),
            KEY element_type (element_type),
            KEY element_id (element_id)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translation status table.
        $table_name = $wpdb->prefix . 'wpt_translation_status';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            translation_id bigint(20) unsigned NOT NULL,
            status varchar(30) NOT NULL DEFAULT 'ai_draft',
            translator bigint(20) unsigned NOT NULL DEFAULT 0,
            assigned_to bigint(20) unsigned NOT NULL DEFAULT 0,
            assigned_at datetime DEFAULT NULL,
            reviewed_by bigint(20) unsigned NOT NULL DEFAULT 0,
            reviewed_at datetime DEFAULT NULL,
            revision_feedback text DEFAULT NULL,
            date_modified datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            md5_hash varchar(32) NOT NULL DEFAULT '',
            PRIMARY KEY  (id),
            UNIQUE KEY translation_id (translation_id),
            KEY status (status),
            KEY assigned_to (assigned_to),
            KEY reviewed_by (reviewed_by)
        ) {$charset_collate};";
        dbDelta( $sql );

        // String translations table.
        $table_name = $wpdb->prefix . 'wpt_string_translations';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            string_name varchar(255) NOT NULL,
            string_value text NOT NULL,
            language_code varchar(10) NOT NULL,
            context varchar(160) NOT NULL DEFAULT '',
            domain varchar(100) NOT NULL DEFAULT 'default',
            status varchar(20) NOT NULL DEFAULT 'translated',
            date_modified datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            UNIQUE KEY string_lang (string_name(191), language_code, domain(50), context(50)),
            KEY language_code (language_code),
            KEY domain (domain),
            KEY status (status)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translation jobs table.
        $table_name = $wpdb->prefix . 'wpt_translation_jobs';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            batch_id varchar(36) NOT NULL DEFAULT '',
            element_id bigint(20) unsigned NOT NULL DEFAULT 0,
            element_type varchar(60) NOT NULL DEFAULT 'post',
            source_lang varchar(10) NOT NULL,
            target_lang varchar(10) NOT NULL,
            provider varchar(30) NOT NULL DEFAULT '',
            status varchar(20) NOT NULL DEFAULT 'pending',
            priority int(11) NOT NULL DEFAULT 10,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            started_at datetime DEFAULT NULL,
            completed_at datetime DEFAULT NULL,
            error_message text DEFAULT NULL,
            PRIMARY KEY  (id),
            KEY batch_id (batch_id),
            KEY status (status),
            KEY priority_status (priority, status),
            KEY target_lang (target_lang)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translation cache table.
        $table_name = $wpdb->prefix . 'wpt_translation_cache';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            source_hash varchar(64) NOT NULL,
            source_lang varchar(10) NOT NULL,
            target_lang varchar(10) NOT NULL,
            provider varchar(30) NOT NULL DEFAULT '',
            source_text text NOT NULL,
            translated_text text NOT NULL,
            source_type varchar(20) NOT NULL DEFAULT 'api',
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            expires_at datetime DEFAULT NULL,
            PRIMARY KEY  (id),
            UNIQUE KEY hash_langs (source_hash, source_lang, target_lang, provider),
            KEY source_type (source_type),
            KEY expires_at (expires_at)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translation glossary table.
        $table_name = $wpdb->prefix . 'wpt_translation_glossary';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            term varchar(255) NOT NULL,
            translation varchar(255) NOT NULL,
            source_lang varchar(10) NOT NULL,
            target_lang varchar(10) NOT NULL,
            case_sensitive tinyint(1) NOT NULL DEFAULT 0,
            exact_match tinyint(1) NOT NULL DEFAULT 0,
            auto_generated tinyint(1) NOT NULL DEFAULT 0,
            confirmed tinyint(1) NOT NULL DEFAULT 1,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY source_target (source_lang, target_lang),
            KEY auto_generated (auto_generated),
            KEY confirmed (confirmed)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Translation corrections table.
        $table_name = $wpdb->prefix . 'wpt_translation_corrections';
        $sql = "CREATE TABLE {$table_name} (
            id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
            translation_id bigint(20) unsigned NOT NULL DEFAULT 0,
            source_text text NOT NULL,
            ai_output text NOT NULL,
            corrected_text text NOT NULL,
            source_lang varchar(10) NOT NULL,
            target_lang varchar(10) NOT NULL,
            provider varchar(30) NOT NULL DEFAULT '',
            correction_type varchar(30) NOT NULL DEFAULT 'terminology',
            translator_user_id bigint(20) unsigned NOT NULL DEFAULT 0,
            promoted_to_glossary tinyint(1) NOT NULL DEFAULT 0,
            created_at datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY  (id),
            KEY source_target_type (source_lang, target_lang, correction_type),
            KEY translator_user_id (translator_user_id),
            KEY created_at (created_at),
            KEY promoted_to_glossary (promoted_to_glossary)
        ) {$charset_collate};";
        dbDelta( $sql );

        // Store DB version.
        update_option( 'wptranslate_db_version', WPTRANSLATE_DB_VERSION );
    }

    /**
     * Set default plugin options.
     */
    /**
     * Auto-add the site's default language to the languages table.
     */
    private static function add_default_language(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        // Only add if the table is empty (fresh install).
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
        if ( $count > 0 ) {
            return;
        }

        // Resolve site locale to a language code.
        $locale = get_locale();
        $code   = strtolower( substr( $locale, 0, 2 ) );

        // Check built-in language catalog.
        $catalog = LanguageManager::get_available_languages();

        // Try exact locale match first (e.g., pt-br).
        $matched_code = null;
        foreach ( $catalog as $cat_code => $cat_data ) {
            if ( strtolower( $cat_data['locale'] ) === strtolower( $locale ) ) {
                $matched_code = $cat_code;
                break;
            }
        }

        // Fall back to 2-letter code.
        if ( ! $matched_code && isset( $catalog[ $code ] ) ) {
            $matched_code = $code;
        }

        if ( $matched_code && isset( $catalog[ $matched_code ] ) ) {
            $data = $catalog[ $matched_code ];
            $wpdb->insert(
                $table,
                array(
                    'code'        => $matched_code,
                    'name'        => $data['name'],
                    'native_name' => $data['native_name'],
                    'locale'      => $data['locale'],
                    'flag'        => $data['flag'],
                    'is_default'  => 1,
                    'is_active'   => 1,
                    'sort_order'  => 0,
                    'rtl'         => $data['rtl'] ? 1 : 0,
                ),
                array( '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d' )
            );
        } else {
            // Unknown locale — add with minimal data.
            $wpdb->insert(
                $table,
                array(
                    'code'        => $code,
                    'name'        => $locale,
                    'native_name' => $locale,
                    'locale'      => $locale,
                    'flag'        => '',
                    'is_default'  => 1,
                    'is_active'   => 1,
                    'sort_order'  => 0,
                    'rtl'         => 0,
                ),
                array( '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d' )
            );
        }

        // Store the default language code in options.
        update_option( 'wptranslate_default_language', $matched_code ?: $code );
    }

    private static function set_default_options(): void {
        $defaults = array(
            'wptranslate_default_language'     => get_locale(),
            'wptranslate_url_format'           => 'directory',
            'wptranslate_primary_provider'     => '',
            'wptranslate_fallback_provider'    => '',
            'wptranslate_post_types'           => array( 'post', 'page' ),
            'wptranslate_taxonomies'           => array( 'category', 'post_tag' ),
            'wptranslate_media_handling'        => 'share',
            'wptranslate_browser_redirect'     => false,
            'wptranslate_translator_workflow'   => false,
            'wptranslate_review_mode'          => false,
            'wptranslate_site_context'         => '',
            'wptranslate_correction_threshold' => 3,
            'wptranslate_cache_ttl'            => 43200,
            'wptranslate_max_chunk_size'       => 3000,
            'wptranslate_auto_assign_method'   => 'round_robin',
            'wptranslate_delete_data_on_uninstall' => false,
        );

        foreach ( $defaults as $key => $value ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $value );
            }
        }
    }

    /**
     * Schedule cron events.
     */
    private static function schedule_cron_events(): void {
        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_event( time(), 'every_five_minutes', 'wptranslate_process_queue' );
        }
        if ( ! wp_next_scheduled( 'wptranslate_analyze_corrections' ) ) {
            wp_schedule_event( time(), 'daily', 'wptranslate_analyze_corrections' );
        }
    }
}
