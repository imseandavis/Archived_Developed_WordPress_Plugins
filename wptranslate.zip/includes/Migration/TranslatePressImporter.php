<?php
namespace WPTranslate\Migration;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Imports translations from TranslatePress into WPTranslate.
 *
 * TranslatePress stores data in two families of tables:
 *  - wp_trp_gettext_{language_code}  (gettext / string translations)
 *  - wp_trp_dictionary_{language_code} (content translations)
 *
 * This importer reads those tables — even when TranslatePress is deactivated —
 * and writes the data into WPTranslate's own tables.
 */
class TranslatePressImporter {

    /**
     * Map TranslatePress status integers to WPTranslate status strings.
     *
     * 0 = not translated (skip), 1 = human-translated, 2 = machine-translated.
     */
    private const STATUS_MAP = array(
        0 => 'needs_translation',
        1 => 'published',
        2 => 'ai_draft',
    );

    /**
     * Common TranslatePress language code → WPTranslate code mappings.
     *
     * TranslatePress uses WordPress locales (e.g. "en_US") while WPTranslate
     * uses short ISO codes (e.g. "en"). This map covers the most frequent
     * divergences; anything not listed is converted via locale_to_short_code().
     */
    private const LANGUAGE_CODE_MAP = array(
        'en_US' => 'en',
        'en_GB' => 'en',
        'es_ES' => 'es',
        'es_MX' => 'es',
        'fr_FR' => 'fr',
        'fr_CA' => 'fr',
        'de_DE' => 'de',
        'de_AT' => 'de',
        'it_IT' => 'it',
        'pt_PT' => 'pt',
        'pt_BR' => 'pt-br',
        'nl_NL' => 'nl',
        'ru_RU' => 'ru',
        'zh_CN' => 'zh',
        'zh_TW' => 'zh-tw',
        'ja'    => 'ja',
        'ko_KR' => 'ko',
        'ar'    => 'ar',
        'he_IL' => 'he',
        'hi_IN' => 'hi',
        'tr_TR' => 'tr',
        'pl_PL' => 'pl',
        'sv_SE' => 'sv',
        'da_DK' => 'da',
        'nb_NO' => 'no',
        'cs_CZ' => 'cs',
        'el'    => 'el',
        'hu_HU' => 'hu',
        'ro_RO' => 'ro',
        'bg_BG' => 'bg',
        'uk'    => 'uk',
        'th'    => 'th',
        'vi'    => 'vi',
        'id_ID' => 'id',
        'sk_SK' => 'sk',
        'sl_SI' => 'sl',
        'hr'    => 'hr',
        'sr_RS' => 'sr',
        'lt_LT' => 'lt',
        'fi'    => 'fi',
        'et'    => 'et',
        'fa_IR' => 'fa',
        'bn_BD' => 'bn',
        'ta_IN' => 'ta',
        'ms_MY' => 'ms',
        'af'    => 'af',
        'ca'    => 'ca',
        'eu'    => 'eu',
        'gl_ES' => 'gl',
        'lv'    => 'lv',
        'ur'    => 'ur',
        'sw'    => 'sw',
    );

    /** @var \wpdb */
    private $wpdb;

    /** @var callable|null Logger callback. */
    private $logger;

    /**
     * @param callable|null $logger Optional logging callback that receives ($message, $level).
     */
    public function __construct( ?callable $logger = null ) {
        global $wpdb;
        $this->wpdb   = $wpdb;
        $this->logger = $logger;
    }

    // ------------------------------------------------------------------
    // Detection
    // ------------------------------------------------------------------

    /**
     * Check whether TranslatePress tables exist in the database.
     *
     * Returns true even when the TranslatePress plugin is deactivated, as long
     * as its tables are still present.
     *
     * @return bool
     */
    public function detect_translatepress(): bool {
        $tables = $this->wpdb->get_col( 'SHOW TABLES' );

        foreach ( $tables as $table ) {
            if ( preg_match( '/trp_(gettext|dictionary)_/', $table ) ) {
                $this->log( 'TranslatePress tables detected.' );
                return true;
            }
        }

        $this->log( 'No TranslatePress tables found.', 'warning' );
        return false;
    }

    /**
     * Discover which TranslatePress language tables exist.
     *
     * @return array{
     *     gettext:    string[],
     *     dictionary: string[],
     *     languages:  string[]
     * } Arrays of TranslatePress language codes keyed by table type, plus a
     *   deduplicated list of all language codes.
     */
    public function get_available_languages(): array {
        $tables = $this->wpdb->get_col( 'SHOW TABLES' );
        $prefix = $this->wpdb->prefix;

        $gettext    = array();
        $dictionary = array();

        foreach ( $tables as $table ) {
            if ( preg_match( '/^' . preg_quote( $prefix, '/' ) . 'trp_gettext_(.+)$/', $table, $m ) ) {
                $gettext[] = $m[1];
            }
            if ( preg_match( '/^' . preg_quote( $prefix, '/' ) . 'trp_dictionary_(.+)$/', $table, $m ) ) {
                $dictionary[] = $m[1];
            }
        }

        $all = array_unique( array_merge( $gettext, $dictionary ) );
        sort( $all );

        $this->log( sprintf(
            'Found %d gettext table(s) and %d dictionary table(s) covering %d language(s).',
            count( $gettext ),
            count( $dictionary ),
            count( $all )
        ) );

        return array(
            'gettext'    => $gettext,
            'dictionary' => $dictionary,
            'languages'  => $all,
        );
    }

    // ------------------------------------------------------------------
    // Settings import
    // ------------------------------------------------------------------

    /**
     * Import TranslatePress settings (languages, default language, URL slugs).
     *
     * Reads the `trp_settings` option and configures WPTranslate accordingly.
     *
     * @return ImportResult
     */
    public function import_settings(): ImportResult {
        $result   = new ImportResult();
        $settings = get_option( 'trp_settings', array() );

        if ( empty( $settings ) ) {
            $result->add_warning( 'TranslatePress settings option (trp_settings) not found or empty.' );
            return $result;
        }

        $this->log( 'Importing TranslatePress settings.' );

        $plugin = \WPTranslate\Plugin::get_instance();
        $lang_manager = $plugin->get_language_manager();

        // Import default language.
        $default_locale = $settings['default-language'] ?? '';
        if ( ! empty( $default_locale ) ) {
            $default_code = $this->map_language_code( $default_locale );
            $existing = $lang_manager->get_language( $default_code );

            if ( ! $existing ) {
                $added = $lang_manager->add_language( array(
                    'code'       => $default_code,
                    'is_default' => 1,
                    'is_active'  => 1,
                ) );
                if ( $added ) {
                    $result->add_imported( "Added default language: {$default_code} (from {$default_locale})." );
                } else {
                    $result->add_failed( "Failed to add default language: {$default_code}." );
                }
            } else {
                $lang_manager->update_language( $default_code, array( 'is_default' => 1 ) );
                $result->add_skipped( "Default language {$default_code} already exists; set as default." );
            }
        }

        // Import translation languages.
        $publish_languages = $settings['publish-languages'] ?? array();
        if ( is_array( $publish_languages ) ) {
            foreach ( $publish_languages as $locale ) {
                if ( $locale === $default_locale ) {
                    continue; // Already handled above.
                }

                $code = $this->map_language_code( $locale );
                $existing = $lang_manager->get_language( $code );

                if ( ! $existing ) {
                    $added = $lang_manager->add_language( array(
                        'code'      => $code,
                        'is_active' => 1,
                    ) );
                    if ( $added ) {
                        $result->add_imported( "Added language: {$code} (from {$locale})." );
                    } else {
                        $result->add_failed( "Failed to add language: {$code}." );
                    }
                } else {
                    $result->add_skipped( "Language {$code} already exists." );
                }
            }
        }

        // Import URL slugs.
        $url_slugs = $settings['url-slugs'] ?? array();
        if ( is_array( $url_slugs ) && ! empty( $url_slugs ) ) {
            update_option( 'wptranslate_trp_url_slugs', $url_slugs );
            $result->add_imported( 'Imported URL slug mappings.' );
        }

        $this->log( 'Settings import complete. ' . $result->get_summary() );

        return $result;
    }

    // ------------------------------------------------------------------
    // String translation import (gettext tables)
    // ------------------------------------------------------------------

    /**
     * Import string translations from a TranslatePress gettext table.
     *
     * @param string $language  TranslatePress language code (e.g. "es_ES") as it
     *                          appears in the table suffix.
     * @param bool   $dry_run   When true, counts rows without writing anything.
     *
     * @return ImportResult
     */
    public function import_strings( string $language, bool $dry_run = false ): ImportResult {
        $result = new ImportResult();
        $table  = $this->wpdb->prefix . 'trp_gettext_' . $language;

        // Verify the table exists.
        if ( ! $this->table_exists( $table ) ) {
            $result->add_failed( "Table {$table} does not exist." );
            return $result;
        }

        $wpt_code = $this->map_language_code( $language );
        $this->log( "Importing strings from {$table} into language '{$wpt_code}'" . ( $dry_run ? ' (dry run)' : '' ) . '.' );

        $wpt_table = $this->wpdb->prefix . 'wpt_string_translations';

        // Process in batches of 500.
        $offset    = 0;
        $batch     = 500;

        while ( true ) {
            $rows = $this->wpdb->get_results( $this->wpdb->prepare(
                "SELECT id, original, translated, domain, status FROM {$table} ORDER BY id ASC LIMIT %d OFFSET %d",
                $batch,
                $offset
            ), ARRAY_A );

            if ( empty( $rows ) ) {
                break;
            }

            foreach ( $rows as $row ) {
                // Skip untranslated strings.
                if ( empty( $row['translated'] ) || (int) $row['status'] === 0 ) {
                    $result->add_skipped( "Skipped untranslated string ID {$row['id']}." );
                    continue;
                }

                $wpt_status = self::STATUS_MAP[ (int) $row['status'] ] ?? 'translated';
                if ( 'needs_translation' === $wpt_status ) {
                    $result->add_skipped( "Skipped untranslated string ID {$row['id']}." );
                    continue;
                }

                // Map TranslatePress status to wpt_string_translations status.
                // The string table uses 'translated' / 'needs_translation';
                // we store human-approved as 'translated' and machine as 'translated'
                // (the distinction is tracked at the post level via translation_status).
                $string_status = 'translated';

                if ( $dry_run ) {
                    $result->add_imported( "[dry-run] Would import string: " . mb_substr( $row['original'], 0, 60 ) );
                    continue;
                }

                $domain = ! empty( $row['domain'] ) ? $row['domain'] : 'default';

                // Check for existing entry.
                $exists = $this->wpdb->get_var( $this->wpdb->prepare(
                    "SELECT id FROM {$wpt_table}
                     WHERE string_name = %s AND language_code = %s AND domain = %s AND context = ''
                     LIMIT 1",
                    $row['original'],
                    $wpt_code,
                    $domain
                ) );

                if ( $exists ) {
                    $result->add_skipped( "String already exists (ID {$exists}): " . mb_substr( $row['original'], 0, 60 ) );
                    continue;
                }

                $inserted = $this->wpdb->insert(
                    $wpt_table,
                    array(
                        'string_name'   => $row['original'],
                        'string_value'  => $row['translated'],
                        'language_code' => $wpt_code,
                        'context'       => '',
                        'domain'        => $domain,
                        'status'        => $string_status,
                        'date_modified' => current_time( 'mysql' ),
                    ),
                    array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
                );

                if ( $inserted ) {
                    $result->add_imported( "Imported string: " . mb_substr( $row['original'], 0, 60 ) );
                } else {
                    $result->add_failed( "Failed to insert string: " . mb_substr( $row['original'], 0, 60 ) );
                }
            }

            $offset += $batch;
        }

        $this->log( "String import for '{$language}' complete. " . $result->get_summary() );

        return $result;
    }

    // ------------------------------------------------------------------
    // Content translation import (dictionary tables)
    // ------------------------------------------------------------------

    /**
     * Import content translations from a TranslatePress dictionary table.
     *
     * TranslatePress stores content as original/translated text pairs. This
     * method attempts to find which WordPress posts those originals belong to,
     * creates translated posts, and links them via WPTranslate's trid system.
     *
     * @param string $language TranslatePress language code.
     * @param bool   $dry_run  When true, counts rows without writing anything.
     *
     * @return ImportResult
     */
    public function import_content( string $language, bool $dry_run = false ): ImportResult {
        $result = new ImportResult();
        $table  = $this->wpdb->prefix . 'trp_dictionary_' . $language;

        if ( ! $this->table_exists( $table ) ) {
            $result->add_failed( "Table {$table} does not exist." );
            return $result;
        }

        $wpt_code = $this->map_language_code( $language );
        $this->log( "Importing content from {$table} into language '{$wpt_code}'" . ( $dry_run ? ' (dry run)' : '' ) . '.' );

        $plugin            = \WPTranslate\Plugin::get_instance();
        $translation_mgr   = $plugin->get_translation_manager();
        $language_mgr      = $plugin->get_language_manager();
        $default_lang      = $language_mgr->get_default_language();

        // Build a lookup of original text => post data for matching.
        // We index by post_title and post_content (trimmed to first 200 chars).
        $post_index = $this->build_post_index();

        $offset = 0;
        $batch  = 200;

        // Track which source posts we have already created translations for in
        // this run, to avoid duplicates when multiple dictionary rows map to the
        // same post.
        $processed_posts = array();

        while ( true ) {
            $rows = $this->wpdb->get_results( $this->wpdb->prepare(
                "SELECT id, original, translated, status, original_id
                 FROM {$table}
                 WHERE translated != '' AND status IN (1, 2)
                 ORDER BY id ASC LIMIT %d OFFSET %d",
                $batch,
                $offset
            ), ARRAY_A );

            if ( empty( $rows ) ) {
                break;
            }

            foreach ( $rows as $row ) {
                $source_post_id = $this->find_source_post( $row['original'], $post_index );

                if ( ! $source_post_id ) {
                    $result->add_skipped( "Could not match original to a post (dict ID {$row['id']}): " . mb_substr( $row['original'], 0, 80 ) );
                    continue;
                }

                // Only process each source post once per language.
                $process_key = "{$source_post_id}_{$wpt_code}";
                if ( isset( $processed_posts[ $process_key ] ) ) {
                    // Append translated content to the existing translated post.
                    if ( ! $dry_run ) {
                        $this->append_translated_content(
                            $processed_posts[ $process_key ],
                            $row['original'],
                            $row['translated'],
                            $source_post_id
                        );
                    }
                    $result->add_skipped( "Additional content fragment for post {$source_post_id} merged." );
                    continue;
                }

                // Check if a translation already exists in WPTranslate.
                $existing_translation = $translation_mgr->get_translation_id( $source_post_id, $wpt_code );
                if ( $existing_translation ) {
                    $result->add_skipped( "Translation already exists for post {$source_post_id} in {$wpt_code} (post {$existing_translation})." );
                    $processed_posts[ $process_key ] = $existing_translation;
                    continue;
                }

                $wpt_status = self::STATUS_MAP[ (int) $row['status'] ] ?? 'ai_draft';

                if ( $dry_run ) {
                    $result->add_imported( "[dry-run] Would create translation for post {$source_post_id} in {$wpt_code}." );
                    $processed_posts[ $process_key ] = 0;
                    continue;
                }

                // Create the translated post.
                $source_post = get_post( $source_post_id );
                if ( ! $source_post ) {
                    $result->add_failed( "Source post {$source_post_id} could not be loaded." );
                    continue;
                }

                // Build translated content by replacing the original fragment.
                $translated_content = str_replace(
                    $row['original'],
                    $row['translated'],
                    $source_post->post_content
                );

                // If the original was actually the title, translate the title.
                $translated_title = $source_post->post_title;
                if ( trim( $row['original'] ) === trim( $source_post->post_title ) ) {
                    $translated_title = $row['translated'];
                }

                $post_status = ( 'published' === $wpt_status ) ? 'publish' : 'draft';

                $translated_post_id = wp_insert_post( array(
                    'post_title'   => $translated_title,
                    'post_content' => $translated_content,
                    'post_type'    => $source_post->post_type,
                    'post_status'  => $post_status,
                    'post_author'  => $source_post->post_author,
                    'post_parent'  => $source_post->post_parent,
                    'menu_order'   => $source_post->menu_order,
                    'post_name'    => sanitize_title( $translated_title ),
                ), true );

                if ( is_wp_error( $translated_post_id ) ) {
                    $result->add_failed( "Failed to create translated post for source {$source_post_id}: " . $translated_post_id->get_error_message() );
                    continue;
                }

                // Register in translation group.
                $trid = $translation_mgr->get_trid( $source_post_id );
                if ( ! $trid ) {
                    $trid = $translation_mgr->register_translation( $source_post_id, $default_lang, 'post', 0, '' );
                }
                $translation_mgr->register_translation( $translated_post_id, $wpt_code, 'post', $trid, $default_lang );

                // Set translation status.
                $translation_mgr->set_translation_status( $translated_post_id, $wpt_status, array(
                    'md5_hash' => md5( $source_post->post_content ),
                ) );

                // Store metadata for tracking.
                update_post_meta( $translated_post_id, '_wptranslate_source_post', $source_post_id );
                update_post_meta( $translated_post_id, '_wptranslate_source_hash', md5( $source_post->post_content ) );
                update_post_meta( $translated_post_id, '_wptranslate_imported_from', 'translatepress' );

                $processed_posts[ $process_key ] = $translated_post_id;
                $result->add_imported( "Created translation (post {$translated_post_id}) for source post {$source_post_id} in {$wpt_code}." );
            }

            $offset += $batch;
        }

        $this->log( "Content import for '{$language}' complete. " . $result->get_summary() );

        return $result;
    }

    // ------------------------------------------------------------------
    // Full import
    // ------------------------------------------------------------------

    /**
     * Run a full import from TranslatePress.
     *
     * @param array $options {
     *     Optional. Import options.
     *
     *     @type bool   $dry_run  Whether to perform a dry run. Default false.
     *     @type string $include  What to import: 'all', 'content', 'strings', 'settings'.
     *                            Default 'all'.
     * }
     *
     * @return ImportResult Combined result from all import phases.
     */
    public function import_all( array $options = array() ): ImportResult {
        $dry_run = ! empty( $options['dry_run'] );
        $include = $options['include'] ?? 'all';
        $result  = new ImportResult();

        if ( ! $this->detect_translatepress() ) {
            $result->add_failed( 'TranslatePress tables not found. Nothing to import.' );
            return $result;
        }

        $this->log( 'Starting full TranslatePress import.' . ( $dry_run ? ' (dry run)' : '' ) );

        // Phase 1: Settings.
        if ( in_array( $include, array( 'all', 'settings' ), true ) ) {
            $this->log( '--- Phase 1: Settings ---' );
            $settings_result = $this->import_settings();
            $result->merge( $settings_result );
        }

        $available = $this->get_available_languages();

        // Phase 2: String translations.
        if ( in_array( $include, array( 'all', 'strings' ), true ) ) {
            $this->log( '--- Phase 2: String translations ---' );
            foreach ( $available['gettext'] as $lang ) {
                $strings_result = $this->import_strings( $lang, $dry_run );
                $result->merge( $strings_result );
            }
        }

        // Phase 3: Content translations.
        if ( in_array( $include, array( 'all', 'content' ), true ) ) {
            $this->log( '--- Phase 3: Content translations ---' );
            foreach ( $available['dictionary'] as $lang ) {
                $content_result = $this->import_content( $lang, $dry_run );
                $result->merge( $content_result );
            }
        }

        $this->log( 'Full import complete. ' . $result->get_summary() );

        return $result;
    }

    // ------------------------------------------------------------------
    // Internal helpers
    // ------------------------------------------------------------------

    /**
     * Check whether a database table exists.
     *
     * @param string $table Full table name.
     * @return bool
     */
    private function table_exists( string $table ): bool {
        $found = $this->wpdb->get_var( $this->wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        return null !== $found;
    }

    /**
     * Map a TranslatePress language code (WordPress locale) to a WPTranslate
     * short code.
     *
     * @param string $trp_code TranslatePress language code.
     * @return string WPTranslate language code.
     */
    private function map_language_code( string $trp_code ): string {
        if ( isset( self::LANGUAGE_CODE_MAP[ $trp_code ] ) ) {
            return self::LANGUAGE_CODE_MAP[ $trp_code ];
        }

        return $this->locale_to_short_code( $trp_code );
    }

    /**
     * Convert a WordPress locale string to a short ISO 639-1 code.
     *
     * @param string $locale WordPress locale (e.g. "es_ES").
     * @return string Short code (e.g. "es").
     */
    private function locale_to_short_code( string $locale ): string {
        // Handle codes that are already short.
        if ( strlen( $locale ) <= 3 && ! str_contains( $locale, '_' ) ) {
            return strtolower( $locale );
        }

        $parts = explode( '_', $locale );

        return strtolower( $parts[0] );
    }

    /**
     * Build an index of existing posts for fast original-text matching.
     *
     * Keys are MD5 hashes of trimmed title or trimmed content (first 200 chars)
     * and values are post IDs.
     *
     * @return array<string, int>
     */
    private function build_post_index(): array {
        $index      = array();
        $post_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );

        if ( empty( $post_types ) ) {
            $post_types = array( 'post', 'page' );
        }

        $posts = get_posts( array(
            'post_type'      => $post_types,
            'post_status'    => array( 'publish', 'draft', 'private' ),
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'wptranslate_bypass' => true,
        ) );

        foreach ( $posts as $post_id ) {
            $post = get_post( $post_id );
            if ( ! $post ) {
                continue;
            }

            // Index by title.
            $title_key = md5( trim( $post->post_title ) );
            if ( ! isset( $index[ $title_key ] ) ) {
                $index[ $title_key ] = $post_id;
            }

            // Index by content opening (first 200 characters).
            if ( ! empty( $post->post_content ) ) {
                $content_key = md5( trim( mb_substr( $post->post_content, 0, 200 ) ) );
                if ( ! isset( $index[ $content_key ] ) ) {
                    $index[ $content_key ] = $post_id;
                }

                // Also index by full content hash.
                $full_key = md5( trim( $post->post_content ) );
                if ( ! isset( $index[ $full_key ] ) ) {
                    $index[ $full_key ] = $post_id;
                }
            }
        }

        $this->log( sprintf( 'Built post index with %d entries.', count( $index ) ) );

        return $index;
    }

    /**
     * Try to find the source post that a TranslatePress original text belongs to.
     *
     * @param string $original   The original text from TranslatePress.
     * @param array  $post_index The post index from build_post_index().
     *
     * @return int|null Post ID or null if not found.
     */
    private function find_source_post( string $original, array $post_index ): ?int {
        $original = trim( $original );

        if ( empty( $original ) ) {
            return null;
        }

        // Try exact title match.
        $title_key = md5( $original );
        if ( isset( $post_index[ $title_key ] ) ) {
            return $post_index[ $title_key ];
        }

        // Try content opening match.
        $content_key = md5( mb_substr( $original, 0, 200 ) );
        if ( isset( $post_index[ $content_key ] ) ) {
            return $post_index[ $content_key ];
        }

        // Try full content match.
        $full_key = md5( $original );
        if ( isset( $post_index[ $full_key ] ) ) {
            return $post_index[ $full_key ];
        }

        // Fall back: search the database directly for posts containing this text.
        $post_id = $this->wpdb->get_var( $this->wpdb->prepare(
            "SELECT ID FROM {$this->wpdb->posts}
             WHERE (post_title = %s OR post_content LIKE %s)
             AND post_status IN ('publish', 'draft', 'private')
             ORDER BY ID ASC LIMIT 1",
            $original,
            '%' . $this->wpdb->esc_like( mb_substr( $original, 0, 100 ) ) . '%'
        ) );

        return $post_id ? (int) $post_id : null;
    }

    /**
     * Append translated content fragments to an already-created translated post.
     *
     * When multiple TranslatePress dictionary rows map to the same source post,
     * we replace the matching original fragment in the translated post's content
     * with the translated version.
     *
     * @param int    $translated_post_id The translated post ID.
     * @param string $original           The original text fragment.
     * @param string $translated         The translated text fragment.
     * @param int    $source_post_id     The source post ID.
     */
    private function append_translated_content( int $translated_post_id, string $original, string $translated, int $source_post_id ): void {
        if ( ! $translated_post_id ) {
            return;
        }

        $post = get_post( $translated_post_id );
        if ( ! $post ) {
            return;
        }

        $updated_content = str_replace( $original, $translated, $post->post_content );

        // Also check if the original matches the title.
        $updated_title = $post->post_title;
        $source_post   = get_post( $source_post_id );
        if ( $source_post && trim( $original ) === trim( $source_post->post_title ) ) {
            $updated_title = $translated;
        }

        wp_update_post( array(
            'ID'           => $translated_post_id,
            'post_content' => $updated_content,
            'post_title'   => $updated_title,
        ) );
    }

    /**
     * Write a log message.
     *
     * @param string $message Log message.
     * @param string $level   Log level (info, warning, error).
     */
    private function log( string $message, string $level = 'info' ): void {
        if ( is_callable( $this->logger ) ) {
            call_user_func( $this->logger, $message, $level );
            return;
        }

        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf( '[WPTranslate Import][%s] %s', strtoupper( $level ), $message ) );
        }
    }
}
