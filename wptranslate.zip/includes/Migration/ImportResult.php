<?php
namespace WPTranslate\Migration;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Value object representing the result of an import operation.
 */
class ImportResult {

    /** @var int Number of items successfully imported. */
    public $imported_count = 0;

    /** @var int Number of items skipped (already exist, empty, etc.). */
    public $skipped_count = 0;

    /** @var int Number of items that failed to import. */
    public $failed_count = 0;

    /** @var string[] Error messages encountered during import. */
    public $errors = array();

    /** @var string[] Warning messages encountered during import. */
    public $warnings = array();

    /** @var array Detailed per-item import information. */
    public $details = array();

    /**
     * Record a successful import.
     *
     * @param string $detail Optional detail message.
     */
    public function add_imported( string $detail = '' ): void {
        $this->imported_count++;
        if ( '' !== $detail ) {
            $this->details[] = array( 'type' => 'imported', 'message' => $detail );
        }
    }

    /**
     * Record a skipped item.
     *
     * @param string $detail Optional detail message.
     */
    public function add_skipped( string $detail = '' ): void {
        $this->skipped_count++;
        if ( '' !== $detail ) {
            $this->details[] = array( 'type' => 'skipped', 'message' => $detail );
        }
    }

    /**
     * Record a failed item.
     *
     * @param string $error Error message.
     */
    public function add_failed( string $error ): void {
        $this->failed_count++;
        $this->errors[] = $error;
        $this->details[] = array( 'type' => 'failed', 'message' => $error );
    }

    /**
     * Add a warning.
     *
     * @param string $warning Warning message.
     */
    public function add_warning( string $warning ): void {
        $this->warnings[] = $warning;
        $this->details[] = array( 'type' => 'warning', 'message' => $warning );
    }

    /**
     * Merge another ImportResult into this one.
     *
     * @param ImportResult $other The result to merge.
     */
    public function merge( ImportResult $other ): void {
        $this->imported_count += $other->imported_count;
        $this->skipped_count  += $other->skipped_count;
        $this->failed_count   += $other->failed_count;
        $this->errors          = array_merge( $this->errors, $other->errors );
        $this->warnings        = array_merge( $this->warnings, $other->warnings );
        $this->details         = array_merge( $this->details, $other->details );
    }

    /**
     * Check whether the import encountered any errors.
     *
     * @return bool
     */
    public function has_errors(): bool {
        return ! empty( $this->errors );
    }

    /**
     * Get a human-readable summary string.
     *
     * @return string
     */
    public function get_summary(): string {
        return sprintf(
            'Imported: %d | Skipped: %d | Failed: %d | Warnings: %d',
            $this->imported_count,
            $this->skipped_count,
            $this->failed_count,
            count( $this->warnings )
        );
    }

    /**
     * Convert to an associative array.
     *
     * @return array
     */
    public function to_array(): array {
        return array(
            'imported_count' => $this->imported_count,
            'skipped_count'  => $this->skipped_count,
            'failed_count'   => $this->failed_count,
            'errors'         => $this->errors,
            'warnings'       => $this->warnings,
            'details'        => $this->details,
        );
    }
}
