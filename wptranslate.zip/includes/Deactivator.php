<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Plugin deactivation handler.
 */
class Deactivator {

    /**
     * Run on plugin deactivation.
     */
    public static function deactivate(): void {
        // Clear scheduled cron events.
        wp_clear_scheduled_hook( 'wptranslate_process_queue' );
        wp_clear_scheduled_hook( 'wptranslate_analyze_corrections' );

        // Flush rewrite rules.
        flush_rewrite_rules();

        // Clear transients.
        delete_transient( 'wptranslate_conflict_check' );
        delete_transient( 'wptranslate_active_languages' );
    }
}
