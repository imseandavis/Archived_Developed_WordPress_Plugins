<?php
namespace WPTranslate\cache;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Multi-layer cache manager for WPTranslate.
 *
 * Implements three caching layers:
 * 1. In-memory runtime cache (PHP array, cleared per-request).
 * 2. WordPress object cache (wp_cache_set/get -- works with Redis/Memcached).
 * 3. Transient cache for longer-lived data.
 *
 * Also manages the wpt_translation_cache database table and bulk-loads
 * string translations to avoid per-string queries.
 */
class CacheManager {

    /**
     * Runtime in-memory cache, keyed by group.
     *
     * @var array<string, array<string, mixed>>
     */
    private $runtime_cache = array();

    /**
     * Tracks which language+domain combos have been bulk-loaded.
     *
     * @var array<string, true>
     */
    private $loaded_string_groups = array();

    /**
     * Default TTL in seconds (1 hour).
     *
     * @var int
     */
    private const DEFAULT_TTL = 3600;

    /**
     * Retrieve a value from the multi-layer cache.
     *
     * Checks runtime -> object cache -> transient. When a value is found in a
     * deeper layer it is promoted into the faster layers automatically.
     *
     * @param string $key   Cache key.
     * @param string $group Cache group.
     *
     * @return mixed|false Cached value or false on miss.
     */
    public function get( string $key, string $group = 'wptranslate' ) {
        // Layer 1: runtime cache.
        if ( isset( $this->runtime_cache[ $group ][ $key ] ) ) {
            return $this->runtime_cache[ $group ][ $key ];
        }

        // Layer 2: WordPress object cache.
        $found = false;
        $value = wp_cache_get( $key, $group, false, $found );

        if ( $found ) {
            $this->runtime_cache[ $group ][ $key ] = $value;
            return $value;
        }

        // Layer 3: transient.
        $transient_key = $this->transient_key( $key, $group );
        $value         = get_transient( $transient_key );

        if ( false !== $value ) {
            // Promote into faster layers.
            $this->runtime_cache[ $group ][ $key ] = $value;
            wp_cache_set( $key, $value, $group );
            return $value;
        }

        return false;
    }

    /**
     * Store a value in all cache layers.
     *
     * @param string $key   Cache key.
     * @param mixed  $value Value to cache.
     * @param int    $ttl   Time-to-live in seconds. Applies to object cache and transient.
     * @param string $group Cache group.
     */
    public function set( string $key, $value, int $ttl = self::DEFAULT_TTL, string $group = 'wptranslate' ): void {
        // Layer 1: runtime cache (no TTL, lives until end of request).
        $this->runtime_cache[ $group ][ $key ] = $value;

        // Layer 2: WordPress object cache.
        wp_cache_set( $key, $value, $group, $ttl );

        // Layer 3: transient.
        $transient_key = $this->transient_key( $key, $group );
        set_transient( $transient_key, $value, $ttl );
    }

    /**
     * Delete a value from all cache layers.
     *
     * @param string $key   Cache key.
     * @param string $group Cache group.
     */
    public function delete( string $key, string $group = 'wptranslate' ): void {
        unset( $this->runtime_cache[ $group ][ $key ] );

        wp_cache_delete( $key, $group );

        $transient_key = $this->transient_key( $key, $group );
        delete_transient( $transient_key );
    }

    /**
     * Flush the runtime cache for a given group.
     *
     * Object cache and transients are not cleared here because WordPress does
     * not provide a group-level flush for transients. Use delete() for
     * individual keys or wp_cache_flush() for a full object-cache purge.
     *
     * @param string $group Cache group.
     */
    public function flush( string $group = 'wptranslate' ): void {
        unset( $this->runtime_cache[ $group ] );
    }

    // ------------------------------------------------------------------
    // Translation cache (wpt_translation_cache table).
    // ------------------------------------------------------------------

    /**
     * Look up a cached translation from the database table.
     *
     * @param string $source_hash SHA-256 hash of the source text.
     * @param string $source_lang Source language code.
     * @param string $target_lang Target language code.
     * @param string $provider    Provider slug (empty string matches any).
     *
     * @return string|false Translated text or false on miss/expired.
     */
    public function get_translation_cache( string $source_hash, string $source_lang, string $target_lang, string $provider = '' ) {
        $cache_key = "tc_{$source_hash}_{$source_lang}_{$target_lang}_{$provider}";
        $cached    = $this->get( $cache_key, 'wptranslate_tc' );

        if ( false !== $cached ) {
            return $cached;
        }

        global $wpdb;

        $table = $wpdb->prefix . 'wpt_translation_cache';

        if ( '' !== $provider ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT translated_text FROM {$table}
                     WHERE source_hash = %s
                       AND source_lang = %s
                       AND target_lang = %s
                       AND provider    = %s
                       AND ( expires_at IS NULL OR expires_at > %s )
                     LIMIT 1",
                    $source_hash,
                    $source_lang,
                    $target_lang,
                    $provider,
                    current_time( 'mysql', true )
                )
            );
        } else {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row(
                $wpdb->prepare(
                    "SELECT translated_text FROM {$table}
                     WHERE source_hash = %s
                       AND source_lang = %s
                       AND target_lang = %s
                       AND ( expires_at IS NULL OR expires_at > %s )
                     ORDER BY created_at DESC
                     LIMIT 1",
                    $source_hash,
                    $source_lang,
                    $target_lang,
                    current_time( 'mysql', true )
                )
            );
        }

        if ( ! $row ) {
            return false;
        }

        // Promote into multi-layer cache.
        $this->set( $cache_key, $row->translated_text, self::DEFAULT_TTL, 'wptranslate_tc' );

        return $row->translated_text;
    }

    /**
     * Store a translation in the database cache table.
     *
     * Uses INSERT ... ON DUPLICATE KEY UPDATE so existing entries are refreshed.
     *
     * @param string      $source_hash    SHA-256 hash of the source text.
     * @param string      $source_lang    Source language code.
     * @param string      $target_lang    Target language code.
     * @param string      $provider       Provider slug.
     * @param string      $source_text    Original text.
     * @param string      $translated_text Translated text.
     * @param string      $source_type    'api', 'manual', 'glossary', etc.
     * @param int|null    $ttl            TTL in seconds. Null means no expiry.
     */
    public function set_translation_cache(
        string $source_hash,
        string $source_lang,
        string $target_lang,
        string $provider,
        string $source_text,
        string $translated_text,
        string $source_type = 'api',
        ?int $ttl = null
    ): void {
        global $wpdb;

        $table      = $wpdb->prefix . 'wpt_translation_cache';
        $now        = current_time( 'mysql', true );
        $expires_at = null;

        if ( null !== $ttl && $ttl > 0 ) {
            $expires_at = gmdate( 'Y-m-d H:i:s', time() + $ttl );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            $wpdb->prepare(
                "INSERT INTO {$table}
                    ( source_hash, source_lang, target_lang, provider, source_text, translated_text, source_type, created_at, expires_at )
                 VALUES ( %s, %s, %s, %s, %s, %s, %s, %s, %s )
                 ON DUPLICATE KEY UPDATE
                    source_text     = VALUES( source_text ),
                    translated_text = VALUES( translated_text ),
                    source_type     = VALUES( source_type ),
                    created_at      = VALUES( created_at ),
                    expires_at      = VALUES( expires_at )",
                $source_hash,
                $source_lang,
                $target_lang,
                $provider,
                $source_text,
                $translated_text,
                $source_type,
                $now,
                $expires_at
            )
        );

        // Update the multi-layer cache as well.
        $cache_key = "tc_{$source_hash}_{$source_lang}_{$target_lang}_{$provider}";
        $this->set( $cache_key, $translated_text, $ttl ?? self::DEFAULT_TTL, 'wptranslate_tc' );
    }

    /**
     * Clear entries from the translation cache table.
     *
     * When both language parameters are empty the entire table is truncated.
     *
     * @param string $source_lang Source language filter (empty = all).
     * @param string $target_lang Target language filter (empty = all).
     *
     * @return int Number of rows deleted.
     */
    public function clear_translation_cache( string $source_lang = '', string $target_lang = '' ): int {
        global $wpdb;

        $table = $wpdb->prefix . 'wpt_translation_cache';

        if ( '' === $source_lang && '' === $target_lang ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
            $wpdb->query( "TRUNCATE TABLE {$table}" );
            $this->flush( 'wptranslate_tc' );
            return 0;
        }

        $where  = array();
        $values = array();

        if ( '' !== $source_lang ) {
            $where[]  = 'source_lang = %s';
            $values[] = $source_lang;
        }

        if ( '' !== $target_lang ) {
            $where[]  = 'target_lang = %s';
            $values[] = $target_lang;
        }

        $where_sql = implode( ' AND ', $where );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching, WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $deleted = (int) $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE {$where_sql}",
                ...$values
            )
        );

        $this->flush( 'wptranslate_tc' );

        return $deleted;
    }

    // ------------------------------------------------------------------
    // String translations (wpt_string_translations table).
    // ------------------------------------------------------------------

    /**
     * Bulk-load all string translations for a language and domain.
     *
     * On first access the entire set is fetched from the database and stored
     * in the runtime and object caches. Subsequent calls during the same
     * request return from the runtime cache with zero database queries.
     *
     * @param string $language_code Language code.
     * @param string $domain        Text domain.
     *
     * @return array<string, string> Associative array of string_name => string_value.
     */
    public function get_string_translations( string $language_code, string $domain = 'default' ): array {
        $group_key = "{$language_code}:{$domain}";

        // Already loaded this request -- return from runtime cache.
        if ( isset( $this->loaded_string_groups[ $group_key ] ) ) {
            $cached = $this->get( "strings_{$group_key}", 'wptranslate_strings' );
            if ( is_array( $cached ) ) {
                return $cached;
            }
        }

        // Try the object cache / transient layers.
        $cached = $this->get( "strings_{$group_key}", 'wptranslate_strings' );
        if ( is_array( $cached ) ) {
            $this->loaded_string_groups[ $group_key ] = true;
            return $cached;
        }

        // Nothing cached -- bulk-load from the database.
        global $wpdb;

        $table = $wpdb->prefix . 'wpt_string_translations';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT string_name, string_value
                 FROM {$table}
                 WHERE language_code = %s
                   AND domain        = %s
                   AND status        = 'translated'",
                $language_code,
                $domain
            )
        );

        $translations = array();
        if ( $rows ) {
            foreach ( $rows as $row ) {
                $translations[ $row->string_name ] = $row->string_value;
            }
        }

        // Store in all layers with a 12-hour TTL.
        $this->set( "strings_{$group_key}", $translations, 43200, 'wptranslate_strings' );
        $this->loaded_string_groups[ $group_key ] = true;

        return $translations;
    }

    /**
     * Invalidate string translation caches.
     *
     * When $language_code is empty, all string caches are flushed. Otherwise
     * only caches for the specified language are removed.
     *
     * @param string $language_code Language code (empty = all languages).
     */
    public function invalidate_string_cache( string $language_code = '' ): void {
        if ( '' === $language_code ) {
            $this->flush( 'wptranslate_strings' );
            $this->loaded_string_groups = array();
            return;
        }

        // Remove all group keys that start with this language code.
        foreach ( array_keys( $this->loaded_string_groups ) as $group_key ) {
            if ( 0 === strpos( $group_key, "{$language_code}:" ) ) {
                $this->delete( "strings_{$group_key}", 'wptranslate_strings' );
                unset( $this->loaded_string_groups[ $group_key ] );
            }
        }

        // Also remove from the runtime cache bucket in case entries were set
        // outside the tracked keys (defensive).
        if ( isset( $this->runtime_cache['wptranslate_strings'] ) ) {
            foreach ( array_keys( $this->runtime_cache['wptranslate_strings'] ) as $cache_key ) {
                if ( 0 === strpos( $cache_key, "strings_{$language_code}:" ) ) {
                    unset( $this->runtime_cache['wptranslate_strings'][ $cache_key ] );
                }
            }
        }
    }

    // ------------------------------------------------------------------
    // Full flush.
    // ------------------------------------------------------------------

    /**
     * Flush all caches: runtime, object cache, wpt_ transients, and the
     * wpt_translation_cache database table.
     */
    public function flush_all(): void {
        // Clear all runtime cache buckets.
        $this->runtime_cache       = array();
        $this->loaded_string_groups = array();

        // Flush the WordPress object cache entirely for our groups.
        wp_cache_flush();

        // Delete all wpt_ transients from the database.
        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query(
            "DELETE FROM {$wpdb->options}
             WHERE option_name LIKE '_transient_wpt\_%'
                OR option_name LIKE '_transient_timeout_wpt\_%'"
        );

        // Truncate the translation cache table.
        $table = $wpdb->prefix . 'wpt_translation_cache';
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery, WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->query( "TRUNCATE TABLE {$table}" );
    }

    // ------------------------------------------------------------------
    // Internal helpers.
    // ------------------------------------------------------------------

    /**
     * Build a transient key from a cache key and group.
     *
     * Transient names are limited to 172 characters. We use a short prefix
     * plus an MD5 hash to guarantee uniqueness within the limit.
     *
     * @param string $key   Cache key.
     * @param string $group Cache group.
     *
     * @return string
     */
    private function transient_key( string $key, string $group ): string {
        return 'wpt_' . md5( $group . ':' . $key );
    }
}
