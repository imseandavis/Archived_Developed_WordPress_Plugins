<?php
namespace WPTranslate\Admin;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Admin controller — registers menus, enqueues assets, renders metaboxes,
 * handles AJAX requests, and dispatches to admin page classes.
 */
class AdminController {

    /** @var Plugin */
    private $plugin;

    /** @var string Admin page hook prefix used to scope asset loading. */
    private $hook_prefix = 'toplevel_page_wptranslate';

    /** @var string[] Map of page slugs to their hook suffixes. */
    private $page_hooks = array();

    /**
     * @param Plugin $plugin Main plugin instance.
     */
    /** @var array Page instances (kept alive so their AJAX handlers stay registered). */
    private $pages = array();

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'admin_menu', array( $this, 'register_menu' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_admin_scripts' ) );
        add_action( 'add_meta_boxes', array( $this, 'add_post_metabox' ) );
        add_action( 'admin_notices', array( $this, 'admin_notices' ) );
        $this->handle_ajax_requests();

        // Instantiate page classes early so their AJAX handlers are registered
        // before WordPress processes admin-ajax.php requests.
        $this->pages['languages']    = new Pages\LanguagesPage( $this->plugin );
        $this->pages['strings']      = new Pages\StringTranslationPage( $this->plugin );
        $this->pages['queue']        = new Pages\TranslationQueuePage( $this->plugin );
        $this->pages['translators']  = new Pages\TranslatorsPage( $this->plugin );
        $this->pages['glossary']     = new Pages\GlossaryPage( $this->plugin );
        $this->pages['tools']        = new Pages\ToolsPage( $this->plugin );
    }

    // -------------------------------------------------------------------------
    // Menu Registration
    // -------------------------------------------------------------------------

    /**
     * Register the top-level WPTranslate menu and all sub-pages.
     */
    public function register_menu(): void {
        $this->page_hooks['dashboard'] = add_menu_page(
            __( 'WPTranslate', 'wptranslate' ),
            __( 'WPTranslate', 'wptranslate' ),
            'wptranslate_translate_posts',
            'wptranslate',
            array( $this, 'render_dashboard_page' ),
            'dashicons-translation',
            30
        );

        $this->page_hooks['dashboard_sub'] = add_submenu_page(
            'wptranslate',
            __( 'Dashboard', 'wptranslate' ),
            __( 'Dashboard', 'wptranslate' ),
            'wptranslate_translate_posts',
            'wptranslate',
            array( $this, 'render_dashboard_page' )
        );

        $this->page_hooks['languages'] = add_submenu_page(
            'wptranslate',
            __( 'Languages', 'wptranslate' ),
            __( 'Languages', 'wptranslate' ),
            'wptranslate_manage_languages',
            'wptranslate-languages',
            array( $this, 'render_languages_page' )
        );

        $this->page_hooks['settings'] = add_submenu_page(
            'wptranslate',
            __( 'Translation Settings', 'wptranslate' ),
            __( 'Translation Settings', 'wptranslate' ),
            'wptranslate_manage_settings',
            'wptranslate-settings',
            array( $this, 'render_settings_page' )
        );

        $this->page_hooks['string_translation'] = add_submenu_page(
            'wptranslate',
            __( 'String Translation', 'wptranslate' ),
            __( 'String Translation', 'wptranslate' ),
            'wptranslate_translate_posts',
            'wptranslate-strings',
            array( $this, 'render_string_translation_page' )
        );

        $this->page_hooks['queue'] = add_submenu_page(
            'wptranslate',
            __( 'Translation Queue', 'wptranslate' ),
            __( 'Translation Queue', 'wptranslate' ),
            'wptranslate_translate_posts',
            'wptranslate-queue',
            array( $this, 'render_queue_page' )
        );

        // Translators page — only if translator workflow is enabled.
        if ( get_option( 'wptranslate_enable_translator_workflow', false ) ) {
            $this->page_hooks['translators'] = add_submenu_page(
                'wptranslate',
                __( 'Translators', 'wptranslate' ),
                __( 'Translators', 'wptranslate' ),
                'wptranslate_manage_translators',
                'wptranslate-translators',
                array( $this, 'render_translators_page' )
            );
        }

        $this->page_hooks['glossary'] = add_submenu_page(
            'wptranslate',
            __( 'Glossary', 'wptranslate' ),
            __( 'Glossary', 'wptranslate' ),
            'wptranslate_manage_glossary',
            'wptranslate-glossary',
            array( $this, 'render_glossary_page' )
        );

        $this->page_hooks['tools'] = add_submenu_page(
            'wptranslate',
            __( 'Tools', 'wptranslate' ),
            __( 'Tools', 'wptranslate' ),
            'wptranslate_manage_settings',
            'wptranslate-tools',
            array( $this, 'render_tools_page' )
        );
    }

    // -------------------------------------------------------------------------
    // Page Renderers (delegate to page classes)
    // -------------------------------------------------------------------------

    public function render_dashboard_page(): void {
        $page = new Pages\DashboardPage( $this->plugin );
        $page->render();
    }

    public function render_languages_page(): void {
        $this->pages['languages']->render();
    }

    /**
     * Register all plugin settings during admin_init.
     * Must run early so options.php knows which options are allowed.
     */
    public function register_settings(): void {
        $settings_page = new Pages\SettingsPage( $this->plugin );
        $settings_page->register_settings();
    }

    public function render_settings_page(): void {
        $page = new Pages\SettingsPage( $this->plugin );
        $page->render();
    }

    public function render_string_translation_page(): void {
        $this->pages['strings']->render();
    }

    public function render_queue_page(): void {
        $this->pages['queue']->render();
    }

    public function render_translators_page(): void {
        $this->pages['translators']->render();
    }

    public function render_glossary_page(): void {
        $this->pages['glossary']->render();
    }

    public function render_tools_page(): void {
        $page = $this->pages['tools'];
        $page->render();
    }

    // -------------------------------------------------------------------------
    // Asset Enqueuing
    // -------------------------------------------------------------------------

    /**
     * Enqueue admin CSS and JS only on WPTranslate pages.
     *
     * @param string $hook The current admin page hook suffix.
     */
    public function enqueue_admin_scripts( string $hook ): void {
        // Only load on our own pages.
        $is_our_page = false;
        foreach ( $this->page_hooks as $page_hook ) {
            if ( $hook === $page_hook ) {
                $is_our_page = true;
                break;
            }
        }

        // Also load on post edit screens (for the metabox).
        $screen = get_current_screen();
        $enabled_post_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );
        $is_post_edit = $screen && 'post' === $screen->base && in_array( $screen->post_type, $enabled_post_types, true );

        if ( ! $is_our_page && ! $is_post_edit ) {
            return;
        }

        // Admin CSS.
        wp_enqueue_style(
            'wptranslate-admin',
            WPTRANSLATE_PLUGIN_URL . 'assets/admin/css/admin.css',
            array(),
            WPTRANSLATE_VERSION
        );

        // Admin JS.
        wp_enqueue_script(
            'wptranslate-admin',
            WPTRANSLATE_PLUGIN_URL . 'assets/admin/js/admin.js',
            array( 'jquery', 'wp-util' ),
            WPTRANSLATE_VERSION,
            true
        );

        wp_localize_script( 'wptranslate-admin', 'wptranslateAdmin', array(
            'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
            'restUrl'   => rest_url( 'wptranslate/v1/' ),
            'adminUrl'  => admin_url(),
            'nonce'     => wp_create_nonce( 'wptranslate_admin' ),
            'restNonce' => wp_create_nonce( 'wp_rest' ),
            'i18n'      => array(
                'translating'         => __( 'Translating...', 'wptranslate' ),
                'view_queue'          => __( 'View Translation Queue', 'wptranslate' ),
                'translated'          => __( 'Translated', 'wptranslate' ),
                'translate'           => __( 'Translate', 'wptranslate' ),
                'edit'                => __( 'Edit', 'wptranslate' ),
                'error'               => __( 'An error occurred. Please try again.', 'wptranslate' ),
                'confirm_delete'      => __( 'Are you sure you want to delete this?', 'wptranslate' ),
                'saving'              => __( 'Saving...', 'wptranslate' ),
                'saved'               => __( 'Saved', 'wptranslate' ),
                'save'                => __( 'Save', 'wptranslate' ),
                'confirm_bulk'        => __( 'This will translate all untranslated content for the selected language. Continue?', 'wptranslate' ),
                'validating'          => __( 'Validating...', 'wptranslate' ),
                'validate'            => __( 'Validate', 'wptranslate' ),
                'valid'               => __( 'Valid', 'wptranslate' ),
                'invalid'             => __( 'Invalid', 'wptranslate' ),
                'select_language'     => __( 'Please select a language.', 'wptranslate' ),
                'select_translator'   => __( 'Please select a translator.', 'wptranslate' ),
                'importing'           => __( 'Importing...', 'wptranslate' ),
                'import'              => __( 'Import', 'wptranslate' ),
                'import_complete'     => __( 'Import complete!', 'wptranslate' ),
                'fill_required'       => __( 'Please fill in all required fields.', 'wptranslate' ),
                'confirm_remove_lang' => __( 'Are you sure you want to remove this language? Existing translations will not be deleted.', 'wptranslate' ),
                'revision_feedback'   => __( 'Please describe what needs to be revised:', 'wptranslate' ),
                'complete'            => __( 'Complete!', 'wptranslate' ),
                'ai_draft'            => __( 'AI Draft', 'wptranslate' ),
                'loading'             => __( 'Loading...', 'wptranslate' ),
                'confirm_cancel'      => __( 'Are you sure you want to cancel this job?', 'wptranslate' ),
                'retrying'            => __( 'Retrying...', 'wptranslate' ),
                'cancelling'          => __( 'Cancelling...', 'wptranslate' ),
                'yes'                 => __( 'Yes', 'wptranslate' ),
                'no'                  => __( 'No', 'wptranslate' ),
            ),
            'wizard' => array(
                'has_languages' => count( $this->plugin->get_language_manager()->get_active_languages() ) > 1,
                'has_api_key'   => ! empty( get_option( 'wptranslate_claude_api_key' ) ) || ! empty( get_option( 'wptranslate_openai_api_key' ) ) || ! empty( get_option( 'wptranslate_deepl_api_key' ) ),
                'has_post_types' => ! empty( get_option( 'wptranslate_post_types', array() ) ),
                'dismissed'     => (bool) get_user_meta( get_current_user_id(), '_wptranslate_wizard_dismissed', true ),
            ),
        ) );

        // Sortable for language reordering.
        if ( $is_our_page ) {
            wp_enqueue_script( 'jquery-ui-sortable' );
        }
    }

    // -------------------------------------------------------------------------
    // Post Edit Metabox
    // -------------------------------------------------------------------------

    /**
     * Register the translation metabox on enabled post type edit screens.
     */
    public function add_post_metabox(): void {
        $enabled_post_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );

        foreach ( $enabled_post_types as $post_type ) {
            add_meta_box(
                'wptranslate_translations',
                __( 'WPTranslate', 'wptranslate' ),
                array( $this, 'render_post_metabox' ),
                $post_type,
                'side',
                'high'
            );
        }
    }

    /**
     * Render the translation metabox on a post edit screen.
     *
     * Shows per-language translation status with translate/edit/view links.
     *
     * @param \WP_Post $post The current post.
     */
    public function render_post_metabox( $post ): void {
        $translation_manager = $this->plugin->get_translation_manager();
        $language_manager    = $this->plugin->get_language_manager();
        $active_languages    = $language_manager->get_active_languages();
        $post_language       = $translation_manager->get_post_language( $post->ID );
        $default_language    = $language_manager->get_default_language();
        $translations        = $translation_manager->get_all_translations( $post->ID );

        if ( ! $post_language ) {
            $post_language = $default_language;
        }

        wp_nonce_field( 'wptranslate_metabox', 'wptranslate_metabox_nonce' );
        ?>
        <div class="wptranslate-metabox">
            <?php if ( $post_language !== $default_language ) : ?>
                <p class="wptranslate-post-language">
                    <strong><?php esc_html_e( 'Language:', 'wptranslate' ); ?></strong>
                    <?php
                    $lang_data = $language_manager->get_language( $post_language );
                    echo esc_html( $lang_data ? $lang_data['name'] : $post_language );
                    ?>
                </p>
            <?php endif; ?>

            <table class="widefat striped wptranslate-translations-table">
                <thead>
                    <tr>
                        <th><?php esc_html_e( 'Language', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'wptranslate' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    // Determine the source post ID (the original / default language version).
                    $source_post_id = null;
                    if ( $post_language !== $default_language && ! empty( $translations[ $default_language ] ) ) {
                        $source_post_id = $translations[ $default_language ];
                    }

                    foreach ( $active_languages as $lang ) :
                        // Skip the current post's own language.
                        if ( $lang['code'] === $post_language ) {
                            continue;
                        }

                        // Skip the default/source language when viewing a source post —
                        // only show target languages that need translation.
                        if ( $lang['code'] === $default_language && $post_language === $default_language ) {
                            continue;
                        }

                        // If this is a translated post and we're looking at the default/source language,
                        // show it as "Original" with a link back — not as "Not translated".
                        if ( $lang['code'] === $default_language && $post_language !== $default_language ) :
                            $source_id = $source_post_id ?: ( $translations[ $default_language ] ?? null );
                            ?>
                            <tr>
                                <td>
                                    <?php echo esc_html( $lang['name'] ); ?>
                                </td>
                                <td>
                                    <span class="wptranslate-status wptranslate-status--published">
                                        <?php esc_html_e( 'Original', 'wptranslate' ); ?>
                                    </span>
                                </td>
                                <td class="wptranslate-actions">
                                    <?php if ( $source_id ) : ?>
                                        <a href="<?php echo esc_url( get_edit_post_link( $source_id ) ); ?>"
                                           class="button button-small">
                                            <?php esc_html_e( 'Edit Original', 'wptranslate' ); ?>
                                        </a>
                                        <a href="<?php echo esc_url( get_permalink( $source_id ) ); ?>"
                                           class="button button-small" target="_blank">
                                            <?php esc_html_e( 'View', 'wptranslate' ); ?>
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                            <?php
                            continue;
                        endif;

                        $translated_id = $translations[ $lang['code'] ] ?? null;
                        $status        = null;

                        if ( $translated_id ) {
                            $status = $translation_manager->get_translation_status( $translated_id );
                        }

                        $status_label = $this->get_status_label( $status );
                        $status_class = $this->get_status_css_class( $status );

                        // Determine View link: preview for drafts, permalink for published.
                        $translated_post_obj = $translated_id ? get_post( $translated_id ) : null;
                        $is_published = $translated_post_obj && 'publish' === $translated_post_obj->post_status;
                        $view_url     = null;
                        if ( $translated_post_obj ) {
                            $view_url = $is_published
                                ? get_permalink( $translated_id )
                                : get_preview_post_link( $translated_id );
                        }
                    ?>
                    <tr>
                        <td>
                            <?php echo esc_html( $lang['name'] ); ?>
                        </td>
                        <td>
                            <span class="wptranslate-status <?php echo esc_attr( $status_class ); ?>">
                                <?php echo esc_html( $status_label ); ?>
                            </span>
                        </td>
                        <td class="wptranslate-actions">
                            <?php if ( $translated_id ) : ?>
                                <a href="<?php echo esc_url( get_edit_post_link( $translated_id ) ); ?>"
                                   class="button button-small"
                                   title="<?php esc_attr_e( 'Edit translation', 'wptranslate' ); ?>">
                                    <?php esc_html_e( 'Edit', 'wptranslate' ); ?>
                                </a>
                                <?php if ( $view_url ) : ?>
                                    <a href="<?php echo esc_url( $view_url ); ?>"
                                       class="button button-small"
                                       target="_blank"
                                       title="<?php esc_attr_e( 'View translation', 'wptranslate' ); ?>">
                                        <?php esc_html_e( 'View', 'wptranslate' ); ?>
                                    </a>
                                <?php endif; ?>
                                <button type="button"
                                        class="button button-small wptranslate-retranslate"
                                        data-post-id="<?php echo esc_attr( $post->ID ); ?>"
                                        data-lang="<?php echo esc_attr( $lang['code'] ); ?>"
                                        title="<?php esc_attr_e( 'Re-translate from source', 'wptranslate' ); ?>">
                                    <?php echo ( $status && 'needs_update' === $status['status'] )
                                        ? esc_html__( 'Update', 'wptranslate' )
                                        : esc_html__( 'Retranslate', 'wptranslate' ); ?>
                                </button>
                            <?php else : ?>
                                <button type="button"
                                        class="button button-small button-primary wptranslate-translate-btn"
                                        data-post-id="<?php echo esc_attr( $post->ID ); ?>"
                                        data-lang="<?php echo esc_attr( $lang['code'] ); ?>">
                                    <?php esc_html_e( 'Translate', 'wptranslate' ); ?>
                                </button>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>

            <p class="wptranslate-metabox-footer">
                <button type="button"
                        class="button wptranslate-translate-all"
                        data-post-id="<?php echo esc_attr( $post->ID ); ?>">
                    <?php esc_html_e( 'Translate to All Languages', 'wptranslate' ); ?>
                </button>
            </p>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // AJAX Request Handling
    // -------------------------------------------------------------------------

    /**
     * Register all AJAX action handlers.
     */
    public function handle_ajax_requests(): void {
        // Wizard dismiss handler.
        add_action( 'wp_ajax_wptranslate_dismiss_wizard', array( $this, 'ajax_dismiss_wizard' ) );

        // API key validation handler.
        add_action( 'wp_ajax_wptranslate_validate_api_key', array( $this, 'ajax_validate_api_key' ) );

        $ajax_actions = array(
            'wptranslate_translate_post',
            'wptranslate_save_string_translation',
            'wptranslate_get_translation_status',
            'wptranslate_queue_bulk_translate',
            'wptranslate_assign_translation',
            'wptranslate_submit_for_review',
            'wptranslate_approve_translation',
            'wptranslate_request_revision',
        );

        foreach ( $ajax_actions as $action ) {
            $method = str_replace( 'wptranslate_', 'ajax_', $action );
            add_action( "wp_ajax_{$action}", array( $this, $method ) );
        }
    }

    /**
     * AJAX: Translate a single post to a target language.
     */
    public function ajax_translate_post(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_translate_posts' );

        $post_id     = absint( $_POST['post_id'] ?? 0 );
        $target_lang = sanitize_text_field( $_POST['target_lang'] ?? '' );

        if ( ! $post_id || empty( $target_lang ) ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        $result = $this->plugin->get_translation_manager()->translate_post( $post_id, $target_lang, array(
            'force' => ! empty( $_POST['force'] ),
        ) );

        if ( is_wp_error( $result ) ) {
            wp_send_json_error( array( 'message' => $result->get_error_message() ) );
        }

        wp_send_json_success( array(
            'translated_post_id' => $result,
            'edit_url'           => get_edit_post_link( $result, 'raw' ),
            'view_url'           => get_permalink( $result ),
            'message'            => __( 'Post translated successfully.', 'wptranslate' ),
        ) );
    }

    /**
     * AJAX: Save a string translation.
     */
    public function ajax_save_string_translation(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_translate_posts' );

        $original   = sanitize_textarea_field( $_POST['original'] ?? '' );
        $translated = sanitize_textarea_field( $_POST['translated'] ?? '' );
        $language   = sanitize_text_field( $_POST['language'] ?? '' );
        $domain     = sanitize_text_field( $_POST['domain'] ?? 'default' );
        $context    = sanitize_text_field( $_POST['context'] ?? '' );

        if ( empty( $original ) || empty( $language ) ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        $result = $this->plugin->get_string_translation()->save_translation(
            $original,
            $translated,
            $language,
            $domain,
            $context
        );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Failed to save translation.', 'wptranslate' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'String translation saved.', 'wptranslate' ) ) );
    }

    /**
     * AJAX: Get translation status for a post.
     */
    public function ajax_get_translation_status(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_translate_posts' );

        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Missing post ID.', 'wptranslate' ) ) );
        }

        $translation_manager = $this->plugin->get_translation_manager();
        $language_manager    = $this->plugin->get_language_manager();
        $translations        = $translation_manager->get_all_translations( $post_id );
        $active_languages    = $language_manager->get_active_languages();

        $statuses = array();
        foreach ( $active_languages as $lang ) {
            $translated_id = $translations[ $lang['code'] ] ?? null;
            $status = null;
            if ( $translated_id ) {
                $status = $translation_manager->get_translation_status( $translated_id );
            }
            $statuses[ $lang['code'] ] = array(
                'translated_id' => $translated_id,
                'status'        => $status ? $status['status'] : 'not_translated',
                'label'         => $this->get_status_label( $status ),
            );
        }

        wp_send_json_success( array( 'statuses' => $statuses ) );
    }

    /**
     * AJAX: Queue bulk translation jobs.
     */
    public function ajax_queue_bulk_translate(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_translate_posts' );

        $post_ids    = array_map( 'absint', (array) ( $_POST['post_ids'] ?? array() ) );
        $target_lang = sanitize_text_field( $_POST['target_lang'] ?? '' );
        $provider    = sanitize_text_field( $_POST['provider'] ?? '' );

        if ( empty( $post_ids ) || empty( $target_lang ) ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        $translation_manager = $this->plugin->get_translation_manager();
        $default_lang        = $this->plugin->get_language_manager()->get_default_language();
        $batch_ids           = array();

        foreach ( $post_ids as $post_id ) {
            $batch_id = $translation_manager->queue_translation_job( array(
                'element_id'  => $post_id,
                'source_lang' => $default_lang,
                'target_lang' => $target_lang,
                'provider'    => $provider,
                'priority'    => 10,
            ) );
            $batch_ids[] = $batch_id;
        }

        // Trigger queue processing.
        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time(), 'wptranslate_process_queue' );
        }

        wp_send_json_success( array(
            'batch_ids' => $batch_ids,
            'count'     => count( $post_ids ),
            'message'   => sprintf(
                /* translators: %d: number of posts queued */
                __( '%d posts queued for translation.', 'wptranslate' ),
                count( $post_ids )
            ),
        ) );
    }

    /**
     * AJAX: Assign a translation to a translator.
     */
    public function ajax_assign_translation(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_assign_translations' );

        $post_id       = absint( $_POST['post_id'] ?? 0 );
        $translator_id = absint( $_POST['translator_id'] ?? 0 );

        if ( ! $post_id || ! $translator_id ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        $translator = get_userdata( $translator_id );
        if ( ! $translator ) {
            wp_send_json_error( array( 'message' => __( 'Invalid translator.', 'wptranslate' ) ) );
        }

        $this->plugin->get_translation_manager()->set_translation_status( $post_id, 'assigned', array(
            'assigned_to' => $translator_id,
        ) );

        /**
         * Fires when a translation is assigned to a translator.
         *
         * @param int $post_id       The translated post ID.
         * @param int $translator_id The user ID of the translator.
         */
        do_action( 'wptranslate_translation_assigned', $post_id, $translator_id );

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %s: translator display name */
                __( 'Translation assigned to %s.', 'wptranslate' ),
                $translator->display_name
            ),
        ) );
    }

    /**
     * AJAX: Submit a translation for review.
     */
    public function ajax_submit_for_review(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_submit_translations' );

        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Missing post ID.', 'wptranslate' ) ) );
        }

        $this->plugin->get_translation_manager()->set_translation_status( $post_id, 'pending_review', array(
            'translator' => get_current_user_id(),
        ) );

        do_action( 'wptranslate_translation_submitted_for_review', $post_id, get_current_user_id() );

        wp_send_json_success( array(
            'message' => __( 'Translation submitted for review.', 'wptranslate' ),
        ) );
    }

    /**
     * AJAX: Approve a translation.
     */
    public function ajax_approve_translation(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_review_translations' );

        $post_id = absint( $_POST['post_id'] ?? 0 );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Missing post ID.', 'wptranslate' ) ) );
        }

        $this->plugin->get_translation_manager()->set_translation_status( $post_id, 'published', array(
            'reviewed_by' => get_current_user_id(),
        ) );

        // Publish the translated post.
        wp_update_post( array(
            'ID'          => $post_id,
            'post_status' => 'publish',
        ) );

        do_action( 'wptranslate_translation_approved', $post_id, get_current_user_id() );

        wp_send_json_success( array(
            'message' => __( 'Translation approved and published.', 'wptranslate' ),
        ) );
    }

    /**
     * AJAX: Request revision on a translation.
     */
    public function ajax_request_revision(): void {
        $this->verify_ajax_request( 'wptranslate_admin', 'wptranslate_review_translations' );

        $post_id  = absint( $_POST['post_id'] ?? 0 );
        $feedback = sanitize_textarea_field( $_POST['feedback'] ?? '' );

        if ( ! $post_id ) {
            wp_send_json_error( array( 'message' => __( 'Missing post ID.', 'wptranslate' ) ) );
        }

        $this->plugin->get_translation_manager()->set_translation_status( $post_id, 'revision_requested', array(
            'reviewed_by'       => get_current_user_id(),
            'revision_feedback' => $feedback,
        ) );

        do_action( 'wptranslate_translation_revision_requested', $post_id, get_current_user_id(), $feedback );

        wp_send_json_success( array(
            'message' => __( 'Revision requested.', 'wptranslate' ),
        ) );
    }

    /**
     * AJAX: Validate an API key by making a test call to the provider.
     */
    public function ajax_validate_api_key(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $provider_slug = sanitize_text_field( $_POST['provider'] ?? '' );
        $api_key       = sanitize_text_field( $_POST['api_key'] ?? '' );

        if ( empty( $provider_slug ) ) {
            wp_send_json_error( array( 'message' => __( 'No provider specified.', 'wptranslate' ) ) );
        }

        // If no key provided, test the saved (encrypted) key.
        if ( empty( $api_key ) ) {
            $provider = $this->plugin->get_provider_manager()->get_provider( $provider_slug );
            if ( ! $provider ) {
                wp_send_json_error( array( 'message' => __( 'Provider not available.', 'wptranslate' ) ) );
            }
            $valid = $provider->validateApiKey();
        } else {
            // Test the provided key directly against the API.
            $valid = false;
            switch ( $provider_slug ) {
                case 'deepl':
                    $is_free = ( substr( $api_key, -3 ) === ':fx' );
                    $base    = $is_free ? 'https://api-free.deepl.com/v2' : 'https://api.deepl.com/v2';
                    $resp    = wp_remote_get( $base . '/usage', array(
                        'headers' => array( 'Authorization' => 'DeepL-Auth-Key ' . $api_key ),
                        'timeout' => 10,
                    ) );
                    $valid = ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp );
                    break;
                case 'claude':
                    $resp = wp_remote_post( 'https://api.anthropic.com/v1/messages', array(
                        'headers' => array(
                            'x-api-key'         => $api_key,
                            'anthropic-version'  => '2023-06-01',
                            'content-type'       => 'application/json',
                        ),
                        'body'    => wp_json_encode( array(
                            'model'      => 'claude-haiku-4-5-20251001',
                            'max_tokens' => 1,
                            'messages'   => array( array( 'role' => 'user', 'content' => 'Hi' ) ),
                        ) ),
                        'timeout' => 10,
                    ) );
                    $code = wp_remote_retrieve_response_code( $resp );
                    $valid = ! is_wp_error( $resp ) && ( 200 === $code || 429 === $code );
                    break;
                case 'openai':
                    $resp = wp_remote_get( 'https://api.openai.com/v1/models', array(
                        'headers' => array( 'Authorization' => 'Bearer ' . $api_key ),
                        'timeout' => 10,
                    ) );
                    $valid = ! is_wp_error( $resp ) && 200 === wp_remote_retrieve_response_code( $resp );
                    break;
            }
        }

        if ( $valid ) {
            wp_send_json_success( array( 'message' => __( 'API key is valid!', 'wptranslate' ) ) );
        } else {
            wp_send_json_error( array( 'message' => __( 'API key validation failed. Please check the key and try again.', 'wptranslate' ) ) );
        }
    }

    /**
     * AJAX: Dismiss the setup wizard.
     */
    public function ajax_dismiss_wizard(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        update_user_meta( get_current_user_id(), '_wptranslate_wizard_dismissed', 1 );
        wp_send_json_success();
    }

    /**
     * Render the branded page header used on all WPTranslate admin pages.
     *
     * @param string $title Page title.
     */
    public static function render_page_header( string $title ): void {
        ?>
        <div class="wptranslate-page-header">
            <div class="wptranslate-page-header__left">
                <span class="dashicons dashicons-translation wptranslate-page-header__icon"></span>
                <h1 class="wptranslate-page-header__title"><?php echo esc_html( $title ); ?></h1>
            </div>
            <div class="wptranslate-page-header__right">
                <span class="wptranslate-page-header__version">v<?php echo esc_html( WPTRANSLATE_VERSION ); ?></span>
            </div>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Admin Notices
    // -------------------------------------------------------------------------

    /**
     * Display admin notices for WPTranslate.
     */
    public function admin_notices(): void {
        $screen = get_current_screen();
        if ( ! $screen ) {
            return;
        }

        // Show "continue setup" banner on WPTranslate pages when setup is incomplete.
        if ( false !== strpos( $screen->id ?? '', 'wptranslate' ) && 'toplevel_page_wptranslate' !== $screen->id ) {
            $languages = $this->plugin->get_language_manager()->get_active_languages();
            $default   = $this->plugin->get_language_manager()->get_default_language();
            $target_count = 0;
            foreach ( $languages as $l ) {
                if ( $l['code'] !== $default ) {
                    $target_count++;
                }
            }
            $has_api = ! empty( get_option( 'wptranslate_claude_api_key' ) )
                    || ! empty( get_option( 'wptranslate_openai_api_key' ) )
                    || ! empty( get_option( 'wptranslate_deepl_api_key' ) );
            $has_pt  = ! empty( get_option( 'wptranslate_post_types', array() ) );
            $dismissed = (bool) get_user_meta( get_current_user_id(), '_wptranslate_wizard_dismissed', true );

            if ( ! ( $target_count > 0 && $has_api && $has_pt ) && ! $dismissed ) {
                $done = 0;
                $total = 3;
                if ( $target_count > 0 ) $done++;
                if ( $has_api ) $done++;
                if ( $has_pt ) $done++;

                printf(
                    '<div class="notice notice-info" style="border-left-color: var(--wpt-primary, #4F46E5); display: flex; align-items: center; justify-content: space-between;"><p><strong>%s</strong> %s</p><p><a href="%s" class="button button-small">%s</a></p></div>',
                    esc_html__( 'Setup Progress:', 'wptranslate' ),
                    sprintf(
                        /* translators: 1: completed steps, 2: total steps */
                        esc_html__( '%1$d of %2$d steps complete. Continue setting up WPTranslate.', 'wptranslate' ),
                        $done,
                        $total
                    ),
                    esc_url( admin_url( 'admin.php?page=wptranslate' ) ),
                    esc_html__( 'Back to Setup Wizard', 'wptranslate' )
                );
            }
        }

        // Pending review count badge.
        if ( current_user_can( 'wptranslate_review_translations' ) ) {
            $pending_count = $this->get_pending_review_count();
            if ( $pending_count > 0 ) {
                printf(
                    '<div class="notice notice-info is-dismissible"><p>%s <a href="%s">%s</a></p></div>',
                    sprintf(
                        /* translators: %d: number of translations pending review */
                        esc_html__( 'WPTranslate: %d translations are pending review.', 'wptranslate' ),
                        $pending_count
                    ),
                    esc_url( admin_url( 'admin.php?page=wptranslate-queue&status=pending_review' ) ),
                    esc_html__( 'Review now', 'wptranslate' )
                );
            }
        }

        // Needs-update notifications.
        if ( current_user_can( 'wptranslate_translate_posts' ) ) {
            $needs_update_count = $this->get_needs_update_count();
            if ( $needs_update_count > 0 ) {
                printf(
                    '<div class="notice notice-warning is-dismissible"><p>%s <a href="%s">%s</a></p></div>',
                    sprintf(
                        /* translators: %d: number of translations needing update */
                        esc_html__( 'WPTranslate: %d translations need updating (source content changed).', 'wptranslate' ),
                        $needs_update_count
                    ),
                    esc_url( admin_url( 'admin.php?page=wptranslate-queue&status=needs_update' ) ),
                    esc_html__( 'View details', 'wptranslate' )
                );
            }
        }
    }

    // -------------------------------------------------------------------------
    // Helper Methods
    // -------------------------------------------------------------------------

    /**
     * Verify nonce and capability for an AJAX request.
     *
     * @param string $nonce_action The nonce action to verify.
     * @param string $capability   The required capability.
     */
    private function verify_ajax_request( string $nonce_action, string $capability ): void {
        if ( ! check_ajax_referer( $nonce_action, 'nonce', false ) ) {
            wp_send_json_error( array( 'message' => __( 'Security check failed.', 'wptranslate' ) ), 403 );
        }

        if ( ! current_user_can( $capability ) ) {
            wp_send_json_error( array( 'message' => __( 'You do not have permission to perform this action.', 'wptranslate' ) ), 403 );
        }
    }

    /**
     * Get a human-readable label for a translation status.
     *
     * @param array|null $status Translation status array.
     * @return string
     */
    private function get_status_label( ?array $status ): string {
        if ( ! $status ) {
            return __( 'Not translated', 'wptranslate' );
        }

        return self::format_status_label( $status['status'] );
    }

    /**
     * Convert a status slug to a human-readable label.
     *
     * Centralised helper used by metaboxes, dashboard, queue pages, etc.
     *
     * @param string $status Status slug (e.g. 'ai_draft', 'needs_update').
     * @return string
     */
    public static function format_status_label( string $status ): string {
        $labels = array(
            'ai_draft'           => __( 'AI Draft', 'wptranslate' ),
            'needs_update'       => __( 'Needs Update', 'wptranslate' ),
            'assigned'           => __( 'Assigned', 'wptranslate' ),
            'in_progress'        => __( 'In Progress', 'wptranslate' ),
            'pending_review'     => __( 'Pending Review', 'wptranslate' ),
            'revision_requested' => __( 'Revision Requested', 'wptranslate' ),
            'published'          => __( 'Published', 'wptranslate' ),
            'completed'          => __( 'Completed', 'wptranslate' ),
            'pending'            => __( 'Pending', 'wptranslate' ),
            'failed'             => __( 'Failed', 'wptranslate' ),
            'cancelled'          => __( 'Cancelled', 'wptranslate' ),
            'draft'              => __( 'Draft', 'wptranslate' ),
        );

        return $labels[ $status ] ?? ucwords( str_replace( '_', ' ', $status ) );
    }

    /**
     * Get a CSS class for a translation status.
     *
     * @param array|null $status Translation status array.
     * @return string
     */
    private function get_status_css_class( ?array $status ): string {
        if ( ! $status ) {
            return 'wptranslate-status--none';
        }

        return 'wptranslate-status--' . sanitize_html_class( $status['status'] );
    }

    /**
     * Get the count of translations pending review.
     *
     * @return int
     */
    private function get_pending_review_count(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_status';

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status = %s",
                'pending_review'
            )
        );

        return (int) $count;
    }

    /**
     * Get the count of translations needing update.
     *
     * @return int
     */
    private function get_needs_update_count(): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_status';

        $count = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT COUNT(*) FROM {$table} WHERE status = %s",
                'needs_update'
            )
        );

        return (int) $count;
    }
}
