<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Glossary admin page -- manage translation glossary terms, auto-generated
 * suggestions from corrections, and import/export glossary data.
 */
class GlossaryPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_add_glossary_term', array( $this, 'ajax_add_glossary_term' ) );
        add_action( 'wp_ajax_wptranslate_delete_glossary_term', array( $this, 'ajax_delete_glossary_term' ) );
        add_action( 'wp_ajax_wptranslate_confirm_glossary_suggestion', array( $this, 'ajax_confirm_glossary_suggestion' ) );
        add_action( 'wp_ajax_wptranslate_dismiss_glossary_suggestion', array( $this, 'ajax_dismiss_glossary_suggestion' ) );
        add_action( 'wp_ajax_wptranslate_export_glossary', array( $this, 'ajax_export_glossary' ) );
        add_action( 'wp_ajax_wptranslate_import_glossary', array( $this, 'ajax_import_glossary' ) );
    }

    /**
     * Render the glossary page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $language_manager = $this->plugin->get_language_manager();
        $languages        = $language_manager->get_active_languages();
        $default_language = $language_manager->get_default_language();

        global $wpdb;
        $glossary_table    = $wpdb->prefix . 'wpt_translation_glossary';
        $corrections_table = $wpdb->prefix . 'wpt_translation_corrections';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $glossary_terms = $wpdb->get_results(
            "SELECT * FROM {$glossary_table} WHERE confirmed = 1 ORDER BY source_lang, target_lang, term LIMIT 200",
            ARRAY_A
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $glossary_suggestions = $wpdb->get_results(
            "SELECT * FROM {$glossary_table} WHERE auto_generated = 1 AND confirmed = 0 ORDER BY created_at DESC LIMIT 50",
            ARRAY_A
        );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $top_corrections = $wpdb->get_results(
            "SELECT source_text, corrected_text, source_lang, target_lang, correction_type, COUNT(*) as cnt
             FROM {$corrections_table}
             WHERE created_at > DATE_SUB(NOW(), INTERVAL 6 MONTH)
             GROUP BY source_text, corrected_text, source_lang, target_lang, correction_type
             ORDER BY cnt DESC LIMIT 20",
            ARRAY_A
        );

        wp_nonce_field( 'wptranslate_admin', 'wptranslate_glossary_nonce' );
        ?>
        <div class="wrap wptranslate-glossary">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'Glossary', 'wptranslate' ) ); ?>

            <div class="wptranslate-card" style="margin-bottom: 20px;">
                <p style="font-size: 14px; margin: 0 0 10px;">
                    <?php esc_html_e( 'The glossary ensures consistent translations of key terms across all your content. When a term is added here, the AI translator is instructed to always use your preferred translation instead of guessing. This is essential for brand names, industry jargon, and domain-specific terminology.', 'wptranslate' ); ?>
                </p>
                <p class="description" style="margin: 0;">
                    <strong><?php esc_html_e( 'How it works:', 'wptranslate' ); ?></strong>
                    <?php esc_html_e( 'Terms you add here are automatically included in every translation prompt sent to the AI. For example, adding "tie" with the translation "Seilknoten (not Krawatte)" for German ensures the AI never mistranslates "tie" as "necktie" on your shibari instruction site.', 'wptranslate' ); ?>
                </p>
            </div>

            <?php if ( ! empty( $glossary_suggestions ) ) : ?>
            <!-- Auto-Generated Glossary Suggestions -->
            <div class="notice notice-warning wptranslate-glossary-suggestions" style="margin: 20px 0;">
                <p><strong><?php esc_html_e( 'Auto-Generated Glossary Suggestions', 'wptranslate' ); ?></strong></p>
                <p class="description"><?php esc_html_e( 'These terms were repeatedly corrected by translators and may warrant a glossary entry.', 'wptranslate' ); ?></p>
                <table class="widefat fixed">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Term', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Suggested Translation', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Languages', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'wptranslate' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $glossary_suggestions as $s ) : ?>
                        <tr data-suggestion-id="<?php echo esc_attr( $s['id'] ); ?>">
                            <td><strong><?php echo esc_html( $s['term'] ); ?></strong></td>
                            <td><?php echo esc_html( $s['translation'] ); ?></td>
                            <td><?php echo esc_html( strtoupper( $s['source_lang'] ) . ' -> ' . strtoupper( $s['target_lang'] ) ); ?></td>
                            <td>
                                <button type="button" class="button button-small button-primary wptranslate-confirm-glossary-suggestion" data-id="<?php echo esc_attr( $s['id'] ); ?>">
                                    <?php esc_html_e( 'Confirm', 'wptranslate' ); ?>
                                </button>
                                <button type="button" class="button button-small wptranslate-dismiss-glossary-suggestion" data-id="<?php echo esc_attr( $s['id'] ); ?>">
                                    <?php esc_html_e( 'Dismiss', 'wptranslate' ); ?>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

            <!-- Add Glossary Term -->
            <div class="wptranslate-card" style="margin-bottom: 20px;">
                <h2><span class="dashicons dashicons-book"></span> <?php esc_html_e( 'Add Glossary Term', 'wptranslate' ); ?></h2>
                <div class="wptranslate-glossary-add-form">
                    <div class="wptranslate-form-row">
                        <label for="wptranslate-glossary-term"><?php esc_html_e( 'Source Term', 'wptranslate' ); ?></label>
                        <input type="text" id="wptranslate-glossary-term" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., tie, bondage, hemp', 'wptranslate' ); ?>" />
                    </div>
                    <div class="wptranslate-form-row">
                        <label for="wptranslate-glossary-translation"><?php esc_html_e( 'Translation', 'wptranslate' ); ?></label>
                        <input type="text" id="wptranslate-glossary-translation" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., Seilknoten (not Krawatte)', 'wptranslate' ); ?>" />
                    </div>
                    <div class="wptranslate-form-row">
                        <label for="wptranslate-glossary-notes"><?php esc_html_e( 'Notes / Context', 'wptranslate' ); ?></label>
                        <input type="text" id="wptranslate-glossary-notes" class="regular-text" placeholder="<?php esc_attr_e( 'e.g., In the context of rope work, not clothing', 'wptranslate' ); ?>" />
                    </div>
                    <div class="wptranslate-form-row">
                        <label for="wptranslate-glossary-source-lang"><?php esc_html_e( 'Source Language', 'wptranslate' ); ?></label>
                        <select id="wptranslate-glossary-source-lang">
                            <?php foreach ( $languages as $lang ) : ?>
                                <option value="<?php echo esc_attr( $lang['code'] ); ?>" <?php selected( $lang['code'], $default_language ); ?>>
                                    <?php echo esc_html( $lang['name'] ); ?>
                                </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="wptranslate-form-row">
                        <label for="wptranslate-glossary-target-lang"><?php esc_html_e( 'Target Language', 'wptranslate' ); ?></label>
                        <select id="wptranslate-glossary-target-lang">
                            <?php foreach ( $languages as $lang ) :
                                if ( $lang['code'] === $default_language ) { continue; }
                            ?>
                                <option value="<?php echo esc_attr( $lang['code'] ); ?>"><?php echo esc_html( $lang['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="wptranslate-form-row">
                        <label><input type="checkbox" id="wptranslate-glossary-case-sensitive" /> <?php esc_html_e( 'Case-sensitive', 'wptranslate' ); ?></label>
                        <label><input type="checkbox" id="wptranslate-glossary-exact-match" /> <?php esc_html_e( 'Exact match', 'wptranslate' ); ?></label>
                    </div>
                    <button type="button" class="button button-primary" id="wptranslate-add-glossary-term">
                        <?php esc_html_e( 'Add Term', 'wptranslate' ); ?>
                    </button>
                </div>

                <!-- Import / Export -->
                <div class="wptranslate-glossary-io" style="margin-top: 16px; padding-top: 16px; border-top: 1px solid #ddd;">
                    <button type="button" class="button" id="wptranslate-export-glossary-btn">
                        <span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Export CSV', 'wptranslate' ); ?>
                    </button>
                    <button type="button" class="button" id="wptranslate-import-glossary-btn">
                        <span class="dashicons dashicons-upload"></span> <?php esc_html_e( 'Import CSV', 'wptranslate' ); ?>
                    </button>
                    <input type="file" id="wptranslate-glossary-import-file" accept=".csv,.json" style="display:none;" />
                </div>
            </div>

            <!-- Glossary Terms Table -->
            <div class="wptranslate-card">
                <h2><span class="dashicons dashicons-list-view"></span> <?php esc_html_e( 'Glossary Terms', 'wptranslate' ); ?></h2>
                <?php if ( ! empty( $glossary_terms ) ) : ?>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Term', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Translation', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Languages', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Options', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Actions', 'wptranslate' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $glossary_terms as $term ) : ?>
                        <tr data-term-id="<?php echo esc_attr( $term['id'] ); ?>">
                            <td><strong><?php echo esc_html( $term['term'] ); ?></strong></td>
                            <td><?php echo esc_html( $term['translation'] ); ?></td>
                            <td><?php echo esc_html( strtoupper( $term['source_lang'] ) . ' -> ' . strtoupper( $term['target_lang'] ) ); ?></td>
                            <td>
                                <?php if ( ! empty( $term['case_sensitive'] ) ) : ?>
                                    <span class="wptranslate-badge"><?php esc_html_e( 'CS', 'wptranslate' ); ?></span>
                                <?php endif; ?>
                                <?php if ( ! empty( $term['exact_match'] ) ) : ?>
                                    <span class="wptranslate-badge"><?php esc_html_e( 'EM', 'wptranslate' ); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <button type="button" class="button button-small wptranslate-delete-glossary-term" data-id="<?php echo esc_attr( $term['id'] ); ?>">
                                    <?php esc_html_e( 'Delete', 'wptranslate' ); ?>
                                </button>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
                <?php else : ?>
                    <div class="wptranslate-empty-state">
                        <div class="wptranslate-empty-state__icon">
                            <span class="dashicons dashicons-book"></span>
                        </div>
                        <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No Glossary Terms', 'wptranslate' ); ?></h3>
                        <p class="wptranslate-empty-state__description"><?php esc_html_e( 'No glossary terms yet. Add terms above to ensure consistent translation.', 'wptranslate' ); ?></p>
                    </div>
                <?php endif; ?>
            </div>

            <?php if ( ! empty( $top_corrections ) ) : ?>
            <!-- Correction Dashboard -->
            <div class="wptranslate-card" style="margin-top: 20px;">
                <h2><span class="dashicons dashicons-edit"></span> <?php esc_html_e( 'Correction Dashboard', 'wptranslate' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Most frequently corrected terms over the last 6 months. High-count items are candidates for glossary entries.', 'wptranslate' ); ?></p>
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th><?php esc_html_e( 'Original Term', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Corrected To', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Languages', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Type', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Count', 'wptranslate' ); ?></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ( $top_corrections as $c ) : ?>
                        <tr>
                            <td><?php echo esc_html( wp_trim_words( $c['source_text'], 10 ) ); ?></td>
                            <td><?php echo esc_html( wp_trim_words( $c['corrected_text'], 10 ) ); ?></td>
                            <td><?php echo esc_html( strtoupper( $c['source_lang'] ) . ' -> ' . strtoupper( $c['target_lang'] ) ); ?></td>
                            <td><?php echo esc_html( ucfirst( $c['correction_type'] ) ); ?></td>
                            <td><strong><?php echo esc_html( $c['cnt'] ); ?></strong></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
            <?php endif; ?>

        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // AJAX Handlers
    // -------------------------------------------------------------------------

    public function ajax_add_glossary_term(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $term = sanitize_text_field( $_POST['term'] ?? '' );
        $tran = sanitize_text_field( $_POST['translation'] ?? '' );
        $sl   = sanitize_text_field( $_POST['source_lang'] ?? '' );
        $tl   = sanitize_text_field( $_POST['target_lang'] ?? '' );

        if ( empty( $term ) || empty( $sl ) || empty( $tl ) ) {
            wp_send_json_error( array( 'message' => __( 'Term and languages are required.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $wpdb->insert( $wpdb->prefix . 'wpt_translation_glossary', array(
            'term'           => $term,
            'translation'    => $tran,
            'source_lang'    => $sl,
            'target_lang'    => $tl,
            'case_sensitive' => ! empty( $_POST['case_sensitive'] ) ? 1 : 0,
            'exact_match'    => ! empty( $_POST['exact_match'] ) ? 1 : 0,
            'confirmed'      => 1,
            'auto_generated' => 0,
            'created_at'     => current_time( 'mysql' ),
        ) );

        wp_send_json_success( array( 'message' => __( 'Term added.', 'wptranslate' ), 'id' => $wpdb->insert_id ) );
    }

    public function ajax_delete_glossary_term(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $id = absint( $_POST['id'] ?? 0 );
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'wpt_translation_glossary', array( 'id' => $id ), array( '%d' ) );
        wp_send_json_success( array( 'message' => __( 'Term deleted.', 'wptranslate' ) ) );
    }

    public function ajax_confirm_glossary_suggestion(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $id = absint( $_POST['id'] ?? 0 );
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $wpdb->update( $wpdb->prefix . 'wpt_translation_glossary', array( 'confirmed' => 1 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
        wp_send_json_success( array( 'message' => __( 'Suggestion confirmed.', 'wptranslate' ) ) );
    }

    public function ajax_dismiss_glossary_suggestion(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $id = absint( $_POST['id'] ?? 0 );
        if ( ! $id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $wpdb->delete( $wpdb->prefix . 'wpt_translation_glossary', array( 'id' => $id ), array( '%d' ) );
        wp_send_json_success( array( 'message' => __( 'Suggestion dismissed.', 'wptranslate' ) ) );
    }

    public function ajax_export_glossary(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        global $wpdb;
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $terms = $wpdb->get_results( "SELECT * FROM {$wpdb->prefix}wpt_translation_glossary WHERE confirmed = 1 ORDER BY term", ARRAY_A );
        $lines = array( 'term,translation,source_lang,target_lang,case_sensitive,exact_match' );
        foreach ( $terms as $t ) {
            $lines[] = sprintf(
                '"%s","%s","%s","%s",%d,%d',
                str_replace( '"', '""', $t['term'] ),
                str_replace( '"', '""', $t['translation'] ),
                $t['source_lang'],
                $t['target_lang'],
                $t['case_sensitive'],
                $t['exact_match']
            );
        }
        wp_send_json_success( array( 'content' => implode( "\n", $lines ), 'filename' => 'wptranslate-glossary.csv' ) );
    }

    public function ajax_import_glossary(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_glossary' ) && ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        if ( empty( $_FILES['glossary_file'] ) || ! empty( $_FILES['glossary_file']['error'] ) ) {
            wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'wptranslate' ) ) );
        }

        $content = file_get_contents( $_FILES['glossary_file']['tmp_name'] ); // phpcs:ignore
        $lines   = explode( "\n", $content );
        array_shift( $lines ); // Remove header row.

        global $wpdb;
        $gt = $wpdb->prefix . 'wpt_translation_glossary';
        $n  = 0;

        foreach ( $lines as $l ) {
            $l = trim( $l );
            if ( empty( $l ) ) {
                continue;
            }
            $c = str_getcsv( $l );
            if ( count( $c ) < 4 ) {
                continue;
            }
            $wpdb->insert( $gt, array(
                'term'           => sanitize_text_field( $c[0] ),
                'translation'    => sanitize_text_field( $c[1] ),
                'source_lang'    => sanitize_text_field( $c[2] ),
                'target_lang'    => sanitize_text_field( $c[3] ),
                'case_sensitive' => absint( $c[4] ?? 0 ),
                'exact_match'    => absint( $c[5] ?? 0 ),
                'confirmed'      => 1,
                'auto_generated' => 0,
                'created_at'     => current_time( 'mysql' ),
            ) );
            $n++;
        }

        wp_send_json_success( array( 'message' => sprintf( __( '%d glossary terms imported.', 'wptranslate' ), $n ) ) );
    }
}
