<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Tools admin page -- bulk translate, sync status, import from TranslatePress,
 * import/export CSV/JSON, database maintenance, and diagnostics.
 */
class ToolsPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_bulk_translate_all', array( $this, 'ajax_bulk_translate_all' ) );
        add_action( 'wp_ajax_wptranslate_sync_status', array( $this, 'ajax_sync_status' ) );
        add_action( 'wp_ajax_wptranslate_import_translatepress', array( $this, 'ajax_import_translatepress' ) );
        add_action( 'wp_ajax_wptranslate_export_translations', array( $this, 'ajax_export_translations' ) );
        add_action( 'wp_ajax_wptranslate_import_translations', array( $this, 'ajax_import_translations' ) );
        add_action( 'wp_ajax_wptranslate_clean_orphans', array( $this, 'ajax_clean_orphans' ) );
        add_action( 'wp_ajax_wptranslate_rebuild_cache', array( $this, 'ajax_rebuild_cache' ) );
    }

    /**
     * Render the tools page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $language_manager = $this->plugin->get_language_manager();
        $languages        = $language_manager->get_active_languages();
        $default_language = $language_manager->get_default_language();
        $has_tp           = $this->detect_translatepress();

        wp_nonce_field( 'wptranslate_admin', 'wptranslate_tools_nonce' );
        ?>
        <div class="wrap wptranslate-tools">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'WPTranslate Tools', 'wptranslate' ) ); ?>

            <div class="wptranslate-tools-grid">

                <!-- Bulk Translate -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-translation"></span> <?php esc_html_e( 'Bulk Translate', 'wptranslate' ); ?></h2>
                    <p><?php esc_html_e( 'Translate all untranslated content for a specific language.', 'wptranslate' ); ?></p>
                    <div style="display: flex; flex-direction: column; gap: 8px;">
                        <div style="display: flex; gap: 8px;">
                            <select id="wptranslate-bulk-lang" style="flex: 1;">
                                <option value=""><?php esc_html_e( 'Select Language', 'wptranslate' ); ?></option>
                                <?php foreach ( $languages as $lang ) :
                                    if ( $lang['code'] === $default_language ) { continue; }
                                ?>
                                    <option value="<?php echo esc_attr( $lang['code'] ); ?>">
                                        <?php echo esc_html( ( $lang['flag'] ?? '' ) . ' ' . $lang['name'] ); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                            <select id="wptranslate-bulk-post-type" style="flex: 1;">
                                <?php foreach ( get_option( 'wptranslate_post_types', array( 'post', 'page' ) ) as $pt ) : ?>
                                    <option value="<?php echo esc_attr( $pt ); ?>"><?php echo esc_html( ucfirst( $pt ) ); ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <button type="button" class="button button-primary" id="wptranslate-bulk-translate-btn" style="width: 100%;">
                            <?php esc_html_e( 'Start Bulk Translation', 'wptranslate' ); ?>
                        </button>
                        <div id="wptranslate-bulk-progress" style="display:none;">
                            <div class="wptranslate-progress-bar"><div class="wptranslate-progress-bar__fill"></div></div>
                            <span class="wptranslate-progress-text"></span>
                        </div>
                    </div>
                </div>

                <!-- Sync Translation Status -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-update"></span> <?php esc_html_e( 'Sync Translation Status', 'wptranslate' ); ?></h2>
                    <p><?php esc_html_e( 'Recalculate translation status for all posts. Useful after manual database changes.', 'wptranslate' ); ?></p>
                    <button type="button" class="button" id="wptranslate-sync-status-btn">
                        <?php esc_html_e( 'Sync Now', 'wptranslate' ); ?>
                    </button>
                </div>

                <!-- Import from TranslatePress -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-migrate"></span> <?php esc_html_e( 'Import from TranslatePress', 'wptranslate' ); ?></h2>
                    <?php if ( $has_tp ) : ?>
                        <p class="wptranslate-detected">
                            <span class="dashicons dashicons-yes-alt"></span>
                            <?php esc_html_e( 'TranslatePress data detected!', 'wptranslate' ); ?>
                        </p>
                        <p><?php esc_html_e( 'Import your existing translations from TranslatePress.', 'wptranslate' ); ?></p>
                        <select id="wptranslate-import-tp-scope">
                            <option value="all"><?php esc_html_e( 'All (settings + content + strings)', 'wptranslate' ); ?></option>
                            <option value="content"><?php esc_html_e( 'Content only', 'wptranslate' ); ?></option>
                            <option value="strings"><?php esc_html_e( 'Strings only', 'wptranslate' ); ?></option>
                            <option value="settings"><?php esc_html_e( 'Settings only', 'wptranslate' ); ?></option>
                        </select>
                        <button type="button" class="button" id="wptranslate-import-tp-dry-run">
                            <?php esc_html_e( 'Preview Import (Dry Run)', 'wptranslate' ); ?>
                        </button>
                        <button type="button" class="button button-primary" id="wptranslate-import-tp-run">
                            <?php esc_html_e( 'Import Now', 'wptranslate' ); ?>
                        </button>
                        <div id="wptranslate-import-tp-results" style="display:none;"></div>
                    <?php else : ?>
                        <p class="description"><?php esc_html_e( 'No TranslatePress data found. If you previously used TranslatePress, its database tables may have been removed.', 'wptranslate' ); ?></p>
                    <?php endif; ?>
                </div>

                <!-- Import/Export Translations -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-download"></span> <?php esc_html_e( 'Import / Export Translations', 'wptranslate' ); ?></h2>
                    <h3><?php esc_html_e( 'Export', 'wptranslate' ); ?></h3>
                    <div class="wptranslate-tool-form">
                        <select id="wptranslate-export-format">
                            <option value="csv">CSV</option>
                            <option value="json">JSON</option>
                        </select>
                        <select id="wptranslate-export-lang">
                            <option value=""><?php esc_html_e( 'All Languages', 'wptranslate' ); ?></option>
                            <?php foreach ( $languages as $lang ) : ?>
                                <option value="<?php echo esc_attr( $lang['code'] ); ?>"><?php echo esc_html( $lang['name'] ); ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="button" class="button" id="wptranslate-export-btn">
                            <?php esc_html_e( 'Export', 'wptranslate' ); ?>
                        </button>
                    </div>
                    <hr />
                    <h3><?php esc_html_e( 'Import', 'wptranslate' ); ?></h3>
                    <div class="wptranslate-tool-form">
                        <input type="file" id="wptranslate-import-file" accept=".csv,.json" />
                        <button type="button" class="button" id="wptranslate-import-btn">
                            <?php esc_html_e( 'Import', 'wptranslate' ); ?>
                        </button>
                    </div>
                </div>

                <!-- Database Maintenance -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-admin-tools"></span> <?php esc_html_e( 'Database Maintenance', 'wptranslate' ); ?></h2>
                    <p><?php esc_html_e( 'Clean up orphaned data and rebuild caches.', 'wptranslate' ); ?></p>
                    <button type="button" class="button" id="wptranslate-clean-orphans-btn">
                        <?php esc_html_e( 'Clean Orphaned Translations', 'wptranslate' ); ?>
                    </button>
                    <button type="button" class="button" id="wptranslate-rebuild-cache-btn">
                        <?php esc_html_e( 'Rebuild Caches', 'wptranslate' ); ?>
                    </button>
                </div>

                <!-- Diagnostics -->
                <div class="wptranslate-card wptranslate-card--tool">
                    <h2><span class="dashicons dashicons-info"></span> <?php esc_html_e( 'Diagnostics', 'wptranslate' ); ?></h2>
                    <?php $this->render_diagnostics(); ?>
                </div>
            </div>

            <!-- Glossary Link -->
            <div class="wptranslate-card" style="margin-top: 20px;">
                <h2><span class="dashicons dashicons-book"></span> <?php esc_html_e( 'Glossary', 'wptranslate' ); ?></h2>
                <p><?php esc_html_e( 'Manage glossary terms, review auto-generated suggestions, and import/export your glossary.', 'wptranslate' ); ?></p>
                <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-glossary' ) ); ?>" class="button button-primary">
                    <?php esc_html_e( 'Manage Glossary', 'wptranslate' ); ?>
                </a>
            </div>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // AJAX Handlers
    // -------------------------------------------------------------------------

    public function ajax_bulk_translate_all(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $target_lang = sanitize_text_field( $_POST['target_lang'] ?? '' );
        $post_type   = sanitize_text_field( $_POST['post_type'] ?? 'post' );

        if ( empty( $target_lang ) ) {
            wp_send_json_error( array( 'message' => __( 'Select a target language.', 'wptranslate' ) ) );
        }

        $tm  = $this->plugin->get_translation_manager();
        $dl  = $this->plugin->get_language_manager()->get_default_language();

        global $wpdb;
        $tt = $wpdb->prefix . 'wpt_translations';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT p.ID FROM {$wpdb->posts} p
             WHERE p.post_status = 'publish' AND p.post_type = %s
             AND p.ID NOT IN (
                 SELECT t2.element_id FROM {$tt} t1
                 INNER JOIN {$tt} t2 ON t1.trid = t2.trid
                 WHERE t1.language_code = %s AND t2.language_code = %s AND t2.element_type = 'post'
             ) LIMIT 500",
            $post_type, $dl, $target_lang
        ) );

        if ( empty( $ids ) ) {
            wp_send_json_success( array( 'message' => __( 'All content is already translated.', 'wptranslate' ), 'count' => 0 ) );
        }

        foreach ( $ids as $pid ) {
            $tm->queue_translation_job( array( 'element_id' => (int) $pid, 'source_lang' => $dl, 'target_lang' => $target_lang, 'priority' => 10 ) );
        }

        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time(), 'wptranslate_process_queue' );
        }

        wp_send_json_success( array( 'message' => sprintf( __( '%d posts queued for translation.', 'wptranslate' ), count( $ids ) ), 'count' => count( $ids ) ) );
    }

    public function ajax_sync_status(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $tt = $wpdb->prefix . 'wpt_translations';
        $st = $wpdb->prefix . 'wpt_translation_status';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $missing = $wpdb->get_results( "SELECT t.id, t.element_id FROM {$tt} t LEFT JOIN {$st} s ON s.translation_id = t.id WHERE s.id IS NULL", ARRAY_A );

        $n = 0;
        foreach ( $missing as $row ) {
            $post = get_post( $row['element_id'] );
            $wpdb->insert( $st, array( 'translation_id' => $row['id'], 'status' => ( $post && 'publish' === $post->post_status ? 'published' : 'draft' ), 'date_modified' => current_time( 'mysql' ) ) );
            $n++;
        }

        $this->plugin->get_language_manager()->invalidate_cache();
        wp_send_json_success( array( 'message' => sprintf( __( 'Sync complete. %d status records created.', 'wptranslate' ), $n ) ) );
    }

    public function ajax_import_translatepress(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $scope   = sanitize_text_field( $_POST['scope'] ?? 'all' );
        $dry_run = ! empty( $_POST['dry_run'] );

        if ( ! $this->detect_translatepress() ) {
            wp_send_json_error( array( 'message' => __( 'TranslatePress data not found.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $results = array( 'strings' => 0, 'settings' => 0 );

        if ( in_array( $scope, array( 'all', 'strings' ), true ) ) {
            $tp_tables = $wpdb->get_col( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . 'trp_dictionary_%' ) );
            foreach ( $tp_tables as $tpt ) {
                preg_match( '/trp_dictionary_([a-z_]+)$/', $tpt, $m );
                if ( empty( $m[1] ) ) { continue; }
                $lc = substr( str_replace( '_', '-', strtolower( $m[1] ) ), 0, 2 );
                $rows = $wpdb->get_results( "SELECT original, translated FROM {$tpt} WHERE translated != '' LIMIT 5000", ARRAY_A );
                $results['strings'] += count( $rows );
                if ( ! $dry_run ) {
                    foreach ( $rows as $r ) {
                        $this->plugin->get_string_translation()->save_translation( $r['original'], $r['translated'], $lc, 'translatepress', '' );
                    }
                }
            }
        }

        if ( in_array( $scope, array( 'all', 'settings' ), true ) ) {
            $tp_s = get_option( 'trp_settings', array() );
            if ( ! empty( $tp_s['translation-languages'] ) ) {
                $results['settings'] = count( $tp_s['translation-languages'] );
                if ( ! $dry_run ) {
                    foreach ( $tp_s['translation-languages'] as $tl ) {
                        $c = strtolower( substr( $tl, 0, 2 ) );
                        if ( ! $this->plugin->get_language_manager()->get_language( $c ) ) {
                            $this->plugin->get_language_manager()->add_language( array( 'code' => $c ) );
                        }
                    }
                }
            }
        }

        $msg = $dry_run
            ? sprintf( __( 'Preview: %d strings and %d language(s) would be imported.', 'wptranslate' ), $results['strings'], $results['settings'] )
            : sprintf( __( 'Imported %d strings and %d language(s).', 'wptranslate' ), $results['strings'], $results['settings'] );

        wp_send_json_success( array( 'message' => $msg, 'results' => $results, 'dry_run' => $dry_run ) );
    }

    public function ajax_export_translations(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) { wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) ); }

        $format = sanitize_text_field( $_POST['format'] ?? 'csv' );
        $lang   = sanitize_text_field( $_POST['language'] ?? '' );
        $data   = $this->plugin->get_string_translation()->get_strings( '', $lang, '', 10000, 1 );

        if ( 'json' === $format ) {
            $content = wp_json_encode( $data['items'], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE );
        } else {
            $lines = array( 'string_name,string_value,language_code,domain,context,status' );
            foreach ( $data['items'] as $i ) {
                $lines[] = sprintf( '"%s","%s","%s","%s","%s","%s"', str_replace( '"', '""', $i['string_name'] ), str_replace( '"', '""', $i['string_value'] ?? '' ), $i['language_code'], $i['domain'], $i['context'] ?? '', $i['status'] );
            }
            $content = implode( "\n", $lines );
        }

        wp_send_json_success( array( 'content' => $content, 'filename' => 'wptranslate-translations-' . ( $lang ?: 'all' ) . '.' . $format ) );
    }

    public function ajax_import_translations(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) { wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) ); }

        if ( empty( $_FILES['import_file'] ) || ! empty( $_FILES['import_file']['error'] ) ) {
            wp_send_json_error( array( 'message' => __( 'No file uploaded.', 'wptranslate' ) ) );
        }

        $content = file_get_contents( $_FILES['import_file']['tmp_name'] ); // phpcs:ignore
        $ext     = strtolower( pathinfo( sanitize_file_name( $_FILES['import_file']['name'] ), PATHINFO_EXTENSION ) );
        $n       = 0;
        $st      = $this->plugin->get_string_translation();

        if ( 'json' === $ext ) {
            $arr = json_decode( $content, true );
            if ( is_array( $arr ) ) { foreach ( $arr as $i ) { if ( ! empty( $i['string_name'] ) && ! empty( $i['language_code'] ) ) { $st->save_translation( $i['string_name'], $i['string_value'] ?? '', $i['language_code'], $i['domain'] ?? 'default', $i['context'] ?? '' ); $n++; } } }
        } elseif ( 'csv' === $ext ) {
            $lines = explode( "\n", $content ); array_shift( $lines );
            foreach ( $lines as $l ) { $l = trim( $l ); if ( empty( $l ) ) { continue; } $c = str_getcsv( $l ); if ( count( $c ) >= 4 ) { $st->save_translation( $c[0], $c[1] ?? '', $c[2], $c[3] ?? 'default', $c[4] ?? '' ); $n++; } }
        } else {
            wp_send_json_error( array( 'message' => __( 'Unsupported format. Use CSV or JSON.', 'wptranslate' ) ) );
        }

        wp_send_json_success( array( 'message' => sprintf( __( '%d translations imported.', 'wptranslate' ), $n ) ) );
    }

    public function ajax_clean_orphans(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) { wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) ); }
        global $wpdb; $tt = $wpdb->prefix . 'wpt_translations';
        $d = $wpdb->query( "DELETE t FROM {$tt} t LEFT JOIN {$wpdb->posts} p ON t.element_id = p.ID AND t.element_type = 'post' WHERE t.element_type = 'post' AND p.ID IS NULL" );
        wp_send_json_success( array( 'message' => sprintf( __( '%d orphaned records removed.', 'wptranslate' ), $d ) ) );
    }

    public function ajax_rebuild_cache(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) { wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) ); }
        $this->plugin->get_language_manager()->invalidate_cache();
        $this->plugin->get_cache_manager()->flush_all();
        wp_send_json_success( array( 'message' => __( 'All caches cleared.', 'wptranslate' ) ) );
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------

    private function detect_translatepress(): bool {
        global $wpdb;
        return ! empty( $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . 'trp_dictionary_%' ) ) );
    }

    private function render_diagnostics(): void {
        global $wpdb;
        $checks = array();
        $checks[] = array( 'label' => __( 'PHP Version', 'wptranslate' ), 'value' => PHP_VERSION, 'status' => version_compare( PHP_VERSION, '7.4', '>=' ) ? 'good' : 'bad' );
        $checks[] = array( 'label' => __( 'WordPress Version', 'wptranslate' ), 'value' => get_bloginfo( 'version' ), 'status' => version_compare( get_bloginfo( 'version' ), '6.0', '>=' ) ? 'good' : 'bad' );

        $tables = array( 'wpt_languages', 'wpt_translations', 'wpt_translation_status', 'wpt_string_translations', 'wpt_translation_jobs', 'wpt_translation_cache', 'wpt_translation_glossary', 'wpt_translation_corrections' );
        $missing = array();
        foreach ( $tables as $t ) { if ( ! $wpdb->get_var( $wpdb->prepare( "SHOW TABLES LIKE %s", $wpdb->prefix . $t ) ) ) { $missing[] = $t; } }
        $checks[] = array( 'label' => __( 'Database Tables', 'wptranslate' ), 'value' => empty( $missing ) ? __( 'All present', 'wptranslate' ) : sprintf( __( 'Missing: %s', 'wptranslate' ), implode( ', ', $missing ) ), 'status' => empty( $missing ) ? 'good' : 'bad' );

        foreach ( array( 'claude', 'openai', 'deepl' ) as $p ) {
            $k = get_option( "wptranslate_{$p}_api_key", '' );
            $checks[] = array( 'label' => sprintf( __( '%s API Key', 'wptranslate' ), ucfirst( $p ) ), 'value' => ! empty( $k ) ? __( 'Configured', 'wptranslate' ) : __( 'Not set', 'wptranslate' ), 'status' => ! empty( $k ) ? 'good' : 'neutral' );
        }

        $checks[] = array( 'label' => __( 'OpenSSL', 'wptranslate' ), 'value' => function_exists( 'openssl_encrypt' ) ? __( 'Available', 'wptranslate' ) : __( 'Missing', 'wptranslate' ), 'status' => function_exists( 'openssl_encrypt' ) ? 'good' : 'bad' );
        $checks[] = array( 'label' => __( 'mbstring', 'wptranslate' ), 'value' => extension_loaded( 'mbstring' ) ? __( 'Available', 'wptranslate' ) : __( 'Missing', 'wptranslate' ), 'status' => extension_loaded( 'mbstring' ) ? 'good' : 'bad' );
        $checks[] = array( 'label' => __( 'WP-Cron', 'wptranslate' ), 'value' => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? __( 'Disabled', 'wptranslate' ) : __( 'Enabled', 'wptranslate' ), 'status' => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'bad' : 'good' );
        $checks[] = array( 'label' => __( 'Object Cache', 'wptranslate' ), 'value' => wp_using_ext_object_cache() ? __( 'External', 'wptranslate' ) : __( 'Default', 'wptranslate' ), 'status' => 'neutral' );
        $checks[] = array( 'label' => __( 'Plugin Version', 'wptranslate' ), 'value' => WPTRANSLATE_VERSION, 'status' => 'neutral' );
        ?>
        <table class="widefat" style="border:0;">
            <tbody>
                <?php foreach ( $checks as $ck ) :
                    $ic = 'good' === $ck['status'] ? 'dashicons-yes' : ( 'bad' === $ck['status'] ? 'dashicons-no' : 'dashicons-minus' );
                    $co = 'good' === $ck['status'] ? '#00a32a' : ( 'bad' === $ck['status'] ? '#d63638' : '#646970' );
                ?>
                <tr>
                    <td style="width:20px;"><span class="dashicons <?php echo esc_attr( $ic ); ?>" style="color:<?php echo esc_attr( $co ); ?>;"></span></td>
                    <td><strong><?php echo esc_html( $ck['label'] ); ?></strong></td>
                    <td><?php echo esc_html( $ck['value'] ); ?></td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <?php
    }
}
