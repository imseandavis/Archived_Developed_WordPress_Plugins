<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Settings admin page — all plugin settings organized in tabs:
 * Providers, Content, Quality, Workflow, Advanced.
 *
 * API keys are encrypted before storage using AES-256-CBC.
 */
class SettingsPage {

    /** @var Plugin */
    private $plugin;

    /** @var string Current active tab. */
    private $active_tab;

    public function __construct( Plugin $plugin ) {
        $this->plugin     = $plugin;
        $this->active_tab = sanitize_text_field( $_GET['tab'] ?? 'providers' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
    }

    /**
     * Register all settings using the WordPress Settings API.
     */
    public function register_settings(): void {
        // --- Providers Tab ---
        // --- Providers Tab ---
        $g = 'wptranslate_providers';
        register_setting( $g, 'wptranslate_primary_provider', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'claude' ) );
        register_setting( $g, 'wptranslate_fallback_provider', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ) );
        register_setting( $g, 'wptranslate_claude_model', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'claude-sonnet-4-20250514' ) );
        register_setting( $g, 'wptranslate_openai_model', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'gpt-4o' ) );
        register_setting( $g, 'wptranslate_cost_budget', array( 'type' => 'number', 'sanitize_callback' => array( $this, 'sanitize_float' ), 'default' => 0 ) );
        register_setting( $g, 'wptranslate_provider_language_overrides', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_provider_overrides' ), 'default' => array() ) );
        register_setting( $g, 'wptranslate_claude_api_key', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_and_encrypt_api_key' ) ) );
        register_setting( $g, 'wptranslate_openai_api_key', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_and_encrypt_api_key' ) ) );
        register_setting( $g, 'wptranslate_deepl_api_key', array( 'type' => 'string', 'sanitize_callback' => array( $this, 'sanitize_and_encrypt_api_key' ) ) );

        // --- Content Tab ---
        $g = 'wptranslate_content';
        register_setting( $g, 'wptranslate_auto_translate_on_publish', array( 'type' => 'boolean', 'sanitize_callback' => array( $this, 'sanitize_bool' ), 'default' => false ) );
        register_setting( $g, 'wptranslate_post_types', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_array_text' ), 'default' => array( 'post', 'page' ) ) );
        register_setting( $g, 'wptranslate_taxonomies', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_array_text' ), 'default' => array( 'category', 'post_tag' ) ) );
        register_setting( $g, 'wptranslate_translatable_meta_keys', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_meta_keys' ), 'default' => array() ) );
        register_setting( $g, 'wptranslate_media_handling', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'duplicate' ) );

        // --- Quality Tab ---
        $g = 'wptranslate_quality';
        register_setting( $g, 'wptranslate_site_context', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_textarea_field', 'default' => '' ) );
        register_setting( $g, 'wptranslate_formality', array( 'type' => 'array', 'sanitize_callback' => array( $this, 'sanitize_formality' ), 'default' => array() ) );
        register_setting( $g, 'wptranslate_max_chunk_size', array( 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 4000 ) );

        // --- Workflow Tab ---
        $g = 'wptranslate_workflow';
        register_setting( $g, 'wptranslate_enable_translator_workflow', array( 'type' => 'boolean', 'sanitize_callback' => array( $this, 'sanitize_bool' ), 'default' => false ) );
        register_setting( $g, 'wptranslate_enable_review_mode', array( 'type' => 'boolean', 'sanitize_callback' => array( $this, 'sanitize_bool' ), 'default' => false ) );
        register_setting( $g, 'wptranslate_auto_assign_method', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'none' ) );

        // --- Advanced Tab ---
        $g = 'wptranslate_advanced';
        register_setting( $g, 'wptranslate_url_format', array( 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => 'directory' ) );
        register_setting( $g, 'wptranslate_browser_redirect', array( 'type' => 'boolean', 'sanitize_callback' => array( $this, 'sanitize_bool' ), 'default' => false ) );
        register_setting( $g, 'wptranslate_cache_ttl', array( 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 3600 ) );
        register_setting( $g, 'wptranslate_delete_data_on_uninstall', array( 'type' => 'boolean', 'sanitize_callback' => array( $this, 'sanitize_bool' ), 'default' => false ) );
    }

    /**
     * Render the settings page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $tabs = array(
            'providers' => __( 'Providers', 'wptranslate' ),
            'content'   => __( 'Content', 'wptranslate' ),
            'quality'   => __( 'Quality', 'wptranslate' ),
            'workflow'  => __( 'Workflow', 'wptranslate' ),
            'advanced'  => __( 'Advanced', 'wptranslate' ),
        );
        ?>
        <div class="wrap wptranslate-settings">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'Translation Settings', 'wptranslate' ) ); ?>

            <nav class="nav-tab-wrapper">
                <?php foreach ( $tabs as $slug => $label ) : ?>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-settings&tab=' . $slug ) ); ?>"
                       class="nav-tab <?php echo $this->active_tab === $slug ? 'nav-tab-active' : ''; ?>">
                        <?php echo esc_html( $label ); ?>
                    </a>
                <?php endforeach; ?>
            </nav>

            <form method="post" action="options.php" class="wptranslate-settings-form">
                <?php
                switch ( $this->active_tab ) {
                    case 'providers':
                        $this->render_providers_tab();
                        break;
                    case 'content':
                        $this->render_content_tab();
                        break;
                    case 'quality':
                        $this->render_quality_tab();
                        break;
                    case 'workflow':
                        $this->render_workflow_tab();
                        break;
                    case 'advanced':
                        $this->render_advanced_tab();
                        break;
                }

                submit_button();
                ?>
            </form>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // Tab Renderers
    // -------------------------------------------------------------------------

    /**
     * Providers tab: API keys, model selection, primary/fallback, per-language overrides, budget.
     */
    private function render_providers_tab(): void {
        settings_fields( 'wptranslate_providers' );

        $primary_provider  = get_option( 'wptranslate_primary_provider', 'claude' );
        $fallback_provider = get_option( 'wptranslate_fallback_provider', '' );
        $claude_model      = get_option( 'wptranslate_claude_model', 'claude-sonnet-4-20250514' );
        $openai_model      = get_option( 'wptranslate_openai_model', 'gpt-4o' );
        $budget            = get_option( 'wptranslate_cost_budget', 0 );

        // Check which keys are configured (without revealing them).
        $has_claude_key = ! empty( get_option( 'wptranslate_claude_api_key', '' ) );
        $has_openai_key = ! empty( get_option( 'wptranslate_openai_api_key', '' ) );
        $has_deepl_key  = ! empty( get_option( 'wptranslate_deepl_api_key', '' ) );

        $providers = array(
            'claude' => __( 'Claude (Anthropic)', 'wptranslate' ),
            'openai' => __( 'OpenAI', 'wptranslate' ),
            'deepl'  => __( 'DeepL', 'wptranslate' ),
        );
        ?>
        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'API Keys', 'wptranslate' ); ?></h2>
        <p class="description"><?php esc_html_e( 'API keys are encrypted before storage. Leave blank to keep the existing key.', 'wptranslate' ); ?></p>

        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_claude_api_key"><?php esc_html_e( 'Claude API Key', 'wptranslate' ); $this->info_tip( __( 'Get your API key from console.anthropic.com. Claude provides excellent context-aware translations for nuanced content.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="password"
                           id="wptranslate_claude_api_key"
                           name="wptranslate_claude_api_key"
                           class="regular-text"
                           value=""
                           autocomplete="new-password"
                           placeholder="<?php echo $has_claude_key ? esc_attr__( '(key saved, leave blank to keep)', 'wptranslate' ) : ''; ?>" />
                    <button type="button" class="button button-small wptranslate-validate-key" data-provider="claude">
                        <?php esc_html_e( 'Validate Key', 'wptranslate' ); ?>
                    </button>
                    <span class="wptranslate-key-validation-result" data-provider="claude">
                        <?php if ( $has_claude_key ) : ?>
                            <span class="dashicons dashicons-yes-alt wptranslate-key-status--configured" title="<?php esc_attr_e( 'Configured', 'wptranslate' ); ?>"></span>
                        <?php endif; ?>
                    </span>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_openai_api_key"><?php esc_html_e( 'OpenAI API Key', 'wptranslate' ); $this->info_tip( __( 'Get your API key from platform.openai.com. OpenAI models are fast and widely supported.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="password"
                           id="wptranslate_openai_api_key"
                           name="wptranslate_openai_api_key"
                           class="regular-text"
                           value=""
                           autocomplete="new-password"
                           placeholder="<?php echo $has_openai_key ? esc_attr__( '(key saved, leave blank to keep)', 'wptranslate' ) : ''; ?>" />
                    <button type="button" class="button button-small wptranslate-validate-key" data-provider="openai">
                        <?php esc_html_e( 'Validate Key', 'wptranslate' ); ?>
                    </button>
                    <span class="wptranslate-key-validation-result" data-provider="openai">
                        <?php if ( $has_openai_key ) : ?>
                            <span class="dashicons dashicons-yes-alt wptranslate-key-status--configured" title="<?php esc_attr_e( 'Configured', 'wptranslate' ); ?>"></span>
                        <?php endif; ?>
                    </span>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_deepl_api_key"><?php esc_html_e( 'DeepL API Key', 'wptranslate' ); $this->info_tip( __( 'Get your API key from deepl.com/pro. DeepL excels at European languages and supports native formality controls. Works with both Free and Pro keys.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="password"
                           id="wptranslate_deepl_api_key"
                           name="wptranslate_deepl_api_key"
                           class="regular-text"
                           value=""
                           autocomplete="new-password"
                           placeholder="<?php echo $has_deepl_key ? esc_attr__( '(key saved, leave blank to keep)', 'wptranslate' ) : ''; ?>" />
                    <button type="button" class="button button-small wptranslate-validate-key" data-provider="deepl">
                        <?php esc_html_e( 'Validate Key', 'wptranslate' ); ?>
                    </button>
                    <span class="wptranslate-key-validation-result" data-provider="deepl">
                        <?php if ( $has_deepl_key ) : ?>
                            <span class="dashicons dashicons-yes-alt wptranslate-key-status--configured" title="<?php esc_attr_e( 'Configured', 'wptranslate' ); ?>"></span>
                        <?php endif; ?>
                    </span>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Provider Configuration', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_primary_provider"><?php esc_html_e( 'Primary Provider', 'wptranslate' ); $this->info_tip( __( 'The AI service used for translations by default. Must have a valid API key configured above.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <select id="wptranslate_primary_provider" name="wptranslate_primary_provider">
                        <?php foreach ( $providers as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $primary_provider, $slug ); ?>>
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_fallback_provider"><?php esc_html_e( 'Fallback Provider', 'wptranslate' ); $this->info_tip( __( 'If the primary provider fails or is rate-limited, this provider is used automatically. Requires its own API key.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <select id="wptranslate_fallback_provider" name="wptranslate_fallback_provider">
                        <option value=""><?php esc_html_e( 'None', 'wptranslate' ); ?></option>
                        <?php foreach ( $providers as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $fallback_provider, $slug ); ?>>
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <p class="description"><?php esc_html_e( 'Used automatically if the primary provider fails.', 'wptranslate' ); ?></p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_claude_model"><?php esc_html_e( 'Claude Model', 'wptranslate' ); $this->info_tip( __( 'Sonnet 4 is fast and cost-effective for most translations. Opus 4 produces the highest quality but costs more. Haiku is the cheapest option for bulk work.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <select id="wptranslate_claude_model" name="wptranslate_claude_model">
                        <option value="claude-sonnet-4-20250514" <?php selected( $claude_model, 'claude-sonnet-4-20250514' ); ?>>Claude Sonnet 4</option>
                        <option value="claude-opus-4-20250514" <?php selected( $claude_model, 'claude-opus-4-20250514' ); ?>>Claude Opus 4</option>
                        <option value="claude-3-5-haiku-20241022" <?php selected( $claude_model, 'claude-3-5-haiku-20241022' ); ?>>Claude 3.5 Haiku</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_openai_model"><?php esc_html_e( 'OpenAI Model', 'wptranslate' ); $this->info_tip( __( 'GPT-4o offers the best translation quality. GPT-4o Mini is cheaper for bulk work. GPT-4 Turbo is a balanced option.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <select id="wptranslate_openai_model" name="wptranslate_openai_model">
                        <option value="gpt-4o" <?php selected( $openai_model, 'gpt-4o' ); ?>>GPT-4o</option>
                        <option value="gpt-4o-mini" <?php selected( $openai_model, 'gpt-4o-mini' ); ?>>GPT-4o Mini</option>
                        <option value="gpt-4-turbo" <?php selected( $openai_model, 'gpt-4-turbo' ); ?>>GPT-4 Turbo</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_cost_budget"><?php esc_html_e( 'Monthly Character Limit', 'wptranslate' ); $this->info_tip( __( 'Maximum characters to translate per month. Translation jobs pause when the limit is reached. Set to 0 for unlimited.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="number"
                           id="wptranslate_cost_budget"
                           name="wptranslate_cost_budget"
                           value="<?php echo esc_attr( (int) $budget ); ?>"
                           class="regular-text"
                           min="0"
                           step="1" />
                    <p class="description"><?php esc_html_e( 'Maximum characters to translate per month. Set to 0 for unlimited.', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Per-Language Provider Overrides', 'wptranslate' ); ?></h2>
        <p class="description"><?php esc_html_e( 'Optionally specify a different provider for specific languages.', 'wptranslate' ); ?></p>
        <?php
        $overrides        = get_option( 'wptranslate_provider_language_overrides', array() );
        $active_languages = $this->plugin->get_language_manager()->get_active_languages();
        $default_language = $this->plugin->get_language_manager()->get_default_language();
        ?>
        <table class="form-table">
            <?php foreach ( $active_languages as $lang ) :
                if ( $lang['code'] === $default_language ) {
                    continue;
                }
                $current_override = $overrides[ $lang['code'] ] ?? '';
            ?>
            <tr>
                <th scope="row"><?php echo esc_html( $lang['name'] ); ?></th>
                <td>
                    <select name="wptranslate_provider_language_overrides[<?php echo esc_attr( $lang['code'] ); ?>]">
                        <option value=""><?php esc_html_e( 'Use primary provider', 'wptranslate' ); ?></option>
                        <?php foreach ( $providers as $slug => $label ) : ?>
                            <option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $current_override, $slug ); ?>>
                                <?php echo esc_html( $label ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        </div>
        <?php
    }

    /**
     * Content tab: post types, taxonomies, custom fields, media handling.
     */
    private function render_content_tab(): void {
        settings_fields( 'wptranslate_content' );

        $auto_translate     = get_option( 'wptranslate_auto_translate_on_publish', false );
        $enabled_post_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );
        $enabled_taxonomies = get_option( 'wptranslate_taxonomies', array( 'category', 'post_tag' ) );
        $meta_keys          = get_option( 'wptranslate_translatable_meta_keys', array() );
        $media_handling     = get_option( 'wptranslate_media_handling', 'duplicate' );

        $all_post_types = get_post_types( array( 'public' => true ), 'objects' );
        $all_taxonomies = get_taxonomies( array( 'public' => true ), 'objects' );
        ?>
        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Auto-Translate', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Translate on Publish', 'wptranslate' ); $this->info_tip( __( 'When enabled, new posts are automatically translated to all active languages when published. Translations are created as drafts for review. Only applies to the post types selected below.', 'wptranslate' ) ); ?></th>
                <td>
                    <label>
                        <input type="checkbox"
                               name="wptranslate_auto_translate_on_publish"
                               value="1"
                               <?php checked( $auto_translate ); ?> />
                        <?php esc_html_e( 'Automatically translate new content when published', 'wptranslate' ); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e( 'Translations are created as AI drafts. They will not be published automatically — review them first or use the translator workflow.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Post Types', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Translatable Post Types', 'wptranslate' ); $this->info_tip( __( 'Select which content types should be translatable. Posts and pages are enabled by default. Custom post types from other plugins also appear here.', 'wptranslate' ) ); ?></th>
                <td>
                    <fieldset>
                        <?php foreach ( $all_post_types as $post_type ) :
                            if ( 'attachment' === $post_type->name ) {
                                continue;
                            }
                        ?>
                        <label>
                            <input type="checkbox"
                                   name="wptranslate_post_types[]"
                                   value="<?php echo esc_attr( $post_type->name ); ?>"
                                   <?php checked( in_array( $post_type->name, $enabled_post_types, true ) ); ?> />
                            <?php echo esc_html( $post_type->labels->name ); ?>
                            <code>(<?php echo esc_html( $post_type->name ); ?>)</code>
                        </label><br />
                        <?php endforeach; ?>
                    </fieldset>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Taxonomies', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Translatable Taxonomies', 'wptranslate' ); $this->info_tip( __( 'Select which taxonomies (categories, tags, custom taxonomies) should have their terms translated along with posts.', 'wptranslate' ) ); ?></th>
                <td>
                    <fieldset>
                        <?php foreach ( $all_taxonomies as $taxonomy ) : ?>
                        <label>
                            <input type="checkbox"
                                   name="wptranslate_taxonomies[]"
                                   value="<?php echo esc_attr( $taxonomy->name ); ?>"
                                   <?php checked( in_array( $taxonomy->name, $enabled_taxonomies, true ) ); ?> />
                            <?php echo esc_html( $taxonomy->labels->name ); ?>
                            <code>(<?php echo esc_html( $taxonomy->name ); ?>)</code>
                        </label><br />
                        <?php endforeach; ?>
                    </fieldset>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Custom Fields', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_translatable_meta_keys"><?php esc_html_e( 'Translatable Meta Keys', 'wptranslate' ); $this->info_tip( __( 'Custom field keys that should be translated. SEO plugin fields (Yoast, RankMath) are handled automatically. Enter one key per line.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <textarea id="wptranslate_translatable_meta_keys"
                              name="wptranslate_translatable_meta_keys"
                              class="large-text code"
                              rows="5"
                              placeholder="<?php esc_attr_e( 'One meta key per line', 'wptranslate' ); ?>"><?php echo esc_textarea( implode( "\n", $meta_keys ) ); ?></textarea>
                    <p class="description"><?php esc_html_e( 'Enter one meta key per line. SEO meta (Yoast, RankMath, AIOSEO) is handled automatically.', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Media Handling', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Media in Translations', 'wptranslate' ); $this->info_tip( __( 'How images and media are handled in translated posts. Duplicating allows separate alt text per language. Referencing saves storage but shares the same media.', 'wptranslate' ) ); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="radio" name="wptranslate_media_handling" value="duplicate" <?php checked( $media_handling, 'duplicate' ); ?> />
                            <?php esc_html_e( 'Duplicate media to translated post (allows separate alt text)', 'wptranslate' ); ?>
                        </label><br />
                        <label>
                            <input type="radio" name="wptranslate_media_handling" value="reference" <?php checked( $media_handling, 'reference' ); ?> />
                            <?php esc_html_e( 'Reference original media (shared, saves storage)', 'wptranslate' ); ?>
                        </label><br />
                        <label>
                            <input type="radio" name="wptranslate_media_handling" value="translate_alt" <?php checked( $media_handling, 'translate_alt' ); ?> />
                            <?php esc_html_e( 'Reference original but translate alt text and captions', 'wptranslate' ); ?>
                        </label>
                    </fieldset>
                </td>
            </tr>
        </table>
        </div>
        <?php
    }

    /**
     * Quality tab: site context, formality, glossary link, chunk size.
     */
    private function render_quality_tab(): void {
        settings_fields( 'wptranslate_quality' );

        $site_context    = get_option( 'wptranslate_site_context', '' );
        $formality       = get_option( 'wptranslate_formality', array() );
        $max_chunk_size  = get_option( 'wptranslate_max_chunk_size', 4000 );
        $active_languages = $this->plugin->get_language_manager()->get_active_languages();
        $default_language = $this->plugin->get_language_manager()->get_default_language();
        ?>
        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Site Context', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_site_context"><?php esc_html_e( 'Site Description for AI', 'wptranslate' ); $this->info_tip( __( 'Describe your site, industry, and audience so the AI understands context. This prevents mistranslations of domain-specific terms. E.g., "This is a shibari instruction site — tie means rope knots, not neckties."', 'wptranslate' ) ); ?></label></th>
                <td>
                    <textarea id="wptranslate_site_context"
                              name="wptranslate_site_context"
                              class="large-text"
                              rows="5"
                              placeholder="<?php esc_attr_e( 'Describe your site, audience, and tone to help the AI produce better translations...', 'wptranslate' ); ?>"><?php echo esc_textarea( $site_context ); ?></textarea>
                    <p class="description">
                        <?php esc_html_e( 'This context is included in every translation prompt. Describe your industry, target audience, preferred tone, and any terminology guidelines.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Formality per Language', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <?php foreach ( $active_languages as $lang ) :
                if ( $lang['code'] === $default_language ) {
                    continue;
                }
                $current_formality = $formality[ $lang['code'] ] ?? 'default';
            ?>
            <tr>
                <th scope="row"><?php echo esc_html( $lang['name'] ); ?></th>
                <td>
                    <select name="wptranslate_formality[<?php echo esc_attr( $lang['code'] ); ?>]">
                        <option value="default" <?php selected( $current_formality, 'default' ); ?>><?php esc_html_e( 'Default', 'wptranslate' ); ?></option>
                        <option value="formal" <?php selected( $current_formality, 'formal' ); ?>><?php esc_html_e( 'Formal', 'wptranslate' ); ?></option>
                        <option value="informal" <?php selected( $current_formality, 'informal' ); ?>><?php esc_html_e( 'Informal', 'wptranslate' ); ?></option>
                    </select>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Glossary', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Glossary Management', 'wptranslate' ); ?></th>
                <td>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-glossary' ) ); ?>" class="button">
                        <?php esc_html_e( 'Manage Glossary Terms', 'wptranslate' ); ?>
                    </a>
                    <p class="description"><?php esc_html_e( 'The glossary ensures consistent translation of key terms across all content.', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Content Processing', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_max_chunk_size"><?php esc_html_e( 'Max Chunk Size', 'wptranslate' ); $this->info_tip( __( 'Long content is split into chunks for translation. Larger chunks provide better context but cost more per API call. Default: 4000 characters.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="number"
                           id="wptranslate_max_chunk_size"
                           name="wptranslate_max_chunk_size"
                           value="<?php echo esc_attr( $max_chunk_size ); ?>"
                           class="small-text"
                           min="1000"
                           max="50000"
                           step="500" />
                    <p class="description">
                        <?php esc_html_e( 'Characters per chunk when splitting long content. Larger values mean fewer API calls but higher per-request cost. Default: 4000.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
        </table>
        </div>
        <?php
    }

    /**
     * Workflow tab: translator workflow toggle, review mode, auto-assign.
     */
    private function render_workflow_tab(): void {
        settings_fields( 'wptranslate_workflow' );

        $enable_workflow    = get_option( 'wptranslate_enable_translator_workflow', false );
        $enable_review      = get_option( 'wptranslate_enable_review_mode', false );
        $auto_assign_method = get_option( 'wptranslate_auto_assign_method', 'none' );
        ?>
        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Translation Workflow', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Translator Workflow', 'wptranslate' ); $this->info_tip( __( 'Enables a full translator management system. AI translations are assigned to human translators for review and editing before publishing.', 'wptranslate' ) ); ?></th>
                <td>
                    <label>
                        <input type="checkbox"
                               name="wptranslate_enable_translator_workflow"
                               value="1"
                               <?php checked( $enable_workflow ); ?> />
                        <?php esc_html_e( 'Enable translator workflow', 'wptranslate' ); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e( 'When enabled, AI translations are assigned to human translators for review and editing. Adds a "Translators" menu page.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><?php esc_html_e( 'Review Mode', 'wptranslate' ); $this->info_tip( __( 'Adds an approval step. Translations must be reviewed and approved by a manager before they can be published.', 'wptranslate' ) ); ?></th>
                <td>
                    <label>
                        <input type="checkbox"
                               name="wptranslate_enable_review_mode"
                               value="1"
                               <?php checked( $enable_review ); ?> />
                        <?php esc_html_e( 'Enable review mode', 'wptranslate' ); ?>
                    </label>
                    <p class="description">
                        <?php esc_html_e( 'Translations must be reviewed and approved by a manager before publishing.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
            <tr>
                <th scope="row"><label for="wptranslate_auto_assign_method"><?php esc_html_e( 'Auto-Assign Method', 'wptranslate' ); $this->info_tip( __( 'How new translations are assigned to translators. Round robin distributes evenly. Least busy assigns to the translator with the fewest pending items.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <select id="wptranslate_auto_assign_method" name="wptranslate_auto_assign_method">
                        <option value="none" <?php selected( $auto_assign_method, 'none' ); ?>><?php esc_html_e( 'Manual assignment only', 'wptranslate' ); ?></option>
                        <option value="round_robin" <?php selected( $auto_assign_method, 'round_robin' ); ?>><?php esc_html_e( 'Round robin', 'wptranslate' ); ?></option>
                        <option value="least_busy" <?php selected( $auto_assign_method, 'least_busy' ); ?>><?php esc_html_e( 'Least busy translator', 'wptranslate' ); ?></option>
                    </select>
                    <p class="description"><?php esc_html_e( 'How new AI-translated content is assigned to translators.', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>
        <?php
    }

    /**
     * Advanced tab: URL format, browser redirect, cache TTL, delete data.
     */
    private function render_advanced_tab(): void {
        settings_fields( 'wptranslate_advanced' );

        $url_format        = get_option( 'wptranslate_url_format', 'directory' );
        $browser_redirect  = get_option( 'wptranslate_browser_redirect', false );
        $cache_ttl         = get_option( 'wptranslate_cache_ttl', 3600 );
        $delete_on_uninstall = get_option( 'wptranslate_delete_data_on_uninstall', false );
        ?>
        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'URL Format', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'URL Structure', 'wptranslate' ); $this->info_tip( __( 'How translated URLs are formatted. Directory is the most common and SEO-friendly. Subdomain requires DNS configuration. Query parameter is simplest but least clean.', 'wptranslate' ) ); ?></th>
                <td>
                    <fieldset>
                        <label>
                            <input type="radio" name="wptranslate_url_format" value="directory" <?php checked( $url_format, 'directory' ); ?> />
                            <?php esc_html_e( 'Directory', 'wptranslate' ); ?>
                            <code>example.com/fr/about/</code>
                        </label><br />
                        <label>
                            <input type="radio" name="wptranslate_url_format" value="query" <?php checked( $url_format, 'query' ); ?> />
                            <?php esc_html_e( 'Query parameter', 'wptranslate' ); ?>
                            <code>example.com/about/?lang=fr</code>
                        </label><br />
                        <label>
                            <input type="radio" name="wptranslate_url_format" value="subdomain" <?php checked( $url_format, 'subdomain' ); ?> />
                            <?php esc_html_e( 'Subdomain', 'wptranslate' ); ?>
                            <code>fr.example.com/about/</code>
                        </label>
                    </fieldset>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Browser & Detection', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Browser Language Redirect', 'wptranslate' ); $this->info_tip( __( 'Detects the visitor\'s browser language and redirects them to the matching translation on their first visit. A cookie prevents repeat redirects.', 'wptranslate' ) ); ?></th>
                <td>
                    <label>
                        <input type="checkbox"
                               name="wptranslate_browser_redirect"
                               value="1"
                               <?php checked( $browser_redirect ); ?> />
                        <?php esc_html_e( 'Automatically redirect visitors based on browser language', 'wptranslate' ); ?>
                    </label>
                    <p class="description"><?php esc_html_e( 'Only applies on the first visit. A cookie remembers the choice.', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Caching', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><label for="wptranslate_cache_ttl"><?php esc_html_e( 'Cache TTL (seconds)', 'wptranslate' ); $this->info_tip( __( 'How long translated content is cached before re-checking. Higher values reduce API calls but delay translation updates. 3600 = 1 hour. 0 disables caching.', 'wptranslate' ) ); ?></label></th>
                <td>
                    <input type="number"
                           id="wptranslate_cache_ttl"
                           name="wptranslate_cache_ttl"
                           value="<?php echo esc_attr( $cache_ttl ); ?>"
                           class="small-text"
                           min="0"
                           step="1" />
                    <p class="description"><?php esc_html_e( 'How long translated content is cached. 0 to disable caching. Default: 3600 (1 hour).', 'wptranslate' ); ?></p>
                </td>
            </tr>
        </table>
        </div>

        <div class="wptranslate-card">
        <h2><?php esc_html_e( 'Data Management', 'wptranslate' ); ?></h2>
        <table class="form-table">
            <tr>
                <th scope="row"><?php esc_html_e( 'Delete Data on Uninstall', 'wptranslate' ); $this->info_tip( __( 'When checked, ALL plugin data (translations, database tables, settings, glossary) is permanently deleted when you uninstall the plugin. Leave unchecked to preserve data.', 'wptranslate' ) ); ?></th>
                <td>
                    <label>
                        <input type="checkbox"
                               name="wptranslate_delete_data_on_uninstall"
                               value="1"
                               <?php checked( $delete_on_uninstall ); ?> />
                        <?php esc_html_e( 'Remove all plugin data (translations, settings, database tables) when uninstalling', 'wptranslate' ); ?>
                    </label>
                    <p class="description wptranslate-warning-text">
                        <?php esc_html_e( 'Warning: This cannot be undone. All translations will be permanently deleted.', 'wptranslate' ); ?>
                    </p>
                </td>
            </tr>
        </table>
        </div>
        <?php
    }

    /**
     * Render an info tooltip icon.
     *
     * @param string $text Tooltip text.
     */
    private function info_tip( string $text ): void {
        printf(
            '<span class="wptranslate-info-tip"><span class="dashicons dashicons-info" style="font-size:10px;width:10px;height:10px;"></span><span class="wptranslate-info-tip__text">%s</span></span>',
            esc_html( $text )
        );
    }

    // -------------------------------------------------------------------------
    // Sanitize Callbacks
    // -------------------------------------------------------------------------

    /**
     * Encrypt an API key before storing. If blank, keep existing value.
     *
     * @param string $value The submitted value.
     * @return string The encrypted key, or the existing stored value if blank.
     */
    public function sanitize_and_encrypt_api_key( $value ) {
        $value = sanitize_text_field( $value );

        if ( empty( $value ) ) {
            // Determine which option this is for and return the existing value.
            $option_name = current_filter();
            // Extract option name: sanitize_option_{option_name} -> {option_name}.
            $option_name = str_replace( 'sanitize_option_', '', $option_name );
            return get_option( $option_name, '' );
        }

        return $this->encrypt_value( $value );
    }

    /**
     * Encrypt a value using AES-256-CBC.
     *
     * @param string $value Plain text value.
     * @return string Encrypted value.
     */
    private function encrypt_value( string $value ): string {
        if ( ! function_exists( 'openssl_encrypt' ) ) {
            return base64_encode( $value ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
        }

        $key = wp_salt( 'auth' );
        $iv  = substr( wp_salt( 'secure_auth' ), 0, 16 );

        $encrypted = openssl_encrypt( $value, 'AES-256-CBC', $key, 0, $iv );

        return $encrypted ?: '';
    }

    /**
     * Decrypt a stored value.
     *
     * @param string $encrypted Encrypted value.
     * @return string Decrypted value.
     */
    public static function decrypt_value( string $encrypted ): string {
        if ( empty( $encrypted ) ) {
            return '';
        }

        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return base64_decode( $encrypted ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        }

        $key = wp_salt( 'auth' );
        $iv  = substr( wp_salt( 'secure_auth' ), 0, 16 );

        $decrypted = openssl_decrypt( $encrypted, 'AES-256-CBC', $key, 0, $iv );

        return $decrypted ?: '';
    }

    /**
     * Sanitize a float value.
     *
     * @param mixed $value Input.
     * @return float
     */
    public function sanitize_float( $value ): float {
        return (float) $value;
    }

    /**
     * Sanitize a boolean value.
     *
     * @param mixed $value Input.
     * @return bool
     */
    public function sanitize_bool( $value ): bool {
        return (bool) $value;
    }

    /**
     * Sanitize an array of text values.
     *
     * @param mixed $value Input.
     * @return array
     */
    public function sanitize_array_text( $value ): array {
        if ( ! is_array( $value ) ) {
            return array();
        }
        return array_map( 'sanitize_text_field', $value );
    }

    /**
     * Sanitize meta keys list (textarea, one per line).
     *
     * @param mixed $value Input.
     * @return array
     */
    public function sanitize_meta_keys( $value ): array {
        if ( is_array( $value ) ) {
            return array_map( 'sanitize_text_field', $value );
        }

        if ( is_string( $value ) ) {
            $keys = array_filter( array_map( 'trim', explode( "\n", $value ) ) );
            return array_map( 'sanitize_text_field', $keys );
        }

        return array();
    }

    /**
     * Sanitize formality settings array.
     *
     * @param mixed $value Input.
     * @return array
     */
    public function sanitize_formality( $value ): array {
        if ( ! is_array( $value ) ) {
            return array();
        }

        $allowed = array( 'default', 'formal', 'informal' );
        $sanitized = array();

        foreach ( $value as $lang => $formality ) {
            $lang = sanitize_text_field( $lang );
            $formality = sanitize_text_field( $formality );
            if ( in_array( $formality, $allowed, true ) ) {
                $sanitized[ $lang ] = $formality;
            }
        }

        return $sanitized;
    }

    /**
     * Sanitize provider overrides.
     *
     * @param mixed $value Input.
     * @return array
     */
    public function sanitize_provider_overrides( $value ): array {
        if ( ! is_array( $value ) ) {
            return array();
        }

        $allowed_providers = array( '', 'claude', 'openai', 'deepl' );
        $sanitized = array();

        foreach ( $value as $lang => $provider ) {
            $lang     = sanitize_text_field( $lang );
            $provider = sanitize_text_field( $provider );
            if ( in_array( $provider, $allowed_providers, true ) ) {
                $sanitized[ $lang ] = $provider;
            }
        }

        return $sanitized;
    }
}
