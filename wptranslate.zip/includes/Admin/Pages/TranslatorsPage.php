<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Translators admin page -- manage translator users, assign languages,
 * view completed/pending translation counts, and activity logs.
 */
class TranslatorsPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_assign_translator_languages', array( $this, 'ajax_assign_languages' ) );
        add_action( 'wp_ajax_wptranslate_get_translator_activity', array( $this, 'ajax_get_activity' ) );
        add_action( 'wp_ajax_wptranslate_add_translator', array( $this, 'ajax_add_translator' ) );
        add_action( 'wp_ajax_wptranslate_remove_translator', array( $this, 'ajax_remove_translator' ) );
    }

    /**
     * Render the translators management page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_manage_translators' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $language_manager = $this->plugin->get_language_manager();
        $active_languages = $language_manager->get_active_languages();
        $default_language = $language_manager->get_default_language();

        // Get all users who can translate.
        $translators = get_users( array(
            'role__in' => array( 'wptranslate_translator', 'wptranslate_translation_manager', 'administrator' ),
            'orderby'  => 'display_name',
            'order'    => 'ASC',
        ) );

        $translator_stats = $this->get_translator_stats( $translators );
        ?>
        <div class="wrap wptranslate-translators">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'Translators', 'wptranslate' ) ); ?>

            <?php wp_nonce_field( 'wptranslate_admin', 'wptranslate_translators_nonce' ); ?>

            <!-- Add Translator Section -->
            <div class="wptranslate-card" style="margin-bottom: 20px;">
                <h2><span class="dashicons dashicons-plus-alt2"></span> <?php esc_html_e( 'Add Translator', 'wptranslate' ); ?></h2>
                <p class="description"><?php esc_html_e( 'Grant translator capabilities to an existing WordPress user. This allows them to translate, edit, and submit translations.', 'wptranslate' ); ?></p>
                <div class="wptranslate-form-row" style="display: flex; align-items: center; gap: 10px; margin-top: 12px;">
                    <select id="wptranslate-add-translator-user" style="min-width: 300px;">
                        <option value=""><?php esc_html_e( '-- Select a user --', 'wptranslate' ); ?></option>
                        <?php
                        // Get all users who do NOT already have translator capabilities.
                        $translator_ids = array_map( function( $u ) { return $u->ID; }, $translators );
                        $all_users = get_users( array(
                            'exclude'  => $translator_ids,
                            'orderby'  => 'display_name',
                            'order'    => 'ASC',
                            'number'   => 200,
                        ) );
                        foreach ( $all_users as $u ) :
                        ?>
                            <option value="<?php echo esc_attr( $u->ID ); ?>">
                                <?php echo esc_html( $u->display_name . ' (' . $u->user_email . ')' ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button" class="button button-primary" id="wptranslate-add-translator-btn">
                        <span class="dashicons dashicons-plus" style="vertical-align: middle; line-height: 1.4;"></span>
                        <?php esc_html_e( 'Add as Translator', 'wptranslate' ); ?>
                    </button>
                </div>
                <?php if ( empty( $all_users ) ) : ?>
                    <p class="description" style="margin-top: 8px; color: #646970;">
                        <?php esc_html_e( 'All existing users already have translator capabilities.', 'wptranslate' ); ?>
                    </p>
                <?php endif; ?>
            </div>

            <?php if ( empty( $translators ) ) : ?>
                <div class="wptranslate-empty-state">
                    <div class="wptranslate-empty-state__icon">
                        <span class="dashicons dashicons-groups"></span>
                    </div>
                    <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No Translators Configured', 'wptranslate' ); ?></h3>
                    <p class="wptranslate-empty-state__description"><?php esc_html_e( 'Use the form above to add translator capabilities to existing WordPress users, or assign the \'Translator\' role directly from the Users page.', 'wptranslate' ); ?></p>
                </div>
            <?php else : ?>

            <div class="wptranslate-card">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th class="column-name"><?php esc_html_e( 'Name', 'wptranslate' ); ?></th>
                        <th class="column-role"><?php esc_html_e( 'Role', 'wptranslate' ); ?></th>
                        <th class="column-languages"><?php esc_html_e( 'Assigned Languages', 'wptranslate' ); ?></th>
                        <th class="column-completed"><?php esc_html_e( 'Completed', 'wptranslate' ); ?></th>
                        <th class="column-pending"><?php esc_html_e( 'Pending', 'wptranslate' ); ?></th>
                        <th class="column-last-activity"><?php esc_html_e( 'Last Activity', 'wptranslate' ); ?></th>
                        <th class="column-actions"><?php esc_html_e( 'Actions', 'wptranslate' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ( $translators as $user ) :
                        $stats = $translator_stats[ $user->ID ] ?? array(
                            'completed'     => 0,
                            'pending'       => 0,
                            'last_activity' => null,
                        );
                        $assigned_languages = get_user_meta( $user->ID, '_wptranslate_assigned_languages', true );
                        if ( ! is_array( $assigned_languages ) ) {
                            $assigned_languages = array();
                        }
                        $role_name = $this->get_translator_role_label( $user );
                    ?>
                    <tr data-user-id="<?php echo esc_attr( $user->ID ); ?>">
                        <td class="column-name">
                            <?php echo get_avatar( $user->ID, 32 ); ?>
                            <strong>
                                <a href="<?php echo esc_url( get_edit_user_link( $user->ID ) ); ?>">
                                    <?php echo esc_html( $user->display_name ); ?>
                                </a>
                            </strong>
                            <br />
                            <span class="description"><?php echo esc_html( $user->user_email ); ?></span>
                        </td>
                        <td class="column-role">
                            <?php echo esc_html( $role_name ); ?>
                        </td>
                        <td class="column-languages">
                            <?php if ( empty( $assigned_languages ) ) : ?>
                                <span class="description"><?php esc_html_e( 'None assigned', 'wptranslate' ); ?></span>
                            <?php else : ?>
                                <?php foreach ( $assigned_languages as $lang_code ) :
                                    $lang_data = $language_manager->get_language( $lang_code );
                                    if ( ! $lang_data ) { continue; }
                                ?>
                                    <span class="wptranslate-badge">
                                        <?php echo esc_html( ( $lang_data['flag'] ?? '' ) . ' ' . $lang_data['name'] ); ?>
                                    </span>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </td>
                        <td class="column-completed">
                            <strong><?php echo esc_html( number_format_i18n( $stats['completed'] ) ); ?></strong>
                        </td>
                        <td class="column-pending">
                            <?php if ( $stats['pending'] > 0 ) : ?>
                                <span class="wptranslate-badge wptranslate-badge--warning">
                                    <?php echo esc_html( number_format_i18n( $stats['pending'] ) ); ?>
                                </span>
                            <?php else : ?>
                                0
                            <?php endif; ?>
                        </td>
                        <td class="column-last-activity">
                            <?php if ( $stats['last_activity'] ) : ?>
                                <?php echo esc_html( human_time_diff( strtotime( $stats['last_activity'] ), time() ) ); ?>
                                <?php esc_html_e( 'ago', 'wptranslate' ); ?>
                            <?php else : ?>
                                <span class="description"><?php esc_html_e( 'Never', 'wptranslate' ); ?></span>
                            <?php endif; ?>
                        </td>
                        <td class="column-actions">
                            <div style="display: flex; gap: 4px; align-items: center;">
                                <button type="button"
                                        class="button button-small wptranslate-assign-languages-btn"
                                        data-user-id="<?php echo esc_attr( $user->ID ); ?>"
                                        data-user-name="<?php echo esc_attr( $user->display_name ); ?>"
                                        data-assigned="<?php echo esc_attr( wp_json_encode( $assigned_languages ) ); ?>"
                                        title="<?php esc_attr_e( 'Assign Languages', 'wptranslate' ); ?>">
                                    <span class="dashicons dashicons-translation" style="vertical-align: middle; line-height: 1.4;"></span>
                                    <span class="screen-reader-text"><?php esc_html_e( 'Assign Languages', 'wptranslate' ); ?></span>
                                </button>
                                <button type="button"
                                        class="button button-small wptranslate-view-activity-btn"
                                        data-user-id="<?php echo esc_attr( $user->ID ); ?>"
                                        data-user-name="<?php echo esc_attr( $user->display_name ); ?>"
                                        title="<?php esc_attr_e( 'Activity Log', 'wptranslate' ); ?>">
                                    <span class="dashicons dashicons-list-view" style="vertical-align: middle; line-height: 1.4;"></span>
                                    <span class="screen-reader-text"><?php esc_html_e( 'Activity Log', 'wptranslate' ); ?></span>
                                </button>
                                <button type="button"
                                        class="button button-small wptranslate-remove-translator"
                                        data-user-id="<?php echo esc_attr( $user->ID ); ?>"
                                        data-user-name="<?php echo esc_attr( $user->display_name ); ?>"
                                        title="<?php esc_attr_e( 'Remove Translator', 'wptranslate' ); ?>"
                                        style="color: #b32d2e;">
                                    <span class="dashicons dashicons-no" style="vertical-align: middle; line-height: 1.4;"></span>
                                    <span class="screen-reader-text"><?php esc_html_e( 'Remove Translator', 'wptranslate' ); ?></span>
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            </div>

            <?php endif; ?>

            <!-- Assign Languages Modal -->
            <div id="wptranslate-assign-languages-modal" class="wptranslate-modal" style="display:none;">
                <div class="wptranslate-modal__content">
                    <h2>
                        <?php esc_html_e( 'Assign Languages to', 'wptranslate' ); ?>
                        <span id="wptranslate-assign-user-name"></span>
                    </h2>
                    <form id="wptranslate-assign-languages-form">
                        <input type="hidden" id="wptranslate-assign-user-id" name="user_id" value="" />
                        <fieldset>
                            <?php foreach ( $active_languages as $lang ) :
                                if ( $lang['code'] === $default_language ) { continue; }
                            ?>
                            <label class="wptranslate-language-checkbox">
                                <input type="checkbox"
                                       name="languages[]"
                                       value="<?php echo esc_attr( $lang['code'] ); ?>"
                                       class="wptranslate-assign-lang-cb" />
                                <?php echo esc_html( ( $lang['flag'] ?? '' ) . ' ' . $lang['name'] ); ?>
                            </label><br />
                            <?php endforeach; ?>
                        </fieldset>
                        <p class="submit">
                            <button type="button" class="button button-primary" id="wptranslate-save-language-assignment">
                                <?php esc_html_e( 'Save Assignment', 'wptranslate' ); ?>
                            </button>
                            <button type="button" class="button wptranslate-modal__close">
                                <?php esc_html_e( 'Cancel', 'wptranslate' ); ?>
                            </button>
                        </p>
                    </form>
                </div>
            </div>

            <!-- Activity Log Modal -->
            <div id="wptranslate-activity-modal" class="wptranslate-modal" style="display:none;">
                <div class="wptranslate-modal__content wptranslate-modal__content--wide">
                    <h2>
                        <?php esc_html_e( 'Activity Log:', 'wptranslate' ); ?>
                        <span id="wptranslate-activity-user-name"></span>
                    </h2>
                    <div id="wptranslate-activity-log-content">
                        <p class="description"><?php esc_html_e( 'Loading...', 'wptranslate' ); ?></p>
                    </div>
                    <p>
                        <button type="button" class="button wptranslate-modal__close">
                            <?php esc_html_e( 'Close', 'wptranslate' ); ?>
                        </button>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * Get translation statistics for a list of translator users.
     *
     * @param \WP_User[] $translators Array of user objects.
     * @return array Keyed by user ID.
     */
    private function get_translator_stats( array $translators ): array {
        if ( empty( $translators ) ) {
            return array();
        }

        global $wpdb;
        $status_table = $wpdb->prefix . 'wpt_translation_status';

        $user_ids    = array_map( function( $u ) { return $u->ID; }, $translators );
        $placeholder = implode( ',', array_fill( 0, count( $user_ids ), '%d' ) );

        $stats = array();
        foreach ( $user_ids as $uid ) {
            $stats[ $uid ] = array( 'completed' => 0, 'pending' => 0, 'last_activity' => null );
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $completed_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT translator, COUNT(*) as cnt FROM {$status_table}
                 WHERE translator IN ({$placeholder}) AND status IN ('published', 'approved')
                 GROUP BY translator",
                ...$user_ids
            ),
            ARRAY_A
        );
        foreach ( $completed_rows as $row ) {
            $stats[ (int) $row['translator'] ]['completed'] = (int) $row['cnt'];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $pending_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT assigned_to, COUNT(*) as cnt FROM {$status_table}
                 WHERE assigned_to IN ({$placeholder}) AND status IN ('assigned', 'ai_draft', 'in_progress', 'revision_requested')
                 GROUP BY assigned_to",
                ...$user_ids
            ),
            ARRAY_A
        );
        foreach ( $pending_rows as $row ) {
            $stats[ (int) $row['assigned_to'] ]['pending'] = (int) $row['cnt'];
        }

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $activity_rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT translator, MAX(date_modified) as last_active FROM {$status_table}
                 WHERE translator IN ({$placeholder})
                 GROUP BY translator",
                ...$user_ids
            ),
            ARRAY_A
        );
        foreach ( $activity_rows as $row ) {
            $stats[ (int) $row['translator'] ]['last_activity'] = $row['last_active'];
        }

        return $stats;
    }

    /**
     * Get a human-readable role label for a translator.
     */
    private function get_translator_role_label( \WP_User $user ): string {
        if ( in_array( 'administrator', $user->roles, true ) ) {
            return __( 'Administrator', 'wptranslate' );
        }
        if ( in_array( 'wptranslate_translation_manager', $user->roles, true ) ) {
            return __( 'Translation Manager', 'wptranslate' );
        }
        if ( in_array( 'wptranslate_translator', $user->roles, true ) ) {
            return __( 'Translator', 'wptranslate' );
        }
        return __( 'Other', 'wptranslate' );
    }

    // -------------------------------------------------------------------------
    // AJAX Handlers
    // -------------------------------------------------------------------------

    /**
     * AJAX: Assign languages to a translator.
     */
    public function ajax_assign_languages(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_translators' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $user_id   = absint( $_POST['user_id'] ?? 0 );
        $languages = isset( $_POST['languages'] ) ? array_map( 'sanitize_text_field', (array) $_POST['languages'] ) : array();

        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user.', 'wptranslate' ) ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            wp_send_json_error( array( 'message' => __( 'User not found.', 'wptranslate' ) ) );
        }

        // Validate language codes.
        $valid_codes = array_column( $this->plugin->get_language_manager()->get_active_languages(), 'code' );
        $languages   = array_intersect( $languages, $valid_codes );

        update_user_meta( $user_id, '_wptranslate_assigned_languages', $languages );

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: 1: user name, 2: number of languages */
                __( '%1$s assigned to %2$d language(s).', 'wptranslate' ),
                $user->display_name,
                count( $languages )
            ),
        ) );
    }

    /**
     * AJAX: Add translator capabilities to a user.
     */
    public function ajax_add_translator(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_translators' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $user_id = absint( $_POST['user_id'] ?? 0 );
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Please select a user.', 'wptranslate' ) ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            wp_send_json_error( array( 'message' => __( 'User not found.', 'wptranslate' ) ) );
        }

        // Grant translator capabilities.
        $user->add_cap( 'wptranslate_translate_posts' );
        $user->add_cap( 'wptranslate_edit_translations' );
        $user->add_cap( 'wptranslate_submit_translations' );

        // Also add the translator role if it exists.
        if ( get_role( 'wptranslate_translator' ) ) {
            $user->add_role( 'wptranslate_translator' );
        }

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %s: user display name */
                __( '%s has been added as a translator.', 'wptranslate' ),
                $user->display_name
            ),
            'user'    => array(
                'id'           => $user->ID,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
                'avatar'       => get_avatar_url( $user->ID, array( 'size' => 32 ) ),
                'role_label'   => __( 'Translator', 'wptranslate' ),
            ),
        ) );
    }

    /**
     * AJAX: Remove translator capabilities from a user.
     */
    public function ajax_remove_translator(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_translators' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $user_id = absint( $_POST['user_id'] ?? 0 );
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user.', 'wptranslate' ) ) );
        }

        $user = get_userdata( $user_id );
        if ( ! $user ) {
            wp_send_json_error( array( 'message' => __( 'User not found.', 'wptranslate' ) ) );
        }

        // Remove all wptranslate capabilities.
        $user->remove_cap( 'wptranslate_translate_posts' );
        $user->remove_cap( 'wptranslate_edit_translations' );
        $user->remove_cap( 'wptranslate_submit_translations' );

        // Remove the translator role if assigned.
        if ( in_array( 'wptranslate_translator', $user->roles, true ) ) {
            $user->remove_role( 'wptranslate_translator' );
        }

        // Clean up assigned languages meta.
        delete_user_meta( $user_id, '_wptranslate_assigned_languages' );

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %s: user display name */
                __( '%s has been removed as a translator.', 'wptranslate' ),
                $user->display_name
            ),
        ) );
    }

    /**
     * AJAX: Get activity log for a translator.
     */
    public function ajax_get_activity(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_translators' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $user_id = absint( $_POST['user_id'] ?? 0 );
        if ( ! $user_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid user.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $status_table       = $wpdb->prefix . 'wpt_translation_status';
        $translations_table = $wpdb->prefix . 'wpt_translations';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $activities = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT s.status, s.date_modified, t.element_id, t.language_code, t.element_type
                 FROM {$status_table} s
                 INNER JOIN {$translations_table} t ON s.translation_id = t.id
                 WHERE s.translator = %d OR s.assigned_to = %d OR s.reviewed_by = %d
                 ORDER BY s.date_modified DESC
                 LIMIT 50",
                $user_id, $user_id, $user_id
            ),
            ARRAY_A
        );

        $items = array();
        foreach ( $activities as $activity ) {
            $post      = get_post( $activity['element_id'] );
            $lang_data = $this->plugin->get_language_manager()->get_language( $activity['language_code'] );
            $items[]   = array(
                'title'    => $post ? $post->post_title : __( '(deleted)', 'wptranslate' ),
                'language' => $lang_data ? $lang_data['name'] : $activity['language_code'],
                'status'   => ucfirst( str_replace( '_', ' ', $activity['status'] ) ),
                'date'     => $activity['date_modified'],
                'ago'      => human_time_diff( strtotime( $activity['date_modified'] ), time() ),
            );
        }

        wp_send_json_success( array( 'activities' => $items ) );
    }
}
