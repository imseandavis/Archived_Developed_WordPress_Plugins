<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * String Translation admin page -- extends WP_List_Table to display all
 * registered gettext strings with inline AJAX editing, bulk actions,
 * filtering, and PO/POT import/export.
 */
class StringTranslationPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_inline_save_string', array( $this, 'ajax_inline_save_string' ) );
        add_action( 'wp_ajax_wptranslate_bulk_translate_strings', array( $this, 'ajax_bulk_translate_strings' ) );
        add_action( 'wp_ajax_wptranslate_import_po', array( $this, 'ajax_import_po' ) );
        add_action( 'wp_ajax_wptranslate_export_po', array( $this, 'ajax_export_po' ) );
    }

    /**
     * Render the string translation page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $table = new StringTranslationListTable( $this->plugin );
        $table->prepare_items();

        $language_manager   = $this->plugin->get_language_manager();
        $active_languages   = $language_manager->get_active_languages();
        $string_translation = $this->plugin->get_string_translation();
        $domains            = $string_translation->get_domains();
        $current_domain     = sanitize_text_field( $_GET['domain'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_status     = sanitize_text_field( $_GET['status'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $current_language   = sanitize_text_field( $_GET['language'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        ?>
        <div class="wrap wptranslate-string-translations">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'String Translation', 'wptranslate' ) ); ?>

            <?php wp_nonce_field( 'wptranslate_admin', 'wptranslate_strings_nonce' ); ?>

            <!-- Filters -->
            <div class="wptranslate-card">
            <div class="wptranslate-string-filters">
                <form method="get">
                    <input type="hidden" name="page" value="wptranslate-strings" />

                    <label for="wptranslate-filter-domain"><?php esc_html_e( 'Domain:', 'wptranslate' ); ?></label>
                    <select id="wptranslate-filter-domain" name="domain">
                        <option value=""><?php esc_html_e( 'All Domains', 'wptranslate' ); ?></option>
                        <?php foreach ( $domains as $domain ) : ?>
                            <option value="<?php echo esc_attr( $domain ); ?>" <?php selected( $current_domain, $domain ); ?>>
                                <?php echo esc_html( $domain ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <label for="wptranslate-filter-status"><?php esc_html_e( 'Status:', 'wptranslate' ); ?></label>
                    <select id="wptranslate-filter-status" name="status">
                        <option value=""><?php esc_html_e( 'All Statuses', 'wptranslate' ); ?></option>
                        <option value="translated" <?php selected( $current_status, 'translated' ); ?>><?php esc_html_e( 'Translated', 'wptranslate' ); ?></option>
                        <option value="needs_translation" <?php selected( $current_status, 'needs_translation' ); ?>><?php esc_html_e( 'Needs Translation', 'wptranslate' ); ?></option>
                        <option value="reviewed" <?php selected( $current_status, 'reviewed' ); ?>><?php esc_html_e( 'Reviewed', 'wptranslate' ); ?></option>
                    </select>

                    <label for="wptranslate-filter-language"><?php esc_html_e( 'Language:', 'wptranslate' ); ?></label>
                    <select id="wptranslate-filter-language" name="language">
                        <option value=""><?php esc_html_e( 'All Languages', 'wptranslate' ); ?></option>
                        <?php foreach ( $active_languages as $lang ) : ?>
                            <option value="<?php echo esc_attr( $lang['code'] ); ?>" <?php selected( $current_language, $lang['code'] ); ?>>
                                <?php echo esc_html( $lang['name'] ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <?php $table->search_box( __( 'Search Strings', 'wptranslate' ), 'wptranslate-search' ); ?>

                    <?php submit_button( __( 'Filter', 'wptranslate' ), 'secondary', 'filter_action', false ); ?>
                </form>
            </div>

            </div>

            <!-- Import/Export Buttons -->
            <div class="wptranslate-string-actions">
                <button type="button" class="button" id="wptranslate-import-po-btn">
                    <span class="dashicons dashicons-upload"></span>
                    <?php esc_html_e( 'Import PO/POT', 'wptranslate' ); ?>
                </button>
                <button type="button" class="button" id="wptranslate-export-po-btn">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e( 'Export PO', 'wptranslate' ); ?>
                </button>
                <button type="button" class="button" id="wptranslate-export-pot-btn">
                    <span class="dashicons dashicons-download"></span>
                    <?php esc_html_e( 'Export POT', 'wptranslate' ); ?>
                </button>
            </div>

            <!-- Import Modal -->
            <div id="wptranslate-import-modal" class="wptranslate-modal" style="display:none;">
                <div class="wptranslate-modal__content">
                    <h2><?php esc_html_e( 'Import PO/POT File', 'wptranslate' ); ?></h2>
                    <form id="wptranslate-import-form" enctype="multipart/form-data">
                        <input type="hidden" name="action" value="wptranslate_import_po" />
                        <?php wp_nonce_field( 'wptranslate_admin', 'nonce' ); ?>
                        <table class="form-table">
                            <tr>
                                <th><label for="import-po-file"><?php esc_html_e( 'File', 'wptranslate' ); ?></label></th>
                                <td><input type="file" id="import-po-file" name="po_file" accept=".po,.pot" required /></td>
                            </tr>
                            <tr>
                                <th><label for="import-po-language"><?php esc_html_e( 'Language', 'wptranslate' ); ?></label></th>
                                <td>
                                    <select id="import-po-language" name="language">
                                        <?php foreach ( $active_languages as $lang ) : ?>
                                            <option value="<?php echo esc_attr( $lang['code'] ); ?>"><?php echo esc_html( $lang['name'] ); ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                </td>
                            </tr>
                            <tr>
                                <th><label for="import-po-domain"><?php esc_html_e( 'Domain', 'wptranslate' ); ?></label></th>
                                <td><input type="text" id="import-po-domain" name="domain" value="default" class="regular-text" /></td>
                            </tr>
                        </table>
                        <p class="submit">
                            <button type="submit" class="button button-primary"><?php esc_html_e( 'Import', 'wptranslate' ); ?></button>
                            <button type="button" class="button wptranslate-modal__close"><?php esc_html_e( 'Cancel', 'wptranslate' ); ?></button>
                        </p>
                    </form>
                </div>
            </div>

            <!-- List Table -->
            <div class="wptranslate-card">
            <form method="post" id="wptranslate-strings-form">
                <?php $table->display(); ?>
            </form>
            </div>
        </div>
        <?php
    }

    /**
     * AJAX: Inline save a string translation.
     */
    public function ajax_inline_save_string(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $string_id  = absint( $_POST['string_id'] ?? 0 );
        $translated = sanitize_textarea_field( $_POST['translated'] ?? '' );
        $language   = sanitize_text_field( $_POST['language'] ?? '' );

        if ( ! $string_id || empty( $language ) ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $tbl = $wpdb->prefix . 'wpt_string_translations';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $original = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id = %d", $string_id ),
            ARRAY_A
        );

        if ( ! $original ) {
            wp_send_json_error( array( 'message' => __( 'String not found.', 'wptranslate' ) ) );
        }

        $result = $this->plugin->get_string_translation()->save_translation(
            $original['string_name'],
            $translated,
            $language,
            $original['domain'],
            $original['context']
        );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Failed to save.', 'wptranslate' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Translation saved.', 'wptranslate' ) ) );
    }

    /**
     * AJAX: Bulk translate selected strings using AI.
     */
    public function ajax_bulk_translate_strings(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $string_ids  = array_map( 'absint', (array) ( $_POST['string_ids'] ?? array() ) );
        $target_lang = sanitize_text_field( $_POST['target_lang'] ?? '' );

        if ( empty( $string_ids ) || empty( $target_lang ) ) {
            wp_send_json_error( array( 'message' => __( 'Missing required parameters.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $tbl                 = $wpdb->prefix . 'wpt_string_translations';
        $translation_manager = $this->plugin->get_translation_manager();
        $default_language    = $this->plugin->get_language_manager()->get_default_language();
        $translated_count    = 0;
        $error_count         = 0;

        foreach ( $string_ids as $id ) {
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE id = %d", $id ), ARRAY_A );

            if ( ! $row || empty( $row['string_name'] ) ) {
                $error_count++;
                continue;
            }

            $result = $translation_manager->translate_text( $row['string_name'], $default_language, $target_lang );

            if ( is_wp_error( $result ) ) {
                $error_count++;
                continue;
            }

            $saved = $this->plugin->get_string_translation()->save_translation(
                $row['string_name'], $result, $target_lang, $row['domain'], $row['context']
            );
            $saved ? $translated_count++ : $error_count++;
        }

        wp_send_json_success( array(
            'message'    => sprintf( __( '%1$d strings translated, %2$d errors.', 'wptranslate' ), $translated_count, $error_count ),
            'translated' => $translated_count,
            'errors'     => $error_count,
        ) );
    }

    /**
     * AJAX: Import a PO/POT file.
     */
    public function ajax_import_po(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_settings' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        if ( empty( $_FILES['po_file'] ) || ! empty( $_FILES['po_file']['error'] ) ) {
            wp_send_json_error( array( 'message' => __( 'No file uploaded or upload error.', 'wptranslate' ) ) );
        }

        $file     = $_FILES['po_file'];
        $language = sanitize_text_field( $_POST['language'] ?? '' );
        $domain   = sanitize_text_field( $_POST['domain'] ?? 'default' );

        $ext = strtolower( pathinfo( sanitize_file_name( $file['name'] ), PATHINFO_EXTENSION ) );
        if ( ! in_array( $ext, array( 'po', 'pot' ), true ) ) {
            wp_send_json_error( array( 'message' => __( 'Invalid file type. Please upload a .po or .pot file.', 'wptranslate' ) ) );
        }

        // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $content = file_get_contents( $file['tmp_name'] );
        if ( false === $content ) {
            wp_send_json_error( array( 'message' => __( 'Could not read uploaded file.', 'wptranslate' ) ) );
        }

        $imported = $this->parse_and_import_po( $content, $language, $domain );

        wp_send_json_success( array(
            'message' => sprintf( __( '%d strings imported.', 'wptranslate' ), $imported ),
        ) );
    }

    /**
     * AJAX: Export strings as PO file.
     */
    public function ajax_export_po(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $language = sanitize_text_field( $_POST['language'] ?? '' );
        $domain   = sanitize_text_field( $_POST['domain'] ?? '' );
        $format   = sanitize_text_field( $_POST['format'] ?? 'po' );

        $strings = $this->plugin->get_string_translation()->get_strings( $domain, $language, '', 10000, 1 );
        $output  = $this->generate_po_content( $strings['items'], $language, $domain, 'pot' === $format );

        wp_send_json_success( array(
            'content'  => $output,
            'filename' => sanitize_file_name( ( $domain ?: 'wptranslate' ) . '-' . ( $language ?: 'all' ) . '.' . $format ),
        ) );
    }

    private function parse_and_import_po( string $content, string $language, string $domain ): int {
        $count = 0;
        $entries = array();
        $current = array( 'msgid' => '', 'msgstr' => '', 'msgctxt' => '' );
        $in_field = '';

        foreach ( explode( "\n", $content ) as $line ) {
            $line = trim( $line );
            if ( '' === $line || ( isset( $line[0] ) && '#' === $line[0] ) ) {
                if ( ! empty( $current['msgid'] ) ) { $entries[] = $current; }
                $current = array( 'msgid' => '', 'msgstr' => '', 'msgctxt' => '' );
                $in_field = '';
                continue;
            }
            if ( 0 === strpos( $line, 'msgctxt ' ) ) { $current['msgctxt'] = $this->po_unquote( substr( $line, 8 ) ); $in_field = 'msgctxt'; }
            elseif ( 0 === strpos( $line, 'msgid ' ) ) { $current['msgid'] = $this->po_unquote( substr( $line, 6 ) ); $in_field = 'msgid'; }
            elseif ( 0 === strpos( $line, 'msgstr ' ) ) { $current['msgstr'] = $this->po_unquote( substr( $line, 7 ) ); $in_field = 'msgstr'; }
            elseif ( isset( $line[0] ) && '"' === $line[0] && ! empty( $in_field ) ) { $current[ $in_field ] .= $this->po_unquote( $line ); }
        }
        if ( ! empty( $current['msgid'] ) ) { $entries[] = $current; }

        $st = $this->plugin->get_string_translation();
        foreach ( $entries as $e ) {
            if ( empty( $e['msgid'] ) ) { continue; }
            if ( $st->save_translation( $e['msgid'], $e['msgstr'], $language, $domain, $e['msgctxt'] ) ) { $count++; }
        }
        return $count;
    }

    private function po_unquote( string $str ): string {
        $str = trim( $str );
        if ( strlen( $str ) >= 2 && '"' === $str[0] && '"' === $str[ strlen( $str ) - 1 ] ) { $str = substr( $str, 1, -1 ); }
        return str_replace( array( '\\n', '\\"', '\\\\' ), array( "\n", '"', '\\' ), $str );
    }

    private function generate_po_content( array $strings, string $language, string $domain, bool $is_pot = false ): string {
        $out  = "# WPTranslate Export\n# Domain: {$domain}\n# Language: {$language}\n#\nmsgid \"\"\nmsgstr \"\"\n";
        $out .= "\"Content-Type: text/plain; charset=UTF-8\\n\"\n\"Content-Transfer-Encoding: 8bit\\n\"\n";
        if ( ! $is_pot && $language ) { $out .= "\"Language: {$language}\\n\"\n"; }
        $out .= "\n";
        foreach ( $strings as $s ) {
            if ( ! empty( $s['context'] ) ) { $out .= 'msgctxt ' . $this->po_quote( $s['context'] ) . "\n"; }
            $out .= 'msgid ' . $this->po_quote( $s['string_name'] ) . "\n";
            $out .= 'msgstr ' . ( $is_pot ? '""' : $this->po_quote( $s['string_value'] ?? '' ) ) . "\n\n";
        }
        return $out;
    }

    private function po_quote( string $str ): string {
        return '"' . str_replace( array( '\\', '"', "\n" ), array( '\\\\', '\\"', '\\n' ), $str ) . '"';
    }
}

// ---------------------------------------------------------------------------
// WP_List_Table subclass
// ---------------------------------------------------------------------------
if ( ! class_exists( 'WP_List_Table' ) ) {
    require_once ABSPATH . 'wp-admin/includes/class-wp-list-table.php';
}

class StringTranslationListTable extends \WP_List_Table {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;
        parent::__construct( array( 'singular' => 'string_translation', 'plural' => 'string_translations', 'ajax' => false ) );
    }

    public function no_items(): void {
        ?>
        <div class="wptranslate-empty-state">
            <div class="wptranslate-empty-state__icon">
                <span class="dashicons dashicons-editor-textcolor"></span>
            </div>
            <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No Strings Found', 'wptranslate' ); ?></h3>
            <p class="wptranslate-empty-state__description"><?php esc_html_e( 'Translatable strings will appear here as your site pages are loaded. Visit the front-end of your site to register theme and plugin strings.', 'wptranslate' ); ?></p>
            <div class="wptranslate-empty-state__action">
                <a href="<?php echo esc_url( home_url() ); ?>" class="button button-primary"><?php esc_html_e( 'Visit Site', 'wptranslate' ); ?></a>
            </div>
        </div>
        <?php
    }

    public function get_columns(): array {
        return array(
            'cb' => '<input type="checkbox" />', 'string_name' => __( 'Original String', 'wptranslate' ),
            'translation' => __( 'Translation', 'wptranslate' ), 'domain' => __( 'Domain', 'wptranslate' ),
            'context' => __( 'Context', 'wptranslate' ), 'status' => __( 'Status', 'wptranslate' ),
            'actions' => __( 'Actions', 'wptranslate' ),
        );
    }

    public function get_sortable_columns(): array {
        return array( 'string_name' => array( 'string_name', false ), 'domain' => array( 'domain', false ), 'status' => array( 'status', false ) );
    }

    public function get_bulk_actions(): array {
        return array( 'translate' => __( 'Translate Selected (AI)', 'wptranslate' ), 'mark_reviewed' => __( 'Mark as Reviewed', 'wptranslate' ), 'delete' => __( 'Delete', 'wptranslate' ) );
    }

    public function column_cb( $item ): string {
        return sprintf( '<input type="checkbox" name="string_ids[]" value="%d" />', absint( $item['id'] ) );
    }

    public function column_string_name( $item ): string {
        $t = mb_strlen( $item['string_name'] ) > 100 ? mb_substr( $item['string_name'], 0, 100 ) . '...' : $item['string_name'];
        return sprintf( '<span class="wptranslate-original-string" title="%s">%s</span>', esc_attr( $item['string_name'] ), esc_html( $t ) );
    }

    public function column_translation( $item ): string {
        return sprintf(
            '<div class="wptranslate-inline-edit" data-string-id="%d"><span class="wptranslate-inline-edit__display">%s</span>'
            . '<textarea class="wptranslate-inline-edit__input" style="display:none;">%s</textarea>'
            . '<button type="button" class="button button-small wptranslate-inline-edit__save" style="display:none;">%s</button></div>',
            absint( $item['id'] ), esc_html( $item['string_value'] ?? __( '(untranslated)', 'wptranslate' ) ),
            esc_attr( $item['string_value'] ?? '' ), esc_html__( 'Save', 'wptranslate' )
        );
    }

    public function column_domain( $item ): string { return '<code>' . esc_html( $item['domain'] ) . '</code>'; }
    public function column_context( $item ): string { return esc_html( $item['context'] ?: '-' ); }

    public function column_status( $item ): string {
        $s = $item['status'] ?? 'needs_translation';
        $l = array( 'translated' => __( 'Translated', 'wptranslate' ), 'needs_translation' => __( 'Needs Translation', 'wptranslate' ), 'reviewed' => __( 'Reviewed', 'wptranslate' ) );
        return sprintf( '<span class="wptranslate-string-status wptranslate-string-status--%s">%s</span>', esc_attr( sanitize_html_class( $s ) ), esc_html( $l[ $s ] ?? $s ) );
    }

    public function column_actions( $item ): string {
        return sprintf( '<button type="button" class="button button-small wptranslate-edit-string" data-string-id="%d">%s</button>', absint( $item['id'] ), esc_html__( 'Edit', 'wptranslate' ) );
    }

    public function prepare_items(): void {
        $per_page = 50;
        $page = $this->get_pagenum();
        $domain = sanitize_text_field( $_GET['domain'] ?? '' );     // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $language = sanitize_text_field( $_GET['language'] ?? '' );  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $status = sanitize_text_field( $_GET['status'] ?? '' );      // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $search = sanitize_text_field( $_GET['s'] ?? '' );           // phpcs:ignore WordPress.Security.NonceVerification.Recommended

        if ( empty( $language ) ) { $language = $this->plugin->get_language_manager()->get_default_language(); }

        if ( ! empty( $search ) ) {
            global $wpdb;
            $tbl = $wpdb->prefix . 'wpt_string_translations';
            $w = array( 'language_code = %s' ); $p = array( $language );
            if ( $domain ) { $w[] = 'domain = %s'; $p[] = $domain; }
            if ( $status ) { $w[] = 'status = %s'; $p[] = $status; }
            $w[] = '(string_name LIKE %s OR string_value LIKE %s)';
            $like = '%' . $wpdb->esc_like( $search ) . '%'; $p[] = $like; $p[] = $like;
            $ws = implode( ' AND ', $w ); $cp = $p;
            $p[] = $per_page; $p[] = ( $page - 1 ) * $per_page;
            $items = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$tbl} WHERE {$ws} ORDER BY domain ASC, string_name ASC LIMIT %d OFFSET %d", ...$p ), ARRAY_A ); // phpcs:ignore
            $total = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$tbl} WHERE {$ws}", ...$cp ) ); // phpcs:ignore
        } else {
            $data = $this->plugin->get_string_translation()->get_strings( $domain, $language, $status, $per_page, $page );
            $items = $data['items']; $total = $data['total'];
        }

        $this->items = $items;
        $this->set_pagination_args( array( 'total_items' => $total, 'per_page' => $per_page, 'total_pages' => ceil( $total / $per_page ) ) );
        $this->_column_headers = array( $this->get_columns(), array(), $this->get_sortable_columns() );
    }
}
