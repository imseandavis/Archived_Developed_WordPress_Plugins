<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;
use WPTranslate\Admin\AdminController;

/**
 * Dashboard admin page — overview of translation status, recent activity,
 * API usage statistics, quick actions, and system health.
 */
class DashboardPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;
    }

    /**
     * Render the dashboard page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }
        ?>
        <div class="wrap wptranslate-dashboard">
            <?php
            AdminController::render_page_header( __( 'WPTranslate Dashboard', 'wptranslate' ) );
            $this->render_setup_wizard();
            ?>

            <div class="wptranslate-dashboard-grid">
                <?php
                $this->render_translation_overview();
                $this->render_recent_activity();
                $this->render_api_usage();
                $this->render_quick_actions();
                $this->render_system_health();
                ?>
            </div>
        </div>
        <?php
    }

    /**
     * Setup wizard banner — shown when setup is incomplete and not dismissed.
     */
    private function render_setup_wizard(): void {
        $language_manager = $this->plugin->get_language_manager();
        $languages        = $language_manager->get_active_languages();
        $default_lang     = $language_manager->get_default_language();

        // "Has languages" means at least one TARGET language beyond the default.
        $target_count    = 0;
        foreach ( $languages as $lang ) {
            if ( $lang['code'] !== $default_lang ) {
                $target_count++;
            }
        }
        $has_target_languages = $target_count > 0;

        $has_api_key     = ! empty( get_option( 'wptranslate_claude_api_key' ) )
                        || ! empty( get_option( 'wptranslate_openai_api_key' ) )
                        || ! empty( get_option( 'wptranslate_deepl_api_key' ) );
        $has_post_types  = ! empty( get_option( 'wptranslate_post_types', array() ) );
        $has_site_context = ! empty( get_option( 'wptranslate_site_context', '' ) );
        $wizard_dismissed = (bool) get_user_meta( get_current_user_id(), '_wptranslate_wizard_dismissed', true );
        $all_complete    = $has_target_languages && $has_api_key && $has_post_types && $has_site_context;

        if ( ! $all_complete && ! $wizard_dismissed ) :
            // Determine active step.
            if ( ! $has_target_languages ) {
                $active_step = 1;
            } elseif ( ! $has_api_key ) {
                $active_step = 2;
            } elseif ( ! $has_post_types ) {
                $active_step = 3;
            } elseif ( ! $has_site_context ) {
                $active_step = 4;
            } else {
                $active_step = 5;
            }

            $steps = array(
                1 => array(
                    'label' => __( 'Add Languages', 'wptranslate' ),
                    'url'   => admin_url( 'admin.php?page=wptranslate-languages' ),
                    'done'  => $has_target_languages,
                ),
                2 => array(
                    'label' => __( 'API Key', 'wptranslate' ),
                    'url'   => admin_url( 'admin.php?page=wptranslate-settings&tab=providers' ),
                    'done'  => $has_api_key,
                ),
                3 => array(
                    'label' => __( 'Content Types', 'wptranslate' ),
                    'url'   => admin_url( 'admin.php?page=wptranslate-settings&tab=content' ),
                    'done'  => $has_post_types,
                ),
                4 => array(
                    'label' => __( 'Site Context', 'wptranslate' ),
                    'url'   => admin_url( 'admin.php?page=wptranslate-settings&tab=quality' ),
                    'done'  => $has_site_context,
                ),
                5 => array(
                    'label' => __( 'Start Translating', 'wptranslate' ),
                    'url'   => '#',
                    'done'  => $all_complete,
                ),
            );
            ?>
            <div class="wptranslate-wizard">
                <button type="button" class="wptranslate-wizard__dismiss" aria-label="<?php esc_attr_e( 'Dismiss', 'wptranslate' ); ?>">&times;</button>
                <h2 class="wptranslate-wizard__title"><?php esc_html_e( 'Welcome to WPTranslate', 'wptranslate' ); ?></h2>
                <p class="wptranslate-wizard__subtitle"><?php esc_html_e( 'Complete these steps to start translating your site with AI.', 'wptranslate' ); ?></p>
                <div class="wptranslate-wizard__steps">
                    <?php foreach ( $steps as $num => $step ) :
                        $state = $step['done'] ? 'complete' : ( $num === $active_step ? 'active' : 'pending' );
                    ?>
                    <div class="wptranslate-wizard__step wptranslate-wizard__step--<?php echo esc_attr( $state ); ?>">
                        <div class="wptranslate-wizard__step-icon"><?php echo $step['done'] ? '&#10003;' : (int) $num; ?></div>
                        <span class="wptranslate-wizard__step-label"><?php echo esc_html( $step['label'] ); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="wptranslate-wizard__action">
                    <a href="<?php echo esc_url( $steps[ $active_step ]['url'] ); ?>" class="button button-primary button-hero">
                        <?php echo esc_html( $steps[ $active_step ]['label'] ); ?> &rarr;
                    </a>
                </div>
            </div>
        <?php endif;
    }

    /**
     * Translation status overview — donut chart + per-language progress bars.
     */
    private function render_translation_overview(): void {
        $language_manager  = $this->plugin->get_language_manager();
        $active_languages  = $language_manager->get_active_languages();
        $default_language  = $language_manager->get_default_language();

        // Check if there are non-default languages configured.
        $target_languages = array_filter( $active_languages, function ( $lang ) use ( $default_language ) {
            return $lang['code'] !== $default_language;
        } );

        global $wpdb;
        $translations_table = $wpdb->prefix . 'wpt_translations';
        $status_table       = $wpdb->prefix . 'wpt_translation_status';

        // Total translatable posts in default language.
        $enabled_post_types = get_option( 'wptranslate_post_types', array( 'post', 'page' ) );

        $total_posts = 0;
        if ( ! empty( $enabled_post_types ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $enabled_post_types ), '%s' ) );

            // Count only source-language posts (exclude translation posts) to get accurate percentage.
            // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
            $total_posts = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$wpdb->posts} p
                     WHERE p.post_status = 'publish' AND p.post_type IN ({$placeholders})
                     AND p.ID NOT IN (
                         SELECT t.element_id FROM {$translations_table} t
                         WHERE t.element_type = 'post' AND t.source_language_code != ''
                     )",
                    ...$enabled_post_types
                )
            );
        }
        ?>
        <div class="wptranslate-card wptranslate-card--overview">
            <h2><?php esc_html_e( 'Translation Status', 'wptranslate' ); ?></h2>

            <?php if ( empty( $target_languages ) ) : ?>
                <div class="wptranslate-empty-state">
                    <span class="dashicons dashicons-translation wptranslate-empty-state__icon"></span>
                    <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'Add Your First Language', 'wptranslate' ); ?></h3>
                    <p class="wptranslate-empty-state__description">
                        <?php esc_html_e( 'Configure target languages to start translating your content with AI-powered translations.', 'wptranslate' ); ?>
                    </p>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-languages' ) ); ?>" class="button button-primary">
                        <?php esc_html_e( 'Add Languages', 'wptranslate' ); ?>
                    </a>
                </div>
            <?php else :
                // Calculate overall translation coverage across all target languages.
                $total_possible     = $total_posts * count( $target_languages );
                $total_translated   = 0;
                $language_stats     = array();

                foreach ( $target_languages as $lang ) {
                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
                    $translated_count = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT t.element_id)
                             FROM {$translations_table} t
                             INNER JOIN {$status_table} s ON s.translation_id = t.id
                             WHERE t.language_code = %s
                             AND t.element_type = 'post'
                             AND t.source_language_code != ''
                             AND s.status IN ('published', 'ai_draft', 'pending_review')",
                            $lang['code']
                        )
                    );

                    $translated_count = min( $translated_count, $total_posts );
                    $percentage = $total_posts > 0 ? min( 100, round( ( $translated_count / $total_posts ) * 100 ) ) : 0;

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
                    $published_count = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT t.element_id)
                             FROM {$translations_table} t
                             INNER JOIN {$status_table} s ON s.translation_id = t.id
                             WHERE t.language_code = %s AND t.element_type = 'post' AND s.status = 'published'",
                            $lang['code']
                        )
                    );

                    // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
                    $needs_update_count = (int) $wpdb->get_var(
                        $wpdb->prepare(
                            "SELECT COUNT(DISTINCT t.element_id)
                             FROM {$translations_table} t
                             INNER JOIN {$status_table} s ON s.translation_id = t.id
                             WHERE t.language_code = %s AND t.element_type = 'post' AND s.status = 'needs_update'",
                            $lang['code']
                        )
                    );

                    $total_translated += $translated_count;

                    $language_stats[] = array(
                        'lang'              => $lang,
                        'translated_count'  => $translated_count,
                        'percentage'        => $percentage,
                        'published_count'   => $published_count,
                        'needs_update_count' => $needs_update_count,
                    );
                }

                // Cap translated count to total possible (in case of stale DB entries).
                $total_translated = min( $total_translated, $total_possible );
                $overall_percentage = $total_possible > 0 ? min( 100, round( ( $total_translated / $total_possible ) * 100 ) ) : 0;
                ?>
                <div class="wptranslate-overview-header">
                    <div class="wptranslate-donut">
                        <div class="wptranslate-donut__chart">
                            <svg viewBox="0 0 36 36">
                                <circle
                                    class="wptranslate-donut__track"
                                    cx="18" cy="18" r="15.91549430918954"
                                />
                                <circle
                                    class="wptranslate-donut__fill"
                                    cx="18" cy="18" r="15.91549430918954"
                                    stroke-dasharray="<?php echo esc_attr( $overall_percentage ); ?> 100"
                                    stroke-dashoffset="25"
                                />
                            </svg>
                            <div class="wptranslate-donut__label">
                                <?php echo esc_html( $overall_percentage ); ?>%
                            </div>
                        </div>
                    </div>
                    <div class="wptranslate-overview-summary">
                        <p class="wptranslate-overview-summary__total">
                            <?php
                            printf(
                                /* translators: 1: translated count, 2: total possible translations */
                                esc_html__( '%1$s of %2$s translations complete', 'wptranslate' ),
                                '<strong>' . esc_html( number_format_i18n( $total_translated ) ) . '</strong>',
                                '<strong>' . esc_html( number_format_i18n( $total_possible ) ) . '</strong>'
                            );
                            ?>
                        </p>
                        <p class="wptranslate-overview-summary__languages">
                            <?php
                            printf(
                                /* translators: 1: number of target languages, 2: number of published posts */
                                esc_html__( '%1$d target languages, %2$s published posts', 'wptranslate' ),
                                count( $target_languages ),
                                number_format_i18n( $total_posts )
                            );
                            ?>
                        </p>
                    </div>
                </div>

                <div class="wptranslate-language-bars">
                    <?php foreach ( $language_stats as $stat ) : ?>
                    <div class="wptranslate-lang-progress">
                        <div class="wptranslate-lang-progress__header">
                            <span class="wptranslate-lang-progress__name">
                                <?php echo esc_html( $stat['lang']['flag'] ?? '' ); ?>
                                <?php echo esc_html( $stat['lang']['name'] ); ?>
                            </span>
                            <span class="wptranslate-lang-progress__count">
                                <?php
                                printf(
                                    /* translators: 1: translated count, 2: total count, 3: percentage */
                                    esc_html__( '%1$d / %2$d (%3$d%%)', 'wptranslate' ),
                                    $stat['translated_count'],
                                    $total_posts,
                                    $stat['percentage']
                                );
                                ?>
                            </span>
                        </div>
                        <div class="wptranslate-lang-progress__bar">
                            <div class="wptranslate-lang-progress__fill" style="width: <?php echo esc_attr( $stat['percentage'] ); ?>%"></div>
                        </div>
                        <div class="wptranslate-lang-progress__details">
                            <?php if ( $stat['needs_update_count'] > 0 ) : ?>
                                <span class="wptranslate-badge wptranslate-badge--warning">
                                    <?php
                                    printf(
                                        /* translators: %d: number needing update */
                                        esc_html__( '%d need update', 'wptranslate' ),
                                        $stat['needs_update_count']
                                    );
                                    ?>
                                </span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Recent translation activity.
     */
    private function render_recent_activity(): void {
        global $wpdb;
        $status_table       = $wpdb->prefix . 'wpt_translation_status';
        $translations_table = $wpdb->prefix . 'wpt_translations';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $recent = $wpdb->get_results(
            "SELECT s.status, s.date_modified, t.element_id, t.language_code, t.element_type
             FROM {$status_table} s
             INNER JOIN {$translations_table} t ON s.translation_id = t.id
             ORDER BY s.date_modified DESC
             LIMIT 15",
            ARRAY_A
        );
        ?>
        <div class="wptranslate-card wptranslate-card--activity">
            <h2><?php esc_html_e( 'Recent Activity', 'wptranslate' ); ?></h2>

            <?php if ( empty( $recent ) ) : ?>
                <div class="wptranslate-empty-state">
                    <span class="dashicons dashicons-clock wptranslate-empty-state__icon"></span>
                    <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No Activity Yet', 'wptranslate' ); ?></h3>
                    <p class="wptranslate-empty-state__description">
                        <?php esc_html_e( 'Translations will appear here once you start translating content.', 'wptranslate' ); ?>
                    </p>
                </div>
            <?php else : ?>
                <ul class="wptranslate-activity-list">
                    <?php foreach ( $recent as $item ) :
                        $post       = get_post( $item['element_id'] );
                        $post_title = $post ? $post->post_title : __( '(deleted)', 'wptranslate' );
                        $lang_data  = $this->plugin->get_language_manager()->get_language( $item['language_code'] );
                        $lang_name  = $lang_data ? $lang_data['name'] : $item['language_code'];
                    ?>
                    <li class="wptranslate-activity-item">
                        <span class="wptranslate-activity-item__status wptranslate-status--<?php echo esc_attr( sanitize_html_class( $item['status'] ) ); ?>">
                            <?php echo esc_html( self::format_status_label( $item['status'] ) ); ?>
                        </span>
                        <span class="wptranslate-activity-item__title">
                            <?php if ( $post ) : ?>
                                <a href="<?php echo esc_url( get_edit_post_link( $item['element_id'] ) ); ?>"><?php echo esc_html( $post_title ); ?></a>
                            <?php else : ?>
                                <?php echo esc_html( $post_title ); ?>
                            <?php endif; ?>
                        </span>
                        <span class="wptranslate-activity-item__lang">
                            <?php echo esc_html( $lang_name ); ?>
                        </span>
                        <span class="wptranslate-activity-item__date">
                            <?php echo esc_html( human_time_diff( strtotime( $item['date_modified'] ), time() ) ); ?>
                            <?php esc_html_e( 'ago', 'wptranslate' ); ?>
                        </span>
                    </li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Abbreviate a number for Y-axis labels: 1500 -> 1.5K, 1500000 -> 1.5M, etc.
     *
     * @param int|float $value The number to abbreviate.
     * @return string Abbreviated string.
     */
    private static function abbreviate_number( $value ): string {
        if ( $value <= 0 ) {
            return '0';
        }
        if ( $value >= 1e12 ) {
            return round( $value / 1e12, 1 ) . 'T';
        }
        if ( $value >= 1e9 ) {
            return round( $value / 1e9, 1 ) . 'B';
        }
        if ( $value >= 1e6 ) {
            return round( $value / 1e6, 1 ) . 'M';
        }
        if ( $value >= 1e3 ) {
            return round( $value / 1e3, 1 ) . 'K';
        }
        return (string) round( $value );
    }

    /**
     * API usage — monthly line chart with per-provider lines, current vs last month comparison.
     */
    private function render_api_usage(): void {
        global $wpdb;
        $cache_table = $wpdb->prefix . 'wpt_translation_cache';
        $budget      = (float) get_option( 'wptranslate_cost_budget', 0 );

        // Current month date range.
        $current_month_start = gmdate( 'Y-m-01' );
        $current_month_name  = wp_date( 'F' );
        $days_in_month       = (int) gmdate( 't' );
        $current_day         = (int) gmdate( 'j' );

        // Last month date range.
        $last_month_start = gmdate( 'Y-m-01', strtotime( 'first day of last month' ) );
        $last_month_end   = gmdate( 'Y-m-t', strtotime( 'first day of last month' ) );
        $last_month_name  = wp_date( 'F', strtotime( 'first day of last month' ) );
        $days_in_last_month = (int) gmdate( 't', strtotime( 'first day of last month' ) );

        // Fetch current month usage grouped by day and provider.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $current_usage = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) as day, provider, COUNT(*) as requests,
                        SUM(CHAR_LENGTH(source_text)) as chars_used
                 FROM {$cache_table}
                 WHERE created_at >= %s
                 GROUP BY day, provider
                 ORDER BY day ASC",
                $current_month_start
            ),
            ARRAY_A
        );

        // Fetch last month usage grouped by day and provider.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $last_month_usage = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT DATE(created_at) as day, provider, COUNT(*) as requests,
                        SUM(CHAR_LENGTH(source_text)) as chars_used
                 FROM {$cache_table}
                 WHERE created_at >= %s AND created_at <= %s
                 GROUP BY day, provider
                 ORDER BY day ASC",
                $last_month_start,
                $last_month_end . ' 23:59:59'
            ),
            ARRAY_A
        );

        // Build data structures for current month.
        $providers       = array();
        $current_days    = array();
        $total_chars     = 0;
        $total_reqs      = 0;

        // Fill current month day range (day-of-month as key).
        for ( $i = 1; $i <= $days_in_month; $i++ ) {
            $current_days[ $i ] = array();
        }

        foreach ( $current_usage as $row ) {
            $p   = $row['provider'] ?: 'unknown';
            $dom = (int) gmdate( 'j', strtotime( $row['day'] ) );
            $providers[ $p ]             = true;
            $current_days[ $dom ][ $p ]  = (int) $row['chars_used'];
            $total_chars                += (int) $row['chars_used'];
            $total_reqs                 += (int) $row['requests'];
        }

        // Build data structures for last month.
        $last_days = array();
        for ( $i = 1; $i <= $days_in_last_month; $i++ ) {
            $last_days[ $i ] = array();
        }

        foreach ( $last_month_usage as $row ) {
            $p   = $row['provider'] ?: 'unknown';
            $dom = (int) gmdate( 'j', strtotime( $row['day'] ) );
            $providers[ $p ]          = true;
            $last_days[ $dom ][ $p ]  = (int) $row['chars_used'];
        }

        $provider_names  = array_keys( $providers );
        $provider_colors = array(
            'deepl'  => '#0F2B46',
            'claude' => '#B87333',
            'openai' => '#10A37F',
        );
        $has_data = $total_chars > 0 || ! empty( $last_month_usage );

        // SVG dimensions — increased left padding for Y-axis labels.
        $w       = 400;
        $h       = 120;
        $pad_l   = 45;
        $pad_r   = 5;
        $pad_t   = 5;
        $pad_b   = 5;
        $chart_w = $w - $pad_l - $pad_r;
        $chart_h = $h - $pad_t - $pad_b;

        // Find max daily value across both months and all providers.
        $max_val = 1;
        foreach ( $current_days as $day_data ) {
            foreach ( $day_data as $val ) {
                if ( $val > $max_val ) {
                    $max_val = $val;
                }
            }
        }
        foreach ( $last_days as $day_data ) {
            foreach ( $day_data as $val ) {
                if ( $val > $max_val ) {
                    $max_val = $val;
                }
            }
        }

        // Build polyline points per provider for current month (solid lines).
        $current_polylines = array();
        $num_days_current  = $days_in_month;

        foreach ( $provider_names as $prov ) {
            $points = array();
            for ( $dom = 1; $dom <= $num_days_current; $dom++ ) {
                $val = $current_days[ $dom ][ $prov ] ?? 0;
                $x   = $pad_l + ( ( $dom - 1 ) / max( 1, $num_days_current - 1 ) ) * $chart_w;
                $y   = $pad_t + $chart_h - ( $val / $max_val ) * $chart_h;
                $points[] = round( $x, 1 ) . ',' . round( $y, 1 );
            }
            $current_polylines[ $prov ] = implode( ' ', $points );
        }

        // Build polyline points per provider for last month (dashed lines).
        $last_polylines   = array();
        $num_days_last    = $days_in_last_month;

        foreach ( $provider_names as $prov ) {
            $points = array();
            for ( $dom = 1; $dom <= $num_days_last; $dom++ ) {
                $val = $last_days[ $dom ][ $prov ] ?? 0;
                $x   = $pad_l + ( ( $dom - 1 ) / max( 1, $num_days_current - 1 ) ) * $chart_w;
                $y   = $pad_t + $chart_h - ( $val / $max_val ) * $chart_h;
                $points[] = round( $x, 1 ) . ',' . round( $y, 1 );
            }
            $last_polylines[ $prov ] = implode( ' ', $points );
        }

        // Y-axis label values: 0%, 25%, 50%, 75%, 100% of max.
        $y_axis_steps = array( 0, 0.25, 0.5, 0.75, 1.0 );

        ?>
        <div class="wptranslate-card wptranslate-card--api-usage">
            <h2><?php
                /* translators: %s: current month name */
                printf( esc_html__( 'API Usage — %s', 'wptranslate' ), esc_html( $current_month_name ) );
            ?></h2>

            <?php if ( ! $has_data ) : ?>
                <div class="wptranslate-empty-state">
                    <div class="wptranslate-empty-state__icon"><span class="dashicons dashicons-chart-area"></span></div>
                    <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No API Usage', 'wptranslate' ); ?></h3>
                    <p class="wptranslate-empty-state__description"><?php esc_html_e( 'Usage data will appear here once you start translating.', 'wptranslate' ); ?></p>
                </div>
            <?php else : ?>
                <!-- Totals -->
                <div style="display: flex; gap: 24px; margin-bottom: 12px;">
                    <div>
                        <div style="font-size: 20px; font-weight: 700; color: var(--wpt-neutral-800, #1f2937);"><?php echo esc_html( number_format_i18n( $total_chars ) ); ?></div>
                        <div style="font-size: 11px; color: var(--wpt-neutral-500, #6b7280); text-transform: uppercase; letter-spacing: 0.3px;"><?php esc_html_e( 'Characters', 'wptranslate' ); ?></div>
                    </div>
                    <div>
                        <div style="font-size: 20px; font-weight: 700; color: var(--wpt-neutral-800, #1f2937);"><?php echo esc_html( number_format_i18n( $total_reqs ) ); ?></div>
                        <div style="font-size: 11px; color: var(--wpt-neutral-500, #6b7280); text-transform: uppercase; letter-spacing: 0.3px;"><?php esc_html_e( 'Requests', 'wptranslate' ); ?></div>
                    </div>
                </div>

                <!-- Line Chart -->
                <div style="background: var(--wpt-neutral-50, #f9fafb); border-radius: 8px; padding: 12px; margin-bottom: 12px;">
                    <svg viewBox="0 0 <?php echo $w; ?> <?php echo $h; ?>" style="width: 100%; height: auto; display: block;" preserveAspectRatio="none">
                        <!-- Grid lines + Y-axis labels -->
                        <?php for ( $i = 0; $i <= 4; $i++ ) :
                            $gy        = $pad_t + ( $i / 4 ) * $chart_h;
                            $label_val = $max_val * ( 1 - $i / 4 );
                            $label_str = self::abbreviate_number( $label_val );
                        ?>
                            <line x1="<?php echo $pad_l; ?>" y1="<?php echo round( $gy, 1 ); ?>" x2="<?php echo $w - $pad_r; ?>" y2="<?php echo round( $gy, 1 ); ?>" stroke="#e5e7eb" stroke-width="0.5" />
                            <text x="<?php echo $pad_l - 4; ?>" y="<?php echo round( $gy + 1.5, 1 ); ?>" text-anchor="end" font-size="7" fill="#9ca3af"><?php echo esc_html( $label_str ); ?></text>
                        <?php endfor; ?>

                        <!-- Last month provider lines (dashed) -->
                        <?php foreach ( $last_polylines as $prov => $points ) :
                            $color = $provider_colors[ $prov ] ?? '#6366f1';
                        ?>
                            <polyline points="<?php echo esc_attr( $points ); ?>" fill="none" stroke="<?php echo esc_attr( $color ); ?>" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" stroke-dasharray="4,4" opacity="0.4" />
                        <?php endforeach; ?>

                        <!-- Current month provider lines (solid) -->
                        <?php foreach ( $current_polylines as $prov => $points ) :
                            $color = $provider_colors[ $prov ] ?? '#6366f1';
                        ?>
                            <polyline points="<?php echo esc_attr( $points ); ?>" fill="none" stroke="<?php echo esc_attr( $color ); ?>" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" />
                        <?php endforeach; ?>
                    </svg>

                    <!-- Date labels — current month days -->
                    <div style="display: flex; justify-content: space-between; font-size: 10px; color: var(--wpt-neutral-400, #9ca3af); margin-top: 4px; padding-left: <?php echo $pad_l; ?>px;">
                        <span><?php echo esc_html( $current_month_name . ' 1' ); ?></span>
                        <span><?php echo esc_html( $current_month_name . ' ' . (int) ceil( $days_in_month / 2 ) ); ?></span>
                        <span><?php echo esc_html( $current_month_name . ' ' . $days_in_month ); ?></span>
                    </div>
                </div>

                <!-- Legend -->
                <div style="display: flex; gap: 16px; flex-wrap: wrap; font-size: 12px; align-items: center;">
                    <?php foreach ( $provider_names as $prov ) :
                        $color = $provider_colors[ $prov ] ?? '#6366f1';
                    ?>
                        <span style="display: flex; align-items: center; gap: 4px;">
                            <span style="width: 10px; height: 3px; background: <?php echo esc_attr( $color ); ?>; border-radius: 2px; display: inline-block;"></span>
                            <?php echo esc_html( ucfirst( $prov ) ); ?>
                        </span>
                    <?php endforeach; ?>
                    <span style="display: flex; align-items: center; gap: 6px; margin-left: 8px; color: var(--wpt-neutral-500, #6b7280);">
                        <span style="display: inline-flex; align-items: center; gap: 4px;">
                            <svg width="16" height="3"><line x1="0" y1="1.5" x2="16" y2="1.5" stroke="#9ca3af" stroke-width="2"/></svg>
                            <?php
                            /* translators: Label for current month line in chart legend */
                            esc_html_e( 'This Month', 'wptranslate' );
                            ?>
                        </span>
                        <span style="display: inline-flex; align-items: center; gap: 4px;">
                            <svg width="16" height="3"><line x1="0" y1="1.5" x2="16" y2="1.5" stroke="#9ca3af" stroke-width="1.5" stroke-dasharray="4,4"/></svg>
                            <?php
                            /* translators: %s: last month name */
                            echo esc_html( $last_month_name );
                            ?>
                        </span>
                    </span>
                </div>

                <?php if ( $budget > 0 ) : ?>
                    <p class="wptranslate-budget-notice">
                        <?php
                        printf(
                            /* translators: 1: characters used this month, 2: character limit */
                            esc_html__( '%1$s / %2$s characters used this month', 'wptranslate' ),
                            esc_html( number_format_i18n( $total_chars ) ),
                            esc_html( number_format_i18n( (int) $budget ) )
                        );
                        ?>
                    </p>
                <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Quick action buttons.
     */
    private function render_quick_actions(): void {
        $language_manager  = $this->plugin->get_language_manager();
        $active_languages  = $language_manager->get_active_languages();
        $default_language  = $language_manager->get_default_language();

        wp_nonce_field( 'wptranslate_admin', 'wptranslate_dashboard_nonce' );
        ?>
        <div class="wptranslate-card wptranslate-card--quick-actions">
            <h2><?php esc_html_e( 'Quick Actions', 'wptranslate' ); ?></h2>

            <div class="wptranslate-quick-actions">
                <div class="wptranslate-quick-action">
                    <label for="wptranslate-translate-all-lang">
                        <?php esc_html_e( 'Translate all content to:', 'wptranslate' ); ?>
                    </label>
                    <select id="wptranslate-translate-all-lang" class="regular-text">
                        <option value=""><?php esc_html_e( '-- Select Language --', 'wptranslate' ); ?></option>
                        <?php foreach ( $active_languages as $lang ) :
                            if ( $lang['code'] === $default_language ) {
                                continue;
                            }
                        ?>
                            <option value="<?php echo esc_attr( $lang['code'] ); ?>">
                                <?php echo esc_html( $lang['name'] ); ?>
                            </option>
                        <?php endforeach; ?>
                    </select>
                    <button type="button"
                            class="button button-primary wptranslate-translate-all-content"
                            id="wptranslate-translate-all-btn">
                        <?php esc_html_e( 'Start Translation', 'wptranslate' ); ?>
                    </button>
                </div>

                <div class="wptranslate-quick-action">
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-queue' ) ); ?>" class="button">
                        <?php esc_html_e( 'View Translation Queue', 'wptranslate' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-strings' ) ); ?>" class="button">
                        <?php esc_html_e( 'Manage String Translations', 'wptranslate' ); ?>
                    </a>
                    <a href="<?php echo esc_url( admin_url( 'admin.php?page=wptranslate-settings' ) ); ?>" class="button">
                        <?php esc_html_e( 'Plugin Settings', 'wptranslate' ); ?>
                    </a>
                </div>
            </div>
        </div>
        <?php
    }

    /**
     * System health check with health score ring.
     */
    private function render_system_health(): void {
        $checks = array();

        // Check PHP version.
        $checks['php'] = array(
            'label'  => __( 'PHP Version', 'wptranslate' ),
            'status' => version_compare( PHP_VERSION, '7.4', '>=' ) ? 'good' : 'error',
            'value'  => PHP_VERSION,
        );

        // Check OpenSSL.
        $checks['openssl'] = array(
            'label'  => __( 'OpenSSL Extension', 'wptranslate' ),
            'status' => extension_loaded( 'openssl' ) ? 'good' : 'warning',
            'value'  => extension_loaded( 'openssl' ) ? __( 'Enabled', 'wptranslate' ) : __( 'Disabled (API keys stored unencrypted)', 'wptranslate' ),
        );

        // Check mbstring.
        $checks['mbstring'] = array(
            'label'  => __( 'mbstring Extension', 'wptranslate' ),
            'status' => extension_loaded( 'mbstring' ) ? 'good' : 'warning',
            'value'  => extension_loaded( 'mbstring' ) ? __( 'Enabled', 'wptranslate' ) : __( 'Disabled', 'wptranslate' ),
        );

        // Check if any translation provider API key is configured.
        $has_any_provider = ! empty( get_option( 'wptranslate_claude_api_key', '' ) )
                         || ! empty( get_option( 'wptranslate_openai_api_key', '' ) )
                         || ! empty( get_option( 'wptranslate_deepl_api_key', '' ) );
        $checks['provider'] = array(
            'label'  => __( 'Translation Provider', 'wptranslate' ),
            'status' => $has_any_provider ? 'good' : 'warning',
            'value'  => $has_any_provider ? __( 'Configured', 'wptranslate' ) : __( 'No API key set', 'wptranslate' ),
        );

        // Check WP-Cron.
        $checks['cron'] = array(
            'label'  => __( 'WP-Cron', 'wptranslate' ),
            'status' => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON ) ? 'warning' : 'good',
            'value'  => ( defined( 'DISABLE_WP_CRON' ) && DISABLE_WP_CRON )
                ? __( 'Disabled (queue processing requires external cron)', 'wptranslate' )
                : __( 'Enabled', 'wptranslate' ),
        );

        // Check active languages.
        $lang_count = count( $this->plugin->get_language_manager()->get_active_languages() );
        $checks['languages'] = array(
            'label'  => __( 'Active Languages', 'wptranslate' ),
            'status' => $lang_count > 1 ? 'good' : 'warning',
            'value'  => sprintf(
                /* translators: %d: number of active languages */
                __( '%d languages configured', 'wptranslate' ),
                $lang_count
            ),
        );

        // Calculate health score.
        $total_checks  = count( $checks );
        $passed_checks = 0;
        foreach ( $checks as $check ) {
            if ( 'good' === $check['status'] ) {
                $passed_checks++;
            }
        }
        $health_percentage = $total_checks > 0 ? round( ( $passed_checks / $total_checks ) * 100 ) : 0;
        ?>
        <div class="wptranslate-card wptranslate-card--health">
            <h2><?php esc_html_e( 'System Health', 'wptranslate' ); ?></h2>

            <div class="wptranslate-health-score">
                <div style="display: flex; align-items: center; gap: 12px; margin-bottom: 12px;">
                    <span style="font-size: 24px; font-weight: 700; color: var(--wpt-<?php echo $health_percentage >= 80 ? 'success' : ( $health_percentage >= 50 ? 'warning' : 'error' ); ?>);">
                        <?php echo esc_html( $passed_checks ); ?>/<?php echo esc_html( $total_checks ); ?>
                    </span>
                    <span style="font-size: 13px; color: var(--wpt-neutral-500);"><?php esc_html_e( 'checks passed', 'wptranslate' ); ?></span>
                </div>
                <div class="wptranslate-progress-bar" style="height: 6px;">
                    <div class="wptranslate-progress-bar__fill" style="width: <?php echo esc_attr( $health_percentage ); ?>%; background: var(--wpt-<?php echo $health_percentage >= 80 ? 'success' : ( $health_percentage >= 50 ? 'warning' : 'error' ); ?>);"></div>
                </div>
            </div>

            <table class="widefat striped">
                <tbody>
                    <?php foreach ( $checks as $check ) :
                        $icon = 'good' === $check['status'] ? 'yes' : ( 'warning' === $check['status'] ? 'warning' : ( 'error' === $check['status'] ? 'no' : 'info-outline' ) );
                    ?>
                    <tr>
                        <td>
                            <span class="dashicons dashicons-<?php echo esc_attr( $icon ); ?> wptranslate-health-<?php echo esc_attr( $check['status'] ); ?>"></span>
                            <?php echo esc_html( $check['label'] ); ?>
                        </td>
                        <td><?php echo esc_html( $check['value'] ); ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Format a status string into a proper label.
     *
     * Delegates to AdminController::format_status_label() — kept here for
     * backward compatibility since TranslationQueuePage references it.
     */
    public static function format_status_label( string $status ): string {
        return AdminController::format_status_label( $status );
    }
}
