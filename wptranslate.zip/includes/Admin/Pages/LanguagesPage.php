<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;
use WPTranslate\LanguageManager;

/**
 * Languages admin page — TranslatePress-style unified table with inline add.
 */
class LanguagesPage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_save_languages', array( $this, 'ajax_save_languages' ) );
        add_action( 'wp_ajax_wptranslate_add_language', array( $this, 'ajax_add_language' ) );
        add_action( 'wp_ajax_wptranslate_delete_language', array( $this, 'ajax_delete_language' ) );
        add_action( 'wp_ajax_wptranslate_reorder_languages', array( $this, 'ajax_reorder_languages' ) );
        add_action( 'wp_ajax_wptranslate_update_language', array( $this, 'ajax_update_language' ) );
    }

    public function render(): void {
        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        $language_manager  = $this->plugin->get_language_manager();
        $all_languages     = $language_manager->get_all_languages();
        $catalog           = LanguageManager::get_available_languages();
        $default_language  = $language_manager->get_default_language();

        $added_codes = array();
        foreach ( $all_languages as $lang ) {
            $added_codes[] = $lang['code'];
        }

        $formality_options = array(
            'default'  => __( 'Default', 'wptranslate' ),
            'formal'   => __( 'Formal', 'wptranslate' ),
            'informal' => __( 'Informal', 'wptranslate' ),
        );

        $current_formality = get_option( 'wptranslate_formality', array() );
        ?>
        <div class="wrap wptranslate-languages">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'Website Languages', 'wptranslate' ) ); ?>

            <?php wp_nonce_field( 'wptranslate_admin', 'wptranslate_languages_nonce' ); ?>

            <!-- Default Language Selector -->
            <div class="wptranslate-card" style="margin-bottom: 24px;">
                <h2 style="margin-top: 0;"><?php esc_html_e( 'Default Language', 'wptranslate' ); ?></h2>
                <p class="description" style="margin-bottom: 12px;">
                    <?php esc_html_e( 'Select the language your content is written in.', 'wptranslate' ); ?>
                </p>
                <select id="wptranslate-default-language" class="regular-text">
                    <?php foreach ( $all_languages as $lang ) : ?>
                        <option value="<?php echo esc_attr( $lang['code'] ); ?>" <?php selected( $lang['code'], $default_language ); ?>>
                            <?php echo esc_html( ( $lang['flag'] ? $lang['flag'] . ' ' : '' ) . $lang['name'] . ( $lang['native_name'] ? ' (' . $lang['native_name'] . ')' : '' ) ); ?>
                        </option>
                    <?php endforeach; ?>
                    <?php if ( empty( $all_languages ) ) : ?>
                        <?php foreach ( $catalog as $code => $data ) : ?>
                            <option value="<?php echo esc_attr( $code ); ?>">
                                <?php echo esc_html( $data['flag'] . ' ' . $data['name'] . ' (' . $data['native_name'] . ')' ); ?>
                            </option>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </select>
            </div>

            <!-- All Languages Table -->
            <div class="wptranslate-card">
                <h2 style="margin-top: 0;">
                    <?php esc_html_e( 'All Languages', 'wptranslate' ); ?>
                    <span class="dashicons dashicons-info" title="<?php esc_attr_e( 'Your default language and all translation target languages. Drag to reorder.', 'wptranslate' ); ?>" style="color: var(--wpt-neutral-400); cursor: help;"></span>
                </h2>

                <table class="widefat wptranslate-languages-table" id="wptranslate-languages-list">
                    <thead>
                        <tr>
                            <th style="width: 30px;"></th>
                            <th><?php esc_html_e( 'Language', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Formality', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Code', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Slug', 'wptranslate' ); ?></th>
                            <th><?php esc_html_e( 'Active', 'wptranslate' ); ?></th>
                            <th style="width: 80px;"></th>
                        </tr>
                    </thead>
                    <tbody id="wptranslate-sortable-languages">
                        <?php foreach ( $all_languages as $lang ) :
                            $is_default = ( $lang['code'] === $default_language );
                            $lang_formality = $current_formality[ $lang['code'] ] ?? 'default';
                            // Use code as default slug.
                            $slug = sanitize_title( $lang['code'] );
                        ?>
                        <tr class="wptranslate-language-row<?php echo $is_default ? ' wptranslate-language-row--default' : ''; ?>" data-code="<?php echo esc_attr( $lang['code'] ); ?>">
                            <td class="wptranslate-col-sort">
                                <span class="dashicons dashicons-menu wptranslate-drag-handle"></span>
                            </td>
                            <td>
                                <?php if ( $is_default ) : ?>
                                    <select class="regular-text" disabled>
                                        <option selected>
                                            <?php
                                            printf(
                                                /* translators: %s: language name with native name */
                                                esc_html__( 'Default: %s', 'wptranslate' ),
                                                esc_html( ( $lang['flag'] ? $lang['flag'] . ' ' : '' ) . $lang['name'] . ( $lang['native_name'] ? ' (' . $lang['native_name'] . ')' : '' ) )
                                            );
                                            ?>
                                        </option>
                                    </select>
                                <?php else : ?>
                                    <select class="regular-text wptranslate-lang-name-select" data-code="<?php echo esc_attr( $lang['code'] ); ?>">
                                        <option value="<?php echo esc_attr( $lang['code'] ); ?>" selected>
                                            <?php echo esc_html( ( $lang['flag'] ? $lang['flag'] . ' ' : '' ) . $lang['name'] . ( $lang['native_name'] ? ' (' . $lang['native_name'] . ')' : '' ) ); ?>
                                        </option>
                                    </select>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ( $is_default ) : ?>
                                    <span class="description"><?php esc_html_e( 'Default', 'wptranslate' ); ?></span>
                                <?php else : ?>
                                    <select name="formality[<?php echo esc_attr( $lang['code'] ); ?>]" class="wptranslate-formality-select">
                                        <?php foreach ( $formality_options as $val => $label ) : ?>
                                            <option value="<?php echo esc_attr( $val ); ?>" <?php selected( $lang_formality, $val ); ?>>
                                                <?php echo esc_html( $label ); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                <?php endif; ?>
                            </td>
                            <td>
                                <input type="text" class="small-text" value="<?php echo esc_attr( $lang['locale'] ?: $lang['code'] ); ?>" readonly style="background: transparent; border-color: transparent; width: 60px;" />
                            </td>
                            <td>
                                <input type="text"
                                       class="small-text wptranslate-slug-input"
                                       name="slugs[<?php echo esc_attr( $lang['code'] ); ?>]"
                                       value="<?php echo esc_attr( $slug ); ?>"
                                       style="width: 60px;"
                                       <?php echo $is_default ? 'readonly style="background: transparent; border-color: transparent; width: 60px;"' : ''; ?> />
                            </td>
                            <td>
                                <?php if ( $is_default ) : ?>
                                    <label class="wptranslate-toggle">
                                        <input type="checkbox" checked disabled />
                                    </label>
                                <?php else : ?>
                                    <label class="wptranslate-toggle">
                                        <input type="checkbox"
                                               name="active[<?php echo esc_attr( $lang['code'] ); ?>]"
                                               value="1"
                                               <?php checked( ! empty( $lang['is_active'] ) ); ?>
                                               class="wptranslate-toggle-active" />
                                    </label>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ( ! $is_default ) : ?>
                                    <button type="button"
                                            class="button button-small wptranslate-delete-language"
                                            data-code="<?php echo esc_attr( $lang['code'] ); ?>"
                                            data-name="<?php echo esc_attr( $lang['name'] ); ?>"
                                            title="<?php esc_attr_e( 'Remove', 'wptranslate' ); ?>">
                                        <?php esc_html_e( 'Remove', 'wptranslate' ); ?>
                                        <span class="dashicons dashicons-trash" style="font-size: 14px; width: 14px; height: 14px; vertical-align: text-bottom;"></span>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>

                        <!-- Add New Language Row (always at bottom, styled like TranslatePress) -->
                        <tr class="wptranslate-language-row wptranslate-language-row--add" style="background: var(--wpt-neutral-50);">
                            <td class="wptranslate-col-sort"></td>
                            <td>
                                <select id="wptranslate-language-select" class="regular-text">
                                    <option value=""><?php esc_html_e( 'Select language', 'wptranslate' ); ?></option>
                                    <?php foreach ( $catalog as $code => $data ) :
                                        if ( in_array( $code, $added_codes, true ) ) {
                                            continue;
                                        }
                                    ?>
                                        <option value="<?php echo esc_attr( $code ); ?>">
                                            <?php echo esc_html( $data['flag'] . ' ' . $data['name'] . ' (' . $data['native_name'] . ')' ); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td>
                                <select id="wptranslate-new-formality" class="wptranslate-formality-select">
                                    <?php foreach ( $formality_options as $val => $label ) : ?>
                                        <option value="<?php echo esc_attr( $val ); ?>"><?php echo esc_html( $label ); ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td></td>
                            <td></td>
                            <td></td>
                            <td>
                                <button type="button" class="button button-small" id="wptranslate-add-language-btn" style="white-space: nowrap;">
                                    <?php esc_html_e( 'Add', 'wptranslate' ); ?>
                                </button>
                            </td>
                        </tr>
                    </tbody>
                </table>

                <p class="submit">
                    <button type="button" class="button button-primary" id="wptranslate-save-languages">
                        <?php esc_html_e( 'Save Changes', 'wptranslate' ); ?>
                    </button>
                </p>
            </div>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // AJAX Handlers
    // -------------------------------------------------------------------------

    public function ajax_save_languages(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $language_manager = $this->plugin->get_language_manager();

        // Save formality settings.
        $formality = isset( $_POST['formality'] ) ? array_map( 'sanitize_text_field', (array) $_POST['formality'] ) : array();
        update_option( 'wptranslate_formality', $formality );

        // Save active/inactive states.
        $active = isset( $_POST['active'] ) ? array_map( 'sanitize_text_field', array_keys( (array) $_POST['active'] ) ) : array();
        $all_languages = $language_manager->get_all_languages();
        foreach ( $all_languages as $lang ) {
            $is_active = in_array( $lang['code'], $active, true ) || ! empty( $lang['is_default'] );
            $language_manager->update_language( $lang['code'], array( 'is_active' => $is_active ? 1 : 0 ) );
        }

        // Save default language.
        $default = sanitize_text_field( $_POST['default_language'] ?? '' );
        if ( $default ) {
            // Unset all defaults, then set the new one.
            foreach ( $all_languages as $lang ) {
                $language_manager->update_language( $lang['code'], array( 'is_default' => ( $lang['code'] === $default ) ? 1 : 0 ) );
            }
            update_option( 'wptranslate_default_language', $default );
        }

        // Save slugs.
        $slugs = isset( $_POST['slugs'] ) ? array_map( 'sanitize_title', (array) $_POST['slugs'] ) : array();
        // Store slugs as a separate option for URL rewriting.
        update_option( 'wptranslate_language_slugs', $slugs );

        wp_send_json_success( array( 'message' => __( 'Languages saved successfully.', 'wptranslate' ) ) );
    }

    public function ajax_add_language(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $code = sanitize_text_field( $_POST['code'] ?? '' );

        if ( empty( $code ) ) {
            wp_send_json_error( array( 'message' => __( 'Language code is required.', 'wptranslate' ) ) );
        }

        $language_manager = $this->plugin->get_language_manager();
        $existing = $language_manager->get_language( $code );
        if ( $existing ) {
            wp_send_json_error( array( 'message' => __( 'This language is already added.', 'wptranslate' ) ) );
        }

        $data = array(
            'code'        => $code,
            'name'        => sanitize_text_field( $_POST['name'] ?? '' ),
            'native_name' => sanitize_text_field( $_POST['native_name'] ?? '' ),
            'locale'      => sanitize_text_field( $_POST['locale'] ?? '' ),
            'flag'        => sanitize_text_field( $_POST['flag'] ?? '' ),
            'rtl'         => ! empty( $_POST['rtl'] ) ? 1 : 0,
            'is_active'   => 1,
            'is_default'  => 0,
        );

        // Save formality for the new language.
        $formality_value = sanitize_text_field( $_POST['formality'] ?? 'default' );
        $formality = get_option( 'wptranslate_formality', array() );
        $formality[ $code ] = $formality_value;
        update_option( 'wptranslate_formality', $formality );

        $result = $language_manager->add_language( $data );

        if ( false === $result ) {
            wp_send_json_error( array( 'message' => __( 'Failed to add language.', 'wptranslate' ) ) );
        }

        // Return the full language data so JS can render the new row.
        $lang = $language_manager->get_language( $code );

        wp_send_json_success( array(
            'message' => sprintf(
                /* translators: %s: language name */
                __( '%s added successfully.', 'wptranslate' ),
                $lang ? $lang['name'] : $code
            ),
            'language' => $lang,
        ) );
    }

    public function ajax_delete_language(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $code = sanitize_text_field( $_POST['code'] ?? '' );

        if ( empty( $code ) ) {
            wp_send_json_error( array( 'message' => __( 'Language code is required.', 'wptranslate' ) ) );
        }

        $result = $this->plugin->get_language_manager()->delete_language( $code );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Cannot delete this language. It may be the default language.', 'wptranslate' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Language removed.', 'wptranslate' ) ) );
    }

    public function ajax_reorder_languages(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $order = isset( $_POST['order'] ) ? array_map( 'sanitize_text_field', (array) $_POST['order'] ) : array();
        $language_manager = $this->plugin->get_language_manager();

        foreach ( $order as $position => $code ) {
            $language_manager->update_language( $code, array( 'sort_order' => (int) $position ) );
        }

        wp_send_json_success( array( 'message' => __( 'Language order saved.', 'wptranslate' ) ) );
    }

    public function ajax_update_language(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_manage_languages' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $code = sanitize_text_field( $_POST['code'] ?? '' );

        if ( empty( $code ) ) {
            wp_send_json_error( array( 'message' => __( 'Language code is required.', 'wptranslate' ) ) );
        }

        $data = array(
            'name'        => sanitize_text_field( $_POST['name'] ?? '' ),
            'native_name' => sanitize_text_field( $_POST['native_name'] ?? '' ),
            'flag'        => sanitize_text_field( $_POST['flag'] ?? '' ),
            'locale'      => sanitize_text_field( $_POST['locale'] ?? '' ),
            'rtl'         => ! empty( $_POST['rtl'] ) ? 1 : 0,
            'date_format' => sanitize_text_field( $_POST['date_format'] ?? '' ),
        );

        $result = $this->plugin->get_language_manager()->update_language( $code, $data );

        if ( ! $result ) {
            wp_send_json_error( array( 'message' => __( 'Failed to update language.', 'wptranslate' ) ) );
        }

        wp_send_json_success( array( 'message' => __( 'Language updated.', 'wptranslate' ) ) );
    }
}
