<?php
namespace WPTranslate\Admin\Pages;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;

/**
 * Translation Queue admin page -- shows pending/in-progress/completed/failed jobs
 * with status tabs, bulk retry/cancel, priority adjustment, and job detail diffs.
 */
class TranslationQueuePage {

    /** @var Plugin */
    private $plugin;

    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;

        add_action( 'wp_ajax_wptranslate_retry_job', array( $this, 'ajax_retry_job' ) );
        add_action( 'wp_ajax_wptranslate_cancel_job', array( $this, 'ajax_cancel_job' ) );
        add_action( 'wp_ajax_wptranslate_update_priority', array( $this, 'ajax_update_priority' ) );
        add_action( 'wp_ajax_wptranslate_retry_all_failed', array( $this, 'ajax_retry_all_failed' ) );
        add_action( 'wp_ajax_wptranslate_cancel_all_pending', array( $this, 'ajax_cancel_all_pending' ) );
        add_action( 'wp_ajax_wptranslate_get_job_detail', array( $this, 'ajax_get_job_detail' ) );
    }

    /**
     * Render the translation queue page.
     */
    public function render(): void {
        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_die( esc_html__( 'You do not have permission to access this page.', 'wptranslate' ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        $current_status = sanitize_text_field( $_GET['status'] ?? '' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $paged          = absint( $_GET['paged'] ?? 1 );               // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        $per_page       = 30;
        $offset         = ( $paged - 1 ) * $per_page;

        // Status counts.
        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $counts = array(
            'all'            => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ),
            'pending'        => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'pending' ) ),
            'in_progress'    => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'in_progress' ) ),
            'completed'      => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'completed' ) ),
            'failed'         => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'failed' ) ),
            'pending_review' => (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", 'pending_review' ) ),
        );

        // Query jobs.
        $where  = '1=1';
        $params = array();
        if ( ! empty( $current_status ) ) {
            $where    = 'status = %s';
            $params[] = $current_status;
        }

        $params[] = $per_page;
        $params[] = $offset;

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE {$where} ORDER BY priority ASC, created_at DESC LIMIT %d OFFSET %d",
                ...$params
            ),
            ARRAY_A
        );

        $total       = ! empty( $current_status ) ? ( $counts[ $current_status ] ?? 0 ) : $counts['all'];
        $total_pages = ceil( $total / $per_page );
        ?>
        <div class="wrap wptranslate-queue">
            <?php \WPTranslate\Admin\AdminController::render_page_header( __( 'Translation Queue', 'wptranslate' ) ); ?>

            <?php wp_nonce_field( 'wptranslate_admin', 'wptranslate_queue_nonce' ); ?>

            <!-- Status Tabs -->
            <ul class="subsubsub">
                <?php
                $statuses = array(
                    ''               => __( 'All', 'wptranslate' ),
                    'pending'        => __( 'Pending', 'wptranslate' ),
                    'in_progress'    => __( 'In Progress', 'wptranslate' ),
                    'completed'      => __( 'Completed', 'wptranslate' ),
                    'failed'         => __( 'Failed', 'wptranslate' ),
                    'pending_review' => __( 'Pending Review', 'wptranslate' ),
                );
                $last_key = array_key_last( $statuses );
                foreach ( $statuses as $status_key => $label ) :
                    $count_key = $status_key ?: 'all';
                    $count     = $counts[ $count_key ] ?? 0;
                    $active    = $current_status === $status_key ? 'current' : '';
                    $url       = add_query_arg( array( 'page' => 'wptranslate-queue', 'status' => $status_key ), admin_url( 'admin.php' ) );
                ?>
                <li>
                    <a href="<?php echo esc_url( $url ); ?>" class="<?php echo esc_attr( $active ); ?>">
                        <?php echo esc_html( $label ); ?>
                        <span class="count">(<?php echo esc_html( $count ); ?>)</span>
                    </a>
                    <?php echo $status_key !== $last_key ? '|' : ''; ?>
                </li>
                <?php endforeach; ?>
            </ul>

            <br class="clear" />

            <!-- Bulk Actions -->
            <div class="tablenav top">
                <div class="alignleft actions bulkactions">
                    <?php if ( $counts['failed'] > 0 ) : ?>
                        <button type="button" class="button" id="wptranslate-retry-all-failed">
                            <?php esc_html_e( 'Retry All Failed', 'wptranslate' ); ?>
                        </button>
                    <?php endif; ?>
                    <?php if ( $counts['pending'] > 0 ) : ?>
                        <button type="button" class="button" id="wptranslate-cancel-all-pending">
                            <?php esc_html_e( 'Cancel All Pending', 'wptranslate' ); ?>
                        </button>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Jobs Table -->
            <div class="wptranslate-card">
            <table class="wp-list-table widefat fixed striped">
                <thead>
                    <tr>
                        <th style="width:50px;"><?php esc_html_e( 'ID', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Content', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Languages', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Provider', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Status', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Priority', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Created', 'wptranslate' ); ?></th>
                        <th><?php esc_html_e( 'Actions', 'wptranslate' ); ?></th>
                    </tr>
                </thead>
                <tbody>
                    <?php if ( empty( $jobs ) ) : ?>
                        <tr>
                            <td colspan="8">
                                <div class="wptranslate-empty-state">
                                    <div class="wptranslate-empty-state__icon">
                                        <span class="dashicons dashicons-list-view"></span>
                                    </div>
                                    <h3 class="wptranslate-empty-state__title"><?php esc_html_e( 'No Translation Jobs', 'wptranslate' ); ?></h3>
                                    <p class="wptranslate-empty-state__description"><?php esc_html_e( 'Translation jobs will appear here when you translate posts or run bulk translations.', 'wptranslate' ); ?></p>
                                    <div class="wptranslate-empty-state__action">
                                        <a href="<?php echo esc_url( admin_url( 'edit.php' ) ); ?>" class="button button-primary"><?php esc_html_e( 'Go to Posts', 'wptranslate' ); ?></a>
                                    </div>
                                </div>
                            </td>
                        </tr>
                    <?php else : ?>
                        <?php foreach ( $jobs as $job ) :
                            $post_title = get_the_title( $job['element_id'] );
                            $source_lang_data = $this->plugin->get_language_manager()->get_language( $job['source_lang'] );
                            $target_lang_data = $this->plugin->get_language_manager()->get_language( $job['target_lang'] );
                            $source_name = $source_lang_data ? $source_lang_data['name'] : strtoupper( $job['source_lang'] );
                            $target_name = $target_lang_data ? $target_lang_data['name'] : strtoupper( $job['target_lang'] );
                        ?>
                        <tr data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
                            <td><?php echo esc_html( $job['id'] ); ?></td>
                            <td>
                                <?php if ( $post_title ) : ?>
                                    <a href="<?php echo esc_url( get_edit_post_link( $job['element_id'] ) ); ?>">
                                        <?php echo esc_html( $post_title ); ?>
                                    </a>
                                <?php else : ?>
                                    #<?php echo esc_html( $job['element_id'] ); ?>
                                    <span class="description">(<?php echo esc_html( $job['element_type'] ); ?>)</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo esc_html( $source_name . ' -> ' . $target_name ); ?></td>
                            <td><?php echo esc_html( ucfirst( $job['provider'] ?: '-' ) ); ?></td>
                            <td>
                                <span class="wptranslate-status wptranslate-status--<?php echo esc_attr( sanitize_html_class( $job['status'] ) ); ?>">
                                    <?php echo esc_html( DashboardPage::format_status_label( $job['status'] ) ); ?>
                                </span>
                                <?php if ( ! empty( $job['error_message'] ) ) : ?>
                                    <span class="dashicons dashicons-warning wptranslate-error-icon"
                                          title="<?php echo esc_attr( $job['error_message'] ); ?>"></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <select class="wptranslate-priority-select"
                                        data-job-id="<?php echo esc_attr( $job['id'] ); ?>"
                                        <?php echo in_array( $job['status'], array( 'completed', 'failed' ), true ) ? 'disabled' : ''; ?>>
                                    <?php for ( $p = 1; $p <= 20; $p++ ) : ?>
                                        <option value="<?php echo esc_attr( $p ); ?>" <?php selected( (int) $job['priority'], $p ); ?>>
                                            <?php echo esc_html( $p ); ?>
                                        </option>
                                    <?php endfor; ?>
                                </select>
                            </td>
                            <td>
                                <?php echo esc_html( human_time_diff( strtotime( $job['created_at'] ), time() ) ); ?>
                                <?php esc_html_e( 'ago', 'wptranslate' ); ?>
                            </td>
                            <td>
                                <?php if ( 'failed' === $job['status'] ) : ?>
                                    <button type="button" class="button button-small wptranslate-retry-job"
                                            data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
                                        <?php esc_html_e( 'Retry', 'wptranslate' ); ?>
                                    </button>
                                <?php endif; ?>
                                <?php if ( 'pending' === $job['status'] ) : ?>
                                    <button type="button" class="button button-small wptranslate-cancel-job"
                                            data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
                                        <?php esc_html_e( 'Cancel', 'wptranslate' ); ?>
                                    </button>
                                <?php endif; ?>
                                <?php if ( 'completed' === $job['status'] ) : ?>
                                    <button type="button" class="button button-small wptranslate-view-job-detail"
                                            data-job-id="<?php echo esc_attr( $job['id'] ); ?>">
                                        <?php esc_html_e( 'Detail', 'wptranslate' ); ?>
                                    </button>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </tbody>
            </table>
            </div>

            <?php if ( $total_pages > 1 ) : ?>
            <div class="tablenav bottom">
                <div class="tablenav-pages">
                    <?php
                    echo paginate_links( array( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
                        'base'    => add_query_arg( 'paged', '%#%' ),
                        'current' => $paged,
                        'total'   => $total_pages,
                    ) );
                    ?>
                </div>
            </div>
            <?php endif; ?>

            <!-- Job Detail Modal -->
            <div id="wptranslate-job-detail-modal" class="wptranslate-modal" style="display:none;">
                <div class="wptranslate-modal__content wptranslate-modal__content--wide">
                    <h2><?php esc_html_e( 'Job Detail', 'wptranslate' ); ?></h2>
                    <div id="wptranslate-job-detail-content">
                        <p class="description"><?php esc_html_e( 'Loading...', 'wptranslate' ); ?></p>
                    </div>
                    <p>
                        <button type="button" class="button wptranslate-modal__close">
                            <?php esc_html_e( 'Close', 'wptranslate' ); ?>
                        </button>
                    </p>
                </div>
            </div>
        </div>
        <?php
    }

    // -------------------------------------------------------------------------
    // AJAX Handlers
    // -------------------------------------------------------------------------

    /**
     * AJAX: Retry a single failed job.
     */
    public function ajax_retry_job(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $job_id = absint( $_POST['job_id'] ?? 0 );
        if ( ! $job_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid job ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table,
            array( 'status' => 'pending', 'error_message' => '', 'started_at' => null, 'completed_at' => null ),
            array( 'id' => $job_id, 'status' => 'failed' ),
            array( '%s', '%s', '%s', '%s' ),
            array( '%d', '%s' )
        );

        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time(), 'wptranslate_process_queue' );
        }

        wp_send_json_success( array( 'message' => __( 'Job queued for retry.', 'wptranslate' ) ) );
    }

    /**
     * AJAX: Cancel a pending job.
     */
    public function ajax_cancel_job(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $job_id = absint( $_POST['job_id'] ?? 0 );
        if ( ! $job_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid job ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update(
            $table,
            array( 'status' => 'cancelled', 'completed_at' => current_time( 'mysql' ) ),
            array( 'id' => $job_id, 'status' => 'pending' ),
            array( '%s', '%s' ),
            array( '%d', '%s' )
        );

        wp_send_json_success( array( 'message' => __( 'Job cancelled.', 'wptranslate' ) ) );
    }

    /**
     * AJAX: Update a job's priority.
     */
    public function ajax_update_priority(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $job_id   = absint( $_POST['job_id'] ?? 0 );
        $priority = absint( $_POST['priority'] ?? 10 );

        if ( ! $job_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid job ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $wpdb->update( $table, array( 'priority' => $priority ), array( 'id' => $job_id ), array( '%d' ), array( '%d' ) );

        wp_send_json_success( array( 'message' => __( 'Priority updated.', 'wptranslate' ) ) );
    }

    /**
     * AJAX: Retry all failed jobs.
     */
    public function ajax_retry_all_failed(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $count = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = 'pending', error_message = '', started_at = NULL, completed_at = NULL WHERE status = %s",
                'failed'
            )
        );

        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time(), 'wptranslate_process_queue' );
        }

        wp_send_json_success( array(
            'message' => sprintf( __( '%d failed jobs queued for retry.', 'wptranslate' ), $count ),
        ) );
    }

    /**
     * AJAX: Cancel all pending jobs.
     */
    public function ajax_cancel_all_pending(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $count = $wpdb->query(
            $wpdb->prepare(
                "UPDATE {$table} SET status = 'cancelled', completed_at = %s WHERE status = %s",
                current_time( 'mysql' ),
                'pending'
            )
        );

        wp_send_json_success( array(
            'message' => sprintf( __( '%d pending jobs cancelled.', 'wptranslate' ), $count ),
        ) );
    }

    /**
     * AJAX: Get job detail with source-translated diff.
     */
    public function ajax_get_job_detail(): void {
        check_ajax_referer( 'wptranslate_admin', 'nonce' );

        if ( ! current_user_can( 'wptranslate_translate_posts' ) ) {
            wp_send_json_error( array( 'message' => __( 'Permission denied.', 'wptranslate' ) ) );
        }

        $job_id = absint( $_POST['job_id'] ?? 0 );
        if ( ! $job_id ) {
            wp_send_json_error( array( 'message' => __( 'Invalid job ID.', 'wptranslate' ) ) );
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $job = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $job_id ), ARRAY_A );

        if ( ! $job ) {
            wp_send_json_error( array( 'message' => __( 'Job not found.', 'wptranslate' ) ) );
        }

        $source_post = get_post( $job['element_id'] );
        $source_content = $source_post ? $source_post->post_content : '';
        $source_title   = $source_post ? $source_post->post_title : '';

        // Find the translated post.
        $translated_id = $this->plugin->get_translation_manager()->get_translation_id(
            (int) $job['element_id'],
            $job['target_lang']
        );

        $translated_content = '';
        $translated_title   = '';
        if ( $translated_id ) {
            $translated_post    = get_post( $translated_id );
            $translated_content = $translated_post ? $translated_post->post_content : '';
            $translated_title   = $translated_post ? $translated_post->post_title : '';
        }

        wp_send_json_success( array(
            'job'                => $job,
            'source_title'       => $source_title,
            'source_content'     => wp_trim_words( wp_strip_all_tags( $source_content ), 200 ),
            'translated_title'   => $translated_title,
            'translated_content' => wp_trim_words( wp_strip_all_tags( $translated_content ), 200 ),
        ) );
    }
}
