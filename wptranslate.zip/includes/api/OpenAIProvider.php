<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Translation provider for the OpenAI Chat Completions API.
 *
 * Uses the system + user message format to translate content.
 */
class OpenAIProvider extends AbstractProvider implements TranslationProviderInterface {

    /**
     * API endpoint.
     */
    const API_URL = 'https://api.openai.com/v1/chat/completions';

    /**
     * Available models.
     */
    const MODELS = array(
        'gpt-4o'       => 'GPT-4o',
        'gpt-4o-mini'  => 'GPT-4o Mini',
        'gpt-4-turbo'  => 'GPT-4 Turbo',
    );

    /**
     * Default model.
     */
    const DEFAULT_MODEL = 'gpt-4o';

    /**
     * Provider slug.
     *
     * @var string
     */
    protected $slug = 'openai';

    /**
     * {@inheritdoc}
     */
    public function getName(): string {
        return 'OpenAI';
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxBatchSize(): int {
        return 10;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxCharactersPerRequest(): int {
        return 100000;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsGlossary(): bool {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsFormality(): bool {
        return true; // Via system prompt instructions.
    }

    /**
     * Get the selected model.
     *
     * @return string Model identifier.
     */
    protected function get_model(): string {
        $model = get_option( 'wptranslate_openai_model', self::DEFAULT_MODEL );
        if ( ! array_key_exists( $model, self::MODELS ) ) {
            $model = self::DEFAULT_MODEL;
        }
        return $model;
    }

    /**
     * {@inheritdoc}
     */
    public function translate( string $text, string $sourceLang, string $targetLang, array $options = array() ): TranslationResult {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            $this->log_error( 'OpenAI API key is not configured.' );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $system_prompt = $this->build_system_prompt( $sourceLang, $targetLang );

        // Add formality instruction if specified.
        if ( ! empty( $options['formality'] ) ) {
            $system_prompt .= sprintf(
                "\n\n## Formality\nUse a %s tone in the translation.",
                sanitize_text_field( $options['formality'] )
            );
        }

        $model = $this->get_model();

        $body = array(
            'model'       => $model,
            'temperature' => 0.3,
            'messages'    => array(
                array(
                    'role'    => 'system',
                    'content' => $system_prompt,
                ),
                array(
                    'role'    => 'user',
                    'content' => $text,
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ),
                'body'    => wp_json_encode( $body ),
            )
        );

        if ( $this->is_error_response( $response ) ) {
            $this->log_error( 'OpenAI translation failed: ' . $this->get_error_message( $response ) );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $data = $this->parse_json_response( $response );

        if ( empty( $data ) || empty( $data['choices'][0]['message']['content'] ) ) {
            $this->log_error( 'OpenAI returned an empty or malformed response.' );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $translated_text = trim( $data['choices'][0]['message']['content'] );
        $tokens_used     = isset( $data['usage'] )
            ? ( $data['usage']['prompt_tokens'] ?? 0 ) + ( $data['usage']['completion_tokens'] ?? 0 )
            : 0;

        return new TranslationResult(
            $translated_text,
            $sourceLang,
            $targetLang,
            $this->slug,
            $tokens_used,
            false
        );
    }

    /**
     * {@inheritdoc}
     */
    public function translateBatch( array $texts, string $sourceLang, string $targetLang, array $options = array() ): array {
        $results = array();

        // Like Claude, OpenAI does not have a native batch translation endpoint.
        // Use numbered prompt approach.
        $batch_size = $this->getMaxBatchSize();
        $batches    = array_chunk( $texts, $batch_size );

        foreach ( $batches as $batch ) {
            if ( count( $batch ) === 1 ) {
                $results[] = $this->translate( $batch[0], $sourceLang, $targetLang, $options );
                continue;
            }

            $numbered = array();
            foreach ( $batch as $index => $text ) {
                $numbered[] = sprintf( '[%d]\n%s', $index + 1, $text );
            }

            $combined_text = "Translate each numbered section separately. Return each translation prefixed with its number in the same [N] format:\n\n" . implode( "\n\n", $numbered );

            $result = $this->translate( $combined_text, $sourceLang, $targetLang, $options );

            if ( empty( $result->translated_text ) ) {
                foreach ( $batch as $text ) {
                    $results[] = new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
                }
                continue;
            }

            $parsed    = $this->parse_numbered_response( $result->translated_text, count( $batch ) );
            $per_token = count( $parsed ) > 0 ? intdiv( $result->tokens_used, count( $parsed ) ) : 0;

            foreach ( $parsed as $translated ) {
                $results[] = new TranslationResult(
                    $translated,
                    $sourceLang,
                    $targetLang,
                    $this->slug,
                    $per_token,
                    false
                );
            }
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getSupportedLanguages(): array {
        return array(
            'en' => 'English',
            'es' => 'Spanish',
            'fr' => 'French',
            'de' => 'German',
            'it' => 'Italian',
            'pt' => 'Portuguese',
            'nl' => 'Dutch',
            'pl' => 'Polish',
            'ru' => 'Russian',
            'ja' => 'Japanese',
            'ko' => 'Korean',
            'zh' => 'Chinese',
            'ar' => 'Arabic',
            'hi' => 'Hindi',
            'tr' => 'Turkish',
            'sv' => 'Swedish',
            'da' => 'Danish',
            'fi' => 'Finnish',
            'nb' => 'Norwegian',
            'cs' => 'Czech',
            'ro' => 'Romanian',
            'hu' => 'Hungarian',
            'el' => 'Greek',
            'bg' => 'Bulgarian',
            'uk' => 'Ukrainian',
            'th' => 'Thai',
            'vi' => 'Vietnamese',
            'id' => 'Indonesian',
            'ms' => 'Malay',
            'he' => 'Hebrew',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function detectLanguage( string $text ): string {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return '';
        }

        $body = array(
            'model'       => $this->get_model(),
            'temperature' => 0,
            'max_tokens'  => 10,
            'messages'    => array(
                array(
                    'role'    => 'system',
                    'content' => 'You are a language detection tool. Respond with ONLY the ISO 639-1 two-letter language code of the text provided. No explanation.',
                ),
                array(
                    'role'    => 'user',
                    'content' => mb_substr( $text, 0, 500 ),
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 15,
            )
        );

        if ( $this->is_error_response( $response ) ) {
            return '';
        }

        $data = $this->parse_json_response( $response );

        if ( ! empty( $data['choices'][0]['message']['content'] ) ) {
            return strtolower( trim( $data['choices'][0]['message']['content'] ) );
        }

        return '';
    }

    /**
     * {@inheritdoc}
     */
    public function getUsage(): array {
        // OpenAI does not provide a simple usage endpoint via API key.
        return array(
            'provider' => $this->slug,
            'note'     => 'OpenAI usage tracking is available at platform.openai.com/usage.',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function validateApiKey(): bool {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return false;
        }

        // Make a minimal request to verify the key works.
        $body = array(
            'model'      => $this->get_model(),
            'max_tokens' => 5,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => 'Hi',
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'Bearer ' . $api_key,
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );

        return $code >= 200 && $code < 300;
    }

    /**
     * Parse a numbered batch response.
     *
     * @param string $response_text The full response text.
     * @param int    $expected_count Expected number of translations.
     * @return array Array of translated texts.
     */
    protected function parse_numbered_response( string $response_text, int $expected_count ): array {
        $results = array();

        $parts = preg_split( '/\[(\d+)\]\s*\n?/', $response_text, -1, PREG_SPLIT_DELIM_CAPTURE );

        if ( false === $parts ) {
            return array( $response_text );
        }

        for ( $i = 1; $i < count( $parts ) - 1; $i += 2 ) {
            $index = (int) $parts[ $i ];
            $text  = isset( $parts[ $i + 1 ] ) ? trim( $parts[ $i + 1 ] ) : '';
            $results[ $index ] = $text;
        }

        $ordered = array();
        for ( $i = 1; $i <= $expected_count; $i++ ) {
            $ordered[] = $results[ $i ] ?? '';
        }

        return $ordered;
    }
}
