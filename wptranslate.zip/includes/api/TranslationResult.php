<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Value object representing a translation result from any provider.
 */
class TranslationResult {

    /** @var string The translated text. */
    public $translated_text;

    /** @var string Source language code. */
    public $source_lang;

    /** @var string Target language code. */
    public $target_lang;

    /** @var string Provider name that produced this result. */
    public $provider;

    /** @var int Tokens or characters used for this translation. */
    public $tokens_used;

    /** @var bool Whether the result came from cache. */
    public $cached;

    /**
     * Constructor.
     *
     * @param string $translated_text The translated text.
     * @param string $source_lang     Source language code.
     * @param string $target_lang     Target language code.
     * @param string $provider        Provider name.
     * @param int    $tokens_used     Tokens or characters consumed.
     * @param bool   $cached          Whether the result was served from cache.
     */
    public function __construct(
        string $translated_text,
        string $source_lang,
        string $target_lang,
        string $provider,
        int $tokens_used = 0,
        bool $cached = false
    ) {
        $this->translated_text = $translated_text;
        $this->source_lang     = $source_lang;
        $this->target_lang     = $target_lang;
        $this->provider        = $provider;
        $this->tokens_used     = $tokens_used;
        $this->cached          = $cached;
    }

    /**
     * Convert to associative array.
     *
     * @return array
     */
    public function to_array(): array {
        return array(
            'translated_text' => $this->translated_text,
            'source_lang'     => $this->source_lang,
            'target_lang'     => $this->target_lang,
            'provider'        => $this->provider,
            'tokens_used'     => $this->tokens_used,
            'cached'          => $this->cached,
        );
    }
}
