<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Translation provider for the Anthropic Claude API.
 *
 * Uses the Anthropic Messages API to translate content via system prompt
 * instructions and user messages containing the source text.
 */
class ClaudeProvider extends AbstractProvider implements TranslationProviderInterface {

    /**
     * API endpoint.
     */
    const API_URL = 'https://api.anthropic.com/v1/messages';

    /**
     * Anthropic API version.
     */
    const API_VERSION = '2023-06-01';

    /**
     * Available models.
     */
    const MODELS = array(
        'claude-sonnet-4-20250514' => 'Claude Sonnet 4',
        'claude-opus-4-0-20250514' => 'Claude Opus 4',
        'claude-haiku-4-5-20251001' => 'Claude Haiku 4.5',
    );

    /**
     * Default model.
     */
    const DEFAULT_MODEL = 'claude-sonnet-4-20250514';

    /**
     * Provider slug.
     *
     * @var string
     */
    protected $slug = 'claude';

    /**
     * {@inheritdoc}
     */
    public function getName(): string {
        return 'Claude (Anthropic)';
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxBatchSize(): int {
        return 10;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxCharactersPerRequest(): int {
        return 100000;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsGlossary(): bool {
        return false;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsFormality(): bool {
        return true; // Via system prompt instructions.
    }

    /**
     * Get the selected model.
     *
     * @return string Model identifier.
     */
    protected function get_model(): string {
        $model = get_option( 'wptranslate_claude_model', self::DEFAULT_MODEL );
        if ( ! array_key_exists( $model, self::MODELS ) ) {
            $model = self::DEFAULT_MODEL;
        }
        return $model;
    }

    /**
     * {@inheritdoc}
     */
    public function translate( string $text, string $sourceLang, string $targetLang, array $options = array() ): TranslationResult {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            $this->log_error( 'Claude API key is not configured.' );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $system_prompt = $this->build_system_prompt( $sourceLang, $targetLang );

        // Add formality instruction if specified.
        if ( ! empty( $options['formality'] ) ) {
            $system_prompt .= sprintf(
                "\n\n## Formality\nUse a %s tone in the translation.",
                sanitize_text_field( $options['formality'] )
            );
        }

        $model = $this->get_model();

        $body = array(
            'model'      => $model,
            'max_tokens' => $this->estimate_max_tokens( $text ),
            'system'     => $system_prompt,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => $text,
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'      => 'application/json',
                    'x-api-key'         => $api_key,
                    'anthropic-version'  => self::API_VERSION,
                ),
                'body'    => wp_json_encode( $body ),
            )
        );

        if ( $this->is_error_response( $response ) ) {
            $this->log_error( 'Claude translation failed: ' . $this->get_error_message( $response ) );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $data = $this->parse_json_response( $response );

        if ( empty( $data ) || empty( $data['content'][0]['text'] ) ) {
            $this->log_error( 'Claude returned an empty or malformed response.' );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $translated_text = $data['content'][0]['text'];
        $tokens_used     = isset( $data['usage'] )
            ? ( $data['usage']['input_tokens'] ?? 0 ) + ( $data['usage']['output_tokens'] ?? 0 )
            : 0;

        return new TranslationResult(
            $translated_text,
            $sourceLang,
            $targetLang,
            $this->slug,
            $tokens_used,
            false
        );
    }

    /**
     * {@inheritdoc}
     */
    public function translateBatch( array $texts, string $sourceLang, string $targetLang, array $options = array() ): array {
        $results = array();

        // Claude does not have a native batch endpoint.
        // Combine texts into a single prompt with numbered items for efficiency.
        $batch_size  = $this->getMaxBatchSize();
        $batches     = array_chunk( $texts, $batch_size );

        foreach ( $batches as $batch ) {
            if ( count( $batch ) === 1 ) {
                $results[] = $this->translate( $batch[0], $sourceLang, $targetLang, $options );
                continue;
            }

            // Build a numbered prompt.
            $numbered = array();
            foreach ( $batch as $index => $text ) {
                $numbered[] = sprintf( '[%d]\n%s', $index + 1, $text );
            }

            $combined_text = "Translate each numbered section separately. Return each translation prefixed with its number in the same [N] format:\n\n" . implode( "\n\n", $numbered );

            $result = $this->translate( $combined_text, $sourceLang, $targetLang, $options );

            if ( empty( $result->translated_text ) ) {
                // On failure, return empty results for each text.
                foreach ( $batch as $text ) {
                    $results[] = new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
                }
                continue;
            }

            // Parse the numbered response.
            $parsed = $this->parse_numbered_response( $result->translated_text, count( $batch ) );
            $per_token = count( $parsed ) > 0 ? intdiv( $result->tokens_used, count( $parsed ) ) : 0;

            foreach ( $parsed as $translated ) {
                $results[] = new TranslationResult(
                    $translated,
                    $sourceLang,
                    $targetLang,
                    $this->slug,
                    $per_token,
                    false
                );
            }
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getSupportedLanguages(): array {
        // Claude supports translation between most major languages via prompting.
        return array(
            'en' => 'English',
            'es' => 'Spanish',
            'fr' => 'French',
            'de' => 'German',
            'it' => 'Italian',
            'pt' => 'Portuguese',
            'nl' => 'Dutch',
            'pl' => 'Polish',
            'ru' => 'Russian',
            'ja' => 'Japanese',
            'ko' => 'Korean',
            'zh' => 'Chinese',
            'ar' => 'Arabic',
            'hi' => 'Hindi',
            'tr' => 'Turkish',
            'sv' => 'Swedish',
            'da' => 'Danish',
            'fi' => 'Finnish',
            'nb' => 'Norwegian',
            'cs' => 'Czech',
            'ro' => 'Romanian',
            'hu' => 'Hungarian',
            'el' => 'Greek',
            'bg' => 'Bulgarian',
            'uk' => 'Ukrainian',
            'th' => 'Thai',
            'vi' => 'Vietnamese',
            'id' => 'Indonesian',
            'ms' => 'Malay',
            'he' => 'Hebrew',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function detectLanguage( string $text ): string {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return '';
        }

        $body = array(
            'model'      => $this->get_model(),
            'max_tokens' => 10,
            'system'     => 'You are a language detection tool. Respond with ONLY the ISO 639-1 two-letter language code of the text provided. No explanation.',
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => mb_substr( $text, 0, 500 ),
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'      => 'application/json',
                    'x-api-key'         => $api_key,
                    'anthropic-version'  => self::API_VERSION,
                ),
                'body'    => wp_json_encode( $body ),
            )
        );

        if ( $this->is_error_response( $response ) ) {
            return '';
        }

        $data = $this->parse_json_response( $response );

        if ( ! empty( $data['content'][0]['text'] ) ) {
            return strtolower( trim( $data['content'][0]['text'] ) );
        }

        return '';
    }

    /**
     * {@inheritdoc}
     */
    public function getUsage(): array {
        // Anthropic does not provide a usage/quota endpoint.
        return array(
            'provider' => $this->slug,
            'note'     => 'Anthropic does not provide a usage tracking API. Check your dashboard at console.anthropic.com.',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function validateApiKey(): bool {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return false;
        }

        // Make a minimal request to verify the key works.
        $body = array(
            'model'      => $this->get_model(),
            'max_tokens' => 5,
            'messages'   => array(
                array(
                    'role'    => 'user',
                    'content' => 'Hi',
                ),
            ),
        );

        $response = $this->make_request(
            self::API_URL,
            array(
                'headers' => array(
                    'Content-Type'      => 'application/json',
                    'x-api-key'         => $api_key,
                    'anthropic-version'  => self::API_VERSION,
                ),
                'body'    => wp_json_encode( $body ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        $code = wp_remote_retrieve_response_code( $response );

        return $code >= 200 && $code < 300;
    }

    /**
     * Estimate the max_tokens for a given input text.
     *
     * Translation generally produces output of similar length to input.
     * We add overhead for languages that tend to expand.
     *
     * @param string $text Input text.
     * @return int Estimated max tokens for the response.
     */
    protected function estimate_max_tokens( string $text ): int {
        // Rough estimate: 1 token ~= 4 characters. Add 50% buffer.
        $estimated = (int) ceil( mb_strlen( $text ) / 4 * 1.5 );
        return max( 256, min( $estimated, 8192 ) );
    }

    /**
     * Parse a numbered batch response from Claude.
     *
     * Expects format:
     * [1]
     * translated text one
     *
     * [2]
     * translated text two
     *
     * @param string $response_text The full response text.
     * @param int    $expected_count Expected number of translations.
     * @return array Array of translated texts.
     */
    protected function parse_numbered_response( string $response_text, int $expected_count ): array {
        $results = array();

        // Split by numbered markers.
        $parts = preg_split( '/\[(\d+)\]\s*\n?/', $response_text, -1, PREG_SPLIT_DELIM_CAPTURE );

        if ( false === $parts ) {
            return array( $response_text );
        }

        // preg_split with DELIM_CAPTURE gives: ['', '1', 'text1', '2', 'text2', ...].
        for ( $i = 1; $i < count( $parts ) - 1; $i += 2 ) {
            $index = (int) $parts[ $i ];
            $text  = isset( $parts[ $i + 1 ] ) ? trim( $parts[ $i + 1 ] ) : '';
            $results[ $index ] = $text;
        }

        // Ensure we have the expected number of results in order.
        $ordered = array();
        for ( $i = 1; $i <= $expected_count; $i++ ) {
            $ordered[] = $results[ $i ] ?? '';
        }

        return $ordered;
    }
}
