<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Interface that all translation providers must implement.
 */
interface TranslationProviderInterface {

    /**
     * Translate a single text string.
     *
     * @param string $text       The text to translate.
     * @param string $sourceLang Source language code.
     * @param string $targetLang Target language code.
     * @param array  $options    Provider-specific options.
     * @return TranslationResult
     */
    public function translate( string $text, string $sourceLang, string $targetLang, array $options = array() ): TranslationResult;

    /**
     * Translate multiple texts in a single batch.
     *
     * @param array  $texts      Array of strings to translate.
     * @param string $sourceLang Source language code.
     * @param string $targetLang Target language code.
     * @param array  $options    Provider-specific options.
     * @return array Array of TranslationResult objects.
     */
    public function translateBatch( array $texts, string $sourceLang, string $targetLang, array $options = array() ): array;

    /**
     * Get supported language codes.
     *
     * @return array Associative array of code => language name.
     */
    public function getSupportedLanguages(): array;

    /**
     * Detect the language of a given text.
     *
     * @param string $text Text to detect language of.
     * @return string Detected language code.
     */
    public function detectLanguage( string $text ): string;

    /**
     * Get current API usage statistics.
     *
     * @return array Associative array with usage details (e.g. characters_used, characters_limit).
     */
    public function getUsage(): array;

    /**
     * Validate the configured API key.
     *
     * @return bool True if the API key is valid.
     */
    public function validateApiKey(): bool;

    /**
     * Get the human-readable provider name.
     *
     * @return string
     */
    public function getName(): string;

    /**
     * Get the maximum number of texts in a single batch request.
     *
     * @return int
     */
    public function getMaxBatchSize(): int;

    /**
     * Get the maximum characters allowed per single request.
     *
     * @return int
     */
    public function getMaxCharactersPerRequest(): int;

    /**
     * Whether this provider supports glossary/terminology management.
     *
     * @return bool
     */
    public function supportsGlossary(): bool;

    /**
     * Whether this provider supports formality levels.
     *
     * @return bool
     */
    public function supportsFormality(): bool;
}
