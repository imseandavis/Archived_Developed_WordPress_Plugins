<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Translation provider for the DeepL API v2.
 *
 * Supports both DeepL Free and DeepL Pro API endpoints, with automatic
 * detection based on the API key format. Includes native support for
 * tag handling, formality levels, and glossaries.
 */
class DeepLProvider extends AbstractProvider implements TranslationProviderInterface {

    /**
     * DeepL Pro API endpoint.
     */
    const API_URL_PRO = 'https://api.deepl.com/v2';

    /**
     * DeepL Free API endpoint.
     */
    const API_URL_FREE = 'https://api-free.deepl.com/v2';

    /**
     * Provider slug.
     *
     * @var string
     */
    protected $slug = 'deepl';

    /**
     * Cached API base URL.
     *
     * @var string|null
     */
    protected $api_base_url = null;

    /**
     * Language code mapping from WPTranslate codes to DeepL codes.
     *
     * DeepL uses some non-standard or variant language codes.
     *
     * @var array
     */
    const LANGUAGE_MAP = array(
        'en'    => 'EN',
        'en-us' => 'EN-US',
        'en-gb' => 'EN-GB',
        'pt'    => 'PT-PT',
        'pt-br' => 'PT-BR',
        'zh'    => 'ZH-HANS',
        'zh-tw' => 'ZH-HANT',
        'de'    => 'DE',
        'fr'    => 'FR',
        'es'    => 'ES',
        'it'    => 'IT',
        'nl'    => 'NL',
        'pl'    => 'PL',
        'ru'    => 'RU',
        'ja'    => 'JA',
        'ko'    => 'KO',
        'ar'    => 'AR',
        'tr'    => 'TR',
        'sv'    => 'SV',
        'da'    => 'DA',
        'fi'    => 'FI',
        'nb'    => 'NB',
        'cs'    => 'CS',
        'ro'    => 'RO',
        'hu'    => 'HU',
        'el'    => 'EL',
        'bg'    => 'BG',
        'uk'    => 'UK',
        'id'    => 'ID',
        'sk'    => 'SK',
        'sl'    => 'SL',
        'lt'    => 'LT',
        'lv'    => 'LV',
        'et'    => 'ET',
    );

    /**
     * Languages that support the formality parameter.
     *
     * @var array
     */
    const FORMALITY_SUPPORTED_LANGS = array(
        'DE', 'FR', 'IT', 'ES', 'NL', 'PL', 'PT-PT', 'PT-BR', 'RU', 'JA',
    );

    /**
     * {@inheritdoc}
     */
    public function getName(): string {
        return 'DeepL';
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxBatchSize(): int {
        return 50;
    }

    /**
     * {@inheritdoc}
     */
    public function getMaxCharactersPerRequest(): int {
        return 128000;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsGlossary(): bool {
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function supportsFormality(): bool {
        return true;
    }

    /**
     * Get the API base URL based on whether the key is Free or Pro.
     *
     * DeepL Free API keys end with ":fx".
     *
     * @return string
     */
    protected function get_api_base_url(): string {
        if ( null !== $this->api_base_url ) {
            return $this->api_base_url;
        }

        $api_key = $this->get_api_key();

        if ( substr( $api_key, -3 ) === ':fx' ) {
            $this->api_base_url = self::API_URL_FREE;
        } else {
            $this->api_base_url = self::API_URL_PRO;
        }

        return $this->api_base_url;
    }

    /**
     * Map a WPTranslate language code to a DeepL language code.
     *
     * @param string $code       The WPTranslate language code.
     * @param bool   $for_source Whether the code is for the source language
     *                           (source codes cannot use regional variants in some cases).
     * @return string The DeepL language code.
     */
    protected function map_language_code( string $code, bool $for_source = false ): string {
        $lower = strtolower( $code );

        if ( isset( self::LANGUAGE_MAP[ $lower ] ) ) {
            $mapped = self::LANGUAGE_MAP[ $lower ];
        } else {
            $mapped = strtoupper( $code );
        }

        // DeepL source language should use base code for English and Portuguese.
        if ( $for_source ) {
            if ( in_array( $mapped, array( 'EN-US', 'EN-GB' ), true ) ) {
                $mapped = 'EN';
            }
            if ( in_array( $mapped, array( 'PT-PT', 'PT-BR' ), true ) ) {
                $mapped = 'PT';
            }
        }

        return $mapped;
    }

    /**
     * Map a DeepL language code back to a WPTranslate code.
     *
     * @param string $deepl_code The DeepL language code.
     * @return string The WPTranslate language code.
     */
    protected function unmap_language_code( string $deepl_code ): string {
        $flipped = array_flip( self::LANGUAGE_MAP );
        $upper   = strtoupper( $deepl_code );

        if ( isset( $flipped[ $upper ] ) ) {
            return $flipped[ $upper ];
        }

        return strtolower( $deepl_code );
    }

    /**
     * {@inheritdoc}
     */
    public function translate( string $text, string $sourceLang, string $targetLang, array $options = array() ): TranslationResult {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            $this->log_error( 'DeepL API key is not configured.' );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        // Strip Gutenberg block comments before sending to DeepL. DeepL's
        // tag_handling:html can choke on HTML comments that contain JSON
        // (e.g. <!-- wp:image {"id":123} -->). We replace them with numbered
        // placeholders, translate, then restore.
        $block_comments = array();
        $clean_text = preg_replace_callback(
            '/<!-- \/?wp:[a-z][a-z0-9\/-]*(?:\s+\{[^}]*\})?\s*\/? ?-->/',
            function ( $match ) use ( &$block_comments ) {
                $idx = count( $block_comments );
                $placeholder = '<wpt-block data-idx="' . $idx . '"></wpt-block>';
                $block_comments[ $idx ] = $match[0];
                return $placeholder;
            },
            $text
        );
        if ( null === $clean_text ) {
            $clean_text = $text;
            $block_comments = array();
        }

        $params = array(
            'text'                => array( $clean_text ),
            'source_lang'         => $this->map_language_code( $sourceLang, true ),
            'target_lang'         => $this->map_language_code( $targetLang, false ),
            'tag_handling'        => 'html',
            'preserve_formatting' => true,
            'split_sentences'     => 'nonewlines',
            'ignore_tags'         => array( 'code', 'pre', 'wpt-block' ),
        );

        // Add formality if supported for this target language.
        if ( ! empty( $options['formality'] ) ) {
            $target_upper = $this->map_language_code( $targetLang, false );
            $base_target  = explode( '-', $target_upper )[0];
            if (
                in_array( $target_upper, self::FORMALITY_SUPPORTED_LANGS, true ) ||
                in_array( $base_target, self::FORMALITY_SUPPORTED_LANGS, true )
            ) {
                $formality_map = array(
                    'formal'   => 'more',
                    'informal' => 'less',
                    'more'     => 'more',
                    'less'     => 'less',
                );
                $formality = strtolower( $options['formality'] );
                if ( isset( $formality_map[ $formality ] ) ) {
                    $params['formality'] = $formality_map[ $formality ];
                }
            }
        }

        // Add glossary ID if provided.
        if ( ! empty( $options['glossary_id'] ) ) {
            $params['glossary_id'] = $options['glossary_id'];
        }

        $url = $this->get_api_base_url() . '/translate';

        // Use a longer timeout for large content to avoid silent failures.
        $text_length = mb_strlen( $text );
        $timeout     = $text_length > 10000 ? 120 : 60;

        $response = $this->make_request(
            $url,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'body'    => wp_json_encode( $params ),
                'timeout' => $timeout,
            )
        );

        if ( $this->is_error_response( $response ) ) {
            $error_msg = $this->get_error_message( $response );
            $this->log_error( sprintf(
                'DeepL translation failed for %d chars of text: %s',
                $text_length,
                $error_msg
            ) );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $data = $this->parse_json_response( $response );

        if ( empty( $data ) || empty( $data['translations'][0]['text'] ) ) {
            $this->log_error( sprintf(
                'DeepL returned an empty or malformed response for %d chars of source text. Response body: %s',
                $text_length,
                wp_remote_retrieve_body( $response )
            ) );
            return new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
        }

        $translated_text = $data['translations'][0]['text'];
        $detected_source = $data['translations'][0]['detected_source_language'] ?? $sourceLang;
        $chars_used      = mb_strlen( $text );

        // Restore Gutenberg block comment placeholders.
        if ( ! empty( $block_comments ) ) {
            $translated_text = preg_replace_callback(
                '/<wpt-block data-idx="(\d+)"><\/wpt-block>/',
                function ( $m ) use ( $block_comments ) {
                    $idx = (int) $m[1];
                    return $block_comments[ $idx ] ?? '';
                },
                $translated_text
            );
        }

        return new TranslationResult(
            $translated_text,
            $this->unmap_language_code( $detected_source ),
            $targetLang,
            $this->slug,
            $chars_used,
            false
        );
    }

    /**
     * {@inheritdoc}
     */
    public function translateBatch( array $texts, string $sourceLang, string $targetLang, array $options = array() ): array {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            $this->log_error( 'DeepL API key is not configured.' );
            return array_fill( 0, count( $texts ), new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false ) );
        }

        $results    = array();
        $batch_size = $this->getMaxBatchSize();
        $batches    = array_chunk( $texts, $batch_size );

        foreach ( $batches as $batch ) {
            $params = array(
                'text'                => $batch,
                'source_lang'         => $this->map_language_code( $sourceLang, true ),
                'target_lang'         => $this->map_language_code( $targetLang, false ),
                'tag_handling'        => 'html',
                'preserve_formatting' => true,
                'split_sentences'     => 'nonewlines',
            );

            // Formality.
            if ( ! empty( $options['formality'] ) ) {
                $target_upper = $this->map_language_code( $targetLang, false );
                $base_target  = explode( '-', $target_upper )[0];
                if (
                    in_array( $target_upper, self::FORMALITY_SUPPORTED_LANGS, true ) ||
                    in_array( $base_target, self::FORMALITY_SUPPORTED_LANGS, true )
                ) {
                    $formality_map = array(
                        'formal'   => 'more',
                        'informal' => 'less',
                        'more'     => 'more',
                        'less'     => 'less',
                    );
                    $formality = strtolower( $options['formality'] );
                    if ( isset( $formality_map[ $formality ] ) ) {
                        $params['formality'] = $formality_map[ $formality ];
                    }
                }
            }

            if ( ! empty( $options['glossary_id'] ) ) {
                $params['glossary_id'] = $options['glossary_id'];
            }

            $url = $this->get_api_base_url() . '/translate';

            $response = $this->make_request(
                $url,
                array(
                    'headers' => array(
                        'Content-Type'  => 'application/json',
                        'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                    ),
                    'body'    => wp_json_encode( $params ),
                )
            );

            if ( $this->is_error_response( $response ) ) {
                $this->log_error( 'DeepL batch translation failed: ' . $this->get_error_message( $response ) );
                foreach ( $batch as $text ) {
                    $results[] = new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
                }
                continue;
            }

            $data = $this->parse_json_response( $response );

            if ( empty( $data ) || empty( $data['translations'] ) ) {
                foreach ( $batch as $text ) {
                    $results[] = new TranslationResult( '', $sourceLang, $targetLang, $this->slug, 0, false );
                }
                continue;
            }

            foreach ( $data['translations'] as $index => $translation ) {
                $detected = $translation['detected_source_language'] ?? $sourceLang;
                $results[] = new TranslationResult(
                    $translation['text'] ?? '',
                    $this->unmap_language_code( $detected ),
                    $targetLang,
                    $this->slug,
                    mb_strlen( $batch[ $index ] ?? '' ),
                    false
                );
            }
        }

        return $results;
    }

    /**
     * {@inheritdoc}
     */
    public function getSupportedLanguages(): array {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return $this->get_default_languages();
        }

        // Attempt to fetch from DeepL API.
        $url = $this->get_api_base_url() . '/languages?type=target';

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return $this->get_default_languages();
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $data ) ) {
            return $this->get_default_languages();
        }

        $languages = array();
        foreach ( $data as $lang ) {
            if ( ! empty( $lang['language'] ) && ! empty( $lang['name'] ) ) {
                $code = $this->unmap_language_code( $lang['language'] );
                $languages[ $code ] = $lang['name'];
            }
        }

        return $languages;
    }

    /**
     * Get default supported languages when API is unavailable.
     *
     * @return array
     */
    protected function get_default_languages(): array {
        return array(
            'en'    => 'English',
            'de'    => 'German',
            'fr'    => 'French',
            'es'    => 'Spanish',
            'it'    => 'Italian',
            'pt'    => 'Portuguese',
            'pt-br' => 'Portuguese (Brazilian)',
            'nl'    => 'Dutch',
            'pl'    => 'Polish',
            'ru'    => 'Russian',
            'ja'    => 'Japanese',
            'zh'    => 'Chinese (Simplified)',
            'ko'    => 'Korean',
            'ar'    => 'Arabic',
            'tr'    => 'Turkish',
            'sv'    => 'Swedish',
            'da'    => 'Danish',
            'fi'    => 'Finnish',
            'nb'    => 'Norwegian',
            'cs'    => 'Czech',
            'ro'    => 'Romanian',
            'hu'    => 'Hungarian',
            'el'    => 'Greek',
            'bg'    => 'Bulgarian',
            'uk'    => 'Ukrainian',
            'id'    => 'Indonesian',
            'sk'    => 'Slovak',
            'sl'    => 'Slovenian',
            'lt'    => 'Lithuanian',
            'lv'    => 'Latvian',
            'et'    => 'Estonian',
        );
    }

    /**
     * {@inheritdoc}
     */
    public function detectLanguage( string $text ): string {
        // DeepL auto-detects when source_lang is omitted.
        // Translate a short sample and check detected_source_language.
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return '';
        }

        $params = array(
            'text'        => array( mb_substr( $text, 0, 200 ) ),
            'target_lang' => 'EN',
        );

        $url = $this->get_api_base_url() . '/translate';

        $response = $this->make_request(
            $url,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'body'    => wp_json_encode( $params ),
            )
        );

        if ( $this->is_error_response( $response ) ) {
            return '';
        }

        $data = $this->parse_json_response( $response );

        if ( ! empty( $data['translations'][0]['detected_source_language'] ) ) {
            return $this->unmap_language_code( $data['translations'][0]['detected_source_language'] );
        }

        return '';
    }

    /**
     * {@inheritdoc}
     */
    public function getUsage(): array {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return array(
                'provider' => $this->slug,
                'error'    => 'API key not configured.',
            );
        }

        $url = $this->get_api_base_url() . '/usage';

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return array(
                'provider' => $this->slug,
                'error'    => 'Failed to retrieve usage data.',
            );
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        if ( ! is_array( $data ) ) {
            return array(
                'provider' => $this->slug,
                'error'    => 'Invalid usage response.',
            );
        }

        return array(
            'provider'         => $this->slug,
            'characters_used'  => $data['character_count'] ?? 0,
            'characters_limit' => $data['character_limit'] ?? 0,
            'is_free'          => $this->is_free_key(),
        );
    }

    /**
     * {@inheritdoc}
     */
    public function validateApiKey(): bool {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return false;
        }

        $url = $this->get_api_base_url() . '/usage';

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        return wp_remote_retrieve_response_code( $response ) === 200;
    }

    /**
     * Check if the configured key is a DeepL Free key.
     *
     * @return bool
     */
    public function is_free_key(): bool {
        $api_key = $this->get_api_key();
        return substr( $api_key, -3 ) === ':fx';
    }

    // -------------------------------------------------------------------------
    // Glossary Management
    // -------------------------------------------------------------------------

    /**
     * List existing DeepL glossaries.
     *
     * @return array Array of glossary info arrays, or empty on failure.
     */
    public function list_glossaries(): array {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return array();
        }

        $url = $this->get_api_base_url() . '/glossaries';

        $response = wp_remote_get(
            $url,
            array(
                'headers' => array(
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) || wp_remote_retrieve_response_code( $response ) !== 200 ) {
            return array();
        }

        $data = json_decode( wp_remote_retrieve_body( $response ), true );

        return $data['glossaries'] ?? array();
    }

    /**
     * Create a DeepL glossary from WPTranslate glossary terms.
     *
     * @param string $name        Glossary name.
     * @param string $source_lang Source language code.
     * @param string $target_lang Target language code.
     * @return string|false The glossary ID on success, false on failure.
     */
    public function create_glossary( string $name, string $source_lang, string $target_lang ) {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return false;
        }

        $terms = $this->get_glossary_terms( $source_lang, $target_lang );

        if ( empty( $terms ) ) {
            return false;
        }

        // Build TSV entries.
        $entries = array();
        foreach ( $terms as $term ) {
            $entries[] = $term['term'] . "\t" . $term['translation'];
        }
        $entries_tsv = implode( "\n", $entries );

        $params = array(
            'name'             => $name,
            'source_lang'      => $this->map_language_code( $source_lang, true ),
            'target_lang'      => $this->map_language_code( $target_lang, false ),
            'entries'          => $entries_tsv,
            'entries_format'   => 'tsv',
        );

        $url = $this->get_api_base_url() . '/glossaries';

        $response = $this->make_request(
            $url,
            array(
                'headers' => array(
                    'Content-Type'  => 'application/json',
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'body'    => wp_json_encode( $params ),
            )
        );

        if ( $this->is_error_response( $response ) ) {
            $this->log_error( 'Failed to create DeepL glossary: ' . $this->get_error_message( $response ) );
            return false;
        }

        $data = $this->parse_json_response( $response );

        return $data['glossary_id'] ?? false;
    }

    /**
     * Delete a DeepL glossary.
     *
     * @param string $glossary_id The glossary ID to delete.
     * @return bool True on success.
     */
    public function delete_glossary( string $glossary_id ): bool {
        $api_key = $this->get_api_key();

        if ( empty( $api_key ) ) {
            return false;
        }

        $url = $this->get_api_base_url() . '/glossaries/' . $glossary_id;

        $response = wp_remote_request(
            $url,
            array(
                'method'  => 'DELETE',
                'headers' => array(
                    'Authorization' => 'DeepL-Auth-Key ' . $api_key,
                ),
                'timeout' => 15,
            )
        );

        if ( is_wp_error( $response ) ) {
            return false;
        }

        return wp_remote_retrieve_response_code( $response ) === 204;
    }
}
