<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;
use WP_REST_Server;
use WP_REST_Request;
use WP_REST_Response;
use WP_Error;

/**
 * REST API controller for WPTranslate.
 *
 * Registers all REST endpoints under the wptranslate/v1 namespace.
 */
class RestController {

    /** @var string */
    private const NAMESPACE = 'wptranslate/v1';

    /** @var Plugin */
    private $plugin;

    /**
     * @param Plugin $plugin Main plugin instance.
     */
    public function __construct( Plugin $plugin ) {
        $this->plugin = $plugin;
    }

    /**
     * Register all REST API routes.
     */
    public function register_routes(): void {

        // GET /languages — List configured languages (public).
        register_rest_route( self::NAMESPACE, '/languages', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_languages' ),
            'permission_callback' => '__return_true',
            'schema'              => array( $this, 'get_languages_schema' ),
        ) );

        // POST /translate — Translate text on-demand.
        register_rest_route( self::NAMESPACE, '/translate', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'translate_text' ),
            'permission_callback' => array( $this, 'can_translate_posts' ),
            'args'                => $this->get_translate_text_args(),
            'schema'              => array( $this, 'get_translate_text_schema' ),
        ) );

        // GET /translations/{post_id} — Get all translations for a post (public).
        // POST /translations/{post_id} — Create/update translation for a post.
        register_rest_route( self::NAMESPACE, '/translations/(?P<post_id>\d+)', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_post_translations' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'post_id' => array(
                        'type'              => 'integer',
                        'required'          => true,
                        'validate_callback' => 'rest_validate_request_arg',
                        'sanitize_callback' => 'absint',
                    ),
                ),
                'schema'              => array( $this, 'get_post_translations_schema' ),
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_post_translation' ),
                'permission_callback' => array( $this, 'can_translate_posts' ),
                'args'                => $this->get_create_post_translation_args(),
                'schema'              => array( $this, 'get_post_translation_create_schema' ),
            ),
        ) );

        // GET /translations/{translation_id}/status — Get translation status.
        register_rest_route( self::NAMESPACE, '/translations/(?P<translation_id>\d+)/status', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_translation_status' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'translation_id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
            'schema'              => array( $this, 'get_translation_status_schema' ),
        ) );

        // POST /translations/{translation_id}/submit — Submit for review.
        register_rest_route( self::NAMESPACE, '/translations/(?P<translation_id>\d+)/submit', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'submit_translation' ),
            'permission_callback' => array( $this, 'can_submit_translations' ),
            'args'                => array(
                'translation_id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // POST /translations/{translation_id}/approve — Approve translation.
        register_rest_route( self::NAMESPACE, '/translations/(?P<translation_id>\d+)/approve', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'approve_translation' ),
            'permission_callback' => array( $this, 'can_review_translations' ),
            'args'                => array(
                'translation_id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // POST /translations/{translation_id}/request-revision — Request revision.
        register_rest_route( self::NAMESPACE, '/translations/(?P<translation_id>\d+)/request-revision', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'request_revision' ),
            'permission_callback' => array( $this, 'can_review_translations' ),
            'args'                => array(
                'translation_id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
                'feedback' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_textarea_field',
                    'validate_callback' => function ( $value ) {
                        return ! empty( trim( $value ) );
                    },
                    'description'       => 'Revision feedback for the translator.',
                ),
            ),
        ) );

        // GET /translations/{translation_id}/notes — Get notes.
        // POST /translations/{translation_id}/notes — Add note.
        register_rest_route( self::NAMESPACE, '/translations/(?P<translation_id>\d+)/notes', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_translation_notes' ),
                'permission_callback' => '__return_true',
                'args'                => array(
                    'translation_id' => array(
                        'type'              => 'integer',
                        'required'          => true,
                        'validate_callback' => 'rest_validate_request_arg',
                        'sanitize_callback' => 'absint',
                    ),
                ),
                'schema'              => array( $this, 'get_translation_notes_schema' ),
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'add_translation_note' ),
                'permission_callback' => array( $this, 'can_edit_translations' ),
                'args'                => $this->get_add_note_args(),
            ),
        ) );

        // GET /status — Translation status overview.
        register_rest_route( self::NAMESPACE, '/status', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_status_overview' ),
            'permission_callback' => array( $this, 'can_translate_posts' ),
            'schema'              => array( $this, 'get_status_overview_schema' ),
        ) );

        // POST /jobs — Queue batch translation job.
        register_rest_route( self::NAMESPACE, '/jobs', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'create_batch_job' ),
            'permission_callback' => array( $this, 'can_translate_posts' ),
            'args'                => $this->get_create_batch_job_args(),
        ) );

        // GET /jobs/{job_id} — Get job status.
        register_rest_route( self::NAMESPACE, '/jobs/(?P<job_id>[a-f0-9\-]+)', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_job_status' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'job_id' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // DELETE /jobs/{job_id} — Cancel job.
        register_rest_route( self::NAMESPACE, '/jobs/(?P<job_id>[a-f0-9\-]+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'cancel_job' ),
            'permission_callback' => array( $this, 'can_translate_posts' ),
            'args'                => array(
                'job_id' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_text_field',
                ),
            ),
        ) );

        // GET /glossary — List glossary terms.
        // POST /glossary — Add glossary term.
        register_rest_route( self::NAMESPACE, '/glossary', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_glossary' ),
                'permission_callback' => array( $this, 'can_translate_posts' ),
                'args'                => $this->get_glossary_list_args(),
                'schema'              => array( $this, 'get_glossary_schema' ),
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'add_glossary_term' ),
                'permission_callback' => array( $this, 'can_manage_glossary' ),
                'args'                => $this->get_add_glossary_term_args(),
            ),
        ) );

        // DELETE /glossary/{id} — Delete glossary term.
        register_rest_route( self::NAMESPACE, '/glossary/(?P<id>\d+)', array(
            'methods'             => WP_REST_Server::DELETABLE,
            'callback'            => array( $this, 'delete_glossary_term' ),
            'permission_callback' => array( $this, 'can_manage_glossary' ),
            'args'                => array(
                'id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // GET /assignments — List assignments.
        // POST /assignments — Assign translation.
        register_rest_route( self::NAMESPACE, '/assignments', array(
            array(
                'methods'             => WP_REST_Server::READABLE,
                'callback'            => array( $this, 'get_assignments' ),
                'permission_callback' => array( $this, 'can_translate_posts' ),
            ),
            array(
                'methods'             => WP_REST_Server::CREATABLE,
                'callback'            => array( $this, 'create_assignment' ),
                'permission_callback' => array( $this, 'can_assign_translations' ),
                'args'                => array(
                    'translation_id' => array(
                        'type'              => 'integer',
                        'required'          => true,
                        'validate_callback' => 'rest_validate_request_arg',
                        'sanitize_callback' => 'absint',
                        'description'       => 'Translation record ID to assign.',
                    ),
                    'user_id' => array(
                        'type'              => 'integer',
                        'required'          => true,
                        'validate_callback' => 'rest_validate_request_arg',
                        'sanitize_callback' => 'absint',
                        'description'       => 'User ID to assign the translation to.',
                    ),
                ),
            ),
        ) );

        // GET /corrections — List corrections.
        register_rest_route( self::NAMESPACE, '/corrections', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_corrections' ),
            'permission_callback' => array( $this, 'can_manage_glossary' ),
            'args'                => array(
                'source_lang' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Filter by source language.',
                ),
                'target_lang' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Filter by target language.',
                ),
                'type' => array(
                    'type'              => 'string',
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Filter by correction type.',
                ),
            ),
        ) );

        // GET /corrections/suggestions — Auto-generated glossary suggestions.
        register_rest_route( self::NAMESPACE, '/corrections/suggestions', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_correction_suggestions' ),
            'permission_callback' => array( $this, 'can_manage_glossary' ),
        ) );

        // POST /corrections/suggestions/{id}/confirm — Promote suggestion.
        register_rest_route( self::NAMESPACE, '/corrections/suggestions/(?P<id>\d+)/confirm', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'confirm_suggestion' ),
            'permission_callback' => array( $this, 'can_manage_glossary' ),
            'args'                => array(
                'id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // POST /corrections/suggestions/{id}/dismiss — Dismiss suggestion.
        register_rest_route( self::NAMESPACE, '/corrections/suggestions/(?P<id>\d+)/dismiss', array(
            'methods'             => WP_REST_Server::CREATABLE,
            'callback'            => array( $this, 'dismiss_suggestion' ),
            'permission_callback' => array( $this, 'can_manage_glossary' ),
            'args'                => array(
                'id' => array(
                    'type'              => 'integer',
                    'required'          => true,
                    'validate_callback' => 'rest_validate_request_arg',
                    'sanitize_callback' => 'absint',
                ),
            ),
        ) );

        // GET /translation-memory — Search translation memory.
        register_rest_route( self::NAMESPACE, '/translation-memory', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'search_translation_memory' ),
            'permission_callback' => '__return_true',
            'args'                => array(
                'text' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Source text to search for.',
                ),
                'source_lang' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Source language code.',
                ),
                'target_lang' => array(
                    'type'              => 'string',
                    'required'          => true,
                    'sanitize_callback' => 'sanitize_text_field',
                    'description'       => 'Target language code.',
                ),
            ),
        ) );

        // GET /translators — List translators with workload stats.
        register_rest_route( self::NAMESPACE, '/translators', array(
            'methods'             => WP_REST_Server::READABLE,
            'callback'            => array( $this, 'get_translators' ),
            'permission_callback' => array( $this, 'can_manage_translators' ),
            'schema'              => array( $this, 'get_translators_schema' ),
        ) );
    }

    // =========================================================================
    // Permission callbacks
    // =========================================================================

    /**
     * @return bool|WP_Error
     */
    public function can_translate_posts(): bool {
        return current_user_can( 'wptranslate_translate_posts' );
    }

    /**
     * @return bool
     */
    public function can_submit_translations(): bool {
        return current_user_can( 'wptranslate_submit_translations' );
    }

    /**
     * @return bool
     */
    public function can_review_translations(): bool {
        return current_user_can( 'wptranslate_review_translations' );
    }

    /**
     * @return bool
     */
    public function can_edit_translations(): bool {
        return current_user_can( 'wptranslate_edit_translations' );
    }

    /**
     * @return bool
     */
    public function can_manage_glossary(): bool {
        return current_user_can( 'wptranslate_manage_glossary' );
    }

    /**
     * @return bool
     */
    public function can_assign_translations(): bool {
        return current_user_can( 'wptranslate_assign_translations' );
    }

    /**
     * @return bool
     */
    public function can_manage_translators(): bool {
        return current_user_can( 'wptranslate_manage_translators' );
    }

    // =========================================================================
    // Endpoint callbacks
    // =========================================================================

    /**
     * GET /languages
     */
    public function get_languages( WP_REST_Request $request ): WP_REST_Response {
        $languages = $this->plugin->get_language_manager()->get_active_languages();
        $default   = $this->plugin->get_language_manager()->get_default_language();

        $data = array();
        foreach ( $languages as $lang ) {
            $data[] = array(
                'code'        => $lang['code'],
                'name'        => $lang['name'],
                'native_name' => $lang['native_name'],
                'locale'      => $lang['locale'],
                'flag'        => $lang['flag'],
                'rtl'         => (bool) $lang['rtl'],
                'is_default'  => $lang['code'] === $default,
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * POST /translate
     */
    public function translate_text( WP_REST_Request $request ): WP_REST_Response {
        $text        = $request->get_param( 'text' );
        $source_lang = $request->get_param( 'source_lang' );
        $target_lang = $request->get_param( 'target_lang' );
        $provider    = $request->get_param( 'provider' );

        $tm = $this->plugin->get_translation_manager();

        $result = $tm->translate_text( $text, $source_lang, $target_lang, $provider );

        if ( is_wp_error( $result ) ) {
            return new WP_REST_Response(
                array(
                    'code'    => $result->get_error_code(),
                    'message' => $result->get_error_message(),
                ),
                500
            );
        }

        return new WP_REST_Response( array(
            'source_text'    => $text,
            'translated_text' => $result,
            'source_lang'    => $source_lang,
            'target_lang'    => $target_lang,
        ), 200 );
    }

    /**
     * GET /translations/{post_id}
     */
    public function get_post_translations( WP_REST_Request $request ): WP_REST_Response {
        $post_id = (int) $request->get_param( 'post_id' );

        $post = get_post( $post_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Post not found.' ),
                404
            );
        }

        $tm           = $this->plugin->get_translation_manager();
        $translations = $tm->get_all_translations( $post_id );

        $data = array();
        foreach ( $translations as $lang_code => $element_id ) {
            $translated_post = get_post( $element_id );
            $status_info     = $tm->get_translation_status( $element_id );

            $data[] = array(
                'language_code' => $lang_code,
                'post_id'       => $element_id,
                'title'         => $translated_post ? $translated_post->post_title : '',
                'status'        => $status_info['status'] ?? 'unknown',
                'post_status'   => $translated_post ? $translated_post->post_status : '',
                'date_modified' => $status_info['date_modified'] ?? null,
            );
        }

        return new WP_REST_Response( array(
            'source_post_id' => $post_id,
            'translations'   => $data,
        ), 200 );
    }

    /**
     * POST /translations/{post_id}
     */
    public function create_post_translation( WP_REST_Request $request ): WP_REST_Response {
        $post_id     = (int) $request->get_param( 'post_id' );
        $target_lang = $request->get_param( 'target_lang' );
        $provider    = $request->get_param( 'provider' );
        $force       = (bool) $request->get_param( 'force' );

        $post = get_post( $post_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Post not found.' ),
                404
            );
        }

        $lm = $this->plugin->get_language_manager();
        if ( ! $lm->get_language( $target_lang ) ) {
            return new WP_REST_Response(
                array( 'code' => 'invalid_language', 'message' => 'Target language is not configured.' ),
                400
            );
        }

        $tm     = $this->plugin->get_translation_manager();
        $result = $tm->translate_post( $post_id, $target_lang, array(
            'provider' => $provider,
            'force'    => $force,
        ) );

        if ( is_wp_error( $result ) ) {
            return new WP_REST_Response(
                array(
                    'code'    => $result->get_error_code(),
                    'message' => $result->get_error_message(),
                ),
                422
            );
        }

        $translated_post = get_post( $result );
        $status_info     = $tm->get_translation_status( $result );

        return new WP_REST_Response( array(
            'post_id'       => $result,
            'title'         => $translated_post ? $translated_post->post_title : '',
            'status'        => $status_info['status'] ?? 'ai_draft',
            'post_status'   => $translated_post ? $translated_post->post_status : 'draft',
            'language_code' => $target_lang,
        ), 201 );
    }

    /**
     * GET /translations/{translation_id}/status
     */
    public function get_translation_status( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $tm     = $this->plugin->get_translation_manager();
        $status = $tm->get_translation_status( $translation_id );

        if ( ! $status ) {
            return new WP_REST_Response(
                array( 'code' => 'no_status', 'message' => 'No translation status found for this post.' ),
                404
            );
        }

        return new WP_REST_Response( array(
            'translation_id'    => $translation_id,
            'status'            => $status['status'],
            'translator'        => (int) $status['translator'],
            'assigned_to'       => (int) $status['assigned_to'],
            'assigned_at'       => $status['assigned_at'],
            'reviewed_by'       => (int) $status['reviewed_by'],
            'reviewed_at'       => $status['reviewed_at'],
            'revision_feedback' => $status['revision_feedback'] ?? '',
            'date_modified'     => $status['date_modified'],
            'md5_hash'          => $status['md5_hash'],
        ), 200 );
    }

    /**
     * POST /translations/{translation_id}/submit
     */
    public function submit_translation( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $tm     = $this->plugin->get_translation_manager();
        $status = $tm->get_translation_status( $translation_id );

        if ( ! $status ) {
            return new WP_REST_Response(
                array( 'code' => 'no_status', 'message' => 'No translation status record found.' ),
                404
            );
        }

        $allowed_from = array( 'ai_draft', 'editing', 'needs_revision' );
        if ( ! in_array( $status['status'], $allowed_from, true ) ) {
            return new WP_REST_Response(
                array(
                    'code'    => 'invalid_transition',
                    'message' => sprintf( 'Cannot submit from status "%s".', $status['status'] ),
                ),
                409
            );
        }

        $tm->set_translation_status( $translation_id, 'pending_review', array(
            'translator' => get_current_user_id(),
        ) );

        return new WP_REST_Response( array(
            'translation_id' => $translation_id,
            'status'         => 'pending_review',
        ), 200 );
    }

    /**
     * POST /translations/{translation_id}/approve
     */
    public function approve_translation( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $tm     = $this->plugin->get_translation_manager();
        $status = $tm->get_translation_status( $translation_id );

        if ( ! $status || 'pending_review' !== $status['status'] ) {
            return new WP_REST_Response(
                array(
                    'code'    => 'invalid_transition',
                    'message' => 'Only translations in "pending_review" status can be approved.',
                ),
                409
            );
        }

        $tm->set_translation_status( $translation_id, 'approved', array(
            'reviewed_by' => get_current_user_id(),
        ) );

        // Publish the translated post.
        wp_update_post( array(
            'ID'          => $translation_id,
            'post_status' => 'publish',
        ) );

        return new WP_REST_Response( array(
            'translation_id' => $translation_id,
            'status'         => 'approved',
        ), 200 );
    }

    /**
     * POST /translations/{translation_id}/request-revision
     */
    public function request_revision( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );
        $feedback       = $request->get_param( 'feedback' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $tm     = $this->plugin->get_translation_manager();
        $status = $tm->get_translation_status( $translation_id );

        if ( ! $status || 'pending_review' !== $status['status'] ) {
            return new WP_REST_Response(
                array(
                    'code'    => 'invalid_transition',
                    'message' => 'Only translations in "pending_review" status can be sent back for revision.',
                ),
                409
            );
        }

        $tm->set_translation_status( $translation_id, 'needs_revision', array(
            'reviewed_by'       => get_current_user_id(),
            'revision_feedback' => $feedback,
        ) );

        return new WP_REST_Response( array(
            'translation_id' => $translation_id,
            'status'         => 'needs_revision',
            'feedback'       => $feedback,
        ), 200 );
    }

    /**
     * GET /translations/{translation_id}/notes
     */
    public function get_translation_notes( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $comments = get_comments( array(
            'post_id' => $translation_id,
            'type'    => 'wpt_translation_note',
            'orderby' => 'comment_date_gmt',
            'order'   => 'ASC',
            'status'  => 'approve',
        ) );

        $data = array();
        foreach ( $comments as $comment ) {
            $data[] = array(
                'id'      => (int) $comment->comment_ID,
                'author'  => array(
                    'id'   => (int) $comment->user_id,
                    'name' => $comment->comment_author,
                ),
                'content' => $comment->comment_content,
                'type'    => get_comment_meta( $comment->comment_ID, '_wpt_note_type', true ) ?: 'general',
                'date'    => $comment->comment_date_gmt,
            );
        }

        return new WP_REST_Response( array(
            'translation_id' => $translation_id,
            'notes'          => $data,
        ), 200 );
    }

    /**
     * POST /translations/{translation_id}/notes
     */
    public function add_translation_note( WP_REST_Request $request ): WP_REST_Response {
        $translation_id = (int) $request->get_param( 'translation_id' );
        $content        = $request->get_param( 'content' );
        $type           = $request->get_param( 'type' );

        $post = get_post( $translation_id );
        if ( ! $post ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation not found.' ),
                404
            );
        }

        $current_user = wp_get_current_user();

        $comment_id = wp_insert_comment( array(
            'comment_post_ID' => $translation_id,
            'comment_content' => $content,
            'comment_type'    => 'wpt_translation_note',
            'comment_approved' => 1,
            'user_id'         => $current_user->ID,
            'comment_author'  => $current_user->display_name,
            'comment_author_email' => $current_user->user_email,
        ) );

        if ( ! $comment_id ) {
            return new WP_REST_Response(
                array( 'code' => 'insert_failed', 'message' => 'Failed to create note.' ),
                500
            );
        }

        if ( $type ) {
            update_comment_meta( $comment_id, '_wpt_note_type', $type );
        }

        return new WP_REST_Response( array(
            'id'             => $comment_id,
            'translation_id' => $translation_id,
            'content'        => $content,
            'type'           => $type ?: 'general',
            'author'         => array(
                'id'   => $current_user->ID,
                'name' => $current_user->display_name,
            ),
        ), 201 );
    }

    /**
     * GET /status
     */
    public function get_status_overview( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $status_table       = $wpdb->prefix . 'wpt_translation_status';
        $translations_table = $wpdb->prefix . 'wpt_translations';
        $jobs_table         = $wpdb->prefix . 'wpt_translation_jobs';

        // Count translations by status.
        $status_counts = $wpdb->get_results(
            "SELECT s.status, COUNT(*) AS count
             FROM {$status_table} s
             INNER JOIN {$translations_table} t ON s.translation_id = t.id
             WHERE t.element_type = 'post'
             GROUP BY s.status",
            ARRAY_A
        );

        $by_status = array();
        $total     = 0;
        foreach ( $status_counts as $row ) {
            $by_status[ $row['status'] ] = (int) $row['count'];
            $total += (int) $row['count'];
        }

        // Count pending jobs.
        $pending_jobs = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$jobs_table} WHERE status IN ('pending', 'in_progress')"
        );

        // Count languages with translations.
        $languages_in_use = (int) $wpdb->get_var(
            "SELECT COUNT(DISTINCT language_code) FROM {$translations_table} WHERE element_type = 'post'"
        );

        return new WP_REST_Response( array(
            'total_translations' => $total,
            'by_status'          => $by_status,
            'pending_jobs'       => $pending_jobs,
            'languages_in_use'   => $languages_in_use,
        ), 200 );
    }

    /**
     * POST /jobs
     */
    public function create_batch_job( WP_REST_Request $request ): WP_REST_Response {
        $element_ids = $request->get_param( 'element_ids' );
        $target_lang = $request->get_param( 'target_lang' );
        $provider    = $request->get_param( 'provider' );
        $priority    = $request->get_param( 'priority' ) ?? 10;

        $lm = $this->plugin->get_language_manager();
        if ( ! $lm->get_language( $target_lang ) ) {
            return new WP_REST_Response(
                array( 'code' => 'invalid_language', 'message' => 'Target language is not configured.' ),
                400
            );
        }

        $tm       = $this->plugin->get_translation_manager();
        $batch_id = null;
        $queued   = array();

        foreach ( $element_ids as $element_id ) {
            $element_id = absint( $element_id );
            $post       = get_post( $element_id );
            if ( ! $post ) {
                continue;
            }

            $source_lang = $tm->get_post_language( $element_id );
            if ( ! $source_lang ) {
                $source_lang = $lm->get_default_language();
            }

            $job_batch_id = $tm->queue_translation_job( array(
                'element_id'   => $element_id,
                'element_type' => 'post',
                'source_lang'  => $source_lang,
                'target_lang'  => $target_lang,
                'provider'     => $provider ?? '',
                'priority'     => $priority,
            ) );

            if ( null === $batch_id ) {
                $batch_id = $job_batch_id;
            }

            $queued[] = $element_id;
        }

        if ( empty( $queued ) ) {
            return new WP_REST_Response(
                array( 'code' => 'no_valid_elements', 'message' => 'No valid elements to translate.' ),
                400
            );
        }

        // Ensure cron will process the queue.
        if ( ! wp_next_scheduled( 'wptranslate_process_queue' ) ) {
            wp_schedule_single_event( time() + 10, 'wptranslate_process_queue' );
        }

        return new WP_REST_Response( array(
            'batch_id'     => $batch_id,
            'queued_count' => count( $queued ),
            'element_ids'  => $queued,
            'target_lang'  => $target_lang,
        ), 202 );
    }

    /**
     * GET /jobs/{job_id}
     */
    public function get_job_status( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $job_id = $request->get_param( 'job_id' );
        $table  = $wpdb->prefix . 'wpt_translation_jobs';

        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE batch_id = %s ORDER BY created_at ASC",
                $job_id
            ),
            ARRAY_A
        );

        if ( empty( $jobs ) ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Job not found.' ),
                404
            );
        }

        $items = array();
        foreach ( $jobs as $job ) {
            $items[] = array(
                'id'            => (int) $job['id'],
                'element_id'    => (int) $job['element_id'],
                'element_type'  => $job['element_type'],
                'source_lang'   => $job['source_lang'],
                'target_lang'   => $job['target_lang'],
                'provider'      => $job['provider'],
                'status'        => $job['status'],
                'priority'      => (int) $job['priority'],
                'created_at'    => $job['created_at'],
                'started_at'    => $job['started_at'],
                'completed_at'  => $job['completed_at'],
                'error_message' => $job['error_message'],
            );
        }

        $statuses  = array_column( $items, 'status' );
        $completed = count( array_filter( $statuses, fn( $s ) => in_array( $s, array( 'completed', 'failed' ), true ) ) );

        return new WP_REST_Response( array(
            'batch_id'  => $job_id,
            'total'     => count( $items ),
            'completed' => $completed,
            'status'    => $completed === count( $items ) ? 'completed' : 'in_progress',
            'jobs'      => $items,
        ), 200 );
    }

    /**
     * DELETE /jobs/{job_id}
     */
    public function cancel_job( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $job_id = $request->get_param( 'job_id' );
        $table  = $wpdb->prefix . 'wpt_translation_jobs';

        $exists = $wpdb->get_var(
            $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE batch_id = %s", $job_id )
        );

        if ( ! $exists ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Job not found.' ),
                404
            );
        }

        $cancelled = $wpdb->update(
            $table,
            array(
                'status'       => 'cancelled',
                'completed_at' => current_time( 'mysql' ),
            ),
            array(
                'batch_id' => $job_id,
                'status'   => 'pending',
            ),
            array( '%s', '%s' ),
            array( '%s', '%s' )
        );

        return new WP_REST_Response( array(
            'batch_id'        => $job_id,
            'cancelled_count' => (int) $cancelled,
        ), 200 );
    }

    /**
     * GET /glossary
     */
    public function get_glossary( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $table       = $wpdb->prefix . 'wpt_translation_glossary';
        $source_lang = $request->get_param( 'source_lang' );
        $target_lang = $request->get_param( 'target_lang' );

        $where  = array( 'confirmed = 1' );
        $values = array();

        if ( $source_lang ) {
            $where[]  = 'source_lang = %s';
            $values[] = $source_lang;
        }
        if ( $target_lang ) {
            $where[]  = 'target_lang = %s';
            $values[] = $target_lang;
        }

        $where_clause = implode( ' AND ', $where );
        $sql          = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY term ASC";

        if ( ! empty( $values ) ) {
            $sql = $wpdb->prepare( $sql, ...$values );
        }

        $results = $wpdb->get_results( $sql, ARRAY_A );

        $data = array();
        foreach ( ( $results ?: array() ) as $row ) {
            $data[] = array(
                'id'             => (int) $row['id'],
                'term'           => $row['term'],
                'translation'    => $row['translation'],
                'source_lang'    => $row['source_lang'],
                'target_lang'    => $row['target_lang'],
                'case_sensitive' => (bool) $row['case_sensitive'],
                'exact_match'    => (bool) $row['exact_match'],
                'auto_generated' => (bool) $row['auto_generated'],
                'created_at'     => $row['created_at'],
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * POST /glossary
     */
    public function add_glossary_term( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $table = $wpdb->prefix . 'wpt_translation_glossary';

        $term           = $request->get_param( 'term' );
        $translation    = $request->get_param( 'translation' );
        $source_lang    = $request->get_param( 'source_lang' );
        $target_lang    = $request->get_param( 'target_lang' );
        $case_sensitive = (bool) $request->get_param( 'case_sensitive' );
        $exact_match    = (bool) $request->get_param( 'exact_match' );

        // Check for duplicate.
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE term = %s AND source_lang = %s AND target_lang = %s",
                $term,
                $source_lang,
                $target_lang
            )
        );

        if ( $existing ) {
            return new WP_REST_Response(
                array( 'code' => 'duplicate', 'message' => 'A glossary entry for this term and language pair already exists.' ),
                409
            );
        }

        $wpdb->insert(
            $table,
            array(
                'term'           => $term,
                'translation'    => $translation,
                'source_lang'    => $source_lang,
                'target_lang'    => $target_lang,
                'case_sensitive' => $case_sensitive ? 1 : 0,
                'exact_match'    => $exact_match ? 1 : 0,
                'auto_generated' => 0,
                'confirmed'      => 1,
                'created_at'     => current_time( 'mysql' ),
            ),
            array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
        );

        $id = $wpdb->insert_id;

        if ( ! $id ) {
            return new WP_REST_Response(
                array( 'code' => 'insert_failed', 'message' => 'Failed to insert glossary term.' ),
                500
            );
        }

        return new WP_REST_Response( array(
            'id'             => $id,
            'term'           => $term,
            'translation'    => $translation,
            'source_lang'    => $source_lang,
            'target_lang'    => $target_lang,
            'case_sensitive' => $case_sensitive,
            'exact_match'    => $exact_match,
        ), 201 );
    }

    /**
     * DELETE /glossary/{id}
     */
    public function delete_glossary_term( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $id    = (int) $request->get_param( 'id' );
        $table = $wpdb->prefix . 'wpt_translation_glossary';

        $existing = $wpdb->get_var(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE id = %d", $id )
        );

        if ( ! $existing ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Glossary term not found.' ),
                404
            );
        }

        $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );

        return new WP_REST_Response( array(
            'deleted' => true,
            'id'      => $id,
        ), 200 );
    }

    /**
     * GET /assignments
     */
    public function get_assignments( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $status_table       = $wpdb->prefix . 'wpt_translation_status';
        $translations_table = $wpdb->prefix . 'wpt_translations';

        $current_user = wp_get_current_user();

        // Translators see only their own assignments; managers see all.
        $is_translator_only = ! current_user_can( 'wptranslate_assign_translations' );

        if ( $is_translator_only ) {
            $results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT s.*, t.element_id, t.language_code, t.source_language_code, t.element_type
                     FROM {$status_table} s
                     INNER JOIN {$translations_table} t ON s.translation_id = t.id
                     WHERE s.assigned_to = %d
                     ORDER BY s.date_modified DESC",
                    $current_user->ID
                ),
                ARRAY_A
            );
        } else {
            $results = $wpdb->get_results(
                "SELECT s.*, t.element_id, t.language_code, t.source_language_code, t.element_type
                 FROM {$status_table} s
                 INNER JOIN {$translations_table} t ON s.translation_id = t.id
                 WHERE s.assigned_to > 0
                 ORDER BY s.date_modified DESC",
                ARRAY_A
            );
        }

        $data = array();
        foreach ( ( $results ?: array() ) as $row ) {
            $assignee = get_userdata( (int) $row['assigned_to'] );
            $data[]   = array(
                'translation_id'     => (int) $row['translation_id'],
                'element_id'         => (int) $row['element_id'],
                'element_type'       => $row['element_type'],
                'language_code'      => $row['language_code'],
                'source_language'    => $row['source_language_code'],
                'status'             => $row['status'],
                'assigned_to'        => (int) $row['assigned_to'],
                'assigned_to_name'   => $assignee ? $assignee->display_name : '',
                'assigned_at'        => $row['assigned_at'],
                'date_modified'      => $row['date_modified'],
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * POST /assignments
     */
    public function create_assignment( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $translation_id = (int) $request->get_param( 'translation_id' );
        $user_id        = (int) $request->get_param( 'user_id' );

        // Verify the translation record exists.
        $translations_table = $wpdb->prefix . 'wpt_translations';
        $record = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$translations_table} WHERE id = %d", $translation_id ),
            ARRAY_A
        );

        if ( ! $record ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Translation record not found.' ),
                404
            );
        }

        // Verify the user exists.
        $user = get_userdata( $user_id );
        if ( ! $user ) {
            return new WP_REST_Response(
                array( 'code' => 'invalid_user', 'message' => 'User not found.' ),
                400
            );
        }

        $tm = $this->plugin->get_translation_manager();
        $tm->set_translation_status( (int) $record['element_id'], 'assigned', array(
            'assigned_to' => $user_id,
        ) );

        return new WP_REST_Response( array(
            'translation_id' => $translation_id,
            'assigned_to'    => $user_id,
            'assigned_to_name' => $user->display_name,
            'status'         => 'assigned',
        ), 200 );
    }

    /**
     * GET /corrections
     */
    public function get_corrections( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $table       = $wpdb->prefix . 'wpt_translation_corrections';
        $source_lang = $request->get_param( 'source_lang' );
        $target_lang = $request->get_param( 'target_lang' );
        $type        = $request->get_param( 'type' );

        $where  = array( '1=1' );
        $values = array();

        if ( $source_lang ) {
            $where[]  = 'source_lang = %s';
            $values[] = $source_lang;
        }
        if ( $target_lang ) {
            $where[]  = 'target_lang = %s';
            $values[] = $target_lang;
        }
        if ( $type ) {
            $where[]  = 'correction_type = %s';
            $values[] = $type;
        }

        $where_clause = implode( ' AND ', $where );
        $sql          = "SELECT * FROM {$table} WHERE {$where_clause} ORDER BY created_at DESC LIMIT 100";

        if ( ! empty( $values ) ) {
            $sql = $wpdb->prepare( $sql, ...$values );
        }

        $results = $wpdb->get_results( $sql, ARRAY_A );

        $data = array();
        foreach ( ( $results ?: array() ) as $row ) {
            $data[] = array(
                'id'                 => (int) $row['id'],
                'translation_id'     => (int) $row['translation_id'],
                'source_text'        => $row['source_text'],
                'ai_output'          => $row['ai_output'],
                'corrected_text'     => $row['corrected_text'],
                'source_lang'        => $row['source_lang'],
                'target_lang'        => $row['target_lang'],
                'provider'           => $row['provider'],
                'correction_type'    => $row['correction_type'],
                'translator_user_id' => (int) $row['translator_user_id'],
                'promoted_to_glossary' => (bool) $row['promoted_to_glossary'],
                'created_at'         => $row['created_at'],
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * GET /corrections/suggestions
     */
    public function get_correction_suggestions( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $table = $wpdb->prefix . 'wpt_translation_glossary';

        $results = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE auto_generated = 1 AND confirmed = 0 ORDER BY created_at DESC",
            ARRAY_A
        );

        $data = array();
        foreach ( ( $results ?: array() ) as $row ) {
            $data[] = array(
                'id'          => (int) $row['id'],
                'term'        => $row['term'],
                'translation' => $row['translation'],
                'source_lang' => $row['source_lang'],
                'target_lang' => $row['target_lang'],
                'created_at'  => $row['created_at'],
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    /**
     * POST /corrections/suggestions/{id}/confirm
     */
    public function confirm_suggestion( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $id    = (int) $request->get_param( 'id' );
        $table = $wpdb->prefix . 'wpt_translation_glossary';

        $row = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE id = %d AND auto_generated = 1 AND confirmed = 0",
                $id
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Suggestion not found or already confirmed.' ),
                404
            );
        }

        $wpdb->update(
            $table,
            array( 'confirmed' => 1 ),
            array( 'id' => $id ),
            array( '%d' ),
            array( '%d' )
        );

        // Mark source corrections as promoted.
        $corrections_table = $wpdb->prefix . 'wpt_translation_corrections';
        $wpdb->update(
            $corrections_table,
            array( 'promoted_to_glossary' => 1 ),
            array(
                'source_text' => $row['term'],
                'source_lang' => $row['source_lang'],
                'target_lang' => $row['target_lang'],
            ),
            array( '%d' ),
            array( '%s', '%s', '%s' )
        );

        return new WP_REST_Response( array(
            'id'        => $id,
            'confirmed' => true,
        ), 200 );
    }

    /**
     * POST /corrections/suggestions/{id}/dismiss
     */
    public function dismiss_suggestion( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $id    = (int) $request->get_param( 'id' );
        $table = $wpdb->prefix . 'wpt_translation_glossary';

        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE id = %d AND auto_generated = 1 AND confirmed = 0",
                $id
            )
        );

        if ( ! $existing ) {
            return new WP_REST_Response(
                array( 'code' => 'not_found', 'message' => 'Suggestion not found or already processed.' ),
                404
            );
        }

        $wpdb->delete( $table, array( 'id' => $id ), array( '%d' ) );

        return new WP_REST_Response( array(
            'id'        => $id,
            'dismissed' => true,
        ), 200 );
    }

    /**
     * GET /translation-memory
     */
    public function search_translation_memory( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $text        = $request->get_param( 'text' );
        $source_lang = $request->get_param( 'source_lang' );
        $target_lang = $request->get_param( 'target_lang' );

        $table = $wpdb->prefix . 'wpt_translation_cache';

        // Search for exact hash match first.
        $hash  = hash( 'sha256', $text );
        $exact = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT source_text, translated_text, provider, source_type, created_at
                 FROM {$table}
                 WHERE source_hash = %s AND source_lang = %s AND target_lang = %s
                 ORDER BY source_type = 'human' DESC, created_at DESC
                 LIMIT 1",
                $hash,
                $source_lang,
                $target_lang
            ),
            ARRAY_A
        );

        // Also search for fuzzy matches via LIKE (short texts only for performance).
        $fuzzy = array();
        if ( mb_strlen( $text ) <= 200 ) {
            $like_term = '%' . $wpdb->esc_like( mb_substr( $text, 0, 50 ) ) . '%';
            $fuzzy_results = $wpdb->get_results(
                $wpdb->prepare(
                    "SELECT source_text, translated_text, provider, source_type, created_at
                     FROM {$table}
                     WHERE source_lang = %s AND target_lang = %s
                     AND source_text LIKE %s
                     AND source_hash != %s
                     ORDER BY source_type = 'human' DESC, created_at DESC
                     LIMIT 5",
                    $source_lang,
                    $target_lang,
                    $like_term,
                    $hash
                ),
                ARRAY_A
            );

            foreach ( ( $fuzzy_results ?: array() ) as $row ) {
                $fuzzy[] = array(
                    'source_text'     => $row['source_text'],
                    'translated_text' => $row['translated_text'],
                    'provider'        => $row['provider'],
                    'source_type'     => $row['source_type'],
                    'created_at'      => $row['created_at'],
                );
            }
        }

        return new WP_REST_Response( array(
            'query'        => $text,
            'source_lang'  => $source_lang,
            'target_lang'  => $target_lang,
            'exact_match'  => $exact ?: null,
            'fuzzy_matches' => $fuzzy,
        ), 200 );
    }

    /**
     * GET /translators
     */
    public function get_translators( WP_REST_Request $request ): WP_REST_Response {
        global $wpdb;

        $status_table = $wpdb->prefix . 'wpt_translation_status';

        // Get all users with translation capabilities.
        $users = get_users( array(
            'role__in' => array( 'wptranslate_translator', 'wptranslate_translation_manager', 'administrator' ),
            'orderby'  => 'display_name',
            'order'    => 'ASC',
        ) );

        $data = array();
        foreach ( $users as $user ) {
            // Count active assignments.
            $active = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$status_table}
                     WHERE assigned_to = %d AND status IN ('assigned', 'editing', 'pending_review')",
                    $user->ID
                )
            );

            // Count completed translations.
            $completed = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$status_table} WHERE translator = %d AND status = 'approved'",
                    $user->ID
                )
            );

            // Count pending reviews.
            $pending_review = (int) $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$status_table} WHERE translator = %d AND status = 'pending_review'",
                    $user->ID
                )
            );

            $data[] = array(
                'id'              => $user->ID,
                'name'            => $user->display_name,
                'email'           => $user->user_email,
                'roles'           => $user->roles,
                'active_tasks'    => $active,
                'completed_tasks' => $completed,
                'pending_review'  => $pending_review,
            );
        }

        return new WP_REST_Response( $data, 200 );
    }

    // =========================================================================
    // Argument definitions
    // =========================================================================

    /**
     * Arguments for POST /translate.
     */
    private function get_translate_text_args(): array {
        return array(
            'text' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_textarea_field',
                'description'       => 'Text to translate.',
            ),
            'source_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Source language code.',
            ),
            'target_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Target language code.',
            ),
            'provider' => array(
                'type'              => 'string',
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Translation provider override.',
            ),
        );
    }

    /**
     * Arguments for POST /translations/{post_id}.
     */
    private function get_create_post_translation_args(): array {
        return array(
            'post_id' => array(
                'type'              => 'integer',
                'required'          => true,
                'validate_callback' => 'rest_validate_request_arg',
                'sanitize_callback' => 'absint',
            ),
            'target_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Target language code.',
            ),
            'provider' => array(
                'type'              => 'string',
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Translation provider override.',
            ),
            'force' => array(
                'type'              => 'boolean',
                'required'          => false,
                'default'           => false,
                'description'       => 'Force re-translation even if one exists.',
            ),
        );
    }

    /**
     * Arguments for POST /translations/{translation_id}/notes.
     */
    private function get_add_note_args(): array {
        return array(
            'translation_id' => array(
                'type'              => 'integer',
                'required'          => true,
                'validate_callback' => 'rest_validate_request_arg',
                'sanitize_callback' => 'absint',
            ),
            'content' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_textarea_field',
                'validate_callback' => function ( $value ) {
                    return ! empty( trim( $value ) );
                },
                'description'       => 'Note content.',
            ),
            'type' => array(
                'type'              => 'string',
                'required'          => false,
                'default'           => 'general',
                'enum'              => array( 'question', 'issue', 'suggestion', 'context_needed' ),
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Note type.',
            ),
        );
    }

    /**
     * Arguments for POST /jobs.
     */
    private function get_create_batch_job_args(): array {
        return array(
            'element_ids' => array(
                'type'              => 'array',
                'required'          => true,
                'items'             => array( 'type' => 'integer' ),
                'validate_callback' => function ( $value ) {
                    return is_array( $value ) && ! empty( $value );
                },
                'sanitize_callback' => function ( $value ) {
                    return array_map( 'absint', (array) $value );
                },
                'description'       => 'Array of post/element IDs to translate.',
            ),
            'target_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Target language code.',
            ),
            'provider' => array(
                'type'              => 'string',
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Translation provider override.',
            ),
            'priority' => array(
                'type'              => 'integer',
                'required'          => false,
                'default'           => 10,
                'sanitize_callback' => 'absint',
                'description'       => 'Job priority (lower = higher priority).',
            ),
        );
    }

    /**
     * Arguments for GET /glossary.
     */
    private function get_glossary_list_args(): array {
        return array(
            'source_lang' => array(
                'type'              => 'string',
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Filter by source language.',
            ),
            'target_lang' => array(
                'type'              => 'string',
                'required'          => false,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Filter by target language.',
            ),
        );
    }

    /**
     * Arguments for POST /glossary.
     */
    private function get_add_glossary_term_args(): array {
        return array(
            'term' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Source term.',
            ),
            'translation' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Translated term.',
            ),
            'source_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Source language code.',
            ),
            'target_lang' => array(
                'type'              => 'string',
                'required'          => true,
                'sanitize_callback' => 'sanitize_text_field',
                'description'       => 'Target language code.',
            ),
            'case_sensitive' => array(
                'type'              => 'boolean',
                'required'          => false,
                'default'           => false,
                'description'       => 'Case-sensitive matching.',
            ),
            'exact_match' => array(
                'type'              => 'boolean',
                'required'          => false,
                'default'           => false,
                'description'       => 'Exact match only.',
            ),
        );
    }

    // =========================================================================
    // Schema definitions
    // =========================================================================

    /**
     * Schema for GET /languages.
     */
    public function get_languages_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-languages',
            'type'    => 'array',
            'items'   => array(
                'type'       => 'object',
                'properties' => array(
                    'code'        => array( 'type' => 'string', 'description' => 'Language code.' ),
                    'name'        => array( 'type' => 'string', 'description' => 'English name.' ),
                    'native_name' => array( 'type' => 'string', 'description' => 'Native name.' ),
                    'locale'      => array( 'type' => 'string', 'description' => 'WordPress locale.' ),
                    'flag'        => array( 'type' => 'string', 'description' => 'Flag emoji.' ),
                    'rtl'         => array( 'type' => 'boolean', 'description' => 'Right-to-left.' ),
                    'is_default'  => array( 'type' => 'boolean', 'description' => 'Whether this is the default language.' ),
                ),
            ),
        );
    }

    /**
     * Schema for POST /translate.
     */
    public function get_translate_text_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-translate',
            'type'    => 'object',
            'properties' => array(
                'source_text'     => array( 'type' => 'string' ),
                'translated_text' => array( 'type' => 'string' ),
                'source_lang'     => array( 'type' => 'string' ),
                'target_lang'     => array( 'type' => 'string' ),
            ),
        );
    }

    /**
     * Schema for GET /translations/{post_id}.
     */
    public function get_post_translations_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-post-translations',
            'type'    => 'object',
            'properties' => array(
                'source_post_id' => array( 'type' => 'integer' ),
                'translations'   => array(
                    'type'  => 'array',
                    'items' => array(
                        'type'       => 'object',
                        'properties' => array(
                            'language_code' => array( 'type' => 'string' ),
                            'post_id'       => array( 'type' => 'integer' ),
                            'title'         => array( 'type' => 'string' ),
                            'status'        => array( 'type' => 'string' ),
                            'post_status'   => array( 'type' => 'string' ),
                            'date_modified' => array( 'type' => array( 'string', 'null' ) ),
                        ),
                    ),
                ),
            ),
        );
    }

    /**
     * Schema for POST /translations/{post_id}.
     */
    public function get_post_translation_create_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-post-translation-create',
            'type'    => 'object',
            'properties' => array(
                'post_id'       => array( 'type' => 'integer' ),
                'title'         => array( 'type' => 'string' ),
                'status'        => array( 'type' => 'string' ),
                'post_status'   => array( 'type' => 'string' ),
                'language_code' => array( 'type' => 'string' ),
            ),
        );
    }

    /**
     * Schema for GET /translations/{translation_id}/status.
     */
    public function get_translation_status_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-translation-status',
            'type'    => 'object',
            'properties' => array(
                'translation_id'    => array( 'type' => 'integer' ),
                'status'            => array( 'type' => 'string' ),
                'translator'        => array( 'type' => 'integer' ),
                'assigned_to'       => array( 'type' => 'integer' ),
                'assigned_at'       => array( 'type' => array( 'string', 'null' ) ),
                'reviewed_by'       => array( 'type' => 'integer' ),
                'reviewed_at'       => array( 'type' => array( 'string', 'null' ) ),
                'revision_feedback' => array( 'type' => 'string' ),
                'date_modified'     => array( 'type' => 'string' ),
                'md5_hash'          => array( 'type' => 'string' ),
            ),
        );
    }

    /**
     * Schema for GET /translations/{translation_id}/notes.
     */
    public function get_translation_notes_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-translation-notes',
            'type'    => 'object',
            'properties' => array(
                'translation_id' => array( 'type' => 'integer' ),
                'notes'          => array(
                    'type'  => 'array',
                    'items' => array(
                        'type'       => 'object',
                        'properties' => array(
                            'id'      => array( 'type' => 'integer' ),
                            'author'  => array(
                                'type'       => 'object',
                                'properties' => array(
                                    'id'   => array( 'type' => 'integer' ),
                                    'name' => array( 'type' => 'string' ),
                                ),
                            ),
                            'content' => array( 'type' => 'string' ),
                            'type'    => array( 'type' => 'string' ),
                            'date'    => array( 'type' => 'string' ),
                        ),
                    ),
                ),
            ),
        );
    }

    /**
     * Schema for GET /status.
     */
    public function get_status_overview_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-status-overview',
            'type'    => 'object',
            'properties' => array(
                'total_translations' => array( 'type' => 'integer' ),
                'by_status'          => array( 'type' => 'object', 'additionalProperties' => array( 'type' => 'integer' ) ),
                'pending_jobs'       => array( 'type' => 'integer' ),
                'languages_in_use'   => array( 'type' => 'integer' ),
            ),
        );
    }

    /**
     * Schema for GET /glossary.
     */
    public function get_glossary_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-glossary',
            'type'    => 'array',
            'items'   => array(
                'type'       => 'object',
                'properties' => array(
                    'id'             => array( 'type' => 'integer' ),
                    'term'           => array( 'type' => 'string' ),
                    'translation'    => array( 'type' => 'string' ),
                    'source_lang'    => array( 'type' => 'string' ),
                    'target_lang'    => array( 'type' => 'string' ),
                    'case_sensitive' => array( 'type' => 'boolean' ),
                    'exact_match'    => array( 'type' => 'boolean' ),
                    'auto_generated' => array( 'type' => 'boolean' ),
                    'created_at'     => array( 'type' => 'string' ),
                ),
            ),
        );
    }

    /**
     * Schema for GET /translators.
     */
    public function get_translators_schema(): array {
        return array(
            '$schema' => 'http://json-schema.org/draft-04/schema#',
            'title'   => 'wptranslate-translators',
            'type'    => 'array',
            'items'   => array(
                'type'       => 'object',
                'properties' => array(
                    'id'              => array( 'type' => 'integer' ),
                    'name'            => array( 'type' => 'string' ),
                    'email'           => array( 'type' => 'string', 'format' => 'email' ),
                    'roles'           => array( 'type' => 'array', 'items' => array( 'type' => 'string' ) ),
                    'active_tasks'    => array( 'type' => 'integer' ),
                    'completed_tasks' => array( 'type' => 'integer' ),
                    'pending_review'  => array( 'type' => 'integer' ),
                ),
            ),
        );
    }
}
