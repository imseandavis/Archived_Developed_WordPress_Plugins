<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manages translation provider instances and orchestrates translation
 * requests with primary/fallback provider selection.
 */
class ProviderManager {

    /**
     * Registered provider class names, keyed by slug.
     *
     * @var array
     */
    protected $registered_providers = array();

    /**
     * Instantiated provider instances, keyed by slug.
     *
     * @var array
     */
    protected $instances = array();

    /**
     * Constructor. Registers the built-in providers.
     */
    public function __construct() {
        $this->registered_providers = array(
            'claude' => ClaudeProvider::class,
            'openai' => OpenAIProvider::class,
            'deepl'  => DeepLProvider::class,
        );

        /**
         * Filter the registered translation providers.
         *
         * Allows third-party plugins to register additional providers.
         *
         * @param array $providers Associative array of slug => class name.
         */
        $this->registered_providers = apply_filters( 'wptranslate_registered_providers', $this->registered_providers );
    }

    /**
     * Register a custom translation provider.
     *
     * The class must extend AbstractProvider and implement TranslationProviderInterface.
     *
     * @param string $name  Provider slug (lowercase, alphanumeric + hyphens).
     * @param string $class Fully qualified class name.
     * @return bool True if registered successfully.
     */
    public function register_provider( string $name, string $class ): bool {
        $name = sanitize_key( $name );

        if ( empty( $name ) ) {
            return false;
        }

        if ( ! class_exists( $class ) ) {
            return false;
        }

        if ( ! is_subclass_of( $class, TranslationProviderInterface::class ) ) {
            return false;
        }

        $this->registered_providers[ $name ] = $class;

        // Clear any cached instance for this name.
        unset( $this->instances[ $name ] );

        return true;
    }

    /**
     * Get a provider instance by name.
     *
     * Returns the primary provider when $name is null.
     *
     * @param string|null $name Provider slug, or null for the primary provider.
     * @return TranslationProviderInterface|null The provider instance, or null if not found/configured.
     */
    public function get_provider( ?string $name = null ): ?TranslationProviderInterface {
        if ( null === $name ) {
            $name = $this->get_primary_provider_name();
        }

        if ( empty( $name ) ) {
            return null;
        }

        // Return cached instance.
        if ( isset( $this->instances[ $name ] ) ) {
            return $this->instances[ $name ];
        }

        // Create new instance.
        if ( ! isset( $this->registered_providers[ $name ] ) ) {
            return null;
        }

        $class = $this->registered_providers[ $name ];

        if ( ! class_exists( $class ) ) {
            return null;
        }

        $instance = new $class();

        if ( ! $instance instanceof TranslationProviderInterface ) {
            return null;
        }

        $this->instances[ $name ] = $instance;

        return $instance;
    }

    /**
     * Translate text using the primary provider, falling back if configured.
     *
     * @param string $text    The text to translate.
     * @param string $source  Source language code.
     * @param string $target  Target language code.
     * @param array  $options Provider-specific options.
     * @return TranslationResult
     */
    public function translate( string $text, string $source, string $target, array $options = array() ): TranslationResult {
        $primary = $this->get_provider();

        // If primary provider has no valid API key, try to find any configured provider.
        if ( null === $primary || ! $primary->validateApiKey() ) {
            $primary = $this->find_any_configured_provider();
        }

        if ( null === $primary ) {
            throw new \Exception( __( 'No translation provider configured. Go to WPTranslate → Settings → Providers to set up an API key and select a primary provider.', 'wptranslate' ) );
        }

        $result = $primary->translate( $text, $source, $target, $options );

        // If primary failed, try the fallback.
        if ( empty( $result->translated_text ) && ! empty( trim( $text ) ) ) {
            $this->log_provider_warning( sprintf(
                'Primary provider "%s" returned empty translation for %d chars of source text.',
                $primary->getName(),
                mb_strlen( $text )
            ) );

            $fallback = $this->get_fallback_provider();

            if ( null !== $fallback ) {
                $result = $fallback->translate( $text, $source, $target, $options );

                if ( ! empty( $result->translated_text ) ) {
                    $this->log_fallback_usage( $primary->getName(), $fallback->getName() );
                } else {
                    $this->log_provider_warning( sprintf(
                        'Fallback provider "%s" also returned empty translation for %d chars of source text.',
                        $fallback->getName(),
                        mb_strlen( $text )
                    ) );
                }
            }
        }

        return $result;
    }

    /**
     * Translate a batch of texts using the primary provider with fallback.
     *
     * @param array  $texts   Array of strings to translate.
     * @param string $source  Source language code.
     * @param string $target  Target language code.
     * @param array  $options Provider-specific options.
     * @return array Array of TranslationResult objects.
     */
    public function translate_batch( array $texts, string $source, string $target, array $options = array() ): array {
        $primary = $this->get_provider();

        if ( null === $primary ) {
            return array_fill(
                0,
                count( $texts ),
                new TranslationResult( '', $source, $target, '', 0, false )
            );
        }

        $results = $primary->translateBatch( $texts, $source, $target, $options );

        // Check for failures and retry with fallback.
        $fallback        = null;
        $fallback_needed = false;

        foreach ( $results as $index => $result ) {
            if ( empty( $result->translated_text ) ) {
                $fallback_needed = true;
                break;
            }
        }

        if ( $fallback_needed ) {
            $fallback = $this->get_fallback_provider();

            if ( null !== $fallback ) {
                $failed_texts   = array();
                $failed_indices = array();

                foreach ( $results as $index => $result ) {
                    if ( empty( $result->translated_text ) ) {
                        $failed_texts[]   = $texts[ $index ];
                        $failed_indices[] = $index;
                    }
                }

                if ( ! empty( $failed_texts ) ) {
                    $fallback_results = $fallback->translateBatch( $failed_texts, $source, $target, $options );

                    foreach ( $failed_indices as $i => $original_index ) {
                        if ( isset( $fallback_results[ $i ] ) && ! empty( $fallback_results[ $i ]->translated_text ) ) {
                            $results[ $original_index ] = $fallback_results[ $i ];
                        }
                    }

                    $this->log_fallback_usage( $primary->getName(), $fallback->getName() );
                }
            }
        }

        return $results;
    }

    /**
     * Get the names of all providers that have a configured API key.
     *
     * @return array Array of provider slugs.
     */
    public function get_available_providers(): array {
        $available = array();

        foreach ( array_keys( $this->registered_providers ) as $slug ) {
            $option_key = 'wptranslate_' . $slug . '_api_key';
            $key        = get_option( $option_key, '' );

            if ( ! empty( $key ) ) {
                $available[] = $slug;
            }
        }

        return $available;
    }

    /**
     * Get all registered provider slugs (whether configured or not).
     *
     * @return array Array of provider slugs.
     */
    public function get_registered_providers(): array {
        return array_keys( $this->registered_providers );
    }

    /**
     * Get provider info for display in admin settings.
     *
     * @return array Array of provider info arrays.
     */
    public function get_providers_info(): array {
        $info = array();

        foreach ( $this->registered_providers as $slug => $class ) {
            $provider = $this->get_provider( $slug );
            if ( null === $provider ) {
                continue;
            }

            $option_key = 'wptranslate_' . $slug . '_api_key';
            $has_key    = ! empty( get_option( $option_key, '' ) );

            $info[ $slug ] = array(
                'name'               => $provider->getName(),
                'slug'               => $slug,
                'configured'         => $has_key,
                'max_batch_size'     => $provider->getMaxBatchSize(),
                'max_chars'          => $provider->getMaxCharactersPerRequest(),
                'supports_glossary'  => $provider->supportsGlossary(),
                'supports_formality' => $provider->supportsFormality(),
            );
        }

        return $info;
    }

    /**
     * Find any provider that has a configured API key.
     *
     * @return TranslationProviderInterface|null
     */
    protected function find_any_configured_provider(): ?TranslationProviderInterface {
        $key_map = array(
            'deepl'  => 'wptranslate_deepl_api_key',
            'claude' => 'wptranslate_claude_api_key',
            'openai' => 'wptranslate_openai_api_key',
        );

        foreach ( $key_map as $provider_name => $option_key ) {
            $key = get_option( $option_key, '' );
            if ( ! empty( $key ) ) {
                $provider = $this->get_provider( $provider_name );
                if ( $provider ) {
                    return $provider;
                }
            }
        }

        return null;
    }

    /**
     * Get the primary provider slug from settings.
     *
     * @return string Provider slug, or empty string if not set.
     */
    protected function get_primary_provider_name(): string {
        return get_option( 'wptranslate_primary_provider', '' );
    }

    /**
     * Get the fallback provider instance, if configured.
     *
     * @return TranslationProviderInterface|null
     */
    protected function get_fallback_provider(): ?TranslationProviderInterface {
        $fallback_name = get_option( 'wptranslate_fallback_provider', '' );

        if ( empty( $fallback_name ) ) {
            return null;
        }

        // Don't fall back to the same provider.
        if ( $fallback_name === $this->get_primary_provider_name() ) {
            return null;
        }

        return $this->get_provider( $fallback_name );
    }

    /**
     * Log when a fallback provider is used.
     *
     * @param string $primary_name  Primary provider name.
     * @param string $fallback_name Fallback provider name.
     */
    protected function log_fallback_usage( string $primary_name, string $fallback_name ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( sprintf( // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
                '[WPTranslate] Primary provider "%s" failed. Falling back to "%s".',
                $primary_name,
                $fallback_name
            ) );
        }
    }

    /**
     * Log a provider warning message.
     *
     * @param string $message Warning message.
     */
    protected function log_provider_warning( string $message ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[WPTranslate][ProviderManager] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
    }
}
