<?php
namespace WPTranslate\api;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Abstract base class for translation providers.
 *
 * Implements common functionality shared by all providers including
 * API key encryption, rate limiting, content chunking, system prompt
 * assembly, and HTTP request handling with retry logic.
 */
abstract class AbstractProvider {

    /**
     * Encryption cipher used for API key storage.
     */
    const CIPHER = 'aes-256-cbc';

    /**
     * Maximum retry attempts for failed requests.
     */
    const MAX_RETRIES = 3;

    /**
     * Base delay in seconds for exponential backoff.
     */
    const BASE_DELAY = 1;

    /**
     * Provider slug identifier.
     *
     * @var string
     */
    protected $slug = '';

    /**
     * Cached decrypted API key.
     *
     * @var string|null
     */
    protected $api_key = null;

    /**
     * Timestamp tracking for rate limit handling.
     *
     * @var array
     */
    protected $rate_limit_state = array(
        'remaining'  => null,
        'reset_at'   => null,
        'retry_after' => null,
    );

    // -------------------------------------------------------------------------
    // API Key Encryption / Decryption
    // -------------------------------------------------------------------------

    /**
     * Encrypt an API key for safe storage in the database.
     *
     * @param string $plain_key The raw API key.
     * @return string Base64-encoded IV + ciphertext, or empty string on failure.
     */
    public function encrypt_api_key( string $plain_key ): string {
        if ( empty( $plain_key ) ) {
            return '';
        }

        if ( ! function_exists( 'openssl_encrypt' ) ) {
            // Fallback: store as-is when OpenSSL is unavailable.
            return base64_encode( $plain_key ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
        }

        $key     = $this->get_encryption_key();
        $iv_len  = openssl_cipher_iv_length( self::CIPHER );
        $iv      = openssl_random_pseudo_bytes( $iv_len );
        $cipher  = openssl_encrypt( $plain_key, self::CIPHER, $key, OPENSSL_RAW_DATA, $iv );

        if ( false === $cipher ) {
            return '';
        }

        return base64_encode( $iv . $cipher ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_encode
    }

    /**
     * Decrypt a stored API key.
     *
     * @param string $encrypted_key The encrypted API key from the database.
     * @return string The decrypted API key, or empty string on failure.
     */
    public function decrypt_api_key( string $encrypted_key ): string {
        if ( empty( $encrypted_key ) ) {
            return '';
        }

        if ( ! function_exists( 'openssl_decrypt' ) ) {
            return base64_decode( $encrypted_key ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions.obfuscation_base64_decode
        }

        // Must match the encryption in SettingsPage::encrypt_value().
        $key = wp_salt( 'auth' );
        $iv  = substr( wp_salt( 'secure_auth' ), 0, 16 );

        $decrypted = openssl_decrypt( $encrypted_key, 'AES-256-CBC', $key, 0, $iv );

        return ( false !== $decrypted ) ? $decrypted : '';
    }

    /**
     * Get the API key for this provider, decrypting if necessary.
     *
     * @return string
     */
    protected function get_api_key(): string {
        if ( null !== $this->api_key ) {
            return $this->api_key;
        }

        $option_key    = 'wptranslate_' . $this->slug . '_api_key';
        $encrypted_key = get_option( $option_key, '' );

        $this->api_key = $this->decrypt_api_key( $encrypted_key );

        return $this->api_key;
    }

    /**
     * Derive an encryption key from wp_salt().
     *
     * @return string 32-byte key derived from wp_salt().
     */
    private function get_encryption_key(): string {
        return hash( 'sha256', wp_salt( 'auth' ) . 'wptranslate_encryption', true );
    }

    // -------------------------------------------------------------------------
    // System Prompt Assembly
    // -------------------------------------------------------------------------

    /**
     * Build the system prompt that instructs the AI on how to translate.
     *
     * Assembles context from multiple sources:
     * 1. Site context (custom description set by admin)
     * 2. Glossary terms for the language pair
     * 3. Correction rules learned from human edits
     * 4. Standard translation preservation instructions
     *
     * @param string $source_lang Source language code.
     * @param string $target_lang Target language code.
     * @return string The assembled system prompt.
     */
    protected function build_system_prompt( string $source_lang, string $target_lang ): string {
        $parts = array();

        // 1. Site context.
        $site_context = get_option( 'wptranslate_site_context', '' );
        if ( ! empty( $site_context ) ) {
            $parts[] = "## Site Context\n" . $site_context;
        }

        // 2. Glossary terms.
        $glossary = $this->get_glossary_terms( $source_lang, $target_lang );
        if ( ! empty( $glossary ) ) {
            $lines = array( '## Glossary' );
            $lines[] = 'Always use these exact translations for the following terms:';
            foreach ( $glossary as $entry ) {
                $flag = $entry['case_sensitive'] ? ' (case-sensitive)' : '';
                $lines[] = sprintf( '- "%s" → "%s"%s', $entry['term'], $entry['translation'], $flag );
            }
            $parts[] = implode( "\n", $lines );
        }

        // 3. Correction rules from human edits.
        $corrections = $this->get_correction_rules( $source_lang, $target_lang );
        if ( ! empty( $corrections ) ) {
            $lines = array( '## Learned Corrections' );
            $lines[] = 'Based on human editor feedback, apply these rules:';
            foreach ( $corrections as $correction ) {
                $lines[] = sprintf(
                    '- When translating "%s", do NOT output "%s" — instead use "%s"',
                    $this->truncate( $correction['source_text'], 100 ),
                    $this->truncate( $correction['ai_output'], 100 ),
                    $this->truncate( $correction['corrected_text'], 100 )
                );
            }
            $parts[] = implode( "\n", $lines );
        }

        // 4. Standard instructions.
        $standard = array(
            '## Translation Instructions',
            sprintf( 'Translate the following content from %s to %s.', $source_lang, $target_lang ),
            '',
            'Rules:',
            '- Preserve all HTML tags, attributes, and structure exactly as-is.',
            '- Preserve all shortcodes (e.g., [shortcode attr="value"]) without modification.',
            '- Preserve all URLs, email addresses, and code blocks unchanged.',
            '- Preserve placeholders such as %s, %d, {0}, {{variable}}, etc.',
            '- Maintain the same formatting (bold, italic, headings, lists).',
            '- Adapt idiomatic expressions naturally rather than translating literally.',
            '- Use appropriate formality level for the target language and audience.',
            '- Do NOT add any explanations, notes, or commentary — output only the translation.',
        );
        $parts[] = implode( "\n", $standard );

        return implode( "\n\n", $parts );
    }

    /**
     * Fetch glossary terms for a language pair.
     *
     * @param string $source_lang Source language code.
     * @param string $target_lang Target language code.
     * @return array Array of glossary entries.
     */
    protected function get_glossary_terms( string $source_lang, string $target_lang ): array {
        global $wpdb;

        $table = $wpdb->prefix . 'wpt_translation_glossary';

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT term, translation, case_sensitive, exact_match FROM {$table}
                WHERE source_lang = %s AND target_lang = %s AND confirmed = 1
                ORDER BY CHAR_LENGTH(term) DESC
                LIMIT 200",
                $source_lang,
                $target_lang
            ),
            ARRAY_A
        );

        return is_array( $results ) ? $results : array();
    }

    /**
     * Fetch recent correction rules for a language pair.
     *
     * Only returns corrections that have been observed at least N times
     * (above the configured threshold) to reduce noise.
     *
     * @param string $source_lang Source language code.
     * @param string $target_lang Target language code.
     * @return array Array of correction entries.
     */
    protected function get_correction_rules( string $source_lang, string $target_lang ): array {
        global $wpdb;

        $table     = $wpdb->prefix . 'wpt_translation_corrections';
        $threshold = (int) get_option( 'wptranslate_correction_threshold', 3 );

        // phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching
        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT source_text, ai_output, corrected_text, COUNT(*) as frequency
                FROM {$table}
                WHERE source_lang = %s AND target_lang = %s
                    AND promoted_to_glossary = 0
                    AND created_at > DATE_SUB(NOW(), INTERVAL 90 DAY)
                GROUP BY source_text, ai_output, corrected_text
                HAVING frequency >= %d
                ORDER BY frequency DESC
                LIMIT 50",
                $source_lang,
                $target_lang,
                $threshold
            ),
            ARRAY_A
        );

        return is_array( $results ) ? $results : array();
    }

    // -------------------------------------------------------------------------
    // Content Chunking
    // -------------------------------------------------------------------------

    /**
     * Split content into chunks that respect paragraph and block boundaries.
     *
     * Splits first by Gutenberg block comments, then by double newlines
     * (paragraphs), ensuring no single chunk exceeds the maximum size.
     *
     * @param string $content  The content to chunk.
     * @param int    $max_size Maximum characters per chunk.
     * @return array Array of content chunks.
     */
    protected function chunk_content( string $content, int $max_size ): array {
        if ( mb_strlen( $content ) <= $max_size ) {
            return array( $content );
        }

        // Try splitting by Gutenberg block comments first.
        $blocks = preg_split( '/(<!-- \/?wp:[a-z][a-z0-9-]* (?:\{[^}]*\} )?\/?>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE );

        if ( false === $blocks ) {
            $blocks = array( $content );
        }

        $chunks        = array();
        $current_chunk = '';

        foreach ( $blocks as $block ) {
            // If appending this block would exceed the limit, finalize the current chunk.
            if ( mb_strlen( $current_chunk ) + mb_strlen( $block ) > $max_size && '' !== $current_chunk ) {
                $chunks[]      = $current_chunk;
                $current_chunk = '';
            }

            // If a single block exceeds the limit, split it by paragraphs.
            if ( mb_strlen( $block ) > $max_size ) {
                $paragraphs = preg_split( '/(\n\n+)/', $block, -1, PREG_SPLIT_DELIM_CAPTURE );

                if ( false === $paragraphs ) {
                    $paragraphs = array( $block );
                }

                foreach ( $paragraphs as $para ) {
                    if ( mb_strlen( $current_chunk ) + mb_strlen( $para ) > $max_size && '' !== $current_chunk ) {
                        $chunks[]      = $current_chunk;
                        $current_chunk = '';
                    }
                    $current_chunk .= $para;
                }
            } else {
                $current_chunk .= $block;
            }
        }

        if ( '' !== $current_chunk ) {
            $chunks[] = $current_chunk;
        }

        return $chunks;
    }

    // -------------------------------------------------------------------------
    // HTTP Request Handling
    // -------------------------------------------------------------------------

    /**
     * Make an HTTP POST request with retry logic and exponential backoff.
     *
     * @param string $url  The API endpoint URL.
     * @param array  $args Arguments for wp_remote_post (headers, body, etc.).
     * @return array|\WP_Error The response array on success, or WP_Error.
     */
    protected function make_request( string $url, array $args ): array {
        $args = wp_parse_args(
            $args,
            array(
                'timeout'   => 60,
                'sslverify' => true,
            )
        );

        $last_error = null;

        for ( $attempt = 0; $attempt < self::MAX_RETRIES; $attempt++ ) {
            // If rate limited, wait until reset.
            if ( $attempt > 0 ) {
                $delay = $this->calculate_backoff_delay( $attempt );
                sleep( $delay );
            }

            $response = wp_remote_post( $url, $args );

            if ( is_wp_error( $response ) ) {
                $last_error = $response;
                $this->log_error( sprintf(
                    'Request to %s failed (attempt %d/%d): %s',
                    $url,
                    $attempt + 1,
                    self::MAX_RETRIES,
                    $response->get_error_message()
                ) );
                continue;
            }

            $code = wp_remote_retrieve_response_code( $response );

            // Update rate limit state from response headers.
            $this->update_rate_limit_state( $response );

            // Success.
            if ( $code >= 200 && $code < 300 ) {
                return $response;
            }

            // Rate limited — retry after specified delay.
            if ( 429 === $code ) {
                $retry_after = wp_remote_retrieve_header( $response, 'retry-after' );
                if ( ! empty( $retry_after ) ) {
                    $this->rate_limit_state['retry_after'] = (int) $retry_after;
                }
                $this->log_error( sprintf(
                    'Rate limited by %s (attempt %d/%d). Retry after: %s seconds.',
                    $this->getName(),
                    $attempt + 1,
                    self::MAX_RETRIES,
                    $retry_after ?: 'unknown'
                ) );
                continue;
            }

            // Server error — retry with backoff.
            if ( $code >= 500 ) {
                $this->log_error( sprintf(
                    'Server error %d from %s (attempt %d/%d).',
                    $code,
                    $this->getName(),
                    $attempt + 1,
                    self::MAX_RETRIES
                ) );
                continue;
            }

            // Client error (4xx) other than 429 — do not retry.
            $body = wp_remote_retrieve_body( $response );
            $this->log_error( sprintf(
                'Client error %d from %s: %s',
                $code,
                $this->getName(),
                $body
            ) );

            return $response;
        }

        // All retries exhausted.
        if ( null !== $last_error ) {
            return array(
                'response' => array( 'code' => 0 ),
                'body'     => $last_error->get_error_message(),
            );
        }

        return $response;
    }

    /**
     * Calculate exponential backoff delay for retries.
     *
     * @param int $attempt Current attempt number (1-based).
     * @return int Delay in seconds.
     */
    protected function calculate_backoff_delay( int $attempt ): int {
        // Check for rate-limit specific retry-after header.
        if ( ! empty( $this->rate_limit_state['retry_after'] ) ) {
            $delay = $this->rate_limit_state['retry_after'];
            $this->rate_limit_state['retry_after'] = null;
            return min( $delay, 60 );
        }

        // Exponential backoff with jitter: 2^attempt * base_delay + random(0-1).
        $delay = (int) pow( 2, $attempt ) * self::BASE_DELAY;
        $delay += wp_rand( 0, 1000 ) / 1000;

        return min( (int) ceil( $delay ), 60 );
    }

    /**
     * Update internal rate limit state from response headers.
     *
     * @param array $response The wp_remote_post response.
     */
    protected function update_rate_limit_state( array $response ): void {
        $remaining = wp_remote_retrieve_header( $response, 'x-ratelimit-remaining' );
        $reset     = wp_remote_retrieve_header( $response, 'x-ratelimit-reset' );

        if ( '' !== $remaining ) {
            $this->rate_limit_state['remaining'] = (int) $remaining;
        }
        if ( '' !== $reset ) {
            $this->rate_limit_state['reset_at'] = (int) $reset;
        }
    }

    // -------------------------------------------------------------------------
    // Logging and Utilities
    // -------------------------------------------------------------------------

    /**
     * Log an error message.
     *
     * @param string $message Error message.
     */
    protected function log_error( string $message ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[WPTranslate][' . $this->slug . '] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
    }

    /**
     * Log a debug message.
     *
     * @param string $message Debug message.
     */
    protected function log_debug( string $message ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG && defined( 'WP_DEBUG_LOG' ) && WP_DEBUG_LOG ) {
            error_log( '[WPTranslate][' . $this->slug . '][debug] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
    }

    /**
     * Truncate a string for display in prompts.
     *
     * @param string $text       The text to truncate.
     * @param int    $max_length Maximum length.
     * @return string
     */
    protected function truncate( string $text, int $max_length = 100 ): string {
        $text = str_replace( array( "\n", "\r" ), ' ', $text );
        if ( mb_strlen( $text ) <= $max_length ) {
            return $text;
        }
        return mb_substr( $text, 0, $max_length - 3 ) . '...';
    }

    /**
     * Parse a JSON response body.
     *
     * @param array $response The wp_remote_post response.
     * @return array|null Decoded JSON or null on failure.
     */
    protected function parse_json_response( array $response ): ?array {
        $body = wp_remote_retrieve_body( $response );

        if ( empty( $body ) ) {
            return null;
        }

        $data = json_decode( $body, true );

        if ( json_last_error() !== JSON_ERROR_NONE ) {
            $this->log_error( 'JSON decode error: ' . json_last_error_msg() );
            return null;
        }

        return $data;
    }

    /**
     * Check if a response indicates an error.
     *
     * @param array $response The wp_remote_post response.
     * @return bool
     */
    protected function is_error_response( $response ): bool {
        if ( is_wp_error( $response ) ) {
            return true;
        }

        $code = wp_remote_retrieve_response_code( $response );

        return $code < 200 || $code >= 300;
    }

    /**
     * Get an error message from a response.
     *
     * @param array $response The response to extract error from.
     * @return string
     */
    protected function get_error_message( $response ): string {
        if ( is_wp_error( $response ) ) {
            return $response->get_error_message();
        }

        $code = wp_remote_retrieve_response_code( $response );
        $body = wp_remote_retrieve_body( $response );
        $data = json_decode( $body, true );

        if ( is_array( $data ) ) {
            // Common error message fields across providers.
            foreach ( array( 'error', 'message', 'error_message' ) as $field ) {
                if ( isset( $data[ $field ] ) ) {
                    $msg = $data[ $field ];
                    if ( is_array( $msg ) && isset( $msg['message'] ) ) {
                        return $msg['message'];
                    }
                    if ( is_string( $msg ) ) {
                        return $msg;
                    }
                }
            }
        }

        return sprintf( 'HTTP %d: %s', $code, wp_remote_retrieve_response_message( $response ) );
    }
}
