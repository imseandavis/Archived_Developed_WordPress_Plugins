<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Core translation management — links posts via trid, manages translation status,
 * queues jobs, and handles the translation workflow.
 */
class TranslationManager {

    /** @var LanguageManager */
    private $language_manager;

    /** @var api\ProviderManager */
    private $provider_manager;

    /** @var cache\CacheManager */
    private $cache;

    public function __construct(
        LanguageManager $language_manager,
        api\ProviderManager $provider_manager,
        cache\CacheManager $cache
    ) {
        $this->language_manager = $language_manager;
        $this->provider_manager = $provider_manager;
        $this->cache            = $cache;

        // Track source post updates.
        add_action( 'post_updated', array( $this, 'on_source_post_updated' ), 10, 3 );
    }

    /**
     * Get the translation group ID for a post.
     *
     * @param int    $element_id   Post/element ID.
     * @param string $element_type Element type (default 'post').
     * @return int|null The trid or null.
     */
    public function get_trid( int $element_id, string $element_type = 'post' ): ?int {
        $cache_key = "trid_{$element_type}_{$element_id}";
        $cached = $this->cache->get( $cache_key );
        if ( false !== $cached ) {
            return $cached ?: null;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $trid = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT trid FROM {$table} WHERE element_id = %d AND element_type = %s",
                $element_id,
                $element_type
            )
        );

        $result = $trid ? (int) $trid : 0;
        $this->cache->set( $cache_key, $result, 3600 );

        return $result ?: null;
    }

    /**
     * Get the translated post ID for a given post and target language.
     *
     * @param int    $post_id     Source post ID.
     * @param string $target_lang Target language code.
     * @param string $element_type Element type.
     * @return int|null Translated post ID or null.
     */
    public function get_translation_id( int $post_id, string $target_lang, string $element_type = 'post' ): ?int {
        $cache_key = "translation_{$element_type}_{$post_id}_{$target_lang}";
        $cached = $this->cache->get( $cache_key );
        if ( false !== $cached ) {
            return $cached ?: null;
        }

        $trid = $this->get_trid( $post_id, $element_type );
        if ( ! $trid ) {
            $this->cache->set( $cache_key, 0, 3600 );
            return null;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $translated_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT element_id FROM {$table} WHERE trid = %d AND language_code = %s AND element_type = %s",
                $trid,
                $target_lang,
                $element_type
            )
        );

        $result = $translated_id ? (int) $translated_id : 0;
        $this->cache->set( $cache_key, $result, 3600 );

        return $result ?: null;
    }

    /**
     * Get all translations for a post (all languages).
     *
     * @param int    $post_id      Post ID.
     * @param string $element_type Element type.
     * @return array Associative array: language_code => element_id.
     */
    public function get_all_translations( int $post_id, string $element_type = 'post' ): array {
        $trid = $this->get_trid( $post_id, $element_type );
        if ( ! $trid ) {
            return array();
        }

        $cache_key = "all_translations_{$element_type}_{$trid}";
        $cached = $this->cache->get( $cache_key );
        if ( false !== $cached ) {
            return $cached;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT element_id, language_code FROM {$table} WHERE trid = %d AND element_type = %s",
                $trid,
                $element_type
            ),
            ARRAY_A
        );

        $translations = array();
        foreach ( $results as $row ) {
            $translations[ $row['language_code'] ] = (int) $row['element_id'];
        }

        $this->cache->set( $cache_key, $translations, 3600 );

        return $translations;
    }

    /**
     * Register a post as belonging to a translation group.
     *
     * @param int    $element_id          Post/element ID.
     * @param string $language_code       Language code.
     * @param string $element_type        Element type.
     * @param int    $trid                Translation group ID (0 = auto-generate).
     * @param string $source_language_code Source language.
     * @return int The trid.
     */
    public function register_translation(
        int $element_id,
        string $language_code,
        string $element_type = 'post',
        int $trid = 0,
        string $source_language_code = ''
    ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        // Generate new trid if needed.
        if ( 0 === $trid ) {
            $max_trid = $wpdb->get_var( "SELECT MAX(trid) FROM {$table}" );
            $trid = ( $max_trid ? (int) $max_trid : 0 ) + 1;
        }

        // Check if this element already has a registration.
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table} WHERE element_id = %d AND element_type = %s AND language_code = %s",
                $element_id,
                $element_type,
                $language_code
            )
        );

        if ( $existing ) {
            $wpdb->update(
                $table,
                array(
                    'trid'                 => $trid,
                    'source_language_code' => $source_language_code,
                ),
                array( 'id' => $existing ),
                array( '%d', '%s' ),
                array( '%d' )
            );
        } else {
            $wpdb->insert(
                $table,
                array(
                    'element_id'           => $element_id,
                    'element_type'         => $element_type,
                    'language_code'        => $language_code,
                    'source_language_code' => $source_language_code,
                    'trid'                 => $trid,
                ),
                array( '%d', '%s', '%s', '%s', '%d' )
            );
        }

        // Invalidate caches.
        $this->cache->delete( "trid_{$element_type}_{$element_id}" );
        $this->cache->delete( "all_translations_{$element_type}_{$trid}" );

        return $trid;
    }

    /**
     * Create a translation of a post.
     *
     * @param int    $source_post_id Source post ID.
     * @param string $target_lang    Target language code.
     * @param array  $options        Translation options.
     * @return int|WP_Error Translated post ID or error.
     */
    public function translate_post( int $source_post_id, string $target_lang, array $options = array() ) {
        $source_post = get_post( $source_post_id );
        if ( ! $source_post ) {
            return new \WP_Error( 'invalid_post', __( 'Source post not found.', 'wptranslate' ) );
        }

        $source_lang = $this->get_post_language( $source_post_id );
        if ( ! $source_lang ) {
            $source_lang = $this->language_manager->get_default_language();
        }

        if ( $source_lang === $target_lang ) {
            return new \WP_Error( 'same_language', __( 'Source and target language are the same.', 'wptranslate' ) );
        }

        // Check if translation already exists.
        $existing = $this->get_translation_id( $source_post_id, $target_lang );
        if ( $existing && empty( $options['force'] ) ) {
            return $existing;
        }

        $provider = $options['provider'] ?? null;

        /**
         * Fires before a post is translated.
         *
         * @param int    $source_post_id Source post ID.
         * @param string $target_lang    Target language.
         * @param string $provider       Provider name.
         */
        do_action( 'wptranslate_before_translate', $source_post_id, $target_lang, $provider );

        // Translate content fields.
        $translated_title = $this->translate_text( $source_post->post_title, $source_lang, $target_lang, $provider );
        $translated_content = $this->translate_text( $source_post->post_content, $source_lang, $target_lang, $provider );
        $translated_excerpt = '';
        if ( ! empty( $source_post->post_excerpt ) ) {
            $translated_excerpt = $this->translate_text( $source_post->post_excerpt, $source_lang, $target_lang, $provider );
        }

        // Generate translated slug.
        $translated_slug = $this->translate_text( $source_post->post_name, $source_lang, $target_lang, $provider );
        $translated_slug = sanitize_title( $translated_slug );

        // Check for translation errors.
        if ( is_wp_error( $translated_title ) ) {
            return $translated_title;
        }
        if ( is_wp_error( $translated_content ) ) {
            return $translated_content;
        }

        // Ensure we have actual translated content.
        if ( empty( trim( $translated_title ) ) && empty( trim( $translated_content ) ) ) {
            return new \WP_Error(
                'translation_empty',
                __( 'Translation returned empty content. Please check that your translation provider API key is valid and the selected provider matches your configured key.', 'wptranslate' )
            );
        }

        // Guard against partial translation: if source had body content but
        // the translated content came back empty, treat as a failure rather
        // than creating a half-translated post with missing body.
        if ( ! empty( trim( $source_post->post_content ) ) && empty( trim( $translated_content ) ) ) {
            $this->log_warning( sprintf(
                'Content translation returned empty for post %d ("%s") which has %d chars of source content. Aborting to prevent half-translated post.',
                $source_post_id,
                $source_post->post_title,
                mb_strlen( $source_post->post_content )
            ) );
            return new \WP_Error(
                'content_translation_failed',
                __( 'The post title was translated but the body content translation failed. This can happen with very large posts or complex block content. Please try again or use a different translation provider.', 'wptranslate' )
            );
        }

        // Create or update translated post.
        $post_data = array(
            'post_title'   => $translated_title,
            'post_content' => $translated_content,
            'post_excerpt' => $translated_excerpt,
            'post_name'    => $translated_slug,
            'post_type'    => $source_post->post_type,
            'post_status'  => 'draft',
            'post_author'  => $source_post->post_author,
            'post_parent'  => $source_post->post_parent,
            'menu_order'   => $source_post->menu_order,
        );

        if ( $existing ) {
            $post_data['ID'] = $existing;
            $translated_post_id = wp_update_post( $post_data, true );
        } else {
            $translated_post_id = wp_insert_post( $post_data, true );
        }

        if ( is_wp_error( $translated_post_id ) ) {
            return $translated_post_id;
        }

        // Register in translation group.
        $trid = $this->get_trid( $source_post_id );
        if ( ! $trid ) {
            // Register source post first.
            $trid = $this->register_translation( $source_post_id, $source_lang, 'post', 0, '' );
        }
        $this->register_translation( $translated_post_id, $target_lang, 'post', $trid, $source_lang );

        // Set translation status.
        $this->set_translation_status( $translated_post_id, 'ai_draft', array(
            'md5_hash' => md5( $source_post->post_content ),
        ) );

        // Copy relevant post meta.
        $this->copy_post_meta( $source_post_id, $translated_post_id, $source_lang, $target_lang, $provider );

        // Copy taxonomy terms (translate if possible).
        $this->copy_taxonomy_terms( $source_post_id, $translated_post_id, $target_lang );

        // Store the AI output for diff tracking.
        update_post_meta( $translated_post_id, '_wptranslate_ai_output', $translated_content );
        update_post_meta( $translated_post_id, '_wptranslate_source_post', $source_post_id );
        update_post_meta( $translated_post_id, '_wptranslate_source_hash', md5( $source_post->post_content ) );

        /**
         * Fires after a post is translated.
         *
         * @param int    $source_post_id     Source post ID.
         * @param string $target_lang        Target language.
         * @param int    $translated_post_id Translated post ID.
         * @param string $provider           Provider name.
         */
        do_action( 'wptranslate_after_translate', $source_post_id, $target_lang, $translated_post_id, $provider );

        return $translated_post_id;
    }

    /**
     * Translate a text string using the configured provider.
     *
     * For large content (e.g. Gutenberg block markup), attempts a single API call first.
     * If that returns empty, falls back to chunked translation — splitting by block
     * boundaries and translating each chunk separately.
     *
     * @param string      $text        Text to translate.
     * @param string      $source_lang Source language.
     * @param string      $target_lang Target language.
     * @param string|null $provider    Provider name override.
     * @return string|WP_Error Translated text or error.
     */
    public function translate_text( string $text, string $source_lang, string $target_lang, ?string $provider = null ) {
        if ( empty( trim( $text ) ) ) {
            return $text;
        }

        // Check cache first.
        $source_hash = hash( 'sha256', $text );
        $cached = $this->cache->get_translation_cache( $source_hash, $source_lang, $target_lang );
        if ( $cached ) {
            return $cached;
        }

        // Check translation memory for exact match.
        $memory_match = $this->check_translation_memory( $text, $source_lang, $target_lang );
        if ( $memory_match ) {
            return $memory_match;
        }

        // Call provider.
        try {
            $result = $this->provider_manager->translate( $text, $source_lang, $target_lang, array(
                'provider' => $provider,
            ) );

            if ( is_wp_error( $result ) ) {
                return $result;
            }

            $translated = $result->translated_text;

            // If the provider returned empty but source had content, try chunked translation
            // as a fallback. Large Gutenberg content can exceed provider limits or timeout.
            if ( empty( trim( $translated ) ) && ! empty( trim( $text ) ) ) {
                $this->log_warning( sprintf(
                    'Translation returned empty for non-empty source (%d chars). Attempting chunked translation.',
                    mb_strlen( $text )
                ) );

                $chunked_result = $this->translate_text_chunked( $text, $source_lang, $target_lang, $provider );

                if ( is_wp_error( $chunked_result ) ) {
                    return $chunked_result;
                }

                if ( ! empty( trim( $chunked_result ) ) ) {
                    $translated = $chunked_result;
                } else {
                    // Both single-call and chunked translation failed.
                    $this->log_warning( sprintf(
                        'Chunked translation also returned empty for source (%d chars). Returning error.',
                        mb_strlen( $text )
                    ) );
                    return new \WP_Error(
                        'translation_empty',
                        __( 'Translation provider returned empty content. The source text may be too large or contain markup the provider cannot process. Check your provider API key and try again.', 'wptranslate' )
                    );
                }
            }

            // Cache the result.
            $provider_name = $result->provider ?? $provider ?? '';
            $this->cache->set_translation_cache(
                $source_hash,
                $source_lang,
                $target_lang,
                $provider_name,
                $text,
                $translated
            );

            return $translated;

        } catch ( \Exception $e ) {
            do_action( 'wptranslate_provider_error', $provider ?? 'unknown', $e->getMessage(), array(
                'source_lang' => $source_lang,
                'target_lang' => $target_lang,
                'text_length' => strlen( $text ),
            ) );

            return new \WP_Error( 'translation_error', $e->getMessage() );
        }
    }

    /**
     * Translate text by splitting it into chunks and translating each separately.
     *
     * Uses AbstractProvider::chunk_content() logic to split by Gutenberg block
     * boundaries, then translates each chunk individually and reassembles.
     *
     * @param string      $text        Full text to translate.
     * @param string      $source_lang Source language code.
     * @param string      $target_lang Target language code.
     * @param string|null $provider    Provider name override.
     * @return string|WP_Error Reassembled translated text or error.
     */
    private function translate_text_chunked( string $text, string $source_lang, string $target_lang, ?string $provider = null ) {
        // Determine a reasonable chunk size. Most providers handle ~5000 chars well.
        $max_chunk_size = (int) apply_filters( 'wptranslate_max_chunk_size', 5000 );
        $chunks = $this->chunk_content_for_translation( $text, $max_chunk_size );

        // If chunking produced only one chunk (same as original), no point retrying.
        if ( count( $chunks ) <= 1 ) {
            return '';
        }

        $this->log_warning( sprintf(
            'Splitting content into %d chunks (max %d chars each) for translation.',
            count( $chunks ),
            $max_chunk_size
        ) );

        $translated_chunks = array();

        foreach ( $chunks as $index => $chunk ) {
            // Skip empty chunks (whitespace-only separators).
            if ( empty( trim( $chunk ) ) ) {
                $translated_chunks[] = $chunk;
                continue;
            }

            // Check if chunk is only block comments / non-translatable markup.
            if ( $this->is_non_translatable_block_markup( $chunk ) ) {
                $translated_chunks[] = $chunk;
                continue;
            }

            $result = $this->provider_manager->translate( $chunk, $source_lang, $target_lang, array(
                'provider' => $provider,
            ) );

            if ( is_wp_error( $result ) ) {
                return $result;
            }

            $chunk_translated = $result->translated_text;

            if ( empty( trim( $chunk_translated ) ) && ! empty( trim( $chunk ) ) ) {
                $this->log_warning( sprintf(
                    'Chunk %d/%d returned empty (%d chars source). Using original chunk.',
                    $index + 1,
                    count( $chunks ),
                    mb_strlen( $chunk )
                ) );
                // Use the original chunk rather than losing content entirely.
                $translated_chunks[] = $chunk;
            } else {
                $translated_chunks[] = $chunk_translated;
            }
        }

        return implode( '', $translated_chunks );
    }

    /**
     * Split content into chunks respecting Gutenberg block boundaries.
     *
     * Mirrors the logic in AbstractProvider::chunk_content() but is accessible
     * from the TranslationManager context.
     *
     * @param string $content  The content to chunk.
     * @param int    $max_size Maximum characters per chunk.
     * @return array Array of content chunks.
     */
    private function chunk_content_for_translation( string $content, int $max_size ): array {
        if ( mb_strlen( $content ) <= $max_size ) {
            return array( $content );
        }

        // Split by Gutenberg block comments, preserving delimiters.
        $blocks = preg_split( '/(<!-- \/?wp:[a-z][a-z0-9\/-]* (?:\{[^}]*\} )?\/?>)/', $content, -1, PREG_SPLIT_DELIM_CAPTURE );

        if ( false === $blocks ) {
            $blocks = array( $content );
        }

        $chunks        = array();
        $current_chunk = '';

        foreach ( $blocks as $block ) {
            // If appending this block would exceed the limit, finalize the current chunk.
            if ( mb_strlen( $current_chunk ) + mb_strlen( $block ) > $max_size && '' !== $current_chunk ) {
                $chunks[]      = $current_chunk;
                $current_chunk = '';
            }

            // If a single block exceeds the limit, split it by paragraphs.
            if ( mb_strlen( $block ) > $max_size ) {
                $paragraphs = preg_split( '/(\n\n+)/', $block, -1, PREG_SPLIT_DELIM_CAPTURE );

                if ( false === $paragraphs ) {
                    $paragraphs = array( $block );
                }

                foreach ( $paragraphs as $para ) {
                    if ( mb_strlen( $current_chunk ) + mb_strlen( $para ) > $max_size && '' !== $current_chunk ) {
                        $chunks[]      = $current_chunk;
                        $current_chunk = '';
                    }
                    $current_chunk .= $para;
                }
            } else {
                $current_chunk .= $block;
            }
        }

        if ( '' !== $current_chunk ) {
            $chunks[] = $current_chunk;
        }

        return $chunks;
    }

    /**
     * Check if a chunk contains only non-translatable block markup.
     *
     * Gutenberg block comments like <!-- wp:image {"id":123} --> and
     * self-closing blocks contain no translatable text.
     *
     * @param string $chunk The chunk to check.
     * @return bool True if the chunk has no translatable text content.
     */
    private function is_non_translatable_block_markup( string $chunk ): bool {
        // Strip block comments.
        $stripped = preg_replace( '/<!-- \/?wp:[a-z][a-z0-9\/-]* (?:\{[^}]*\} )?\/?>/', '', $chunk );
        // Strip HTML tags.
        $stripped = wp_strip_all_tags( $stripped );
        // Strip whitespace.
        $stripped = trim( $stripped );

        return empty( $stripped );
    }

    /**
     * Log a warning message.
     *
     * @param string $message Warning message.
     */
    private function log_warning( string $message ): void {
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( '[WPTranslate][TranslationManager] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
        }
    }

    /**
     * Get the language code for a post.
     */
    public function get_post_language( int $post_id ): ?string {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $lang = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT language_code FROM {$table} WHERE element_id = %d AND element_type = 'post'",
                $post_id
            )
        );

        return $lang ?: null;
    }

    /**
     * Set the translation status for a post.
     */
    public function set_translation_status( int $post_id, string $status, array $extra = array() ): void {
        global $wpdb;
        $translations_table = $wpdb->prefix . 'wpt_translations';
        $status_table = $wpdb->prefix . 'wpt_translation_status';

        // Get translation record ID.
        $translation_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$translations_table} WHERE element_id = %d AND element_type = 'post'",
                $post_id
            )
        );

        if ( ! $translation_id ) {
            return;
        }

        $old_status = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT status FROM {$status_table} WHERE translation_id = %d",
                $translation_id
            )
        );

        $data = array(
            'translation_id' => $translation_id,
            'status'         => $status,
            'date_modified'  => current_time( 'mysql' ),
        );

        if ( isset( $extra['md5_hash'] ) ) {
            $data['md5_hash'] = $extra['md5_hash'];
        }
        if ( isset( $extra['assigned_to'] ) ) {
            $data['assigned_to'] = $extra['assigned_to'];
            $data['assigned_at'] = current_time( 'mysql' );
        }
        if ( isset( $extra['reviewed_by'] ) ) {
            $data['reviewed_by'] = $extra['reviewed_by'];
            $data['reviewed_at'] = current_time( 'mysql' );
        }
        if ( isset( $extra['revision_feedback'] ) ) {
            $data['revision_feedback'] = $extra['revision_feedback'];
        }
        if ( isset( $extra['translator'] ) ) {
            $data['translator'] = $extra['translator'];
        }

        // Upsert.
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$status_table} WHERE translation_id = %d",
                $translation_id
            )
        );

        if ( $existing ) {
            unset( $data['translation_id'] );
            $wpdb->update( $status_table, $data, array( 'translation_id' => $translation_id ) );
        } else {
            $wpdb->insert( $status_table, $data );
        }

        /**
         * Fires when a translation status changes.
         */
        if ( $old_status !== $status ) {
            do_action( 'wptranslate_translation_status_changed', $translation_id, $status, $old_status );
        }
    }

    /**
     * Get translation status for a post.
     */
    public function get_translation_status( int $post_id ): ?array {
        global $wpdb;
        $translations_table = $wpdb->prefix . 'wpt_translations';
        $status_table = $wpdb->prefix . 'wpt_translation_status';

        $result = $wpdb->get_row(
            $wpdb->prepare(
                "SELECT s.* FROM {$status_table} s
                 INNER JOIN {$translations_table} t ON s.translation_id = t.id
                 WHERE t.element_id = %d AND t.element_type = 'post'",
                $post_id
            ),
            ARRAY_A
        );

        return $result ?: null;
    }

    /**
     * Filter posts by language in WP_Query.
     *
     * @param \WP_Query $query The query object.
     */
    public function filter_posts_by_language( $query ): void {
        // Don't filter in admin unless explicitly requested.
        if ( is_admin() && ! ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {
            // Filter admin post lists if on edit.php.
            global $pagenow;
            if ( 'edit.php' !== $pagenow ) {
                return;
            }
        }

        // Don't filter if explicitly bypassed.
        if ( $query->get( 'wptranslate_bypass' ) ) {
            return;
        }

        // Only filter main queries and standard post queries.
        if ( ! $query->is_main_query() && ! $query->get( 'wptranslate_filter' ) ) {
            return;
        }

        $current_lang = $this->language_manager->get_current_language();
        if ( empty( $current_lang ) ) {
            return;
        }

        // Get post IDs in the current language.
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        // Use a subquery approach for efficient filtering.
        $post_type = $query->get( 'post_type' ) ?: 'post';
        if ( is_array( $post_type ) ) {
            $post_type = implode( "','", array_map( 'esc_sql', $post_type ) );
        } else {
            $post_type = esc_sql( $post_type );
        }

        // Add a filter to include posts in the current language + posts not in any translation group.
        add_filter( 'posts_where', function( $where ) use ( $wpdb, $table, $current_lang ) {
            $where .= $wpdb->prepare(
                " AND ({$wpdb->posts}.ID IN (
                    SELECT element_id FROM {$table}
                    WHERE language_code = %s AND element_type = 'post'
                ) OR {$wpdb->posts}.ID NOT IN (
                    SELECT element_id FROM {$table}
                    WHERE element_type = 'post'
                ))",
                $current_lang
            );
            return $where;
        } );
    }

    /**
     * When a source post is updated, mark translations as needing update.
     */
    public function on_source_post_updated( int $post_id, \WP_Post $post_after, \WP_Post $post_before ): void {
        // Only care about content changes.
        if ( $post_after->post_content === $post_before->post_content
            && $post_after->post_title === $post_before->post_title ) {
            return;
        }

        // Check if this post has translations.
        $translations = $this->get_all_translations( $post_id );
        if ( empty( $translations ) ) {
            return;
        }

        $current_lang = $this->get_post_language( $post_id );
        $new_hash = md5( $post_after->post_content );

        foreach ( $translations as $lang => $translated_id ) {
            if ( $lang === $current_lang ) {
                continue;
            }

            $status = $this->get_translation_status( $translated_id );
            if ( ! $status || 'needs_update' === $status['status'] ) {
                continue;
            }

            // Check if hash changed.
            if ( $status['md5_hash'] !== $new_hash ) {
                $this->set_translation_status( $translated_id, 'needs_update', array(
                    'md5_hash' => $status['md5_hash'], // Keep old hash for diff.
                ) );

                // Store the previous source content for diff display.
                update_post_meta( $translated_id, '_wptranslate_prev_source_content', $post_before->post_content );
                update_post_meta( $translated_id, '_wptranslate_prev_source_title', $post_before->post_title );
            }
        }
    }

    /**
     * Check translation memory for exact match.
     *
     * @param string $text        Source text.
     * @param string $source_lang Source language.
     * @param string $target_lang Target language.
     * @return string|null Translated text or null.
     */
    private function check_translation_memory( string $text, string $source_lang, string $target_lang ): ?string {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_cache';

        $hash = hash( 'sha256', $text );

        $result = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT translated_text FROM {$table}
                 WHERE source_hash = %s
                 AND source_lang = %s
                 AND target_lang = %s
                 AND source_type = 'human'
                 ORDER BY created_at DESC LIMIT 1",
                $hash,
                $source_lang,
                $target_lang
            )
        );

        return $result ?: null;
    }

    /**
     * Copy relevant post meta from source to translated post.
     */
    private function copy_post_meta( int $source_id, int $target_id, string $source_lang, string $target_lang, ?string $provider ): void {
        $translatable_keys = get_option( 'wptranslate_translatable_meta_keys', array() );

        /**
         * Filter which meta keys should be translated.
         */
        $translatable_keys = apply_filters( 'wptranslate_translatable_meta_keys', $translatable_keys, get_post_type( $source_id ) );

        // Copy-as-is meta keys (non-translatable).
        $copy_keys = array( '_thumbnail_id', '_wp_page_template' );

        foreach ( $copy_keys as $key ) {
            $value = get_post_meta( $source_id, $key, true );
            if ( '' !== $value ) {
                update_post_meta( $target_id, $key, $value );
            }
        }

        // Translate specific meta keys.
        foreach ( $translatable_keys as $key ) {
            $value = get_post_meta( $source_id, $key, true );
            if ( ! empty( $value ) && is_string( $value ) ) {
                $translated = $this->translate_text( $value, $source_lang, $target_lang, $provider );
                if ( ! is_wp_error( $translated ) ) {
                    update_post_meta( $target_id, $key, $translated );
                }
            }
        }

        // Handle SEO meta (Yoast, RankMath, AIOSEO).
        $seo_keys = array(
            '_yoast_wpseo_title',
            '_yoast_wpseo_metadesc',
            '_yoast_wpseo_focuskw',
            'rank_math_title',
            'rank_math_description',
            'rank_math_focus_keyword',
            '_aioseo_title',
            '_aioseo_description',
        );

        foreach ( $seo_keys as $key ) {
            $value = get_post_meta( $source_id, $key, true );
            if ( ! empty( $value ) ) {
                $translated = $this->translate_text( $value, $source_lang, $target_lang, $provider );
                if ( ! is_wp_error( $translated ) ) {
                    update_post_meta( $target_id, $key, $translated );
                }
            }
        }
    }

    /**
     * Copy taxonomy terms to translated post.
     */
    private function copy_taxonomy_terms( int $source_id, int $target_id, string $target_lang ): void {
        $taxonomies = get_object_taxonomies( get_post_type( $source_id ) );
        $enabled_taxonomies = get_option( 'wptranslate_taxonomies', array( 'category', 'post_tag' ) );

        foreach ( $taxonomies as $taxonomy ) {
            if ( ! in_array( $taxonomy, $enabled_taxonomies, true ) ) {
                continue;
            }

            $terms = wp_get_object_terms( $source_id, $taxonomy, array( 'fields' => 'ids' ) );
            if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
                // Look for translated terms.
                $translated_terms = array();
                foreach ( $terms as $term_id ) {
                    $translated_term = $this->get_translation_id( $term_id, $target_lang, 'taxonomy' );
                    $translated_terms[] = $translated_term ?: $term_id;
                }
                wp_set_object_terms( $target_id, $translated_terms, $taxonomy );
            }
        }
    }

    /**
     * Queue a batch translation job.
     *
     * @param array $params Job parameters.
     * @return string Batch ID.
     */
    public function queue_translation_job( array $params ): string {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        $batch_id = wp_generate_uuid4();

        $wpdb->insert(
            $table,
            array(
                'batch_id'     => $batch_id,
                'element_id'   => $params['element_id'] ?? 0,
                'element_type' => $params['element_type'] ?? 'post',
                'source_lang'  => $params['source_lang'],
                'target_lang'  => $params['target_lang'],
                'provider'     => $params['provider'] ?? '',
                'status'       => 'pending',
                'priority'     => $params['priority'] ?? 10,
                'created_at'   => current_time( 'mysql' ),
            ),
            array( '%s', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
        );

        return $batch_id;
    }

    /**
     * Process the translation queue (called via WP-Cron).
     */
    public function process_queue(): void {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_jobs';

        // Get next batch of pending jobs.
        $jobs = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE status = %s ORDER BY priority ASC, created_at ASC LIMIT 5",
                'pending'
            ),
            ARRAY_A
        );

        if ( empty( $jobs ) ) {
            return;
        }

        foreach ( $jobs as $job ) {
            // Mark as in-progress.
            $wpdb->update(
                $table,
                array(
                    'status'     => 'in_progress',
                    'started_at' => current_time( 'mysql' ),
                ),
                array( 'id' => $job['id'] )
            );

            // Execute translation.
            $result = $this->translate_post(
                (int) $job['element_id'],
                $job['target_lang'],
                array(
                    'provider' => $job['provider'] ?: null,
                    'force'    => true,
                )
            );

            if ( is_wp_error( $result ) ) {
                $wpdb->update(
                    $table,
                    array(
                        'status'        => 'failed',
                        'completed_at'  => current_time( 'mysql' ),
                        'error_message' => $result->get_error_message(),
                    ),
                    array( 'id' => $job['id'] )
                );
            } else {
                $wpdb->update(
                    $table,
                    array(
                        'status'       => 'completed',
                        'completed_at' => current_time( 'mysql' ),
                    ),
                    array( 'id' => $job['id'] )
                );
            }
        }

        // Check if batch is complete.
        $first_job = $jobs[0];
        if ( ! empty( $first_job['batch_id'] ) ) {
            $remaining = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT COUNT(*) FROM {$table} WHERE batch_id = %s AND status IN ('pending', 'in_progress')",
                    $first_job['batch_id']
                )
            );

            if ( 0 === (int) $remaining ) {
                $results = $wpdb->get_results(
                    $wpdb->prepare(
                        "SELECT * FROM {$table} WHERE batch_id = %s",
                        $first_job['batch_id']
                    ),
                    ARRAY_A
                );
                do_action( 'wptranslate_bulk_translate_complete', $first_job['batch_id'], $results );
            }
        }
    }

    /**
     * Analyze translation corrections (called via daily WP-Cron).
     */
    public function analyze_corrections(): void {
        global $wpdb;
        $corrections_table = $wpdb->prefix . 'wpt_translation_corrections';
        $glossary_table = $wpdb->prefix . 'wpt_translation_glossary';

        $threshold = (int) get_option( 'wptranslate_correction_threshold', 3 );

        // Find recurring terminology corrections.
        $recurring = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT source_text, corrected_text, source_lang, target_lang,
                        COUNT(*) as correction_count
                 FROM {$corrections_table}
                 WHERE correction_type = 'terminology'
                 AND promoted_to_glossary = 0
                 AND created_at > DATE_SUB(NOW(), INTERVAL 12 MONTH)
                 GROUP BY source_text, corrected_text, source_lang, target_lang
                 HAVING correction_count >= %d",
                $threshold
            ),
            ARRAY_A
        );

        foreach ( $recurring as $correction ) {
            // Check if glossary entry already exists.
            $exists = $wpdb->get_var(
                $wpdb->prepare(
                    "SELECT id FROM {$glossary_table}
                     WHERE term = %s AND source_lang = %s AND target_lang = %s",
                    $correction['source_text'],
                    $correction['source_lang'],
                    $correction['target_lang']
                )
            );

            if ( ! $exists ) {
                // Create auto-generated glossary suggestion.
                $wpdb->insert(
                    $glossary_table,
                    array(
                        'term'           => $correction['source_text'],
                        'translation'    => $correction['corrected_text'],
                        'source_lang'    => $correction['source_lang'],
                        'target_lang'    => $correction['target_lang'],
                        'auto_generated' => 1,
                        'confirmed'      => 0,
                        'created_at'     => current_time( 'mysql' ),
                    ),
                    array( '%s', '%s', '%s', '%s', '%d', '%d', '%s' )
                );

                $glossary_id = $wpdb->insert_id;

                do_action(
                    'wptranslate_glossary_suggestion_created',
                    $glossary_id,
                    $correction['source_text'],
                    $correction['corrected_text'],
                    $correction['source_lang'],
                    $correction['target_lang']
                );
            }
        }
    }

    /**
     * Record a translator correction.
     */
    public function record_correction( array $data ): int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translation_corrections';

        $wpdb->insert(
            $table,
            array(
                'translation_id'    => $data['translation_id'] ?? 0,
                'source_text'       => $data['source_text'],
                'ai_output'         => $data['ai_output'],
                'corrected_text'    => $data['corrected_text'],
                'source_lang'       => $data['source_lang'],
                'target_lang'       => $data['target_lang'],
                'provider'          => $data['provider'] ?? '',
                'correction_type'   => $data['correction_type'] ?? 'terminology',
                'translator_user_id' => $data['translator_user_id'] ?? get_current_user_id(),
                'created_at'        => current_time( 'mysql' ),
            ),
            array( '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s' )
        );

        $correction_id = $wpdb->insert_id;

        do_action(
            'wptranslate_correction_recorded',
            $correction_id,
            $data['translation_id'] ?? 0,
            $data['correction_type'] ?? 'terminology',
            $data['source_lang'],
            $data['target_lang']
        );

        return $correction_id;
    }
}
