<?php
namespace WPTranslate\FrontEnd;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

use WPTranslate\Plugin;
use WPTranslate\LanguageManager;
use WPTranslate\URLManager;

/**
 * Front-end controller. Handles content filtering, hreflang output, and
 * front-end asset enqueuing for the public-facing side of the plugin.
 */
class FrontController {

    /** @var Plugin */
    private $plugin;

    /** @var LanguageManager */
    private $language_manager;

    /** @var URLManager */
    private $url_manager;

    /**
     * @param Plugin $plugin Main plugin instance.
     */
    public function __construct( Plugin $plugin ) {
        $this->plugin           = $plugin;
        $this->language_manager = $plugin->get_language_manager();
        $this->url_manager      = $plugin->get_url_manager();

        // Front-end hooks.
        if ( ! is_admin() ) {
            add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_styles' ) );
            add_filter( 'wp_nav_menu_objects', array( $this, 'filter_nav_menu_items' ), 10, 2 );
            add_filter( 'post_link', array( $this->url_manager, 'filter_permalink' ), 10, 2 );
            add_filter( 'page_link', array( $this->url_manager, 'filter_permalink' ), 10, 2 );
        }
    }

    // -------------------------------------------------------------------------
    // Content Filters
    // -------------------------------------------------------------------------

    /**
     * Filter the post content.
     *
     * In the separate-post translation model each translation is its own WP_Post,
     * so this is largely a pass-through. The only work done here is to supply
     * fallback content from the default-language source post when the current
     * translation is empty or still in draft.
     *
     * @param string $content The post content.
     * @return string Filtered content.
     */
    public function filter_content( string $content ): string {
        if ( is_admin() || ! in_the_loop() || ! is_main_query() ) {
            return $content;
        }

        $post = get_post();
        if ( ! $post ) {
            return $content;
        }

        // If content is already populated, return it as-is.
        if ( '' !== trim( $content ) ) {
            return $content;
        }

        // Content is empty -- try to fall back to the default-language version.
        $fallback_content = $this->get_fallback_content( $post->ID, 'post_content' );

        return ( '' !== $fallback_content ) ? $fallback_content : $content;
    }

    /**
     * Filter the post title.
     *
     * Same pass-through approach as filter_content, with fallback to the
     * default-language title if the current one is empty.
     *
     * @param string $title   The post title.
     * @param int    $post_id The post ID.
     * @return string Filtered title.
     */
    public function filter_title( string $title, $post_id = 0 ): string {
        if ( is_admin() ) {
            return $title;
        }

        if ( '' !== trim( $title ) ) {
            return $title;
        }

        $post_id = (int) $post_id;
        if ( 0 === $post_id ) {
            return $title;
        }

        $fallback_title = $this->get_fallback_content( $post_id, 'post_title' );

        return ( '' !== $fallback_title ) ? $fallback_title : $title;
    }

    /**
     * Retrieve fallback content from the default-language source post.
     *
     * @param int    $post_id The current (translated) post ID.
     * @param string $field   The post field to retrieve ('post_content' or 'post_title').
     * @return string The fallback content, or empty string if none found.
     */
    private function get_fallback_content( int $post_id, string $field ): string {
        $default_lang = $this->language_manager->get_default_language();
        $source_id    = $this->get_source_post_id( $post_id, $default_lang );

        if ( ! $source_id || $source_id === $post_id ) {
            return '';
        }

        $source_post = get_post( $source_id );
        if ( ! $source_post ) {
            return '';
        }

        return $source_post->$field ?? '';
    }

    /**
     * Look up the source (default-language) post ID via the translations table.
     *
     * @param int    $post_id Current post ID.
     * @param string $lang    Target language code (typically the default language).
     * @return int|null Source post ID or null.
     */
    private function get_source_post_id( int $post_id, string $lang ): ?int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $trid = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT trid FROM {$table} WHERE element_id = %d AND element_type = 'post' LIMIT 1",
                $post_id
            )
        );

        if ( ! $trid ) {
            return null;
        }

        $source_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT element_id FROM {$table} WHERE trid = %d AND language_code = %s AND element_type = 'post' LIMIT 1",
                $trid,
                $lang
            )
        );

        return $source_id ? (int) $source_id : null;
    }

    // -------------------------------------------------------------------------
    // Hreflang Tags
    // -------------------------------------------------------------------------

    /**
     * Output <link rel="alternate" hreflang="..."> tags in the <head>.
     *
     * Called on the 'wp_head' action. Generates hreflang tags for every active
     * language that has a translation of the current post, plus an x-default
     * entry pointing to the default-language version.
     */
    public function output_hreflang_tags(): void {
        if ( is_admin() ) {
            return;
        }

        $languages    = $this->language_manager->get_active_languages();
        $default_lang = $this->language_manager->get_default_language();

        if ( empty( $languages ) ) {
            return;
        }

        $tags            = array();
        $default_url     = '';
        $is_singular     = is_singular();
        $current_post_id = $is_singular ? get_queried_object_id() : 0;

        foreach ( $languages as $lang ) {
            $code = $lang['code'] ?? '';
            if ( empty( $code ) ) {
                continue;
            }

            // For singular content, only emit hreflang if a translation actually exists.
            if ( $is_singular && $current_post_id ) {
                $translated_id = $this->get_translated_post_id_for_language( $current_post_id, $code );
                if ( ! $translated_id ) {
                    continue;
                }
                $url = get_permalink( $translated_id );
            } else {
                // Archives, home, etc. -- just convert the current URL.
                $url = $this->url_manager->get_current_url_in_language( $code );
            }

            if ( empty( $url ) ) {
                continue;
            }

            // Determine the hreflang value. Use locale-style code (e.g., pt-BR) when available.
            $hreflang = $this->code_to_hreflang( $code, $lang );

            $tags[] = sprintf(
                '<link rel="alternate" hreflang="%s" href="%s" />',
                esc_attr( $hreflang ),
                esc_url( $url )
            );

            // Track the default-language URL for x-default.
            if ( $code === $default_lang ) {
                $default_url = $url;
            }
        }

        // x-default tag.
        if ( ! empty( $default_url ) ) {
            $tags[] = sprintf(
                '<link rel="alternate" hreflang="x-default" href="%s" />',
                esc_url( $default_url )
            );
        }

        if ( ! empty( $tags ) ) {
            echo "\n" . implode( "\n", $tags ) . "\n"; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- already escaped above.
        }
    }

    /**
     * Convert a plugin language code to an hreflang value.
     *
     * Hreflang uses ISO 639-1 (and optionally ISO 3166-1 alpha-2 region),
     * separated by a hyphen.
     *
     * @param string $code Plugin language code.
     * @param array  $lang Language data from the database.
     * @return string Hreflang value.
     */
    private function code_to_hreflang( string $code, array $lang ): string {
        // If the code already contains a region (e.g., pt-br), normalise it.
        if ( strpos( $code, '-' ) !== false ) {
            $parts = explode( '-', $code, 2 );
            return strtolower( $parts[0] ) . '-' . strtoupper( $parts[1] );
        }

        // Try to derive region from the locale (e.g., es_ES -> es-ES).
        $locale = $lang['locale'] ?? '';
        if ( ! empty( $locale ) && strpos( $locale, '_' ) !== false ) {
            $parts = explode( '_', $locale, 2 );
            $lang_part   = strtolower( $parts[0] );
            $region_part = strtoupper( $parts[1] );

            // Only add the region if it differs from the language code (avoids redundant en-EN).
            if ( strtolower( $region_part ) !== $lang_part ) {
                return $lang_part . '-' . $region_part;
            }
        }

        return strtolower( $code );
    }

    /**
     * Find a translated post ID for a given post and language.
     *
     * Uses the same translation-group lookup as the URL manager.
     *
     * @param int    $post_id Post ID.
     * @param string $lang    Target language code.
     * @return int|null Translated post ID or null.
     */
    private function get_translated_post_id_for_language( int $post_id, string $lang ): ?int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $trid = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT trid FROM {$table} WHERE element_id = %d AND element_type = 'post' LIMIT 1",
                $post_id
            )
        );

        if ( ! $trid ) {
            // Post has no translation group; it might be the default-language original.
            // If the requested lang is the default, return the post itself.
            if ( $this->language_manager->is_default_language( $lang ) ) {
                return $post_id;
            }
            return null;
        }

        $translated_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT element_id FROM {$table} WHERE trid = %d AND language_code = %s AND element_type = 'post' LIMIT 1",
                $trid,
                $lang
            )
        );

        return $translated_id ? (int) $translated_id : null;
    }

    // -------------------------------------------------------------------------
    // Asset Enqueuing
    // -------------------------------------------------------------------------

    /**
     * Enqueue minimal front-end styles for the language switcher.
     *
     * Called on the 'wp_enqueue_scripts' action.
     */
    public function enqueue_styles(): void {
        wp_enqueue_style(
            'wptranslate-front',
            WPTRANSLATE_PLUGIN_URL . 'assets/public/css/wptranslate.css',
            array(),
            WPTRANSLATE_VERSION
        );

        wp_enqueue_script(
            'wptranslate-front',
            WPTRANSLATE_PLUGIN_URL . 'assets/public/js/wptranslate.js',
            array(),
            WPTRANSLATE_VERSION,
            true
        );
    }

    // -------------------------------------------------------------------------
    // Navigation Menu Filtering
    // -------------------------------------------------------------------------

    /**
     * Filter navigation menu items to point to the correct language versions.
     *
     * For each menu item that links to a post or page, this replaces its URL
     * with the translated post's permalink (if a translation exists in the
     * current language).
     *
     * @param array $items Sorted array of menu item objects.
     * @param array $args  Menu arguments (unused).
     * @return array Modified menu items.
     */
    public function filter_nav_menu_items( $items, $args = array() ): array {
        if ( is_admin() ) {
            return $items;
        }

        $current_lang = $this->language_manager->get_current_language();
        $default_lang = $this->language_manager->get_default_language();

        // Nothing to do if we are viewing the default language.
        if ( $current_lang === $default_lang ) {
            return $items;
        }

        foreach ( $items as $item ) {
            // Only process items linked to posts/pages (type = 'post_type').
            if ( 'post_type' !== $item->type ) {
                continue;
            }

            $original_id   = (int) $item->object_id;
            $translated_id = $this->get_translated_post_id_for_language( $original_id, $current_lang );

            if ( $translated_id && $translated_id !== $original_id ) {
                $translated_permalink = get_permalink( $translated_id );
                if ( $translated_permalink ) {
                    $item->url = $translated_permalink;

                    // Optionally update the title to the translated post's title.
                    $translated_title = get_the_title( $translated_id );
                    if ( ! empty( $translated_title ) ) {
                        $item->title = $translated_title;
                    }
                }
            } else {
                // No translation found -- convert the URL with the URL manager
                // so it at least carries the language prefix.
                $item->url = $this->url_manager->get_translated_url( $item->url, $current_lang );
            }
        }

        return $items;
    }
}
