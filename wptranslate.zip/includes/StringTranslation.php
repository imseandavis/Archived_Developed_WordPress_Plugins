<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Handles gettext string translation — hooks into WordPress's gettext filters
 * to replace theme/plugin strings with translations from the database.
 */
class StringTranslation {

    /** @var LanguageManager */
    private $language_manager;

    /** @var cache\CacheManager */
    private $cache;

    /** @var array Runtime cache of loaded translations: [domain][string_name] => translated */
    private $loaded = array();

    /** @var array Domains that have been bulk-loaded. */
    private $loaded_domains = array();

    /** @var bool Whether to register new strings. */
    private $registering = false;

    public function __construct( LanguageManager $language_manager, cache\CacheManager $cache ) {
        $this->language_manager = $language_manager;
        $this->cache            = $cache;

        // Register strings as they appear during page loads (admin only, throttled).
        if ( is_admin() ) {
            $this->registering = true;
        }
    }

    /**
     * Filter gettext — main string replacement hook.
     *
     * @param string $translation Translated text (from .mo file).
     * @param string $text        Original text.
     * @param string $domain      Text domain.
     * @return string
     */
    public function filter_gettext( string $translation, string $text, string $domain ): string {
        return $this->get_translation( $text, $domain, '', $translation );
    }

    /**
     * Filter gettext_with_context.
     *
     * @param string $translation Translated text.
     * @param string $text        Original text.
     * @param string $context     Context.
     * @param string $domain      Text domain.
     * @return string
     */
    public function filter_gettext_with_context( string $translation, string $text, string $context, string $domain ): string {
        return $this->get_translation( $text, $domain, $context, $translation );
    }

    /**
     * Filter ngettext — plural forms.
     *
     * @param string $translation Translated text.
     * @param string $single      Singular form.
     * @param string $plural      Plural form.
     * @param int    $number      Number.
     * @param string $domain      Text domain.
     * @return string
     */
    public function filter_ngettext( string $translation, string $single, string $plural, int $number, string $domain ): string {
        $text = ( 1 === $number ) ? $single : $plural;
        return $this->get_translation( $text, $domain, '', $translation );
    }

    /**
     * Translate a string programmatically.
     *
     * @param string $string String to translate.
     * @param string $lang   Target language.
     * @param string $domain Text domain.
     * @return string
     */
    public function translate( string $string, string $lang, string $domain = 'default' ): string {
        $current = $this->language_manager->get_current_language();

        // Temporarily switch language context.
        $this->language_manager->set_current_language( $lang );
        $result = $this->get_translation( $string, $domain );
        $this->language_manager->set_current_language( $current );

        return $result ?: $string;
    }

    /**
     * Get translation for a string.
     *
     * @param string $text     Original text.
     * @param string $domain   Text domain.
     * @param string $context  Optional context.
     * @param string $fallback Fallback translation (from .mo file).
     * @return string
     */
    private function get_translation( string $text, string $domain, string $context = '', string $fallback = '' ): string {
        $current_lang = $this->language_manager->get_current_language();
        $default_lang = $this->language_manager->get_default_language();

        // Don't filter default language.
        if ( $current_lang === $default_lang ) {
            return $fallback ?: $text;
        }

        // Skip empty strings.
        if ( empty( trim( $text ) ) ) {
            return $fallback ?: $text;
        }

        // Skip very long strings (likely content, not UI strings).
        if ( strlen( $text ) > 1000 ) {
            return $fallback ?: $text;
        }

        // Ensure domain translations are loaded.
        $this->ensure_domain_loaded( $domain, $current_lang );

        // Build lookup key.
        $key = $this->build_key( $text, $domain, $context );

        if ( isset( $this->loaded[ $current_lang ][ $key ] ) ) {
            return $this->loaded[ $current_lang ][ $key ];
        }

        // Register the string for future translation if in admin.
        if ( $this->registering ) {
            $this->maybe_register_string( $text, $domain, $context );
        }

        return $fallback ?: $text;
    }

    /**
     * Ensure all translations for a domain+language are loaded into memory.
     */
    private function ensure_domain_loaded( string $domain, string $lang ): void {
        $load_key = "{$lang}_{$domain}";

        if ( isset( $this->loaded_domains[ $load_key ] ) ) {
            return;
        }

        // Try object cache first.
        $cache_key = "string_translations_{$lang}_{$domain}";
        $cached = $this->cache->get( $cache_key );

        if ( false !== $cached && is_array( $cached ) ) {
            if ( ! isset( $this->loaded[ $lang ] ) ) {
                $this->loaded[ $lang ] = array();
            }
            $this->loaded[ $lang ] = array_merge( $this->loaded[ $lang ], $cached );
            $this->loaded_domains[ $load_key ] = true;
            return;
        }

        // Load from database.
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_string_translations';

        $results = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT string_name, string_value, context FROM {$table}
                 WHERE language_code = %s AND domain = %s AND status = 'translated'",
                $lang,
                $domain
            ),
            ARRAY_A
        );

        $translations = array();
        if ( $results ) {
            foreach ( $results as $row ) {
                $key = $this->build_key( $row['string_name'], $domain, $row['context'] );
                $translations[ $key ] = $row['string_value'];
            }
        }

        if ( ! isset( $this->loaded[ $lang ] ) ) {
            $this->loaded[ $lang ] = array();
        }
        $this->loaded[ $lang ] = array_merge( $this->loaded[ $lang ], $translations );
        $this->loaded_domains[ $load_key ] = true;

        // Cache for future requests.
        $this->cache->set( $cache_key, $translations, HOUR_IN_SECONDS );
    }

    /**
     * Build a cache key for a string.
     */
    private function build_key( string $text, string $domain, string $context = '' ): string {
        return md5( "{$domain}|{$context}|{$text}" );
    }

    /**
     * Register a new string for translation (if not already registered).
     */
    private function maybe_register_string( string $text, string $domain, string $context = '' ): void {
        // Throttle: only register up to 50 new strings per request.
        static $registered_count = 0;
        if ( $registered_count >= 50 ) {
            return;
        }

        // Skip WordPress core domain (too many strings).
        if ( 'default' === $domain ) {
            return;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_string_translations';
        $default_lang = $this->language_manager->get_default_language();

        // Check if already registered.
        $exists = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE string_name = %s AND domain = %s AND context = %s AND language_code = %s
                 LIMIT 1",
                $text,
                $domain,
                $context,
                $default_lang
            )
        );

        if ( ! $exists ) {
            $wpdb->insert(
                $table,
                array(
                    'string_name'   => $text,
                    'string_value'  => $text,
                    'language_code' => $default_lang,
                    'context'       => $context,
                    'domain'        => $domain,
                    'status'        => 'needs_translation',
                    'date_modified' => current_time( 'mysql' ),
                ),
                array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
            );

            $registered_count++;

            do_action( 'wptranslate_string_registered', $text, $domain, $context );
        }
    }

    /**
     * Save a string translation.
     *
     * @param string $original  Original string.
     * @param string $translated Translated string.
     * @param string $lang      Language code.
     * @param string $domain    Text domain.
     * @param string $context   Context.
     * @return bool
     */
    public function save_translation( string $original, string $translated, string $lang, string $domain = 'default', string $context = '' ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_string_translations';

        // Check for existing.
        $existing = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT id FROM {$table}
                 WHERE string_name = %s AND language_code = %s AND domain = %s AND context = %s",
                $original,
                $lang,
                $domain,
                $context
            )
        );

        if ( $existing ) {
            $result = $wpdb->update(
                $table,
                array(
                    'string_value'  => $translated,
                    'status'        => 'translated',
                    'date_modified' => current_time( 'mysql' ),
                ),
                array( 'id' => $existing ),
                array( '%s', '%s', '%s' ),
                array( '%d' )
            );
        } else {
            $result = $wpdb->insert(
                $table,
                array(
                    'string_name'   => $original,
                    'string_value'  => $translated,
                    'language_code' => $lang,
                    'context'       => $context,
                    'domain'        => $domain,
                    'status'        => 'translated',
                    'date_modified' => current_time( 'mysql' ),
                ),
                array( '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
            );
        }

        // Invalidate cache.
        $cache_key = "string_translations_{$lang}_{$domain}";
        $this->cache->delete( $cache_key );

        // Clear runtime cache for this domain.
        $load_key = "{$lang}_{$domain}";
        unset( $this->loaded_domains[ $load_key ] );

        return false !== $result;
    }

    /**
     * Get all registered strings for a domain.
     *
     * @param string $domain   Text domain filter (empty = all).
     * @param string $lang     Language code.
     * @param string $status   Status filter (empty = all).
     * @param int    $per_page Results per page.
     * @param int    $page     Page number.
     * @return array
     */
    public function get_strings( string $domain = '', string $lang = '', string $status = '', int $per_page = 50, int $page = 1 ): array {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_string_translations';

        $where = array( '1=1' );
        $params = array();

        if ( ! empty( $domain ) ) {
            $where[] = 'domain = %s';
            $params[] = $domain;
        }
        if ( ! empty( $lang ) ) {
            $where[] = 'language_code = %s';
            $params[] = $lang;
        }
        if ( ! empty( $status ) ) {
            $where[] = 'status = %s';
            $params[] = $status;
        }

        $where_sql = implode( ' AND ', $where );
        $offset = ( $page - 1 ) * $per_page;

        $query = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY domain ASC, string_name ASC LIMIT %d OFFSET %d";
        $params[] = $per_page;
        $params[] = $offset;

        $results = $wpdb->get_results(
            $wpdb->prepare( $query, $params ),
            ARRAY_A
        );

        // Get total count.
        $count_query = "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}";
        $total = $wpdb->get_var(
            ! empty( array_slice( $params, 0, -2 ) )
                ? $wpdb->prepare( $count_query, array_slice( $params, 0, -2 ) )
                : $count_query
        );

        return array(
            'items' => $results ?: array(),
            'total' => (int) $total,
            'pages' => ceil( (int) $total / $per_page ),
        );
    }

    /**
     * Get all registered text domains.
     */
    public function get_domains(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_string_translations';

        $domains = $wpdb->get_col( "SELECT DISTINCT domain FROM {$table} ORDER BY domain ASC" );

        return $domains ?: array();
    }
}
