<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Detects conflicting translation plugins.
 */
class ConflictDetector {

    /**
     * Known conflicting plugins: slug => display name.
     */
    private const CONFLICTING_PLUGINS = array(
        'sitepress-multilingual-cms/sitepress.php'  => 'WPML',
        'translatepress-multilingual/index.php'      => 'TranslatePress',
        'polylang/polylang.php'                      => 'Polylang',
        'polylang-pro/polylang.php'                  => 'Polylang Pro',
        'weglot/weglot.php'                          => 'Weglot',
        'gtranslate/gtranslate.php'                  => 'GTranslate',
        'loco-translate/loco.php'                    => 'Loco Translate',
        'qtranslate-xt/qtranslate.php'               => 'qTranslate-XT',
        'multilingualpress/multilingualpress.php'    => 'MultilingualPress',
    );

    private const TRANSIENT_KEY = 'wptranslate_conflict_check';

    /** @var array */
    private $active_conflicts = array();

    public function __construct() {
        $this->active_conflicts = $this->detect_conflicts();

        // Invalidate cache when plugins are activated/deactivated.
        add_action( 'activated_plugin', array( $this, 'invalidate_cache' ) );
        add_action( 'deactivated_plugin', array( $this, 'invalidate_cache' ) );
    }

    /**
     * Check if any conflicting plugins are active.
     */
    public function has_conflicts(): bool {
        return ! empty( $this->active_conflicts );
    }

    /**
     * Get array of active conflicting plugins.
     *
     * @return array Plugin basename => display name.
     */
    public function get_active_conflicts(): array {
        return $this->active_conflicts;
    }

    /**
     * Detect active conflicting plugins (with caching).
     */
    private function detect_conflicts(): array {
        $cached = get_transient( self::TRANSIENT_KEY );
        if ( false !== $cached ) {
            return $cached;
        }

        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $conflicts = array();
        foreach ( self::CONFLICTING_PLUGINS as $plugin_file => $name ) {
            if ( is_plugin_active( $plugin_file ) ) {
                $conflicts[ $plugin_file ] = $name;
            }
        }

        set_transient( self::TRANSIENT_KEY, $conflicts, HOUR_IN_SECONDS );

        return $conflicts;
    }

    /**
     * Invalidate the conflict check cache.
     */
    public function invalidate_cache(): void {
        delete_transient( self::TRANSIENT_KEY );
    }

    /**
     * Register admin notice for conflicts.
     */
    public function register_admin_notice(): void {
        add_action( 'admin_notices', array( $this, 'display_conflict_notice' ) );
    }

    /**
     * Display the conflict notice.
     */
    public function display_conflict_notice(): void {
        if ( empty( $this->active_conflicts ) ) {
            return;
        }

        $names = implode( ', ', $this->active_conflicts );
        ?>
        <div class="notice notice-error">
            <p>
                <strong><?php esc_html_e( 'WPTranslate — Plugin Conflict Detected', 'wptranslate' ); ?></strong>
            </p>
            <p>
                <?php
                printf(
                    /* translators: %s: comma-separated list of conflicting plugin names */
                    esc_html__( 'WPTranslate cannot run while the following translation plugin(s) are active: %s. Please deactivate them to use WPTranslate.', 'wptranslate' ),
                    '<strong>' . esc_html( $names ) . '</strong>'
                );
                ?>
            </p>
            <p>
                <?php esc_html_e( 'Your existing translations are safe. After activating WPTranslate, you can migrate your translations using the import tool under WPTranslate → Tools.', 'wptranslate' ); ?>
            </p>
        </div>
        <?php
    }

    /**
     * Check for conflicts during plugin activation.
     * Called from Activator.
     *
     * @return array Active conflicts.
     */
    public static function check_on_activation(): array {
        if ( ! function_exists( 'is_plugin_active' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $conflicts = array();
        foreach ( self::CONFLICTING_PLUGINS as $plugin_file => $name ) {
            if ( is_plugin_active( $plugin_file ) ) {
                $conflicts[ $plugin_file ] = $name;
            }
        }

        return $conflicts;
    }

    /**
     * Get list of known conflicting plugins (for settings/diagnostics display).
     */
    public static function get_known_plugins(): array {
        return self::CONFLICTING_PLUGINS;
    }
}
