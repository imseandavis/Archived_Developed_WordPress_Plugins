<?php
namespace WPTranslate\Widgets;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Language Switcher Widget.
 */
class LanguageSwitcherWidget extends \WP_Widget {

    public function __construct() {
        parent::__construct(
            'wptranslate_language_switcher',
            __( 'WPTranslate Language Switcher', 'wptranslate' ),
            array(
                'description'                 => __( 'Display a language switcher for your multilingual site.', 'wptranslate' ),
                'customize_selective_refresh' => true,
            )
        );
    }

    /**
     * Front-end display.
     */
    public function widget( $args, $instance ): void {
        echo $args['before_widget'];

        if ( ! empty( $instance['title'] ) ) {
            echo $args['before_title'] . esc_html( $instance['title'] ) . $args['after_title'];
        }

        echo wptranslate_language_switcher( array(
            'style'        => $instance['style'] ?? 'dropdown',
            'show_flags'   => ! empty( $instance['show_flags'] ),
            'show_names'   => ! empty( $instance['show_names'] ),
            'show_native'  => ! empty( $instance['show_native'] ),
            'hide_current' => ! empty( $instance['hide_current'] ),
            'hide_missing' => ! empty( $instance['hide_missing'] ),
        ) );

        echo $args['after_widget'];
    }

    /**
     * Admin form.
     */
    public function form( $instance ): void {
        $title = $instance['title'] ?? __( 'Languages', 'wptranslate' );
        $style = $instance['style'] ?? 'dropdown';
        $show_flags = isset( $instance['show_flags'] ) ? (bool) $instance['show_flags'] : true;
        $show_names = isset( $instance['show_names'] ) ? (bool) $instance['show_names'] : true;
        $show_native = ! empty( $instance['show_native'] );
        $hide_current = ! empty( $instance['hide_current'] );
        $hide_missing = ! empty( $instance['hide_missing'] );
        ?>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>">
                <?php esc_html_e( 'Title:', 'wptranslate' ); ?>
            </label>
            <input class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'title' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'title' ) ); ?>"
                   type="text" value="<?php echo esc_attr( $title ); ?>">
        </p>
        <p>
            <label for="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>">
                <?php esc_html_e( 'Style:', 'wptranslate' ); ?>
            </label>
            <select class="widefat" id="<?php echo esc_attr( $this->get_field_id( 'style' ) ); ?>"
                    name="<?php echo esc_attr( $this->get_field_name( 'style' ) ); ?>">
                <option value="dropdown" <?php selected( $style, 'dropdown' ); ?>><?php esc_html_e( 'Dropdown', 'wptranslate' ); ?></option>
                <option value="list" <?php selected( $style, 'list' ); ?>><?php esc_html_e( 'Vertical List', 'wptranslate' ); ?></option>
                <option value="horizontal" <?php selected( $style, 'horizontal' ); ?>><?php esc_html_e( 'Horizontal List', 'wptranslate' ); ?></option>
                <option value="flags" <?php selected( $style, 'flags' ); ?>><?php esc_html_e( 'Flags Only', 'wptranslate' ); ?></option>
            </select>
        </p>
        <p>
            <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_flags' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'show_flags' ) ); ?>"
                   <?php checked( $show_flags ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_flags' ) ); ?>">
                <?php esc_html_e( 'Show flags', 'wptranslate' ); ?>
            </label>
        </p>
        <p>
            <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_names' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'show_names' ) ); ?>"
                   <?php checked( $show_names ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_names' ) ); ?>">
                <?php esc_html_e( 'Show language names', 'wptranslate' ); ?>
            </label>
        </p>
        <p>
            <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'show_native' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'show_native' ) ); ?>"
                   <?php checked( $show_native ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'show_native' ) ); ?>">
                <?php esc_html_e( 'Show native names', 'wptranslate' ); ?>
            </label>
        </p>
        <p>
            <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'hide_current' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'hide_current' ) ); ?>"
                   <?php checked( $hide_current ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'hide_current' ) ); ?>">
                <?php esc_html_e( 'Hide current language', 'wptranslate' ); ?>
            </label>
        </p>
        <p>
            <input type="checkbox" id="<?php echo esc_attr( $this->get_field_id( 'hide_missing' ) ); ?>"
                   name="<?php echo esc_attr( $this->get_field_name( 'hide_missing' ) ); ?>"
                   <?php checked( $hide_missing ); ?>>
            <label for="<?php echo esc_attr( $this->get_field_id( 'hide_missing' ) ); ?>">
                <?php esc_html_e( 'Hide languages without translation', 'wptranslate' ); ?>
            </label>
        </p>
        <?php
    }

    /**
     * Save widget settings.
     */
    public function update( $new_instance, $old_instance ): array {
        return array(
            'title'        => sanitize_text_field( $new_instance['title'] ?? '' ),
            'style'        => sanitize_text_field( $new_instance['style'] ?? 'dropdown' ),
            'show_flags'   => ! empty( $new_instance['show_flags'] ),
            'show_names'   => ! empty( $new_instance['show_names'] ),
            'show_native'  => ! empty( $new_instance['show_native'] ),
            'hide_current' => ! empty( $new_instance['hide_current'] ),
            'hide_missing' => ! empty( $new_instance['hide_missing'] ),
        );
    }
}
