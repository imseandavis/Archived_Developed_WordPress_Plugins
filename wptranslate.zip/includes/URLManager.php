<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manages URL rewriting, language detection, and URL generation for multilingual routing.
 */
class URLManager {

    /** @var LanguageManager */
    private $language_manager;

    /** Cookie name for storing the selected language. */
    private const COOKIE_NAME = 'wptranslate_lang';

    /** Default cookie expiry in seconds (30 days). */
    private const COOKIE_EXPIRY_DEFAULT = 2592000;

    /** Common bot user-agent patterns. */
    private const BOT_PATTERNS = array(
        'googlebot',
        'bingbot',
        'slurp',
        'duckduckbot',
        'baiduspider',
        'yandexbot',
        'facebot',
        'ia_archiver',
        'mj12bot',
        'ahrefsbot',
        'semrushbot',
        'dotbot',
        'rogerbot',
        'screaming frog',
        'uptimerobot',
        'pingdom',
        'crawler',
        'spider',
        'bot/',
        'bot;',
    );

    /**
     * @param LanguageManager $language_manager Language manager instance.
     */
    public function __construct( LanguageManager $language_manager ) {
        $this->language_manager = $language_manager;
    }

    // -------------------------------------------------------------------------
    // URL Format Helpers
    // -------------------------------------------------------------------------

    /**
     * Get the configured URL format.
     *
     * @return string One of 'directory', 'subdomain', or 'parameter'.
     */
    public function get_url_format(): string {
        $format = get_option( 'wptranslate_url_format', 'directory' );

        if ( ! in_array( $format, array( 'directory', 'subdomain', 'parameter' ), true ) ) {
            return 'directory';
        }

        return $format;
    }

    // -------------------------------------------------------------------------
    // Rewrite Rules & Query Vars
    // -------------------------------------------------------------------------

    /**
     * Register rewrite rules for the directory URL format.
     *
     * Called on the 'init' action. Rewrite rules are persisted by WordPress and
     * only need to be flushed on activation (handled by Activator).
     */
    public function register_rewrite_rules(): void {
        if ( 'directory' !== $this->get_url_format() ) {
            return;
        }

        $codes = $this->get_language_codes_pattern();
        if ( empty( $codes ) ) {
            return;
        }

        // Match /{lang}/ (homepage in that language).
        add_rewrite_rule(
            '^(' . $codes . ')/?$',
            'index.php?lang=$matches[1]',
            'top'
        );

        // Match /{lang}/any/path (pages, posts, archives, etc.).
        add_rewrite_rule(
            '^(' . $codes . ')/(.*)$',
            'index.php?lang=$matches[1]&pagename=$matches[2]',
            'top'
        );
    }

    /**
     * Register 'lang' as a public query variable.
     *
     * @param array $vars Existing query vars.
     * @return array Modified query vars.
     */
    public function add_query_vars( array $vars ): array {
        $vars[] = 'lang';
        return $vars;
    }

    // -------------------------------------------------------------------------
    // Language Detection
    // -------------------------------------------------------------------------

    /**
     * Detect the current language from the request.
     *
     * Priority: URL (query var / subdomain) > cookie > Accept-Language header > default.
     * Called on the 'template_redirect' action.
     */
    public function detect_language(): void {
        // Skip admin and AJAX requests.
        if ( is_admin() || wp_doing_ajax() ) {
            return;
        }

        $detected = '';
        $format   = $this->get_url_format();

        // 1. Try URL-based detection.
        if ( 'subdomain' === $format ) {
            $detected = $this->detect_language_from_subdomain();
        } else {
            // Both 'directory' and 'parameter' use the query var.
            $detected = $this->detect_language_from_query_var();
        }

        // 2. Try cookie.
        if ( empty( $detected ) ) {
            $detected = $this->detect_language_from_cookie();
        }

        // 3. Try Accept-Language header (only for non-bots and when browser redirect is enabled).
        if ( empty( $detected ) && ! $this->is_bot() && get_option( 'wptranslate_browser_redirect', false ) ) {
            $detected = $this->detect_language_from_header();
        }

        // 4. Fall back to default language.
        if ( empty( $detected ) ) {
            $detected = $this->language_manager->get_default_language();
        }

        // Apply the detected language.
        $this->language_manager->set_current_language( $detected );
        $this->set_language_cookie( $detected );
        $this->switch_locale( $detected );
    }

    /**
     * Detect language from the 'lang' query variable (directory and parameter formats).
     *
     * @return string Language code or empty string.
     */
    private function detect_language_from_query_var(): string {
        $lang = get_query_var( 'lang', '' );

        if ( ! empty( $lang ) && $this->is_active_language( $lang ) ) {
            return $lang;
        }

        return '';
    }

    /**
     * Detect language from the subdomain.
     *
     * @return string Language code or empty string.
     */
    private function detect_language_from_subdomain(): string {
        $host = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';

        if ( empty( $host ) ) {
            return '';
        }

        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );

        // Strip the site host from the beginning to find the subdomain prefix.
        if ( $site_host && $host !== $site_host ) {
            $subdomain = str_replace( '.' . $site_host, '', $host );

            if ( $subdomain !== $host && $this->is_active_language( $subdomain ) ) {
                return $subdomain;
            }
        }

        return '';
    }

    /**
     * Detect language from the cookie.
     *
     * @return string Language code or empty string.
     */
    private function detect_language_from_cookie(): string {
        if ( isset( $_COOKIE[ self::COOKIE_NAME ] ) ) {
            $lang = sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE_NAME ] ) );

            if ( $this->is_active_language( $lang ) ) {
                return $lang;
            }
        }

        return '';
    }

    /**
     * Detect language from the Accept-Language HTTP header.
     *
     * @return string Language code or empty string.
     */
    private function detect_language_from_header(): string {
        if ( ! isset( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) ) {
            return '';
        }

        $header = sanitize_text_field( wp_unslash( $_SERVER['HTTP_ACCEPT_LANGUAGE'] ) );

        // Parse quality values and sort by preference.
        $languages = array();
        foreach ( explode( ',', $header ) as $part ) {
            $part = trim( $part );
            if ( strpos( $part, ';q=' ) !== false ) {
                list( $lang, $quality ) = explode( ';q=', $part, 2 );
                $languages[ trim( $lang ) ] = (float) $quality;
            } else {
                $languages[ $part ] = 1.0;
            }
        }
        arsort( $languages );

        foreach ( $languages as $lang => $quality ) {
            // Try exact match first (e.g., pt-br).
            $code = strtolower( str_replace( '_', '-', $lang ) );
            if ( $this->is_active_language( $code ) ) {
                return $code;
            }

            // Try two-letter prefix (e.g., pt).
            $short = substr( $code, 0, 2 );
            if ( $this->is_active_language( $short ) ) {
                return $short;
            }
        }

        return '';
    }

    // -------------------------------------------------------------------------
    // Cookie Management
    // -------------------------------------------------------------------------

    /**
     * Set the language cookie.
     *
     * @param string $lang Language code.
     */
    private function set_language_cookie( string $lang ): void {
        // Do not set cookies for bots.
        if ( $this->is_bot() ) {
            return;
        }

        // Only set if the value has changed or cookie is not yet set.
        if ( isset( $_COOKIE[ self::COOKIE_NAME ] ) && $_COOKIE[ self::COOKIE_NAME ] === $lang ) {
            return;
        }

        if ( headers_sent() ) {
            return;
        }

        $expiry = (int) apply_filters( 'wptranslate_cookie_expiry', self::COOKIE_EXPIRY_DEFAULT );

        setcookie(
            self::COOKIE_NAME,
            $lang,
            array(
                'expires'  => time() + $expiry,
                'path'     => COOKIEPATH,
                'domain'   => COOKIE_DOMAIN,
                'secure'   => is_ssl(),
                'httponly'  => true,
                'samesite' => 'Lax',
            )
        );
    }

    // -------------------------------------------------------------------------
    // Locale Switching
    // -------------------------------------------------------------------------

    /**
     * Switch the WordPress locale to match the current language.
     *
     * @param string $lang Language code.
     */
    private function switch_locale( string $lang ): void {
        if ( $this->language_manager->is_default_language( $lang ) ) {
            return;
        }

        $language_data = $this->language_manager->get_language( $lang );
        $locale        = $language_data['locale'] ?? '';

        if ( empty( $locale ) ) {
            // Try built-in catalog.
            $catalog = LanguageManager::get_available_languages();
            $locale  = $catalog[ $lang ]['locale'] ?? '';
        }

        if ( ! empty( $locale ) ) {
            switch_to_locale( $locale );
        }
    }

    // -------------------------------------------------------------------------
    // URL Generation
    // -------------------------------------------------------------------------

    /**
     * Convert any URL to its equivalent in the target language.
     *
     * @param string $url         The source URL.
     * @param string $target_lang Target language code.
     * @return string Translated URL.
     */
    public function get_translated_url( string $url, string $target_lang ): string {
        $format        = $this->get_url_format();
        $default_lang  = $this->language_manager->get_default_language();

        // Strip any existing language prefix / parameter from the URL.
        $clean_url = $this->strip_language_from_url( $url );

        // If the target is the default language, return the clean URL.
        if ( $target_lang === $default_lang ) {
            return $clean_url;
        }

        switch ( $format ) {
            case 'directory':
                return $this->add_directory_prefix( $clean_url, $target_lang );

            case 'subdomain':
                return $this->add_subdomain_prefix( $clean_url, $target_lang );

            case 'parameter':
                return add_query_arg( 'lang', $target_lang, $clean_url );

            default:
                return $clean_url;
        }
    }

    /**
     * Get the current page URL in the specified language.
     *
     * For posts/pages, this looks up the translated post (if one exists) to use
     * its actual permalink instead of just adding a language prefix.
     *
     * @param string $lang Target language code.
     * @return string URL in the specified language.
     */
    public function get_current_url_in_language( string $lang ): string {
        // If viewing a singular post, try to find its translated counterpart.
        if ( is_singular() ) {
            $post_id       = get_queried_object_id();
            $translated_id = $this->get_translated_post_id( $post_id, $lang );

            if ( $translated_id && $translated_id !== $post_id ) {
                $permalink = get_permalink( $translated_id );
                if ( $permalink ) {
                    return $permalink;
                }
            }
        }

        // Fallback: take the current URL and convert it.
        $current_url = $this->get_current_request_url();
        return $this->get_translated_url( $current_url, $lang );
    }

    /**
     * Get the home URL for a specific language.
     *
     * @param string $lang Language code. Defaults to current language.
     * @return string Home URL for the language.
     */
    public function get_home_url( string $lang = '' ): string {
        if ( empty( $lang ) ) {
            $lang = $this->language_manager->get_current_language();
        }

        $home = home_url( '/' );

        if ( $this->language_manager->is_default_language( $lang ) ) {
            return $home;
        }

        return $this->get_translated_url( $home, $lang );
    }

    /**
     * Filter post permalinks to include the language prefix.
     *
     * Hooked to 'post_link' and 'page_link' filters.
     *
     * @param string   $url  The post permalink.
     * @param \WP_Post $post The post object.
     * @return string Modified permalink.
     */
    public function filter_permalink( string $url, $post ): string {
        if ( is_admin() ) {
            return $url;
        }

        $post_lang = $this->get_post_language( $post );

        if ( empty( $post_lang ) || $this->language_manager->is_default_language( $post_lang ) ) {
            return $url;
        }

        return $this->get_translated_url( $url, $post_lang );
    }

    // -------------------------------------------------------------------------
    // Internal Helpers
    // -------------------------------------------------------------------------

    /**
     * Build a regex alternation of all active non-default language codes.
     *
     * @return string Regex pattern like "es|fr|de".
     */
    private function get_language_codes_pattern(): string {
        $languages    = $this->language_manager->get_active_languages();
        $default_lang = $this->language_manager->get_default_language();
        $codes        = array();

        foreach ( $languages as $lang ) {
            $code = $lang['code'] ?? '';
            if ( ! empty( $code ) && $code !== $default_lang ) {
                $codes[] = preg_quote( $code, '/' );
            }
        }

        return implode( '|', $codes );
    }

    /**
     * Check whether a language code is an active language.
     *
     * @param string $code Language code.
     * @return bool
     */
    private function is_active_language( string $code ): bool {
        $languages = $this->language_manager->get_active_languages();

        foreach ( $languages as $lang ) {
            if ( ( $lang['code'] ?? '' ) === $code ) {
                return true;
            }
        }

        return false;
    }

    /**
     * Strip existing language information from a URL.
     *
     * @param string $url URL to clean.
     * @return string Cleaned URL.
     */
    private function strip_language_from_url( string $url ): string {
        $format = $this->get_url_format();

        switch ( $format ) {
            case 'directory':
                return $this->strip_directory_prefix( $url );

            case 'subdomain':
                return $this->strip_subdomain_prefix( $url );

            case 'parameter':
                return remove_query_arg( 'lang', $url );

            default:
                return $url;
        }
    }

    /**
     * Strip a language directory prefix from a URL.
     *
     * @param string $url URL to clean.
     * @return string URL without language directory prefix.
     */
    private function strip_directory_prefix( string $url ): string {
        $codes = $this->get_language_codes_pattern();

        if ( empty( $codes ) ) {
            return $url;
        }

        // Also include the default language in the strip pattern so we normalize fully.
        $default = preg_quote( $this->language_manager->get_default_language(), '/' );
        $all     = $codes . '|' . $default;

        $parsed = wp_parse_url( $url );
        $path   = $parsed['path'] ?? '/';

        // Remove the language prefix from the path.
        $path = preg_replace( '/^\/(' . $all . ')(\/|$)/', '/', $path );

        // Rebuild the URL.
        $scheme = ( $parsed['scheme'] ?? 'https' ) . '://';
        $host   = $parsed['host'] ?? '';
        $port   = isset( $parsed['port'] ) ? ':' . $parsed['port'] : '';
        $query  = isset( $parsed['query'] ) ? '?' . $parsed['query'] : '';
        $frag   = isset( $parsed['fragment'] ) ? '#' . $parsed['fragment'] : '';

        return $scheme . $host . $port . $path . $query . $frag;
    }

    /**
     * Strip a language subdomain prefix from a URL.
     *
     * @param string $url URL to clean.
     * @return string URL with the base domain (no language subdomain).
     */
    private function strip_subdomain_prefix( string $url ): string {
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $parsed    = wp_parse_url( $url );
        $host      = $parsed['host'] ?? '';

        // Replace lang.site.com with site.com.
        if ( $host !== $site_host ) {
            $url = str_replace( '://' . $host, '://' . $site_host, $url );
        }

        return $url;
    }

    /**
     * Add a directory prefix to a URL.
     *
     * @param string $url  Clean URL.
     * @param string $lang Language code.
     * @return string URL with directory prefix.
     */
    private function add_directory_prefix( string $url, string $lang ): string {
        $parsed = wp_parse_url( $url );
        $path   = $parsed['path'] ?? '/';

        // Prepend language code to the path.
        $path = '/' . $lang . $path;

        $scheme = ( $parsed['scheme'] ?? 'https' ) . '://';
        $host   = $parsed['host'] ?? '';
        $port   = isset( $parsed['port'] ) ? ':' . $parsed['port'] : '';
        $query  = isset( $parsed['query'] ) ? '?' . $parsed['query'] : '';
        $frag   = isset( $parsed['fragment'] ) ? '#' . $parsed['fragment'] : '';

        return $scheme . $host . $port . $path . $query . $frag;
    }

    /**
     * Add a subdomain prefix to a URL.
     *
     * @param string $url  Clean URL.
     * @param string $lang Language code.
     * @return string URL with language subdomain.
     */
    private function add_subdomain_prefix( string $url, string $lang ): string {
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );

        return str_replace( '://' . $site_host, '://' . $lang . '.' . $site_host, $url );
    }

    /**
     * Get the current request URL.
     *
     * @return string Full URL of the current request.
     */
    private function get_current_request_url(): string {
        $scheme = is_ssl() ? 'https' : 'http';
        $host   = isset( $_SERVER['HTTP_HOST'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_HOST'] ) ) : '';
        $uri    = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '/';

        return $scheme . '://' . $host . $uri;
    }

    /**
     * Get the language code for a post.
     *
     * Looks up the language assigned to the post in the translations table.
     *
     * @param \WP_Post|int $post Post object or ID.
     * @return string Language code or empty string.
     */
    private function get_post_language( $post ): string {
        $post_id = is_object( $post ) ? $post->ID : (int) $post;

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        $lang = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT language_code FROM {$table} WHERE element_id = %d AND element_type = 'post' LIMIT 1",
                $post_id
            )
        );

        return $lang ?: '';
    }

    /**
     * Find the translated post ID for a given post and target language.
     *
     * @param int    $post_id Post ID.
     * @param string $lang    Target language code.
     * @return int|null Translated post ID or null.
     */
    private function get_translated_post_id( int $post_id, string $lang ): ?int {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_translations';

        // Find the translation group (trid) for this post.
        $trid = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT trid FROM {$table} WHERE element_id = %d AND element_type = 'post' LIMIT 1",
                $post_id
            )
        );

        if ( ! $trid ) {
            return null;
        }

        // Find the post in the same group with the target language.
        $translated_id = $wpdb->get_var(
            $wpdb->prepare(
                "SELECT element_id FROM {$table} WHERE trid = %d AND language_code = %s AND element_type = 'post' LIMIT 1",
                $trid,
                $lang
            )
        );

        return $translated_id ? (int) $translated_id : null;
    }

    /**
     * Check if the current visitor is a known bot.
     *
     * @return bool True if the user-agent matches a bot pattern.
     */
    private function is_bot(): bool {
        if ( ! isset( $_SERVER['HTTP_USER_AGENT'] ) ) {
            return false;
        }

        $ua = strtolower( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ) );

        foreach ( self::BOT_PATTERNS as $pattern ) {
            if ( strpos( $ua, $pattern ) !== false ) {
                return true;
            }
        }

        return false;
    }
}
