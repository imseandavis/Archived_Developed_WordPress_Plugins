<?php
namespace WPTranslate\CLI;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( ! defined( 'WP_CLI' ) || ! WP_CLI ) {
    return;
}

/**
 * WPTranslate WP-CLI commands.
 *
 * Provides CLI access to translation management, import/export, diagnostics,
 * and more under the `wp wptranslate` namespace.
 */
class Commands {

    /**
     * Register all WP-CLI commands.
     */
    public static function register(): void {
        \WP_CLI::add_command( 'wptranslate translate',     array( __CLASS__, 'translate' ) );
        \WP_CLI::add_command( 'wptranslate translate-all', array( __CLASS__, 'translate_all' ) );
        \WP_CLI::add_command( 'wptranslate status',        array( __CLASS__, 'status' ) );
        \WP_CLI::add_command( 'wptranslate languages',     array( __CLASS__, 'languages' ) );
        \WP_CLI::add_command( 'wptranslate cache',         array( __CLASS__, 'cache' ) );
        \WP_CLI::add_command( 'wptranslate import',        array( __CLASS__, 'import' ) );
        \WP_CLI::add_command( 'wptranslate export',        array( __CLASS__, 'export' ) );
        \WP_CLI::add_command( 'wptranslate glossary',      array( __CLASS__, 'glossary' ) );
        \WP_CLI::add_command( 'wptranslate queue',         array( __CLASS__, 'queue' ) );
        \WP_CLI::add_command( 'wptranslate translators',   array( __CLASS__, 'translators' ) );
        \WP_CLI::add_command( 'wptranslate corrections',   array( __CLASS__, 'corrections' ) );
        \WP_CLI::add_command( 'wptranslate memory',        array( __CLASS__, 'memory' ) );
        \WP_CLI::add_command( 'wptranslate diagnostics',   array( __CLASS__, 'diagnostics' ) );
    }

    // ------------------------------------------------------------------
    // translate
    // ------------------------------------------------------------------

    /**
     * Translate a single post.
     *
     * ## OPTIONS
     *
     * <post_id>
     * : The post ID to translate.
     *
     * --to=<lang>
     * : Target language code.
     *
     * [--provider=<provider>]
     * : Translation provider to use (e.g. deepl, openai, claude).
     *
     * [--force]
     * : Re-translate even if a translation already exists.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate translate 42 --to=es
     *     wp wptranslate translate 42 --to=fr --provider=deepl --force
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function translate( $args, $assoc_args ): void {
        $post_id     = (int) $args[0];
        $target_lang = $assoc_args['to'] ?? '';
        $provider    = $assoc_args['provider'] ?? null;
        $force       = \WP_CLI\Utils\get_flag_value( $assoc_args, 'force', false );

        if ( empty( $target_lang ) ) {
            \WP_CLI::error( 'The --to flag is required.' );
        }

        $post = get_post( $post_id );
        if ( ! $post ) {
            \WP_CLI::error( "Post {$post_id} not found." );
        }

        $plugin = \WPTranslate\Plugin::get_instance();
        $tm     = $plugin->get_translation_manager();

        \WP_CLI::line( "Translating post {$post_id} (\"{$post->post_title}\") to {$target_lang}..." );

        $result = $tm->translate_post( $post_id, $target_lang, array(
            'provider' => $provider,
            'force'    => $force,
        ) );

        if ( is_wp_error( $result ) ) {
            \WP_CLI::error( $result->get_error_message() );
        }

        \WP_CLI::success( "Translation created as post {$result}." );
    }

    // ------------------------------------------------------------------
    // translate-all
    // ------------------------------------------------------------------

    /**
     * Bulk translate all posts of a type.
     *
     * ## OPTIONS
     *
     * --type=<post_type>
     * : Post type to translate (e.g. post, page).
     *
     * --to=<lang>
     * : Target language code.
     *
     * [--provider=<provider>]
     * : Translation provider to use.
     *
     * [--batch-size=<n>]
     * : Number of posts per batch. Default 10.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate translate-all --type=post --to=es
     *     wp wptranslate translate-all --type=page --to=fr --provider=claude --batch-size=5
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function translate_all( $args, $assoc_args ): void {
        $post_type   = $assoc_args['type'] ?? '';
        $target_lang = $assoc_args['to'] ?? '';
        $provider    = $assoc_args['provider'] ?? null;
        $batch_size  = (int) ( $assoc_args['batch-size'] ?? 10 );

        if ( empty( $post_type ) ) {
            \WP_CLI::error( 'The --type flag is required.' );
        }
        if ( empty( $target_lang ) ) {
            \WP_CLI::error( 'The --to flag is required.' );
        }
        if ( $batch_size < 1 ) {
            $batch_size = 10;
        }

        $posts = get_posts( array(
            'post_type'      => $post_type,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'fields'         => 'ids',
            'no_found_rows'  => true,
            'wptranslate_bypass' => true,
        ) );

        if ( empty( $posts ) ) {
            \WP_CLI::warning( "No published {$post_type} posts found." );
            return;
        }

        $total     = count( $posts );
        $progress  = \WP_CLI\Utils\make_progress_bar( "Translating {$total} {$post_type}(s) to {$target_lang}", $total );
        $plugin    = \WPTranslate\Plugin::get_instance();
        $tm        = $plugin->get_translation_manager();
        $success   = 0;
        $failed    = 0;
        $skipped   = 0;

        foreach ( $posts as $post_id ) {
            $result = $tm->translate_post( $post_id, $target_lang, array(
                'provider' => $provider,
            ) );

            if ( is_wp_error( $result ) ) {
                $failed++;
                \WP_CLI::warning( "Post {$post_id}: " . $result->get_error_message() );
            } elseif ( is_int( $result ) && $result !== $post_id ) {
                $success++;
            } else {
                $skipped++;
            }

            $progress->tick();
        }

        $progress->finish();

        \WP_CLI::line( '' );
        \WP_CLI::line( "Results: {$success} translated, {$skipped} skipped, {$failed} failed." );

        if ( $failed > 0 ) {
            \WP_CLI::warning( "{$failed} post(s) failed to translate." );
        } else {
            \WP_CLI::success( 'Bulk translation complete.' );
        }
    }

    // ------------------------------------------------------------------
    // status
    // ------------------------------------------------------------------

    /**
     * Show translation status counts.
     *
     * ## OPTIONS
     *
     * [--language=<lang>]
     * : Filter by language code.
     *
     * [--type=<post_type>]
     * : Filter by post type. Default "post".
     *
     * ## EXAMPLES
     *
     *     wp wptranslate status
     *     wp wptranslate status --language=es --type=page
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function status( $args, $assoc_args ): void {
        global $wpdb;

        $language  = $assoc_args['language'] ?? '';
        $post_type = $assoc_args['type'] ?? '';

        $translations_table = $wpdb->prefix . 'wpt_translations';
        $status_table       = $wpdb->prefix . 'wpt_translation_status';

        $where  = array( "t.element_type = 'post'" );
        $values = array();

        if ( ! empty( $language ) ) {
            $where[]  = 't.language_code = %s';
            $values[] = $language;
        }

        if ( ! empty( $post_type ) ) {
            $where[]  = "p.post_type = %s";
            $values[] = $post_type;
        }

        $where_sql = implode( ' AND ', $where );

        $query = "SELECT
                    COALESCE(s.status, 'no_status') as status,
                    COUNT(*) as count
                  FROM {$translations_table} t
                  LEFT JOIN {$status_table} s ON s.translation_id = t.id
                  LEFT JOIN {$wpdb->posts} p ON p.ID = t.element_id
                  WHERE {$where_sql}
                  GROUP BY s.status
                  ORDER BY count DESC";

        if ( ! empty( $values ) ) {
            $query = $wpdb->prepare( $query, ...$values );
        }

        $rows = $wpdb->get_results( $query, ARRAY_A );

        if ( empty( $rows ) ) {
            \WP_CLI::line( 'No translations found.' );
            return;
        }

        \WP_CLI\Utils\format_items( 'table', $rows, array( 'status', 'count' ) );
    }

    // ------------------------------------------------------------------
    // languages
    // ------------------------------------------------------------------

    /**
     * Manage languages.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : One of: list, add, remove.
     *
     * [<code>]
     * : Language code (for add/remove).
     *
     * [--name=<name>]
     * : Display name (for add).
     *
     * [--set-default]
     * : Set this language as default (for add).
     *
     * ## EXAMPLES
     *
     *     wp wptranslate languages list
     *     wp wptranslate languages add es --name="Spanish"
     *     wp wptranslate languages add de --set-default
     *     wp wptranslate languages remove es
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function languages( $args, $assoc_args ): void {
        $subcommand = $args[0] ?? '';
        $code       = $args[1] ?? '';

        $plugin       = \WPTranslate\Plugin::get_instance();
        $lang_manager = $plugin->get_language_manager();

        switch ( $subcommand ) {

            case 'list':
                $languages = $lang_manager->get_all_languages();
                if ( empty( $languages ) ) {
                    \WP_CLI::line( 'No languages configured.' );
                    return;
                }
                \WP_CLI\Utils\format_items(
                    'table',
                    $languages,
                    array( 'code', 'name', 'native_name', 'locale', 'is_default', 'is_active', 'rtl' )
                );
                break;

            case 'add':
                if ( empty( $code ) ) {
                    \WP_CLI::error( 'Please provide a language code.' );
                }

                $existing = $lang_manager->get_language( $code );
                if ( $existing ) {
                    \WP_CLI::error( "Language '{$code}' already exists." );
                }

                $name        = $assoc_args['name'] ?? '';
                $set_default = \WP_CLI\Utils\get_flag_value( $assoc_args, 'set-default', false );

                $data = array(
                    'code'       => $code,
                    'is_active'  => 1,
                    'is_default' => $set_default ? 1 : 0,
                );
                if ( ! empty( $name ) ) {
                    $data['name'] = $name;
                }

                $id = $lang_manager->add_language( $data );
                if ( $id ) {
                    \WP_CLI::success( "Language '{$code}' added (ID {$id})." );
                } else {
                    \WP_CLI::error( "Failed to add language '{$code}'." );
                }
                break;

            case 'remove':
                if ( empty( $code ) ) {
                    \WP_CLI::error( 'Please provide a language code.' );
                }

                $existing = $lang_manager->get_language( $code );
                if ( ! $existing ) {
                    \WP_CLI::error( "Language '{$code}' not found." );
                }
                if ( ! empty( $existing['is_default'] ) ) {
                    \WP_CLI::error( "Cannot remove the default language '{$code}'. Set another language as default first." );
                }

                \WP_CLI::confirm( "Are you sure you want to remove language '{$code}'?" );

                $deleted = $lang_manager->delete_language( $code );
                if ( $deleted ) {
                    \WP_CLI::success( "Language '{$code}' removed." );
                } else {
                    \WP_CLI::error( "Failed to remove language '{$code}'." );
                }
                break;

            default:
                \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: list, add, remove." );
        }
    }

    // ------------------------------------------------------------------
    // cache
    // ------------------------------------------------------------------

    /**
     * Manage caches.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : Must be "clear".
     *
     * [--scope=<scope>]
     * : What to clear: all, translations, strings. Default "all".
     *
     * ## EXAMPLES
     *
     *     wp wptranslate cache clear
     *     wp wptranslate cache clear --scope=translations
     *     wp wptranslate cache clear --scope=strings
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function cache( $args, $assoc_args ): void {
        $subcommand = $args[0] ?? '';

        if ( 'clear' !== $subcommand ) {
            \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: clear." );
        }

        $scope  = $assoc_args['scope'] ?? 'all';
        $plugin = \WPTranslate\Plugin::get_instance();
        $cache  = $plugin->get_cache_manager();

        switch ( $scope ) {
            case 'translations':
                $cache->clear_translation_cache();
                \WP_CLI::success( 'Translation cache cleared.' );
                break;

            case 'strings':
                $cache->invalidate_string_cache();
                \WP_CLI::success( 'String translation cache cleared.' );
                break;

            case 'all':
                $cache->clear_translation_cache();
                $cache->invalidate_string_cache();
                $cache->flush( 'wptranslate' );
                wp_cache_flush();
                \WP_CLI::success( 'All caches cleared.' );
                break;

            default:
                \WP_CLI::error( "Unknown scope '{$scope}'. Use: all, translations, strings." );
        }
    }

    // ------------------------------------------------------------------
    // import
    // ------------------------------------------------------------------

    /**
     * Import translations from another plugin.
     *
     * ## OPTIONS
     *
     * <source>
     * : Import source. Currently supported: translatepress.
     *
     * [--dry-run]
     * : Preview what would be imported without writing anything.
     *
     * [--include=<include>]
     * : What to import: all, content, strings, settings. Default "all".
     *
     * ## EXAMPLES
     *
     *     wp wptranslate import translatepress
     *     wp wptranslate import translatepress --dry-run
     *     wp wptranslate import translatepress --include=strings
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function import( $args, $assoc_args ): void {
        $source  = $args[0] ?? '';
        $dry_run = \WP_CLI\Utils\get_flag_value( $assoc_args, 'dry-run', false );
        $include = $assoc_args['include'] ?? 'all';

        switch ( $source ) {

            case 'translatepress':
                $logger = function ( string $message, string $level = 'info' ) {
                    switch ( $level ) {
                        case 'error':
                            \WP_CLI::warning( $message );
                            break;
                        case 'warning':
                            \WP_CLI::warning( $message );
                            break;
                        default:
                            \WP_CLI::line( $message );
                    }
                };

                $importer = new \WPTranslate\Migration\TranslatePressImporter( $logger );

                if ( ! $importer->detect_translatepress() ) {
                    \WP_CLI::error( 'TranslatePress tables not found in the database.' );
                }

                // Show available languages.
                $available = $importer->get_available_languages();
                \WP_CLI::line( '' );
                \WP_CLI::line( 'Languages found: ' . implode( ', ', $available['languages'] ) );
                \WP_CLI::line( '' );

                if ( $dry_run ) {
                    \WP_CLI::line( '--- DRY RUN (no data will be written) ---' );
                    \WP_CLI::line( '' );
                }

                $result = $importer->import_all( array(
                    'dry_run' => $dry_run,
                    'include' => $include,
                ) );

                // Print summary.
                \WP_CLI::line( '' );
                \WP_CLI::line( '=== Import Summary ===' );
                \WP_CLI::line( "Imported: {$result->imported_count}" );
                \WP_CLI::line( "Skipped:  {$result->skipped_count}" );
                \WP_CLI::line( "Failed:   {$result->failed_count}" );

                if ( ! empty( $result->warnings ) ) {
                    \WP_CLI::line( '' );
                    \WP_CLI::line( 'Warnings:' );
                    foreach ( $result->warnings as $warning ) {
                        \WP_CLI::warning( "  {$warning}" );
                    }
                }

                if ( ! empty( $result->errors ) ) {
                    \WP_CLI::line( '' );
                    \WP_CLI::line( 'Errors:' );
                    foreach ( $result->errors as $error ) {
                        \WP_CLI::warning( "  {$error}" );
                    }
                }

                if ( $result->has_errors() ) {
                    \WP_CLI::warning( 'Import completed with errors.' );
                } else {
                    \WP_CLI::success( 'Import complete.' );
                }
                break;

            default:
                \WP_CLI::error( "Unknown import source '{$source}'. Supported: translatepress." );
        }
    }

    // ------------------------------------------------------------------
    // export
    // ------------------------------------------------------------------

    /**
     * Export translations.
     *
     * ## OPTIONS
     *
     * --format=<format>
     * : Export format: csv or json.
     *
     * [--language=<lang>]
     * : Filter by language code.
     *
     * [--type=<post_type>]
     * : Filter by post type.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate export --format=csv --language=es
     *     wp wptranslate export --format=json
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function export( $args, $assoc_args ): void {
        global $wpdb;

        $format    = $assoc_args['format'] ?? '';
        $language  = $assoc_args['language'] ?? '';
        $post_type = $assoc_args['type'] ?? '';

        if ( ! in_array( $format, array( 'csv', 'json' ), true ) ) {
            \WP_CLI::error( 'The --format flag is required. Use: csv, json.' );
        }

        $translations_table = $wpdb->prefix . 'wpt_translations';
        $status_table       = $wpdb->prefix . 'wpt_translation_status';

        $where  = array( "t.element_type = 'post'" );
        $values = array();

        if ( ! empty( $language ) ) {
            $where[]  = 't.language_code = %s';
            $values[] = $language;
        }

        $where_sql = implode( ' AND ', $where );

        $query = "SELECT
                    t.element_id, t.language_code, t.source_language_code, t.trid,
                    p.post_title, p.post_type, p.post_status,
                    COALESCE(s.status, '') as translation_status
                  FROM {$translations_table} t
                  LEFT JOIN {$wpdb->posts} p ON p.ID = t.element_id
                  LEFT JOIN {$status_table} s ON s.translation_id = t.id
                  WHERE {$where_sql}
                  ORDER BY t.trid ASC, t.language_code ASC";

        if ( ! empty( $values ) ) {
            $query = $wpdb->prepare( $query, ...$values );
        }

        $rows = $wpdb->get_results( $query, ARRAY_A );

        if ( ! empty( $post_type ) ) {
            $rows = array_filter( $rows, function ( $row ) use ( $post_type ) {
                return $row['post_type'] === $post_type;
            } );
            $rows = array_values( $rows );
        }

        if ( empty( $rows ) ) {
            \WP_CLI::warning( 'No translations found matching the criteria.' );
            return;
        }

        if ( 'json' === $format ) {
            \WP_CLI::line( wp_json_encode( $rows, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE ) );
        } else {
            // CSV output.
            $columns = array( 'element_id', 'language_code', 'source_language_code', 'trid', 'post_title', 'post_type', 'post_status', 'translation_status' );
            fputcsv( STDOUT, $columns );
            foreach ( $rows as $row ) {
                fputcsv( STDOUT, $row );
            }
        }

        \WP_CLI::success( sprintf( 'Exported %d translation record(s).', count( $rows ) ) );
    }

    // ------------------------------------------------------------------
    // glossary
    // ------------------------------------------------------------------

    /**
     * Manage glossary terms.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : One of: import, list.
     *
     * [<file>]
     * : CSV file path (for import).
     *
     * [--source=<lang>]
     * : Source language code.
     *
     * [--target=<lang>]
     * : Target language code.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate glossary list
     *     wp wptranslate glossary list --source=en --target=es
     *     wp wptranslate glossary import /path/to/terms.csv --source=en --target=es
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function glossary( $args, $assoc_args ): void {
        global $wpdb;

        $subcommand  = $args[0] ?? '';
        $source_lang = $assoc_args['source'] ?? '';
        $target_lang = $assoc_args['target'] ?? '';
        $table       = $wpdb->prefix . 'wpt_translation_glossary';

        switch ( $subcommand ) {

            case 'list':
                $where  = array( '1=1' );
                $values = array();

                if ( ! empty( $source_lang ) ) {
                    $where[]  = 'source_lang = %s';
                    $values[] = $source_lang;
                }
                if ( ! empty( $target_lang ) ) {
                    $where[]  = 'target_lang = %s';
                    $values[] = $target_lang;
                }

                $where_sql = implode( ' AND ', $where );
                $query     = "SELECT id, term, translation, source_lang, target_lang, case_sensitive, exact_match, auto_generated, confirmed FROM {$table} WHERE {$where_sql} ORDER BY term ASC";

                if ( ! empty( $values ) ) {
                    $query = $wpdb->prepare( $query, ...$values );
                }

                $rows = $wpdb->get_results( $query, ARRAY_A );

                if ( empty( $rows ) ) {
                    \WP_CLI::line( 'No glossary terms found.' );
                    return;
                }

                \WP_CLI\Utils\format_items(
                    'table',
                    $rows,
                    array( 'id', 'term', 'translation', 'source_lang', 'target_lang', 'case_sensitive', 'exact_match', 'auto_generated', 'confirmed' )
                );
                break;

            case 'import':
                $file = $args[1] ?? '';

                if ( empty( $file ) ) {
                    \WP_CLI::error( 'Please provide a CSV file path.' );
                }
                if ( ! file_exists( $file ) ) {
                    \WP_CLI::error( "File not found: {$file}" );
                }
                if ( empty( $source_lang ) || empty( $target_lang ) ) {
                    \WP_CLI::error( 'Both --source and --target flags are required for import.' );
                }

                $handle = fopen( $file, 'r' );
                if ( ! $handle ) {
                    \WP_CLI::error( "Could not open file: {$file}" );
                }

                // Read header row.
                $header = fgetcsv( $handle );
                if ( ! $header ) {
                    fclose( $handle );
                    \WP_CLI::error( 'CSV file is empty or has no header row.' );
                }

                // Normalize headers.
                $header = array_map( 'strtolower', array_map( 'trim', $header ) );
                $term_col        = array_search( 'term', $header, true );
                $translation_col = array_search( 'translation', $header, true );

                if ( false === $term_col || false === $translation_col ) {
                    fclose( $handle );
                    \WP_CLI::error( 'CSV must have "term" and "translation" columns.' );
                }

                $imported = 0;
                $skipped  = 0;

                while ( ( $row = fgetcsv( $handle ) ) !== false ) {
                    $term        = trim( $row[ $term_col ] ?? '' );
                    $translation = trim( $row[ $translation_col ] ?? '' );

                    if ( empty( $term ) || empty( $translation ) ) {
                        $skipped++;
                        continue;
                    }

                    // Check for duplicate.
                    $exists = $wpdb->get_var( $wpdb->prepare(
                        "SELECT id FROM {$table} WHERE term = %s AND source_lang = %s AND target_lang = %s LIMIT 1",
                        $term,
                        $source_lang,
                        $target_lang
                    ) );

                    if ( $exists ) {
                        $skipped++;
                        continue;
                    }

                    $wpdb->insert(
                        $table,
                        array(
                            'term'           => $term,
                            'translation'    => $translation,
                            'source_lang'    => $source_lang,
                            'target_lang'    => $target_lang,
                            'case_sensitive' => 0,
                            'exact_match'    => 0,
                            'auto_generated' => 0,
                            'confirmed'      => 1,
                            'created_at'     => current_time( 'mysql' ),
                        ),
                        array( '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d', '%s' )
                    );
                    $imported++;
                }

                fclose( $handle );

                \WP_CLI::success( "Glossary import complete. Imported: {$imported}, Skipped: {$skipped}." );
                break;

            default:
                \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: list, import." );
        }
    }

    // ------------------------------------------------------------------
    // queue
    // ------------------------------------------------------------------

    /**
     * Manage the translation queue.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : One of: status, retry-failed, clear.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate queue status
     *     wp wptranslate queue retry-failed
     *     wp wptranslate queue clear
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function queue( $args, $assoc_args ): void {
        global $wpdb;

        $subcommand = $args[0] ?? '';
        $table      = $wpdb->prefix . 'wpt_translation_jobs';

        switch ( $subcommand ) {

            case 'status':
                $stats = $wpdb->get_results(
                    "SELECT status, COUNT(*) as count FROM {$table} GROUP BY status ORDER BY FIELD(status, 'pending', 'in_progress', 'completed', 'failed')",
                    ARRAY_A
                );

                if ( empty( $stats ) ) {
                    \WP_CLI::line( 'Queue is empty.' );
                    return;
                }

                \WP_CLI\Utils\format_items( 'table', $stats, array( 'status', 'count' ) );

                // Show oldest pending.
                $oldest = $wpdb->get_var(
                    "SELECT created_at FROM {$table} WHERE status = 'pending' ORDER BY created_at ASC LIMIT 1"
                );
                if ( $oldest ) {
                    \WP_CLI::line( "Oldest pending job: {$oldest}" );
                }
                break;

            case 'retry-failed':
                $updated = $wpdb->query(
                    "UPDATE {$table} SET status = 'pending', error_message = NULL, started_at = NULL, completed_at = NULL WHERE status = 'failed'"
                );

                if ( $updated ) {
                    \WP_CLI::success( "{$updated} failed job(s) re-queued." );
                } else {
                    \WP_CLI::line( 'No failed jobs to retry.' );
                }
                break;

            case 'clear':
                \WP_CLI::confirm( 'This will remove all pending and in-progress jobs. Continue?' );

                $deleted = $wpdb->query(
                    "DELETE FROM {$table} WHERE status IN ('pending', 'in_progress')"
                );

                \WP_CLI::success( "{$deleted} job(s) cleared from the queue." );
                break;

            default:
                \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: status, retry-failed, clear." );
        }
    }

    // ------------------------------------------------------------------
    // translators
    // ------------------------------------------------------------------

    /**
     * List translator users.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : Must be "list".
     *
     * [--language=<lang>]
     * : Filter by assigned language.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate translators list
     *     wp wptranslate translators list --language=es
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function translators( $args, $assoc_args ): void {
        $subcommand = $args[0] ?? '';

        if ( 'list' !== $subcommand ) {
            \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: list." );
        }

        $language = $assoc_args['language'] ?? '';

        $user_query_args = array(
            'role__in' => array( 'wptranslate_translator', 'wptranslate_translation_manager' ),
            'orderby'  => 'display_name',
        );

        $users = get_users( $user_query_args );

        if ( empty( $users ) ) {
            \WP_CLI::line( 'No translators found.' );
            return;
        }

        $rows = array();
        foreach ( $users as $user ) {
            $user_langs = get_user_meta( $user->ID, 'wptranslate_languages', true );
            $user_langs = is_array( $user_langs ) ? implode( ', ', $user_langs ) : '';

            if ( ! empty( $language ) && ! empty( $user_langs ) && ! str_contains( $user_langs, $language ) ) {
                continue;
            }

            $rows[] = array(
                'ID'           => $user->ID,
                'display_name' => $user->display_name,
                'email'        => $user->user_email,
                'roles'        => implode( ', ', $user->roles ),
                'languages'    => $user_langs,
            );
        }

        if ( empty( $rows ) ) {
            \WP_CLI::line( 'No translators found matching the criteria.' );
            return;
        }

        \WP_CLI\Utils\format_items( 'table', $rows, array( 'ID', 'display_name', 'email', 'roles', 'languages' ) );
    }

    // ------------------------------------------------------------------
    // corrections
    // ------------------------------------------------------------------

    /**
     * Manage translation corrections.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : One of: list, stats.
     *
     * [--source=<lang>]
     * : Source language code.
     *
     * [--target=<lang>]
     * : Target language code.
     *
     * [--type=<type>]
     * : Correction type filter (for list).
     *
     * [--limit=<n>]
     * : Number of results (for list). Default 20.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate corrections list
     *     wp wptranslate corrections list --source=en --target=es --limit=50
     *     wp wptranslate corrections stats
     *     wp wptranslate corrections stats --source=en --target=fr
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function corrections( $args, $assoc_args ): void {
        global $wpdb;

        $subcommand  = $args[0] ?? '';
        $source_lang = $assoc_args['source'] ?? '';
        $target_lang = $assoc_args['target'] ?? '';
        $table       = $wpdb->prefix . 'wpt_translation_corrections';

        switch ( $subcommand ) {

            case 'list':
                $type  = $assoc_args['type'] ?? '';
                $limit = (int) ( $assoc_args['limit'] ?? 20 );
                if ( $limit < 1 ) {
                    $limit = 20;
                }

                $where  = array( '1=1' );
                $values = array();

                if ( ! empty( $source_lang ) ) {
                    $where[]  = 'source_lang = %s';
                    $values[] = $source_lang;
                }
                if ( ! empty( $target_lang ) ) {
                    $where[]  = 'target_lang = %s';
                    $values[] = $target_lang;
                }
                if ( ! empty( $type ) ) {
                    $where[]  = 'correction_type = %s';
                    $values[] = $type;
                }

                $where_sql = implode( ' AND ', $where );
                $values[]  = $limit;

                $query = "SELECT id, source_lang, target_lang, correction_type, provider,
                                 LEFT(source_text, 80) as source_text,
                                 LEFT(corrected_text, 80) as corrected_text,
                                 created_at
                          FROM {$table}
                          WHERE {$where_sql}
                          ORDER BY created_at DESC
                          LIMIT %d";

                $rows = $wpdb->get_results( $wpdb->prepare( $query, ...$values ), ARRAY_A );

                if ( empty( $rows ) ) {
                    \WP_CLI::line( 'No corrections found.' );
                    return;
                }

                \WP_CLI\Utils\format_items(
                    'table',
                    $rows,
                    array( 'id', 'source_lang', 'target_lang', 'correction_type', 'source_text', 'corrected_text', 'created_at' )
                );
                break;

            case 'stats':
                $where  = array( '1=1' );
                $values = array();

                if ( ! empty( $source_lang ) ) {
                    $where[]  = 'source_lang = %s';
                    $values[] = $source_lang;
                }
                if ( ! empty( $target_lang ) ) {
                    $where[]  = 'target_lang = %s';
                    $values[] = $target_lang;
                }

                $where_sql = implode( ' AND ', $where );

                $query = "SELECT
                            source_lang, target_lang, correction_type,
                            COUNT(*) as total,
                            SUM(promoted_to_glossary) as promoted
                          FROM {$table}
                          WHERE {$where_sql}
                          GROUP BY source_lang, target_lang, correction_type
                          ORDER BY total DESC";

                if ( ! empty( $values ) ) {
                    $query = $wpdb->prepare( $query, ...$values );
                }

                $rows = $wpdb->get_results( $query, ARRAY_A );

                if ( empty( $rows ) ) {
                    \WP_CLI::line( 'No correction statistics available.' );
                    return;
                }

                \WP_CLI\Utils\format_items(
                    'table',
                    $rows,
                    array( 'source_lang', 'target_lang', 'correction_type', 'total', 'promoted' )
                );
                break;

            default:
                \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: list, stats." );
        }
    }

    // ------------------------------------------------------------------
    // memory
    // ------------------------------------------------------------------

    /**
     * Show translation memory statistics.
     *
     * ## OPTIONS
     *
     * <subcommand>
     * : Must be "stats".
     *
     * ## EXAMPLES
     *
     *     wp wptranslate memory stats
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function memory( $args, $assoc_args ): void {
        global $wpdb;

        $subcommand = $args[0] ?? '';

        if ( 'stats' !== $subcommand ) {
            \WP_CLI::error( "Unknown subcommand '{$subcommand}'. Use: stats." );
        }

        $cache_table = $wpdb->prefix . 'wpt_translation_cache';

        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$cache_table}" );
        $by_type = $wpdb->get_results(
            "SELECT source_type, COUNT(*) as count FROM {$cache_table} GROUP BY source_type ORDER BY count DESC",
            ARRAY_A
        );
        $by_pair = $wpdb->get_results(
            "SELECT source_lang, target_lang, COUNT(*) as count FROM {$cache_table} GROUP BY source_lang, target_lang ORDER BY count DESC LIMIT 20",
            ARRAY_A
        );
        $expired = (int) $wpdb->get_var( $wpdb->prepare(
            "SELECT COUNT(*) FROM {$cache_table} WHERE expires_at IS NOT NULL AND expires_at < %s",
            current_time( 'mysql', true )
        ) );

        \WP_CLI::line( "Total translation memory entries: {$total}" );
        \WP_CLI::line( "Expired entries: {$expired}" );
        \WP_CLI::line( '' );

        if ( ! empty( $by_type ) ) {
            \WP_CLI::line( 'By source type:' );
            \WP_CLI\Utils\format_items( 'table', $by_type, array( 'source_type', 'count' ) );
            \WP_CLI::line( '' );
        }

        if ( ! empty( $by_pair ) ) {
            \WP_CLI::line( 'By language pair (top 20):' );
            \WP_CLI\Utils\format_items( 'table', $by_pair, array( 'source_lang', 'target_lang', 'count' ) );
        }
    }

    // ------------------------------------------------------------------
    // diagnostics
    // ------------------------------------------------------------------

    /**
     * Run system diagnostics.
     *
     * Checks PHP version, database tables, API keys, cache, and queue health.
     *
     * ## EXAMPLES
     *
     *     wp wptranslate diagnostics
     *
     * @param array $args       Positional arguments.
     * @param array $assoc_args Named arguments.
     */
    public static function diagnostics( $args, $assoc_args ): void {
        global $wpdb;

        \WP_CLI::line( '=== WPTranslate Diagnostics ===' );
        \WP_CLI::line( '' );

        $issues = 0;

        // PHP version.
        $php_ok = version_compare( PHP_VERSION, '7.4', '>=' );
        if ( $php_ok ) {
            \WP_CLI::line( "[OK]  PHP version: " . PHP_VERSION );
        } else {
            \WP_CLI::warning( "[FAIL] PHP version " . PHP_VERSION . " is below the minimum 7.4." );
            $issues++;
        }

        // WordPress version.
        \WP_CLI::line( "[OK]  WordPress version: " . get_bloginfo( 'version' ) );

        // Plugin version.
        if ( defined( 'WPTRANSLATE_VERSION' ) ) {
            \WP_CLI::line( "[OK]  WPTranslate version: " . WPTRANSLATE_VERSION );
        }

        // Database tables.
        \WP_CLI::line( '' );
        \WP_CLI::line( 'Database tables:' );

        $required_tables = array(
            'wpt_languages',
            'wpt_translations',
            'wpt_translation_status',
            'wpt_string_translations',
            'wpt_translation_jobs',
            'wpt_translation_cache',
            'wpt_translation_glossary',
            'wpt_translation_corrections',
        );

        foreach ( $required_tables as $short_name ) {
            $full_name = $wpdb->prefix . $short_name;
            $exists    = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $full_name ) );
            if ( $exists ) {
                $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$full_name}" );
                \WP_CLI::line( "  [OK]  {$short_name} ({$count} rows)" );
            } else {
                \WP_CLI::warning( "  [FAIL] {$short_name} - table missing" );
                $issues++;
            }
        }

        // API keys.
        \WP_CLI::line( '' );
        \WP_CLI::line( 'API providers:' );

        $providers = array(
            'deepl'  => 'wptranslate_deepl_api_key',
            'openai' => 'wptranslate_openai_api_key',
            'claude' => 'wptranslate_claude_api_key',
        );

        $configured_providers = 0;
        foreach ( $providers as $name => $option_key ) {
            $key = get_option( $option_key, '' );
            if ( ! empty( $key ) ) {
                $masked = substr( $key, 0, 4 ) . str_repeat( '*', max( 0, strlen( $key ) - 8 ) ) . substr( $key, -4 );
                \WP_CLI::line( "  [OK]  {$name}: configured ({$masked})" );
                $configured_providers++;
            } else {
                \WP_CLI::line( "  [--]  {$name}: not configured" );
            }
        }

        if ( 0 === $configured_providers ) {
            \WP_CLI::warning( '  No translation providers configured.' );
            $issues++;
        }

        // Active languages.
        \WP_CLI::line( '' );
        $plugin = \WPTranslate\Plugin::get_instance();
        $lang_manager = $plugin->get_language_manager();
        $languages = $lang_manager->get_active_languages();
        \WP_CLI::line( "Active languages: " . count( $languages ) );
        \WP_CLI::line( "Default language: " . $lang_manager->get_default_language() );

        // Cache health.
        \WP_CLI::line( '' );
        \WP_CLI::line( 'Cache:' );
        $cache_manager = $plugin->get_cache_manager();
        $test_key      = 'diagnostics_test_' . time();
        $cache_manager->set( $test_key, 'test_value', 60 );
        $retrieved = $cache_manager->get( $test_key );
        $cache_manager->delete( $test_key );

        if ( 'test_value' === $retrieved ) {
            \WP_CLI::line( '  [OK]  Cache read/write working.' );
        } else {
            \WP_CLI::warning( '  [FAIL] Cache read/write test failed.' );
            $issues++;
        }

        $using_external = wp_using_ext_object_cache();
        \WP_CLI::line( '  External object cache: ' . ( $using_external ? 'Yes' : 'No' ) );

        // Queue health.
        \WP_CLI::line( '' );
        \WP_CLI::line( 'Queue:' );

        $jobs_table = $wpdb->prefix . 'wpt_translation_jobs';
        $table_exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $jobs_table ) );

        if ( $table_exists ) {
            $pending     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'pending'" );
            $in_progress = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'in_progress'" );
            $failed      = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'failed'" );

            \WP_CLI::line( "  Pending:     {$pending}" );
            \WP_CLI::line( "  In progress: {$in_progress}" );
            \WP_CLI::line( "  Failed:      {$failed}" );

            if ( $failed > 0 ) {
                \WP_CLI::warning( "  {$failed} failed job(s) in queue. Run 'wp wptranslate queue retry-failed' to re-queue." );
            }

            // Check for stuck jobs (in_progress for more than 1 hour).
            $stuck = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$jobs_table} WHERE status = 'in_progress' AND started_at < DATE_SUB(NOW(), INTERVAL 1 HOUR)"
            );
            if ( $stuck > 0 ) {
                \WP_CLI::warning( "  {$stuck} job(s) appear stuck (in progress > 1 hour)." );
                $issues++;
            }
        }

        // Cron check.
        \WP_CLI::line( '' );
        \WP_CLI::line( 'Cron schedules:' );

        $queue_cron = wp_next_scheduled( 'wptranslate_process_queue' );
        if ( $queue_cron ) {
            \WP_CLI::line( '  [OK]  Queue processing: next run at ' . date( 'Y-m-d H:i:s', $queue_cron ) );
        } else {
            \WP_CLI::warning( '  [FAIL] Queue processing cron not scheduled.' );
            $issues++;
        }

        $corrections_cron = wp_next_scheduled( 'wptranslate_analyze_corrections' );
        if ( $corrections_cron ) {
            \WP_CLI::line( '  [OK]  Corrections analysis: next run at ' . date( 'Y-m-d H:i:s', $corrections_cron ) );
        } else {
            \WP_CLI::warning( '  [FAIL] Corrections analysis cron not scheduled.' );
            $issues++;
        }

        // Summary.
        \WP_CLI::line( '' );
        if ( 0 === $issues ) {
            \WP_CLI::success( 'All diagnostics passed.' );
        } else {
            \WP_CLI::warning( "{$issues} issue(s) found." );
        }
    }
}

// Auto-register commands when this file is loaded.
Commands::register();
