<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Language switcher — renders language selection UI in multiple formats.
 */
class LanguageSwitcher {

    /** @var LanguageManager */
    private $language_manager;

    /** @var URLManager */
    private $url_manager;

    public function __construct( LanguageManager $language_manager, URLManager $url_manager ) {
        $this->language_manager = $language_manager;
        $this->url_manager      = $url_manager;

        // Register shortcode.
        add_shortcode( 'wptranslate_switcher', array( $this, 'shortcode_handler' ) );

        // Register widget.
        add_action( 'widgets_init', array( $this, 'register_widget' ) );

        // Register Gutenberg block.
        add_action( 'init', array( $this, 'register_block' ) );

        // Register nav menu item type.
        add_filter( 'wp_setup_nav_menu_item', array( $this, 'setup_nav_menu_item' ) );
        add_filter( 'walker_nav_menu_start_el', array( $this, 'nav_menu_start_el' ), 10, 4 );
    }

    /**
     * Render the language switcher.
     *
     * @param array $args Configuration arguments.
     * @return string HTML output.
     */
    public function render( array $args = array() ): string {
        $defaults = array(
            'style'       => 'dropdown',  // dropdown, list, horizontal, flags
            'show_flags'  => true,
            'show_names'  => true,
            'show_native' => false,
            'hide_current' => false,
            'hide_missing' => false,
            'class'       => '',
        );

        $args = wp_parse_args( $args, $defaults );

        $languages = $this->language_manager->get_active_languages();
        $current = $this->language_manager->get_current_language();

        if ( empty( $languages ) ) {
            return '';
        }

        // Build language items.
        $items = array();
        foreach ( $languages as $lang ) {
            $code = $lang['code'];
            $url = $this->url_manager->get_current_url_in_language( $code );
            $is_current = ( $code === $current );

            // Check if translation exists for current post.
            $has_translation = true;
            if ( is_singular() && ! $is_current ) {
                $post_id = get_queried_object_id();
                if ( $post_id ) {
                    $translation = wptranslate_get_translation( $post_id, $code );
                    $has_translation = ! empty( $translation );
                }
            }

            if ( ! $has_translation && $args['hide_missing'] ) {
                continue;
            }

            if ( $is_current && $args['hide_current'] ) {
                continue;
            }

            $items[] = array(
                'code'            => $code,
                'name'            => $lang['name'],
                'native_name'     => $lang['native_name'],
                'flag'            => $lang['flag'],
                'url'             => $url,
                'is_current'      => $is_current,
                'has_translation' => $has_translation,
            );
        }

        $method = 'render_' . $args['style'];
        if ( method_exists( $this, $method ) ) {
            $html = $this->$method( $items, $args );
        } else {
            $html = $this->render_dropdown( $items, $args );
        }

        /**
         * Filter the language switcher HTML.
         */
        return apply_filters( 'wptranslate_language_switcher_html', $html, $args );
    }

    /**
     * Render dropdown style.
     */
    private function render_dropdown( array $items, array $args ): string {
        $class = 'wptranslate-switcher wptranslate-switcher--dropdown ' . esc_attr( $args['class'] );

        $html = '<div class="' . $class . '">';
        $html .= '<select class="wptranslate-switcher__select" aria-label="' . esc_attr__( 'Select language', 'wptranslate' ) . '">';

        foreach ( $items as $item ) {
            $selected = $item['is_current'] ? ' selected' : '';
            $disabled = ! $item['has_translation'] ? ' disabled' : '';
            $label = $this->build_label( $item, $args );

            $html .= sprintf(
                '<option value="%s"%s%s>%s</option>',
                esc_url( $item['url'] ),
                $selected,
                $disabled,
                esc_html( $label )
            );
        }

        $html .= '</select>';
        $html .= '</div>';

        return $html;
    }

    /**
     * Render horizontal list style.
     */
    private function render_horizontal( array $items, array $args ): string {
        return $this->render_list_style( $items, $args, 'horizontal' );
    }

    /**
     * Render vertical list style.
     */
    private function render_list( array $items, array $args ): string {
        return $this->render_list_style( $items, $args, 'list' );
    }

    /**
     * Render flags-only style.
     */
    private function render_flags( array $items, array $args ): string {
        $args['show_names'] = false;
        $args['show_native'] = false;
        $args['show_flags'] = true;
        return $this->render_list_style( $items, $args, 'flags' );
    }

    /**
     * Common list rendering.
     */
    private function render_list_style( array $items, array $args, string $style ): string {
        $class = "wptranslate-switcher wptranslate-switcher--{$style} " . esc_attr( $args['class'] );

        $html = '<ul class="' . $class . '" role="navigation" aria-label="' . esc_attr__( 'Language selection', 'wptranslate' ) . '">';

        foreach ( $items as $item ) {
            $li_class = 'wptranslate-switcher__item';
            if ( $item['is_current'] ) {
                $li_class .= ' wptranslate-switcher__item--current';
            }
            if ( ! $item['has_translation'] ) {
                $li_class .= ' wptranslate-switcher__item--no-translation';
            }

            $label = $this->build_label( $item, $args );

            $html .= sprintf(
                '<li class="%s"><a href="%s" hreflang="%s"%s>%s</a></li>',
                esc_attr( $li_class ),
                esc_url( $item['url'] ),
                esc_attr( $item['code'] ),
                $item['is_current'] ? ' aria-current="true"' : '',
                $label  // Already escaped in build_label.
            );
        }

        $html .= '</ul>';

        return $html;
    }

    /**
     * Build display label for a language item.
     */
    private function build_label( array $item, array $args ): string {
        $parts = array();

        if ( $args['show_flags'] && ! empty( $item['flag'] ) ) {
            $parts[] = '<span class="wptranslate-switcher__flag">' . esc_html( $item['flag'] ) . '</span>';
        }

        if ( $args['show_native'] && ! empty( $item['native_name'] ) ) {
            $parts[] = '<span class="wptranslate-switcher__name">' . esc_html( $item['native_name'] ) . '</span>';
        } elseif ( $args['show_names'] ) {
            $parts[] = '<span class="wptranslate-switcher__name">' . esc_html( $item['name'] ) . '</span>';
        }

        return implode( ' ', $parts );
    }

    /**
     * Shortcode handler.
     */
    public function shortcode_handler( $atts ): string {
        $atts = shortcode_atts(
            array(
                'style'        => 'dropdown',
                'show_flags'   => 'true',
                'show_names'   => 'true',
                'show_native'  => 'false',
                'hide_current' => 'false',
                'hide_missing' => 'false',
                'class'        => '',
            ),
            $atts,
            'wptranslate_switcher'
        );

        // Convert string booleans.
        foreach ( array( 'show_flags', 'show_names', 'show_native', 'hide_current', 'hide_missing' ) as $key ) {
            $atts[ $key ] = filter_var( $atts[ $key ], FILTER_VALIDATE_BOOLEAN );
        }

        return $this->render( $atts );
    }

    /**
     * Register the language switcher widget.
     */
    public function register_widget(): void {
        register_widget( Widgets\LanguageSwitcherWidget::class );
    }

    /**
     * Register Gutenberg block.
     */
    public function register_block(): void {
        if ( ! function_exists( 'register_block_type' ) ) {
            return;
        }

        register_block_type( 'wptranslate/language-switcher', array(
            'render_callback' => array( $this, 'render_block' ),
            'attributes'      => array(
                'style'       => array( 'type' => 'string', 'default' => 'dropdown' ),
                'showFlags'   => array( 'type' => 'boolean', 'default' => true ),
                'showNames'   => array( 'type' => 'boolean', 'default' => true ),
                'showNative'  => array( 'type' => 'boolean', 'default' => false ),
                'hideCurrent' => array( 'type' => 'boolean', 'default' => false ),
                'hideMissing' => array( 'type' => 'boolean', 'default' => false ),
            ),
        ) );
    }

    /**
     * Render the Gutenberg block.
     */
    public function render_block( array $attributes ): string {
        return $this->render( array(
            'style'        => $attributes['style'] ?? 'dropdown',
            'show_flags'   => $attributes['showFlags'] ?? true,
            'show_names'   => $attributes['showNames'] ?? true,
            'show_native'  => $attributes['showNative'] ?? false,
            'hide_current' => $attributes['hideCurrent'] ?? false,
            'hide_missing' => $attributes['hideMissing'] ?? false,
        ) );
    }

    /**
     * Set up nav menu item for language switcher.
     */
    public function setup_nav_menu_item( $item ) {
        if ( isset( $item->type ) && 'wptranslate_switcher' === $item->type ) {
            $item->type_label = __( 'Language Switcher', 'wptranslate' );
        }
        return $item;
    }

    /**
     * Render language switcher in nav menu.
     */
    public function nav_menu_start_el( string $item_output, $item, int $depth, $args ): string {
        if ( isset( $item->type ) && 'wptranslate_switcher' === $item->type ) {
            return $this->render( array( 'style' => 'horizontal', 'class' => 'wptranslate-nav-switcher' ) );
        }
        return $item_output;
    }
}
