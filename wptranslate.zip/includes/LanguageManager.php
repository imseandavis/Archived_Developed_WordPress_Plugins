<?php
namespace WPTranslate;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

/**
 * Manages languages configuration and current language state.
 */
class LanguageManager {

    /** @var cache\CacheManager */
    private $cache;

    /** @var string Current language code. */
    private $current_language = '';

    /** @var string Default language code. */
    private $default_language = '';

    /** @var array|null Cached active languages. */
    private $active_languages = null;

    /**
     * Complete list of available languages with metadata.
     */
    private const LANGUAGE_DATA = array(
        'en' => array( 'name' => 'English', 'native_name' => 'English', 'locale' => 'en_US', 'flag' => '🇺🇸', 'rtl' => false ),
        'es' => array( 'name' => 'Spanish', 'native_name' => 'Español', 'locale' => 'es_ES', 'flag' => '🇪🇸', 'rtl' => false ),
        'fr' => array( 'name' => 'French', 'native_name' => 'Français', 'locale' => 'fr_FR', 'flag' => '🇫🇷', 'rtl' => false ),
        'de' => array( 'name' => 'German', 'native_name' => 'Deutsch', 'locale' => 'de_DE', 'flag' => '🇩🇪', 'rtl' => false ),
        'it' => array( 'name' => 'Italian', 'native_name' => 'Italiano', 'locale' => 'it_IT', 'flag' => '🇮🇹', 'rtl' => false ),
        'pt' => array( 'name' => 'Portuguese', 'native_name' => 'Português', 'locale' => 'pt_PT', 'flag' => '🇵🇹', 'rtl' => false ),
        'pt-br' => array( 'name' => 'Portuguese (Brazil)', 'native_name' => 'Português do Brasil', 'locale' => 'pt_BR', 'flag' => '🇧🇷', 'rtl' => false ),
        'nl' => array( 'name' => 'Dutch', 'native_name' => 'Nederlands', 'locale' => 'nl_NL', 'flag' => '🇳🇱', 'rtl' => false ),
        'ru' => array( 'name' => 'Russian', 'native_name' => 'Русский', 'locale' => 'ru_RU', 'flag' => '🇷🇺', 'rtl' => false ),
        'zh' => array( 'name' => 'Chinese (Simplified)', 'native_name' => '简体中文', 'locale' => 'zh_CN', 'flag' => '🇨🇳', 'rtl' => false ),
        'zh-tw' => array( 'name' => 'Chinese (Traditional)', 'native_name' => '繁體中文', 'locale' => 'zh_TW', 'flag' => '🇹🇼', 'rtl' => false ),
        'ja' => array( 'name' => 'Japanese', 'native_name' => '日本語', 'locale' => 'ja', 'flag' => '🇯🇵', 'rtl' => false ),
        'ko' => array( 'name' => 'Korean', 'native_name' => '한국어', 'locale' => 'ko_KR', 'flag' => '🇰🇷', 'rtl' => false ),
        'ar' => array( 'name' => 'Arabic', 'native_name' => 'العربية', 'locale' => 'ar', 'flag' => '🇸🇦', 'rtl' => true ),
        'he' => array( 'name' => 'Hebrew', 'native_name' => 'עברית', 'locale' => 'he_IL', 'flag' => '🇮🇱', 'rtl' => true ),
        'hi' => array( 'name' => 'Hindi', 'native_name' => 'हिन्दी', 'locale' => 'hi_IN', 'flag' => '🇮🇳', 'rtl' => false ),
        'tr' => array( 'name' => 'Turkish', 'native_name' => 'Türkçe', 'locale' => 'tr_TR', 'flag' => '🇹🇷', 'rtl' => false ),
        'pl' => array( 'name' => 'Polish', 'native_name' => 'Polski', 'locale' => 'pl_PL', 'flag' => '🇵🇱', 'rtl' => false ),
        'sv' => array( 'name' => 'Swedish', 'native_name' => 'Svenska', 'locale' => 'sv_SE', 'flag' => '🇸🇪', 'rtl' => false ),
        'da' => array( 'name' => 'Danish', 'native_name' => 'Dansk', 'locale' => 'da_DK', 'flag' => '🇩🇰', 'rtl' => false ),
        'fi' => array( 'name' => 'Finnish', 'native_name' => 'Suomi', 'locale' => 'fi', 'flag' => '🇫🇮', 'rtl' => false ),
        'no' => array( 'name' => 'Norwegian', 'native_name' => 'Norsk', 'locale' => 'nb_NO', 'flag' => '🇳🇴', 'rtl' => false ),
        'cs' => array( 'name' => 'Czech', 'native_name' => 'Čeština', 'locale' => 'cs_CZ', 'flag' => '🇨🇿', 'rtl' => false ),
        'el' => array( 'name' => 'Greek', 'native_name' => 'Ελληνικά', 'locale' => 'el', 'flag' => '🇬🇷', 'rtl' => false ),
        'hu' => array( 'name' => 'Hungarian', 'native_name' => 'Magyar', 'locale' => 'hu_HU', 'flag' => '🇭🇺', 'rtl' => false ),
        'ro' => array( 'name' => 'Romanian', 'native_name' => 'Română', 'locale' => 'ro_RO', 'flag' => '🇷🇴', 'rtl' => false ),
        'bg' => array( 'name' => 'Bulgarian', 'native_name' => 'Български', 'locale' => 'bg_BG', 'flag' => '🇧🇬', 'rtl' => false ),
        'uk' => array( 'name' => 'Ukrainian', 'native_name' => 'Українська', 'locale' => 'uk', 'flag' => '🇺🇦', 'rtl' => false ),
        'th' => array( 'name' => 'Thai', 'native_name' => 'ไทย', 'locale' => 'th', 'flag' => '🇹🇭', 'rtl' => false ),
        'vi' => array( 'name' => 'Vietnamese', 'native_name' => 'Tiếng Việt', 'locale' => 'vi', 'flag' => '🇻🇳', 'rtl' => false ),
        'id' => array( 'name' => 'Indonesian', 'native_name' => 'Bahasa Indonesia', 'locale' => 'id_ID', 'flag' => '🇮🇩', 'rtl' => false ),
        'ms' => array( 'name' => 'Malay', 'native_name' => 'Bahasa Melayu', 'locale' => 'ms_MY', 'flag' => '🇲🇾', 'rtl' => false ),
        'sk' => array( 'name' => 'Slovak', 'native_name' => 'Slovenčina', 'locale' => 'sk_SK', 'flag' => '🇸🇰', 'rtl' => false ),
        'sl' => array( 'name' => 'Slovenian', 'native_name' => 'Slovenščina', 'locale' => 'sl_SI', 'flag' => '🇸🇮', 'rtl' => false ),
        'hr' => array( 'name' => 'Croatian', 'native_name' => 'Hrvatski', 'locale' => 'hr', 'flag' => '🇭🇷', 'rtl' => false ),
        'sr' => array( 'name' => 'Serbian', 'native_name' => 'Српски', 'locale' => 'sr_RS', 'flag' => '🇷🇸', 'rtl' => false ),
        'lt' => array( 'name' => 'Lithuanian', 'native_name' => 'Lietuvių', 'locale' => 'lt_LT', 'flag' => '🇱🇹', 'rtl' => false ),
        'lv' => array( 'name' => 'Latvian', 'native_name' => 'Latviešu', 'locale' => 'lv', 'flag' => '🇱🇻', 'rtl' => false ),
        'et' => array( 'name' => 'Estonian', 'native_name' => 'Eesti', 'locale' => 'et', 'flag' => '🇪🇪', 'rtl' => false ),
        'fa' => array( 'name' => 'Persian', 'native_name' => 'فارسی', 'locale' => 'fa_IR', 'flag' => '🇮🇷', 'rtl' => true ),
        'ur' => array( 'name' => 'Urdu', 'native_name' => 'اردو', 'locale' => 'ur', 'flag' => '🇵🇰', 'rtl' => true ),
        'bn' => array( 'name' => 'Bengali', 'native_name' => 'বাংলা', 'locale' => 'bn_BD', 'flag' => '🇧🇩', 'rtl' => false ),
        'ta' => array( 'name' => 'Tamil', 'native_name' => 'தமிழ்', 'locale' => 'ta_IN', 'flag' => '🇮🇳', 'rtl' => false ),
        'sw' => array( 'name' => 'Swahili', 'native_name' => 'Kiswahili', 'locale' => 'sw', 'flag' => '🇰🇪', 'rtl' => false ),
        'af' => array( 'name' => 'Afrikaans', 'native_name' => 'Afrikaans', 'locale' => 'af', 'flag' => '🇿🇦', 'rtl' => false ),
        'ca' => array( 'name' => 'Catalan', 'native_name' => 'Català', 'locale' => 'ca', 'flag' => '🏴', 'rtl' => false ),
        'eu' => array( 'name' => 'Basque', 'native_name' => 'Euskara', 'locale' => 'eu', 'flag' => '🏴', 'rtl' => false ),
        'gl' => array( 'name' => 'Galician', 'native_name' => 'Galego', 'locale' => 'gl_ES', 'flag' => '🏴', 'rtl' => false ),
    );

    public function __construct( cache\CacheManager $cache ) {
        $this->cache = $cache;
        $this->default_language = $this->resolve_default_language();
        $this->current_language = $this->default_language;
    }

    /**
     * Get the current language code.
     */
    public function get_current_language(): string {
        return $this->current_language;
    }

    /**
     * Set the current language.
     */
    public function set_current_language( string $code ): void {
        $this->current_language = $code;
    }

    /**
     * Get the default language code.
     */
    public function get_default_language(): string {
        return $this->default_language;
    }

    /**
     * Check if a language code is the default language.
     */
    public function is_default_language( string $code = '' ): bool {
        if ( empty( $code ) ) {
            $code = $this->current_language;
        }
        return $code === $this->default_language;
    }

    /**
     * Get all active languages from the database.
     *
     * @return array Array of language objects.
     */
    public function get_active_languages(): array {
        if ( null !== $this->active_languages ) {
            return $this->active_languages;
        }

        $cached = $this->cache->get( 'active_languages' );
        if ( false !== $cached ) {
            $this->active_languages = $cached;
            return $this->active_languages;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        $results = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE is_active = 1 ORDER BY sort_order ASC, name ASC",
            ARRAY_A
        );

        $this->active_languages = $results ?: array();
        $this->cache->set( 'active_languages', $this->active_languages, HOUR_IN_SECONDS );

        return $this->active_languages;
    }

    /**
     * Get a single language by code.
     *
     * @param string $code Language code.
     * @return array|null Language data or null.
     */
    public function get_language( string $code ): ?array {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        $result = $wpdb->get_row(
            $wpdb->prepare( "SELECT * FROM {$table} WHERE code = %s", $code ),
            ARRAY_A
        );

        return $result ?: null;
    }

    /**
     * Get all languages (including inactive).
     */
    public function get_all_languages(): array {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        $results = $wpdb->get_results(
            "SELECT * FROM {$table} ORDER BY sort_order ASC, name ASC",
            ARRAY_A
        );

        return $results ?: array();
    }

    /**
     * Add a language.
     *
     * @param array $data Language data.
     * @return int|false Inserted ID or false.
     */
    public function add_language( array $data ) {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        // Fill missing fields from built-in catalog data.
        $code = $data['code'] ?? '';
        if ( isset( self::LANGUAGE_DATA[ $code ] ) ) {
            $builtin = self::LANGUAGE_DATA[ $code ];
            foreach ( $builtin as $key => $value ) {
                if ( ! isset( $data[ $key ] ) || '' === $data[ $key ] ) {
                    $data[ $key ] = $value;
                }
            }
        }

        $result = $wpdb->insert(
            $table,
            array(
                'code'        => sanitize_text_field( $data['code'] ),
                'name'        => sanitize_text_field( $data['name'] ?? '' ),
                'native_name' => sanitize_text_field( $data['native_name'] ?? '' ),
                'locale'      => sanitize_text_field( $data['locale'] ?? '' ),
                'flag'        => sanitize_text_field( $data['flag'] ?? '' ),
                'is_default'  => intval( $data['is_default'] ?? 0 ),
                'is_active'   => intval( $data['is_active'] ?? 1 ),
                'sort_order'  => intval( $data['sort_order'] ?? 0 ),
                'rtl'         => intval( $data['rtl'] ?? 0 ),
            ),
            array( '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%d', '%d' )
        );

        if ( $result ) {
            $this->invalidate_cache();
            return $wpdb->insert_id;
        }

        return false;
    }

    /**
     * Update a language.
     */
    public function update_language( string $code, array $data ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        $update_data = array();
        $format = array();

        $allowed = array( 'name', 'native_name', 'locale', 'flag', 'is_default', 'is_active', 'sort_order', 'rtl', 'date_format' );

        foreach ( $allowed as $field ) {
            if ( isset( $data[ $field ] ) ) {
                $update_data[ $field ] = $data[ $field ];
                $format[] = in_array( $field, array( 'is_default', 'is_active', 'sort_order', 'rtl' ), true ) ? '%d' : '%s';
            }
        }

        if ( empty( $update_data ) ) {
            return false;
        }

        // If setting as default, unset all others.
        if ( ! empty( $data['is_default'] ) ) {
            $wpdb->update( $table, array( 'is_default' => 0 ), array( 'is_default' => 1 ), array( '%d' ), array( '%d' ) );
        }

        $result = $wpdb->update( $table, $update_data, array( 'code' => $code ), $format, array( '%s' ) );

        $this->invalidate_cache();

        return false !== $result;
    }

    /**
     * Delete a language.
     */
    public function delete_language( string $code ): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        // Cannot delete default language.
        $lang = $this->get_language( $code );
        if ( $lang && $lang['is_default'] ) {
            return false;
        }

        $result = $wpdb->delete( $table, array( 'code' => $code ), array( '%s' ) );
        $this->invalidate_cache();

        return false !== $result;
    }

    /**
     * Get the built-in language data catalog.
     */
    public static function get_available_languages(): array {
        return self::LANGUAGE_DATA;
    }

    /**
     * Invalidate language cache.
     */
    public function invalidate_cache(): void {
        $this->active_languages = null;
        $this->cache->delete( 'active_languages' );
        delete_transient( 'wptranslate_active_languages' );
    }

    /**
     * Resolve the default language code from options or site locale.
     */
    private function resolve_default_language(): string {
        global $wpdb;
        $table = $wpdb->prefix . 'wpt_languages';

        // Check if the table exists first (during activation it might not yet).
        $table_exists = $wpdb->get_var(
            $wpdb->prepare( "SHOW TABLES LIKE %s", $table )
        );

        if ( $table_exists ) {
            $default = $wpdb->get_var(
                "SELECT code FROM {$table} WHERE is_default = 1 LIMIT 1"
            );
            if ( $default ) {
                return $default;
            }
        }

        // Fall back to site locale.
        $locale = get_locale();
        $code = strtolower( substr( $locale, 0, 2 ) );

        return $code ?: 'en';
    }

    /**
     * Check if a language code is RTL.
     */
    public function is_rtl( string $code = '' ): bool {
        if ( empty( $code ) ) {
            $code = $this->current_language;
        }

        $lang = $this->get_language( $code );
        if ( $lang ) {
            return (bool) $lang['rtl'];
        }

        // Check built-in data.
        if ( isset( self::LANGUAGE_DATA[ $code ] ) ) {
            return self::LANGUAGE_DATA[ $code ]['rtl'];
        }

        return false;
    }

    /**
     * Get language code from WordPress locale.
     */
    public function locale_to_code( string $locale ): string {
        foreach ( self::LANGUAGE_DATA as $code => $data ) {
            if ( $data['locale'] === $locale ) {
                return $code;
            }
        }

        return strtolower( substr( $locale, 0, 2 ) );
    }
}
