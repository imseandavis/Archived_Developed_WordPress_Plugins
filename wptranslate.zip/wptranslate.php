<?php
/**
 * Plugin Name:       WPTranslate
 * Plugin URI:        https://wptranslate.io
 * Description:       AI-powered multilingual translation for WordPress using Claude, OpenAI, and DeepL.
 * Version:           1.0.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            WPTranslate
 * Author URI:        https://wptranslate.io
 * License:           GPL v2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       wptranslate
 * Domain Path:       /languages
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'WPTRANSLATE_VERSION', '1.0.0' );
define( 'WPTRANSLATE_PLUGIN_FILE', __FILE__ );
define( 'WPTRANSLATE_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'WPTRANSLATE_PLUGIN_URL', plugin_dir_url( __FILE__ ) );
define( 'WPTRANSLATE_PLUGIN_BASENAME', plugin_basename( __FILE__ ) );
define( 'WPTRANSLATE_DB_VERSION', '1.0.0' );

// Autoloader.
if ( file_exists( WPTRANSLATE_PLUGIN_DIR . 'vendor/autoload.php' ) ) {
    require_once WPTRANSLATE_PLUGIN_DIR . 'vendor/autoload.php';
} else {
    // Fallback autoloader for when Composer is not available.
    spl_autoload_register( function ( $class ) {
        $prefix    = 'WPTranslate\\';
        $base_dir  = WPTRANSLATE_PLUGIN_DIR . 'includes/';
        $len       = strlen( $prefix );

        if ( strncmp( $prefix, $class, $len ) !== 0 ) {
            return;
        }

        $relative_class = substr( $class, $len );
        $file           = $base_dir . str_replace( '\\', '/', $relative_class ) . '.php';

        if ( file_exists( $file ) ) {
            require $file;
        }
    } );
}

// Activation hook.
register_activation_hook( __FILE__, array( 'WPTranslate\\Activator', 'activate' ) );

// Deactivation hook.
register_deactivation_hook( __FILE__, array( 'WPTranslate\\Deactivator', 'deactivate' ) );

// Register custom cron interval.
add_filter( 'cron_schedules', function( $schedules ) {
    $schedules['every_five_minutes'] = array(
        'interval' => 300,
        'display'  => __( 'Every Five Minutes', 'wptranslate' ),
    );
    return $schedules;
} );

// WP-CLI commands.
if ( defined( 'WP_CLI' ) && WP_CLI ) {
    require_once WPTRANSLATE_PLUGIN_DIR . 'includes/CLI/Commands.php';
}

/**
 * Bootstrap the plugin.
 */
function wptranslate_init() {
    $plugin = WPTranslate\Plugin::get_instance();
    $plugin->run();
}
add_action( 'plugins_loaded', 'wptranslate_init' );

/**
 * Get the current language.
 *
 * @return string Language code.
 */
function wptranslate_current_language() {
    return WPTranslate\Plugin::get_instance()->get_language_manager()->get_current_language();
}

/**
 * Get all active languages.
 *
 * @return array Array of language data.
 */
function wptranslate_get_languages() {
    return WPTranslate\Plugin::get_instance()->get_language_manager()->get_active_languages();
}

/**
 * Get a translated post.
 *
 * @param int    $post_id Post ID.
 * @param string $lang    Target language code.
 * @return int|null Translated post ID or null.
 */
function wptranslate_get_translation( $post_id, $lang ) {
    return WPTranslate\Plugin::get_instance()->get_translation_manager()->get_translation_id( $post_id, $lang );
}

/**
 * Display the language switcher.
 *
 * @param array $args Switcher arguments.
 */
function wptranslate_language_switcher( $args = array() ) {
    echo WPTranslate\Plugin::get_instance()->get_language_switcher()->render( $args );
}

/**
 * Translate a string programmatically.
 *
 * @param string $string String to translate.
 * @param string $lang   Target language code.
 * @param string $domain Text domain.
 * @return string Translated string.
 */
function wptranslate_translate_string( $string, $lang, $domain = 'default' ) {
    return WPTranslate\Plugin::get_instance()->get_string_translation()->translate( $string, $lang, $domain );
}
