=== WPTranslate - AI-Powered Translation ===
Contributors: wptranslate
Tags: translation, multilingual, ai, claude, openai, deepl, language, i18n
Requires at least: 6.0
Tested up to: 6.7
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI-powered multilingual translation for WordPress using Claude, OpenAI, and DeepL. Enterprise-grade translation workflow with zero front-end performance impact.

== Description ==

WPTranslate transforms your WordPress site into a fully multilingual experience using AI-powered translations from Claude (Anthropic), OpenAI, and DeepL.

**Key Features:**

* **AI-Powered Translation** — Translate posts, pages, custom post types, taxonomies, menus, and theme strings using Claude, OpenAI, or DeepL
* **Zero Performance Impact** — Each translation is a native WordPress post. No output buffering, no DOM parsing, no overhead on page load
* **Full Page Cache Compatible** — Works out of the box with Varnish, WP Super Cache, W3 Total Cache, Cloudflare, LiteSpeed Cache, and any other caching solution
* **Translator Workflow** — Assign translations to human translators with a review and approval workflow
* **Side-by-Side Editor** — Visual translation editor with diff highlighting, synced scrolling, and paragraph-level control
* **AI Learning Loop** — Translator corrections automatically improve future AI translations through a feedback system
* **Translation Memory** — Reuse previously approved human translations to save API costs
* **Custom Glossary** — Define exact translations for domain-specific terminology
* **SEO Optimized** — Automatic hreflang tags, translated slugs, per-language XML sitemaps
* **WooCommerce Compatible** — Translate products, categories, checkout, and email notifications
* **Language Switcher** — Widget, shortcode, Gutenberg block, nav menu item, and PHP function
* **45+ Languages** — Built-in support for 45+ languages with RTL support
* **WP-CLI Support** — Full command-line interface for bulk operations
* **REST API** — Complete REST API for headless and custom integrations
* **Migration Tools** — Import from TranslatePress with one click

**Translation Providers:**

* **Claude (Anthropic)** — Models: Claude Sonnet, Opus, Haiku. Best for nuanced, context-aware translations
* **OpenAI** — Models: GPT-4o, GPT-4o mini, GPT-4 Turbo. Widely used, fast translations
* **DeepL** — Free and Pro APIs. Best for European languages with formality controls

**Enterprise Features:**

* Custom translator and translation manager roles
* Translation assignment with auto-routing
* Review and approval workflow
* Correction tracking with automatic glossary suggestions
* Site context configuration for domain-specific accuracy
* Per-language provider overrides
* API budget controls and usage tracking
* Translation memory with TMX import/export

== Installation ==

1. Upload the `wptranslate` folder to `/wp-content/plugins/`
2. Activate the plugin through the 'Plugins' menu
3. Go to WPTranslate → Languages and add your target languages
4. Go to WPTranslate → Settings and configure at least one translation provider API key
5. Start translating from any post or page editor

**Important:** WPTranslate cannot run alongside other translation plugins (WPML, TranslatePress, Polylang, etc.). Deactivate them before activating WPTranslate. You can migrate your existing translations afterward using WPTranslate → Tools.

== Frequently Asked Questions ==

= Will this slow down my site? =

No. WPTranslate uses a separate-post architecture where each translation is a native WordPress post. There is zero overhead on page load — no output buffering, no string replacement. The only runtime work is gettext string replacement for theme/plugin UI strings, which is served from an in-memory cache.

= How much does translation cost? =

The plugin is free. You pay only for the AI translation API usage:
* **Claude**: ~$3-15 per million input tokens depending on model
* **OpenAI**: ~$2.50-10 per million tokens depending on model
* **DeepL**: Free tier available (500,000 chars/month), Pro from $5.49/month

A typical blog post costs $0.01-0.05 to translate depending on length and provider.

= Can I use multiple translation providers? =

Yes. You can set a primary provider and fallback provider(s). You can also assign different providers per language (e.g., DeepL for European languages, Claude for Asian languages).

= Does it work with my theme? =

WPTranslate works with any properly coded WordPress theme. It has special compatibility with popular themes including Astra, GeneratePress, Divi, Avada, and OceanWP.

= Can I migrate from TranslatePress? =

Yes. Go to WPTranslate → Tools → Import from TranslatePress. The tool reads TranslatePress's database tables (even after TranslatePress is deactivated) and imports all translations.

= Does it support WooCommerce? =

Yes. Products, categories, attributes, variations, cart, checkout, and email notifications are all translatable.

= Is it compatible with Yoast SEO / RankMath? =

Yes. SEO titles, meta descriptions, and focus keywords are automatically translated along with post content.

== Changelog ==

= 1.0.0 =
* Initial release
* AI translation via Claude, OpenAI, and DeepL
* Separate-post translation architecture
* Language management with 45+ built-in languages
* URL rewriting (directory, subdomain, parameter formats)
* Language switcher (widget, shortcode, block, nav menu, PHP)
* String translation system with gettext hooks
* Translation cache with 3-layer architecture
* Translator roles and review workflow
* Side-by-side translation editor with diff highlighting
* AI correction feedback loop and auto-glossary
* Translation memory system
* Custom glossary management
* WooCommerce compatibility
* SEO meta translation (Yoast, RankMath, AIOSEO)
* TranslatePress migration tool
* WP-CLI commands
* REST API
* Multisite compatible
* RTL support

== Screenshots ==

1. Dashboard showing translation status overview
2. Language management with drag-and-drop ordering
3. Translation settings with provider configuration
4. Side-by-side translation editor with diff highlighting
5. String translation table with inline editing
6. Translation queue with status tracking
7. Language switcher widget configuration
8. Post editor translation metabox

== Upgrade Notice ==

= 1.0.0 =
Initial release of WPTranslate.
