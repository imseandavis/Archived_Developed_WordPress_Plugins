/**
 * WPTranslate Front-End JavaScript
 * Minimal — only handles language switcher dropdown navigation.
 */
(function() {
    'use strict';

    document.addEventListener('DOMContentLoaded', function() {
        var selects = document.querySelectorAll('.wptranslate-switcher__select');
        for (var i = 0; i < selects.length; i++) {
            selects[i].addEventListener('change', function() {
                if (this.value) {
                    window.location.href = this.value;
                }
            });
        }
    });
})();
