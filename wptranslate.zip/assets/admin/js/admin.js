/**
 * WPTranslate Admin JavaScript
 *
 * Production-ready admin UI controller. Provides toast notifications,
 * confirmation modals, button loading states, progress bars, inline editing,
 * modal management, and AJAX handlers for every interactive element across
 * Dashboard, Languages, Settings, String Translation, Translation Queue,
 * Translators, and Tools admin pages.
 */
(function($) {
    'use strict';

    var WPTranslate = window.WPTranslate = {

        // -------------------------------------------------------------------
        // Toast Notification System
        // -------------------------------------------------------------------

        /**
         * Show a slide-in toast notification at top-right.
         *
         * @param {string} message User-facing message text.
         * @param {string} type    One of 'success', 'error', 'warning', 'info'.
         */
        showToast: function(message, type) {
            type = type || 'info';

            var $container = $('#wptranslate-toast-container');
            if (!$container.length) {
                $container = $('<div id="wptranslate-toast-container"></div>').appendTo('body');
            }

            var $toast = $(
                '<div class="wptranslate-toast wptranslate-toast--' + type + '">' +
                    '<span class="wptranslate-toast__message">' + $('<span>').text(message).html() + '</span>' +
                    '<button type="button" class="wptranslate-toast__close" aria-label="Close">&times;</button>' +
                '</div>'
            );

            $container.append($toast);

            // Trigger reflow then add visible class for slide-in animation.
            $toast[0].offsetHeight; // eslint-disable-line no-unused-expressions
            $toast.addClass('wptranslate-toast--visible');

            // Close button.
            $toast.find('.wptranslate-toast__close').on('click', function() {
                WPTranslate._dismissToast($toast);
            });

            // Auto-dismiss after 4 seconds.
            setTimeout(function() {
                WPTranslate._dismissToast($toast);
            }, 4000);
        },

        /**
         * Dismiss a toast with slide-out animation.
         *
         * @param {jQuery} $toast The toast element.
         */
        _dismissToast: function($toast) {
            if ($toast.hasClass('wptranslate-toast--dismissed')) {
                return;
            }
            $toast.addClass('wptranslate-toast--dismissed');
            $toast.removeClass('wptranslate-toast--visible');
            setTimeout(function() {
                $toast.remove();
            }, 300);
        },

        // -------------------------------------------------------------------
        // Confirmation Modal
        // -------------------------------------------------------------------

        /**
         * Show a confirmation modal for destructive actions.
         *
         * @param {string}   message  The question to display.
         * @param {Function} callback Called with no arguments when user clicks Yes.
         */
        confirmAction: function(message, callback) {
            // Remove any existing confirmation modal.
            $('#wptranslate-confirm-overlay').remove();

            var $overlay = $(
                '<div id="wptranslate-confirm-overlay" class="wptranslate-modal-overlay">' +
                    '<div class="wptranslate-confirm-dialog">' +
                        '<p class="wptranslate-confirm-dialog__message">' + $('<span>').text(message).html() + '</p>' +
                        '<div class="wptranslate-confirm-dialog__buttons">' +
                            '<button type="button" class="button button-primary wptranslate-confirm-yes">' +
                                (wptranslateAdmin.i18n.yes || 'Yes') +
                            '</button>' +
                            '<button type="button" class="button wptranslate-confirm-no">' +
                                (wptranslateAdmin.i18n.no || 'No') +
                            '</button>' +
                        '</div>' +
                    '</div>' +
                '</div>'
            );

            $('body').append($overlay);

            $overlay.find('.wptranslate-confirm-yes').on('click', function() {
                $overlay.remove();
                if (typeof callback === 'function') {
                    callback();
                }
            });

            $overlay.find('.wptranslate-confirm-no').on('click', function() {
                $overlay.remove();
            });

            // ESC key closes.
            $(document).one('keydown.wptranslateConfirm', function(e) {
                if (e.key === 'Escape') {
                    $overlay.remove();
                }
            });
        },

        // -------------------------------------------------------------------
        // Button Loading States
        // -------------------------------------------------------------------

        /**
         * Put a button into loading state: disable, show spinner + loading text.
         *
         * @param {jQuery} $btn        The button element.
         * @param {string} loadingText Text to show while loading.
         */
        setButtonLoading: function($btn, loadingText) {
            $btn.data('wpt-original-text', $btn.html());
            $btn.prop('disabled', true)
                .addClass('wptranslate-btn--loading')
                .html('<span class="spinner is-active" style="margin:0 4px 0 0;float:none;"></span> ' + (loadingText || wptranslateAdmin.i18n.loading));
        },

        /**
         * Restore a button from loading state.
         *
         * @param {jQuery} $btn The button element.
         */
        resetButton: function($btn) {
            var original = $btn.data('wpt-original-text');
            if (original) {
                $btn.html(original);
            }
            $btn.prop('disabled', false).removeClass('wptranslate-btn--loading');
        },

        // -------------------------------------------------------------------
        // Modal System
        // -------------------------------------------------------------------

        /**
         * Open a modal by ID. Creates an overlay, handles ESC and overlay click.
         *
         * @param {string} modalId The ID of the .wptranslate-modal element.
         */
        openModal: function(modalId) {
            var $modal = $('#' + modalId);
            if (!$modal.length) {
                return;
            }

            // Create overlay if not present.
            var $overlay = $modal.prev('.wptranslate-modal-overlay');
            if (!$overlay.length) {
                $overlay = $('<div class="wptranslate-modal-overlay"></div>').insertBefore($modal);
            }

            $overlay.show();
            // Remove any inline display:none from PHP, use CSS class for flex centering.
            $modal.css('display', '').addClass('wptranslate-modal--open');

            // Close on overlay click.
            $overlay.off('click.wptModal').on('click.wptModal', function() {
                WPTranslate.closeModal(modalId);
            });

            // Close on ESC key.
            $(document).on('keydown.wptModal_' + modalId, function(e) {
                if (e.key === 'Escape') {
                    WPTranslate.closeModal(modalId);
                }
            });
        },

        /**
         * Close a modal by ID.
         *
         * @param {string} modalId The ID of the .wptranslate-modal element.
         */
        closeModal: function(modalId) {
            var $modal = $('#' + modalId);
            $modal.removeClass('wptranslate-modal--open');

            var $overlay = $modal.prev('.wptranslate-modal-overlay');
            $overlay.hide();

            $(document).off('keydown.wptModal_' + modalId);
        },

        // -------------------------------------------------------------------
        // Progress Bar for Bulk Operations
        // -------------------------------------------------------------------

        /**
         * Show a progress bar inside a container.
         *
         * @param {string} containerId The ID of the container element.
         */
        startProgress: function(containerId) {
            var $container = $('#' + containerId);
            $container.show()
                .find('.wptranslate-progress-bar__fill').css('width', '0%');
            $container.find('.wptranslate-progress-text').text('0%');
        },

        /**
         * Update a progress bar.
         *
         * @param {string} containerId The container element ID.
         * @param {number} percent     Progress percentage (0-100).
         * @param {string} statusText  Optional status text.
         */
        updateProgress: function(containerId, percent, statusText) {
            var $container = $('#' + containerId);
            $container.find('.wptranslate-progress-bar__fill').css('width', percent + '%');
            $container.find('.wptranslate-progress-text').text(statusText || (percent + '%'));
        },

        /**
         * Poll bulk translation progress via AJAX.
         *
         * @param {string} batchId     The batch identifier.
         * @param {string} containerId The progress container ID.
         * @param {jQuery} $btn        Optional button to re-enable on completion.
         */
        pollProgress: function(batchId, containerId, $btn) {
            $.post(wptranslateAdmin.ajaxUrl, {
                action: 'wptranslate_bulk_progress',
                nonce: wptranslateAdmin.nonce,
                batch_id: batchId
            }).done(function(response) {
                if (response.success) {
                    var pct = response.data.percent || 0;
                    var statusText = response.data.status_text || (pct + '%');
                    WPTranslate.updateProgress(containerId, pct, statusText);

                    if (response.data.complete) {
                        WPTranslate.showToast(response.data.message || wptranslateAdmin.i18n.complete, 'success');
                        if ($btn) {
                            WPTranslate.resetButton($btn);
                        }
                    } else {
                        setTimeout(function() {
                            WPTranslate.pollProgress(batchId, containerId, $btn);
                        }, 3000);
                    }
                }
            }).fail(function() {
                WPTranslate.showToast(wptranslateAdmin.i18n.error, 'error');
                if ($btn) {
                    WPTranslate.resetButton($btn);
                }
            });
        },

        // -------------------------------------------------------------------
        // AJAX Helper
        // -------------------------------------------------------------------

        /**
         * Central AJAX helper that wraps jQuery.ajax with standard patterns.
         *
         * @param {Object}   opts
         * @param {string}   opts.action     WordPress AJAX action name.
         * @param {Object}   opts.data       Additional POST data (nonce added automatically).
         * @param {jQuery}   opts.$btn       Optional button to show loading state.
         * @param {string}   opts.loadingText Text for the button while loading.
         * @param {Function} opts.success    Callback on success(response.data).
         * @param {Function} opts.error      Callback on error(message).
         * @param {boolean}  opts.isFormData True if opts.data is a FormData instance.
         */
        ajax: function(opts) {
            var postData;

            if (opts.isFormData) {
                postData = opts.data;
                postData.append('action', opts.action);
                postData.append('nonce', wptranslateAdmin.nonce);
            } else {
                postData = $.extend({
                    action: opts.action,
                    nonce: wptranslateAdmin.nonce
                }, opts.data || {});
            }

            if (opts.$btn) {
                WPTranslate.setButtonLoading(opts.$btn, opts.loadingText || wptranslateAdmin.i18n.loading);
            }

            var ajaxOpts = {
                url: wptranslateAdmin.ajaxUrl,
                type: 'POST',
                data: postData
            };

            if (opts.isFormData) {
                ajaxOpts.processData = false;
                ajaxOpts.contentType = false;
            }

            $.ajax(ajaxOpts).done(function(response) {
                if (opts.$btn) {
                    WPTranslate.resetButton(opts.$btn);
                }

                if (response.success) {
                    if (typeof opts.success === 'function') {
                        opts.success(response.data);
                    } else {
                        WPTranslate.showToast(response.data.message || wptranslateAdmin.i18n.saved, 'success');
                    }
                } else {
                    var msg = (response.data && response.data.message) ? response.data.message : wptranslateAdmin.i18n.error;
                    if (typeof opts.error === 'function') {
                        opts.error(msg);
                    } else {
                        WPTranslate.showToast(msg, 'error');
                    }
                }
            }).fail(function() {
                if (opts.$btn) {
                    WPTranslate.resetButton(opts.$btn);
                }
                var msg = wptranslateAdmin.i18n.error;
                if (typeof opts.error === 'function') {
                    opts.error(msg);
                } else {
                    WPTranslate.showToast(msg, 'error');
                }
            });
        },

        // -------------------------------------------------------------------
        // File Download Helper
        // -------------------------------------------------------------------

        /**
         * Trigger a file download from AJAX response content.
         *
         * @param {string} content  The file content.
         * @param {string} filename The suggested filename.
         * @param {string} mimeType Optional MIME type.
         */
        downloadFile: function(content, filename, mimeType) {
            mimeType = mimeType || 'text/plain';
            var blob = new Blob([content], { type: mimeType });
            var url = URL.createObjectURL(blob);
            var a = document.createElement('a');
            a.href = url;
            a.download = filename;
            document.body.appendChild(a);
            a.click();
            setTimeout(function() {
                document.body.removeChild(a);
                URL.revokeObjectURL(url);
            }, 100);
        },

        // -------------------------------------------------------------------
        // Initialization
        // -------------------------------------------------------------------

        init: function() {
            this.bindModalCloseButtons();
            this.bindDashboardHandlers();
            this.bindLanguageHandlers();
            this.bindSettingsHandlers();
            this.bindStringTranslationHandlers();
            this.bindQueueHandlers();
            this.bindTranslatorHandlers();
            this.bindToolsHandlers();
            this.bindMetaboxHandlers();
            this.initWizard();
            this.initCollapsibles();
        },

        // -------------------------------------------------------------------
        // Modal Close (global for all modals)
        // -------------------------------------------------------------------

        bindModalCloseButtons: function() {
            $(document).on('click', '.wptranslate-modal__close', function(e) {
                e.preventDefault();
                var $modal = $(this).closest('.wptranslate-modal');
                if ($modal.length) {
                    WPTranslate.closeModal($modal.attr('id'));
                }
            });
        },

        // -------------------------------------------------------------------
        // Dashboard Handlers
        // -------------------------------------------------------------------

        bindDashboardHandlers: function() {

            // #wptranslate-translate-all-btn — bulk translate all content for a language.
            $(document).on('click', '#wptranslate-translate-all-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var lang = $('#wptranslate-translate-all-lang').val();

                if (!lang) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.select_language, 'warning');
                    return;
                }

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_bulk, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_bulk_translate_all',
                        data: { target_lang: lang },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.translating,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            // Show a notice with link to queue and auto-refresh dashboard.
                            var $card = $btn.closest('.wptranslate-card');
                            $card.find('.wptranslate-bulk-status').remove();
                            $card.append(
                                '<div class="wptranslate-bulk-status" style="margin-top: 12px; padding: 10px 14px; background: var(--wpt-success-light, #ECFDF5); border: 1px solid var(--wpt-success-border, #A7F3D0); border-radius: 6px; font-size: 13px;">' +
                                '<strong>' + (data.message || 'Jobs queued!') + '</strong> ' +
                                '<a href="' + wptranslateAdmin.adminUrl + 'admin.php?page=wptranslate-queue">' +
                                wptranslateAdmin.i18n.view_queue + '</a>' +
                                '</div>'
                            );
                            // Refresh page after 3s to update stats.
                            setTimeout(function() { location.reload(); }, 3000);
                        }
                    });
                });
            });
        },

        // -------------------------------------------------------------------
        // Languages Handlers
        // -------------------------------------------------------------------

        bindLanguageHandlers: function() {

            // --- Sortable reorder ---
            var $sortable = $('#wptranslate-sortable-languages');
            if ($sortable.length && typeof $.fn.sortable !== 'undefined') {
                $sortable.sortable({
                    handle: '.wptranslate-drag-handle',
                    placeholder: 'wptranslate-sort-placeholder',
                    axis: 'y',
                    update: function() {
                        var order = [];
                        $sortable.find('.wptranslate-language-row').each(function() {
                            order.push($(this).data('code'));
                        });

                        WPTranslate.ajax({
                            action: 'wptranslate_reorder_languages',
                            data: { order: order },
                            success: function(data) {
                                WPTranslate.showToast(data.message, 'success');
                            }
                        });
                    }
                });
            }

            // --- Add language from catalog ---
            $(document).on('click', '#wptranslate-add-language-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var code = $('#wptranslate-language-select').val();

                if (!code) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.select_language, 'warning');
                    return;
                }

                // Get display data from the select option.
                var optionText = $('#wptranslate-language-select option:selected').text().trim();

                WPTranslate.ajax({
                    action: 'wptranslate_add_language',
                    data: { code: code },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Remove from catalog select.
                        $('#wptranslate-language-select option[value="' + code + '"]').remove();
                        // Reload to show the new row properly (language data comes from server).
                        setTimeout(function() { location.reload(); }, 800);
                    }
                });
            });

            // --- Add custom language ---
            $(document).on('click', '#wptranslate-add-custom-language-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var code = $('#custom-lang-code').val().trim();
                var name = $('#custom-lang-name').val().trim();

                if (!code || !name) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.fill_required, 'warning');
                    return;
                }

                WPTranslate.ajax({
                    action: 'wptranslate_add_language',
                    data: {
                        code: code,
                        name: name,
                        native_name: $('#custom-lang-native').val().trim(),
                        locale: $('#custom-lang-locale').val().trim(),
                        flag: $('#custom-lang-flag').val().trim(),
                        rtl: $('#custom-lang-rtl').is(':checked') ? 1 : 0
                    },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Clear inputs.
                        $('#custom-lang-code, #custom-lang-name, #custom-lang-native, #custom-lang-locale, #custom-lang-flag').val('');
                        $('#custom-lang-rtl').prop('checked', false);
                        setTimeout(function() { location.reload(); }, 800);
                    }
                });
            });

            // --- Open edit language modal ---
            $(document).on('click', '.wptranslate-edit-language', function(e) {
                e.preventDefault();
                var code = $(this).data('code');
                var $row = $(this).closest('.wptranslate-language-row');

                // Populate modal fields from the row inputs.
                $('#edit-lang-code').val(code);
                $('#edit-lang-name').val($row.find('input[name$="[name]"]').val());
                $('#edit-lang-native').val($row.find('input[name$="[native_name]"]').val());
                $('#edit-lang-flag').val($row.find('.wptranslate-flag-input').val());
                $('#edit-lang-locale').val('');
                $('#edit-lang-rtl').prop('checked', $row.find('input[name$="[rtl]"]').is(':checked'));
                $('#edit-lang-date-format').val('');

                WPTranslate.openModal('wptranslate-edit-language-modal');
            });

            // --- Save language edit from modal ---
            $(document).on('click', '#wptranslate-save-language-edit', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var code = $('#edit-lang-code').val();

                WPTranslate.ajax({
                    action: 'wptranslate_update_language',
                    data: {
                        code: code,
                        name: $('#edit-lang-name').val(),
                        native_name: $('#edit-lang-native').val(),
                        flag: $('#edit-lang-flag').val(),
                        locale: $('#edit-lang-locale').val(),
                        rtl: $('#edit-lang-rtl').is(':checked') ? 1 : 0,
                        date_format: $('#edit-lang-date-format').val()
                    },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        WPTranslate.closeModal('wptranslate-edit-language-modal');

                        // Update the row in-place.
                        var $row = $('.wptranslate-language-row[data-code="' + code + '"]');
                        $row.find('input[name$="[name]"]').val($('#edit-lang-name').val());
                        $row.find('input[name$="[native_name]"]').val($('#edit-lang-native').val());
                        $row.find('.wptranslate-flag-input').val($('#edit-lang-flag').val());
                    }
                });
            });

            // --- Delete language ---
            $(document).on('click', '.wptranslate-delete-language', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var code = $btn.data('code');
                var name = $btn.data('name') || code;

                WPTranslate.confirmAction(
                    wptranslateAdmin.i18n.confirm_remove_lang.replace('%s', name),
                    function() {
                        WPTranslate.ajax({
                            action: 'wptranslate_delete_language',
                            data: { code: code },
                            $btn: $btn,
                            loadingText: wptranslateAdmin.i18n.loading,
                            success: function(data) {
                                WPTranslate.showToast(data.message, 'success');
                                // Remove the row from the table.
                                $('.wptranslate-language-row[data-code="' + code + '"]').fadeOut(300, function() {
                                    $(this).remove();
                                });
                            }
                        });
                    }
                );
            });

            // --- Save all languages (Save Changes button) ---
            $(document).on('click', '#wptranslate-save-languages', function(e) {
                e.preventDefault();
                var $btn = $(this);

                // Gather all language data from the form inputs.
                var languages = {};
                $('#wptranslate-sortable-languages .wptranslate-language-row').each(function() {
                    var code = $(this).data('code');
                    languages[code] = {
                        name: $(this).find('input[name$="[name]"]').val(),
                        native_name: $(this).find('input[name$="[native_name]"]').val(),
                        flag: $(this).find('.wptranslate-flag-input').val(),
                        rtl: $(this).find('input[name$="[rtl]"]').is(':checked') ? 1 : 0,
                        is_active: $(this).find('.wptranslate-toggle-active').is(':checked') ? 1 : 0
                    };
                });

                var defaultLanguage = $('input[name="default_language"]:checked').val();

                WPTranslate.ajax({
                    action: 'wptranslate_save_languages',
                    data: {
                        languages: languages,
                        default_language: defaultLanguage
                    },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Settings Handlers
        // -------------------------------------------------------------------

        bindSettingsHandlers: function() {
            // The settings form posts to options.php via WordPress Settings API.
            $(document).on('submit', '.wptranslate-settings-form', function() {
                var $btn = $(this).find(':submit');
                WPTranslate.setButtonLoading($btn, wptranslateAdmin.i18n.saving);
            });

            // Validate API key buttons.
            $(document).on('click', '.wptranslate-validate-key', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var provider = $btn.data('provider');
                var $input = $btn.siblings('input[type="password"]');
                var $result = $btn.siblings('.wptranslate-key-validation-result');
                var apiKey = $input.val().trim();

                WPTranslate.ajax({
                    action: 'wptranslate_validate_api_key',
                    data: { provider: provider, api_key: apiKey },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.validating,
                    success: function(data) {
                        $result.html('<span class="dashicons dashicons-yes-alt" style="color: var(--wpt-success, #059669);"></span> <span style="color: var(--wpt-success, #059669);">' + data.message + '</span>');
                        WPTranslate.showToast(data.message, 'success');
                    },
                    error: function(msg) {
                        $result.html('<span class="dashicons dashicons-dismiss" style="color: var(--wpt-error, #DC2626);"></span> <span style="color: var(--wpt-error, #DC2626);">' + msg + '</span>');
                        WPTranslate.showToast(msg, 'error');
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // String Translation Handlers
        // -------------------------------------------------------------------

        bindStringTranslationHandlers: function() {

            // --- Edit string (toggle inline edit) ---
            $(document).on('click', '.wptranslate-edit-string', function(e) {
                e.preventDefault();
                var stringId = $(this).data('string-id');
                var $editContainer = $('.wptranslate-inline-edit[data-string-id="' + stringId + '"]');

                if (!$editContainer.length) {
                    return;
                }

                var $display = $editContainer.find('.wptranslate-inline-edit__display');
                var $textarea = $editContainer.find('.wptranslate-inline-edit__input');
                var $saveBtn = $editContainer.find('.wptranslate-inline-edit__save');

                // Toggle visibility.
                $display.toggle();
                $textarea.toggle().focus();
                $saveBtn.toggle();
            });

            // --- Save inline edit ---
            $(document).on('click', '.wptranslate-inline-edit__save', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var $container = $btn.closest('.wptranslate-inline-edit');
                var stringId = $container.data('string-id');
                var $textarea = $container.find('.wptranslate-inline-edit__input');
                var $display = $container.find('.wptranslate-inline-edit__display');
                var newValue = $textarea.val();

                // Determine current language from the filter or default.
                var language = $('#wptranslate-filter-language').val() || '';

                WPTranslate.ajax({
                    action: 'wptranslate_inline_save_string',
                    data: {
                        string_id: stringId,
                        translated: newValue,
                        language: language
                    },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Update display text.
                        $display.text(newValue || '(untranslated)').show();
                        $textarea.hide();
                        $btn.hide();
                    }
                });
            });

            // --- Import PO: open modal ---
            $(document).on('click', '#wptranslate-import-po-btn', function(e) {
                e.preventDefault();
                WPTranslate.openModal('wptranslate-import-modal');
            });

            // --- Import PO: form submit ---
            $(document).on('submit', '#wptranslate-import-form', function(e) {
                e.preventDefault();
                var $form = $(this);
                var $btn = $form.find(':submit');
                var formData = new FormData($form[0]);

                WPTranslate.ajax({
                    action: 'wptranslate_import_po',
                    data: formData,
                    isFormData: true,
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.importing,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        WPTranslate.closeModal('wptranslate-import-modal');
                        setTimeout(function() { location.reload(); }, 1000);
                    }
                });
            });

            // --- Export PO ---
            $(document).on('click', '#wptranslate-export-po-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var language = $('#wptranslate-filter-language').val() || '';
                var domain = $('#wptranslate-filter-domain').val() || '';

                WPTranslate.ajax({
                    action: 'wptranslate_export_po',
                    data: { language: language, domain: domain, format: 'po' },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.downloadFile(data.content, data.filename, 'text/x-gettext-translation');
                        WPTranslate.showToast(wptranslateAdmin.i18n.complete, 'success');
                    }
                });
            });

            // --- Export POT ---
            $(document).on('click', '#wptranslate-export-pot-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var domain = $('#wptranslate-filter-domain').val() || '';

                WPTranslate.ajax({
                    action: 'wptranslate_export_po',
                    data: { domain: domain, format: 'pot' },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.downloadFile(data.content, data.filename, 'text/x-gettext-translation');
                        WPTranslate.showToast(wptranslateAdmin.i18n.complete, 'success');
                    }
                });
            });

            // --- Bulk actions for strings (translate, mark reviewed, delete) ---
            $(document).on('click', '#doaction, #doaction2', function(e) {
                var $form = $('#wptranslate-strings-form');
                if (!$form.length) {
                    return;
                }

                // Determine which action selector triggered this.
                var $selectId = $(this).attr('id') === 'doaction' ? '#bulk-action-selector-top' : '#bulk-action-selector-bottom';
                var action = $($selectId).val();

                if (action === '-1' || !action) {
                    return;
                }

                var stringIds = [];
                $form.find('input[name="string_ids[]"]:checked').each(function() {
                    stringIds.push($(this).val());
                });

                if (!stringIds.length) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.fill_required, 'warning');
                    e.preventDefault();
                    return;
                }

                if (action === 'translate') {
                    e.preventDefault();
                    var $btn = $(this);
                    var language = $('#wptranslate-filter-language').val() || '';

                    if (!language) {
                        WPTranslate.showToast(wptranslateAdmin.i18n.select_language, 'warning');
                        return;
                    }

                    WPTranslate.ajax({
                        action: 'wptranslate_bulk_translate_strings',
                        data: { string_ids: stringIds, target_lang: language },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.translating,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            setTimeout(function() { location.reload(); }, 1000);
                        }
                    });
                } else if (action === 'delete') {
                    e.preventDefault();
                    WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_delete, function() {
                        $form.append('<input type="hidden" name="action2_confirmed" value="delete" />');
                        $form[0].submit();
                    });
                }
                // 'mark_reviewed' — let the form submit normally if applicable,
                // or handle via AJAX if the backend supports it.
            });
        },

        // -------------------------------------------------------------------
        // Translation Queue Handlers
        // -------------------------------------------------------------------

        bindQueueHandlers: function() {

            // --- Retry single job ---
            $(document).on('click', '.wptranslate-retry-job', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var jobId = $btn.data('job-id');

                WPTranslate.ajax({
                    action: 'wptranslate_retry_job',
                    data: { job_id: jobId },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.retrying,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Update the row status.
                        var $row = $btn.closest('tr');
                        $row.find('.wptranslate-status')
                            .attr('class', 'wptranslate-status wptranslate-status--pending')
                            .text('Pending');
                        $btn.remove();
                    }
                });
            });

            // --- Cancel single job ---
            $(document).on('click', '.wptranslate-cancel-job', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var jobId = $btn.data('job-id');

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_cancel, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_cancel_job',
                        data: { job_id: jobId },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.cancelling,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            var $row = $btn.closest('tr');
                            $row.find('.wptranslate-status')
                                .attr('class', 'wptranslate-status wptranslate-status--cancelled')
                                .text('Cancelled');
                            $btn.remove();
                        }
                    });
                });
            });

            // --- View job detail ---
            $(document).on('click', '.wptranslate-view-job-detail', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var jobId = $btn.data('job-id');

                $('#wptranslate-job-detail-content').html(
                    '<p class="description">' + wptranslateAdmin.i18n.loading + '</p>'
                );
                WPTranslate.openModal('wptranslate-job-detail-modal');

                WPTranslate.ajax({
                    action: 'wptranslate_get_job_detail',
                    data: { job_id: jobId },
                    success: function(data) {
                        var html = '<table class="widefat">';
                        html += '<tr><th>Job ID</th><td>' + data.job.id + '</td></tr>';
                        html += '<tr><th>Status</th><td>' + data.job.status + '</td></tr>';
                        html += '<tr><th>Provider</th><td>' + (data.job.provider || '-') + '</td></tr>';
                        if (data.job.error_message) {
                            html += '<tr><th>Error</th><td style="color:#d63638;">' + $('<span>').text(data.job.error_message).html() + '</td></tr>';
                        }
                        html += '</table>';

                        html += '<h3>Source</h3>';
                        html += '<p><strong>' + $('<span>').text(data.source_title).html() + '</strong></p>';
                        html += '<p>' + $('<span>').text(data.source_content).html() + '</p>';

                        if (data.translated_title) {
                            html += '<h3>Translation</h3>';
                            html += '<p><strong>' + $('<span>').text(data.translated_title).html() + '</strong></p>';
                            html += '<p>' + $('<span>').text(data.translated_content).html() + '</p>';
                        }

                        $('#wptranslate-job-detail-content').html(html);
                    },
                    error: function(msg) {
                        $('#wptranslate-job-detail-content').html(
                            '<p style="color:#d63638;">' + $('<span>').text(msg).html() + '</p>'
                        );
                    }
                });
            });

            // --- Retry all failed ---
            $(document).on('click', '#wptranslate-retry-all-failed', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_bulk, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_retry_all_failed',
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.retrying,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            setTimeout(function() { location.reload(); }, 1000);
                        }
                    });
                });
            });

            // --- Cancel all pending ---
            $(document).on('click', '#wptranslate-cancel-all-pending', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_cancel, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_cancel_all_pending',
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.cancelling,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            setTimeout(function() { location.reload(); }, 1000);
                        }
                    });
                });
            });

            // --- Priority change ---
            $(document).on('change', '.wptranslate-priority-select', function() {
                var $select = $(this);
                var jobId = $select.data('job-id');
                var priority = $select.val();

                WPTranslate.ajax({
                    action: 'wptranslate_update_priority',
                    data: { job_id: jobId, priority: priority },
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Translators Handlers
        // -------------------------------------------------------------------

        bindTranslatorHandlers: function() {

            // --- Open assign languages modal ---
            $(document).on('click', '.wptranslate-assign-languages-btn', function(e) {
                e.preventDefault();
                var userId = $(this).data('user-id');
                var userName = $(this).data('user-name');
                var assigned = $(this).data('assigned') || [];

                // Ensure assigned is an array.
                if (typeof assigned === 'string') {
                    try { assigned = JSON.parse(assigned); } catch (ex) { assigned = []; }
                }

                // Populate the modal.
                $('#wptranslate-assign-user-id').val(userId);
                $('#wptranslate-assign-user-name').text(userName);

                // Pre-check assigned languages.
                $('.wptranslate-assign-lang-cb').each(function() {
                    $(this).prop('checked', $.inArray($(this).val(), assigned) !== -1);
                });

                WPTranslate.openModal('wptranslate-assign-languages-modal');
            });

            // --- Save language assignment ---
            $(document).on('click', '#wptranslate-save-language-assignment', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var userId = $('#wptranslate-assign-user-id').val();
                var languages = [];
                $('.wptranslate-assign-lang-cb:checked').each(function() {
                    languages.push($(this).val());
                });

                WPTranslate.ajax({
                    action: 'wptranslate_assign_translator_languages',
                    data: { user_id: userId, languages: languages },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        WPTranslate.closeModal('wptranslate-assign-languages-modal');

                        // Update badges in the table row.
                        var $row = $('tr[data-user-id="' + userId + '"]');
                        var $langCell = $row.find('.column-languages');
                        $langCell.empty();

                        if (languages.length === 0) {
                            $langCell.html('<span class="description">None assigned</span>');
                        } else {
                            $.each(languages, function(i, code) {
                                $langCell.append('<span class="wptranslate-badge">' + code + '</span> ');
                            });
                        }

                        // Update the data-assigned attribute on the button.
                        $row.find('.wptranslate-assign-languages-btn').data('assigned', languages);
                    }
                });
            });

            // --- Add translator ---
            $(document).on('click', '#wptranslate-add-translator-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var userId = $('#wptranslate-add-translator-user').val();

                if (!userId) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.select_user || 'Please select a user.', 'warning');
                    return;
                }

                WPTranslate.ajax({
                    action: 'wptranslate_add_translator',
                    data: { user_id: userId },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');

                        // Remove the user from the dropdown.
                        $('#wptranslate-add-translator-user option[value="' + userId + '"]').remove();
                        $('#wptranslate-add-translator-user').val('');

                        // If there's an empty state, replace it with the translators table.
                        var $emptyState = $('.wptranslate-translators .wptranslate-empty-state');
                        if ($emptyState.length) {
                            var tableHtml = '<div class="wptranslate-card">' +
                                '<table class="wp-list-table widefat fixed striped">' +
                                '<thead><tr>' +
                                '<th class="column-name">Name</th>' +
                                '<th class="column-role">Role</th>' +
                                '<th class="column-languages">Assigned Languages</th>' +
                                '<th class="column-completed">Completed</th>' +
                                '<th class="column-pending">Pending</th>' +
                                '<th class="column-last-activity">Last Activity</th>' +
                                '<th class="column-actions">Actions</th>' +
                                '</tr></thead><tbody></tbody></table></div>';
                            $emptyState.replaceWith(tableHtml);
                        }

                        // Add a new row to the translators table.
                        var user = data.user;
                        var newRow = '<tr data-user-id="' + user.id + '">' +
                            '<td class="column-name">' +
                                '<img src="' + user.avatar + '" width="32" height="32" class="avatar" /> ' +
                                '<strong>' + $('<span>').text(user.display_name).html() + '</strong>' +
                                '<br /><span class="description">' + $('<span>').text(user.email).html() + '</span>' +
                            '</td>' +
                            '<td class="column-role">' + $('<span>').text(user.role_label).html() + '</td>' +
                            '<td class="column-languages"><span class="description">None assigned</span></td>' +
                            '<td class="column-completed"><strong>0</strong></td>' +
                            '<td class="column-pending">0</td>' +
                            '<td class="column-last-activity"><span class="description">Never</span></td>' +
                            '<td class="column-actions">' +
                                '<div style="display: flex; gap: 4px; align-items: center;">' +
                                    '<button type="button" class="button button-small wptranslate-assign-languages-btn" data-user-id="' + user.id + '" data-user-name="' + $('<span>').text(user.display_name).html() + '" data-assigned="[]" title="Assign Languages">' +
                                        '<span class="dashicons dashicons-translation" style="vertical-align: middle; line-height: 1.4;"></span>' +
                                    '</button>' +
                                    '<button type="button" class="button button-small wptranslate-view-activity-btn" data-user-id="' + user.id + '" data-user-name="' + $('<span>').text(user.display_name).html() + '" title="Activity Log">' +
                                        '<span class="dashicons dashicons-list-view" style="vertical-align: middle; line-height: 1.4;"></span>' +
                                    '</button>' +
                                    '<button type="button" class="button button-small wptranslate-remove-translator" data-user-id="' + user.id + '" data-user-name="' + $('<span>').text(user.display_name).html() + '" title="Remove Translator" style="color: #b32d2e;">' +
                                        '<span class="dashicons dashicons-no" style="vertical-align: middle; line-height: 1.4;"></span>' +
                                    '</button>' +
                                '</div>' +
                            '</td>' +
                            '</tr>';

                        $('.wptranslate-translators .wp-list-table tbody').append(newRow);
                    }
                });
            });

            // --- Remove translator ---
            $(document).on('click', '.wptranslate-remove-translator', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var userId = $btn.data('user-id');
                var userName = $btn.data('user-name');

                WPTranslate.confirmAction(
                    (wptranslateAdmin.i18n.confirm_remove_translator || 'Remove translator capabilities from "' + userName + '"? They will no longer be able to translate content.'),
                    function() {
                        WPTranslate.ajax({
                            action: 'wptranslate_remove_translator',
                            data: { user_id: userId },
                            $btn: $btn,
                            loadingText: wptranslateAdmin.i18n.loading,
                            success: function(data) {
                                WPTranslate.showToast(data.message, 'success');

                                // Remove the row from the table.
                                var $row = $('tr[data-user-id="' + userId + '"]');
                                $row.fadeOut(300, function() {
                                    $(this).remove();

                                    // If no more translators, show empty state.
                                    if ($('.wptranslate-translators .wp-list-table tbody tr').length === 0) {
                                        var $card = $('.wptranslate-translators .wptranslate-card').has('.wp-list-table');
                                        $card.html(
                                            '<div class="wptranslate-empty-state">' +
                                                '<div class="wptranslate-empty-state__icon"><span class="dashicons dashicons-groups"></span></div>' +
                                                '<h3 class="wptranslate-empty-state__title">No Translators Configured</h3>' +
                                                '<p class="wptranslate-empty-state__description">Use the form above to add translator capabilities to existing WordPress users.</p>' +
                                            '</div>'
                                        );
                                    }
                                });

                                // Re-add the user to the dropdown.
                                var $select = $('#wptranslate-add-translator-user');
                                $select.append('<option value="' + userId + '">' + $('<span>').text(userName).html() + '</option>');
                            }
                        });
                    }
                );
            });

            // --- View activity log ---
            $(document).on('click', '.wptranslate-view-activity-btn', function(e) {
                e.preventDefault();
                var userId = $(this).data('user-id');
                var userName = $(this).data('user-name');

                $('#wptranslate-activity-user-name').text(userName);
                $('#wptranslate-activity-log-content').html(
                    '<p class="description">' + wptranslateAdmin.i18n.loading + '</p>'
                );

                WPTranslate.openModal('wptranslate-activity-modal');

                WPTranslate.ajax({
                    action: 'wptranslate_get_translator_activity',
                    data: { user_id: userId },
                    success: function(data) {
                        var items = data.activities || [];
                        if (!items.length) {
                            $('#wptranslate-activity-log-content').html(
                                '<p class="description">No activity found.</p>'
                            );
                            return;
                        }

                        var html = '<table class="widefat striped"><thead><tr>';
                        html += '<th>Title</th><th>Language</th><th>Status</th><th>Date</th>';
                        html += '</tr></thead><tbody>';

                        $.each(items, function(i, item) {
                            html += '<tr>';
                            html += '<td>' + $('<span>').text(item.title).html() + '</td>';
                            html += '<td>' + $('<span>').text(item.language).html() + '</td>';
                            html += '<td>' + $('<span>').text(item.status).html() + '</td>';
                            html += '<td>' + $('<span>').text(item.ago + ' ago').html() + '</td>';
                            html += '</tr>';
                        });

                        html += '</tbody></table>';
                        $('#wptranslate-activity-log-content').html(html);
                    },
                    error: function(msg) {
                        $('#wptranslate-activity-log-content').html(
                            '<p style="color:#d63638;">' + $('<span>').text(msg).html() + '</p>'
                        );
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Tools Handlers
        // -------------------------------------------------------------------

        bindToolsHandlers: function() {

            // --- Bulk translate (Tools page) ---
            $(document).on('click', '#wptranslate-bulk-translate-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var lang = $('#wptranslate-bulk-lang').val();
                var postType = $('#wptranslate-bulk-post-type').val();

                if (!lang) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.select_language, 'warning');
                    return;
                }

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_bulk, function() {
                    WPTranslate.startProgress('wptranslate-bulk-progress');

                    WPTranslate.ajax({
                        action: 'wptranslate_bulk_translate_all',
                        data: { target_lang: lang, post_type: postType },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.translating,
                        success: function(data) {
                            if (data.count === 0) {
                                WPTranslate.updateProgress('wptranslate-bulk-progress', 100, data.message);
                                WPTranslate.showToast(data.message, 'info');
                            } else {
                                WPTranslate.updateProgress('wptranslate-bulk-progress', 100, data.message);
                                WPTranslate.showToast(data.message, 'success');
                            }
                        }
                    });
                });
            });

            // --- Sync status ---
            $(document).on('click', '#wptranslate-sync-status-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.ajax({
                    action: 'wptranslate_sync_status',
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                    }
                });
            });

            // --- TranslatePress dry run ---
            $(document).on('click', '#wptranslate-import-tp-dry-run', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var scope = $('#wptranslate-import-tp-scope').val();

                WPTranslate.ajax({
                    action: 'wptranslate_import_translatepress',
                    data: { scope: scope, dry_run: 1 },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'info');
                        $('#wptranslate-import-tp-results')
                            .show()
                            .html('<p>' + $('<span>').text(data.message).html() + '</p>');
                    }
                });
            });

            // --- TranslatePress actual import ---
            $(document).on('click', '#wptranslate-import-tp-run', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var scope = $('#wptranslate-import-tp-scope').val();

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_bulk, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_import_translatepress',
                        data: { scope: scope, dry_run: 0 },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.importing,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            $('#wptranslate-import-tp-results')
                                .show()
                                .html('<p>' + $('<span>').text(data.message).html() + '</p>');
                        }
                    });
                });
            });

            // --- Export translations ---
            $(document).on('click', '#wptranslate-export-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var format = $('#wptranslate-export-format').val();
                var language = $('#wptranslate-export-lang').val();

                WPTranslate.ajax({
                    action: 'wptranslate_export_translations',
                    data: { format: format, language: language },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        var mime = format === 'json' ? 'application/json' : 'text/csv';
                        WPTranslate.downloadFile(data.content, data.filename, mime);
                        WPTranslate.showToast(wptranslateAdmin.i18n.complete, 'success');
                    }
                });
            });

            // --- Import translations ---
            $(document).on('click', '#wptranslate-import-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var fileInput = document.getElementById('wptranslate-import-file');

                if (!fileInput || !fileInput.files.length) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.fill_required, 'warning');
                    return;
                }

                var formData = new FormData();
                formData.append('import_file', fileInput.files[0]);

                WPTranslate.ajax({
                    action: 'wptranslate_import_translations',
                    data: formData,
                    isFormData: true,
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.importing,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Clear file input.
                        $(fileInput).val('');
                    }
                });
            });

            // --- Clean orphaned translations ---
            $(document).on('click', '#wptranslate-clean-orphans-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_delete, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_clean_orphans',
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.loading,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                        }
                    });
                });
            });

            // --- Rebuild caches ---
            $(document).on('click', '#wptranslate-rebuild-cache-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.ajax({
                    action: 'wptranslate_rebuild_cache',
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                    }
                });
            });

            // --- Add glossary term ---
            $(document).on('click', '#wptranslate-add-glossary-term', function(e) {
                e.preventDefault();
                var $btn = $(this);

                var term = $('#wptranslate-glossary-term').val().trim();
                var translation = $('#wptranslate-glossary-translation').val().trim();
                var sourceLang = $('#wptranslate-glossary-source-lang').val();
                var targetLang = $('#wptranslate-glossary-target-lang').val();

                if (!term || !sourceLang || !targetLang) {
                    WPTranslate.showToast(wptranslateAdmin.i18n.fill_required, 'warning');
                    return;
                }

                WPTranslate.ajax({
                    action: 'wptranslate_add_glossary_term',
                    data: {
                        term: term,
                        translation: translation,
                        source_lang: sourceLang,
                        target_lang: targetLang,
                        case_sensitive: $('#wptranslate-glossary-case-sensitive').is(':checked') ? 1 : 0,
                        exact_match: $('#wptranslate-glossary-exact-match').is(':checked') ? 1 : 0
                    },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');

                        // Build the new row HTML.
                        var badges = '';
                        if ($('#wptranslate-glossary-case-sensitive').is(':checked')) {
                            badges += '<span class="wptranslate-badge">CS</span> ';
                        }
                        if ($('#wptranslate-glossary-exact-match').is(':checked')) {
                            badges += '<span class="wptranslate-badge">EM</span> ';
                        }

                        var newRow = '<tr data-term-id="' + data.id + '">' +
                            '<td><strong>' + $('<span>').text(term).html() + '</strong></td>' +
                            '<td>' + $('<span>').text(translation).html() + '</td>' +
                            '<td>' + sourceLang.toUpperCase() + ' -> ' + targetLang.toUpperCase() + '</td>' +
                            '<td>' + badges + '</td>' +
                            '<td><button type="button" class="button button-small wptranslate-delete-glossary-term" data-id="' + data.id + '">Delete</button></td>' +
                            '</tr>';

                        // Find the glossary terms card by its heading text.
                        var $termsCard = null;
                        $('.wptranslate-glossary .wptranslate-card').each(function() {
                            var heading = $(this).find('h2').text().trim();
                            if (heading.indexOf('Glossary Terms') !== -1 || $(this).find('.wp-list-table').length > 0) {
                                $termsCard = $(this);
                                return false; // break
                            }
                        });
                        if (!$termsCard) {
                            // Fallback: last card on the page
                            $termsCard = $('.wptranslate-glossary .wptranslate-card').last();
                        }

                        // If empty state is showing, replace it with the table.
                        var $emptyState = $termsCard.find('.wptranslate-empty-state');
                        if ($emptyState.length) {
                            var tableHtml = '<table class="wp-list-table widefat fixed striped">' +
                                '<thead><tr>' +
                                '<th>Term</th><th>Translation</th><th>Languages</th><th>Options</th><th>Actions</th>' +
                                '</tr></thead>' +
                                '<tbody>' + newRow + '</tbody></table>';
                            $emptyState.replaceWith(tableHtml);
                        } else {
                            // Append to existing table tbody.
                            var $tbody = $termsCard.find('.wp-list-table tbody');
                            if ($tbody.length) {
                                $tbody.append(newRow);
                            }
                        }

                        // Clear form fields.
                        $('#wptranslate-glossary-term, #wptranslate-glossary-translation, #wptranslate-glossary-notes').val('');
                        $('#wptranslate-glossary-case-sensitive, #wptranslate-glossary-exact-match').prop('checked', false);
                    }
                });
            });

            // --- Delete glossary term ---
            $(document).on('click', '.wptranslate-delete-glossary-term', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var id = $btn.data('id');

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_delete, function() {
                    WPTranslate.ajax({
                        action: 'wptranslate_delete_glossary_term',
                        data: { id: id },
                        $btn: $btn,
                        loadingText: wptranslateAdmin.i18n.loading,
                        success: function(data) {
                            WPTranslate.showToast(data.message, 'success');
                            $('tr[data-term-id="' + id + '"]').fadeOut(300, function() {
                                $(this).remove();
                            });
                        }
                    });
                });
            });

            // --- Confirm glossary suggestion ---
            $(document).on('click', '.wptranslate-confirm-glossary-suggestion', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var id = $btn.data('id');

                WPTranslate.ajax({
                    action: 'wptranslate_confirm_glossary_suggestion',
                    data: { id: id },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.saving,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        // Move row from suggestions to confirmed or just remove it.
                        $('tr[data-suggestion-id="' + id + '"]').fadeOut(300, function() {
                            $(this).remove();
                            // If no more suggestions, hide the suggestions section.
                            if ($('.wptranslate-glossary-suggestions tbody tr').length === 0) {
                                $('.wptranslate-glossary-suggestions').fadeOut(300);
                            }
                        });
                    }
                });
            });

            // --- Dismiss glossary suggestion ---
            $(document).on('click', '.wptranslate-dismiss-glossary-suggestion', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var id = $btn.data('id');

                WPTranslate.ajax({
                    action: 'wptranslate_dismiss_glossary_suggestion',
                    data: { id: id },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        $('tr[data-suggestion-id="' + id + '"]').fadeOut(300, function() {
                            $(this).remove();
                            if ($('.wptranslate-glossary-suggestions tbody tr').length === 0) {
                                $('.wptranslate-glossary-suggestions').fadeOut(300);
                            }
                        });
                    }
                });
            });

            // --- Export glossary ---
            $(document).on('click', '#wptranslate-export-glossary-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);

                WPTranslate.ajax({
                    action: 'wptranslate_export_glossary',
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.loading,
                    success: function(data) {
                        WPTranslate.downloadFile(data.content, data.filename, 'text/csv');
                        WPTranslate.showToast(wptranslateAdmin.i18n.complete, 'success');
                    }
                });
            });

            // --- Import glossary: trigger hidden file input ---
            $(document).on('click', '#wptranslate-import-glossary-btn', function(e) {
                e.preventDefault();
                $('#wptranslate-glossary-import-file').trigger('click');
            });

            // --- Import glossary: on file selection ---
            $(document).on('change', '#wptranslate-glossary-import-file', function() {
                var fileInput = this;
                if (!fileInput.files.length) {
                    return;
                }

                var $btn = $('#wptranslate-import-glossary-btn');
                var formData = new FormData();
                formData.append('glossary_file', fileInput.files[0]);

                WPTranslate.ajax({
                    action: 'wptranslate_import_glossary',
                    data: formData,
                    isFormData: true,
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.importing,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        $(fileInput).val('');
                        setTimeout(function() { location.reload(); }, 1000);
                    }
                });
            });
        },

        // -------------------------------------------------------------------
        // Post Edit Metabox Handlers
        // -------------------------------------------------------------------

        bindMetaboxHandlers: function() {

            // --- Translate single post (metabox) ---
            $(document).on('click', '.wptranslate-translate-btn', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var postId = $btn.data('post-id');
                var lang = $btn.data('lang');

                WPTranslate.ajax({
                    action: 'wptranslate_translate_post',
                    data: { post_id: postId, target_lang: lang },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.translating,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');

                        var $row = $btn.closest('tr');
                        // Update status.
                        $row.find('.wptranslate-status')
                            .attr('class', 'wptranslate-status wptranslate-status--ai_draft')
                            .text(wptranslateAdmin.i18n.ai_draft);

                        // Replace button with edit/view links.
                        var $actionsCell = $row.find('.wptranslate-actions');
                        $actionsCell.html(
                            '<a href="' + data.edit_url + '" class="button button-small">' + wptranslateAdmin.i18n.edit + '</a> ' +
                            '<a href="' + data.view_url + '" class="button button-small" target="_blank">View</a>'
                        );
                    }
                });
            });

            // --- Retranslate (update) post (metabox) ---
            $(document).on('click', '.wptranslate-retranslate', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var postId = $btn.data('post-id');
                var lang = $btn.data('lang');

                WPTranslate.ajax({
                    action: 'wptranslate_translate_post',
                    data: { post_id: postId, target_lang: lang, force: 1 },
                    $btn: $btn,
                    loadingText: wptranslateAdmin.i18n.translating,
                    success: function(data) {
                        WPTranslate.showToast(data.message, 'success');
                        var $row = $btn.closest('tr');
                        $row.find('.wptranslate-status')
                            .attr('class', 'wptranslate-status wptranslate-status--ai_draft')
                            .text('AI Draft');
                        // Update the Retranslate button text
                        $btn.text('Retranslate');
                    }
                });
            });

            // --- Translate to all languages (metabox) ---
            $(document).on('click', '.wptranslate-translate-all', function(e) {
                e.preventDefault();
                var $btn = $(this);
                var postId = $btn.data('post-id');

                WPTranslate.confirmAction(wptranslateAdmin.i18n.confirm_bulk, function() {
                    WPTranslate.setButtonLoading($btn, wptranslateAdmin.i18n.translating);

                    // Collect all untranslated languages from the metabox table.
                    var $translateBtns = $btn.closest('.wptranslate-metabox').find('.wptranslate-translate-btn');
                    var remaining = $translateBtns.length;
                    var completed = 0;

                    if (remaining === 0) {
                        WPTranslate.resetButton($btn);
                        WPTranslate.showToast(wptranslateAdmin.i18n.complete, 'info');
                        return;
                    }

                    $translateBtns.each(function() {
                        var lang = $(this).data('lang');
                        var $langBtn = $(this);

                        $.post(wptranslateAdmin.ajaxUrl, {
                            action: 'wptranslate_translate_post',
                            nonce: wptranslateAdmin.nonce,
                            post_id: postId,
                            target_lang: lang
                        }).done(function(response) {
                            if (response.success) {
                                completed++;
                                var $row = $langBtn.closest('tr');
                                $row.find('.wptranslate-status')
                                    .attr('class', 'wptranslate-status wptranslate-status--ai_draft')
                                    .text(wptranslateAdmin.i18n.ai_draft);
                                var d = response.data;
                                $row.find('.wptranslate-actions').html(
                                    '<a href="' + d.edit_url + '" class="button button-small">' + wptranslateAdmin.i18n.edit + '</a> ' +
                                    '<a href="' + d.view_url + '" class="button button-small" target="_blank">View</a>'
                                );
                            }
                        }).always(function() {
                            remaining--;
                            if (remaining <= 0) {
                                WPTranslate.resetButton($btn);
                                WPTranslate.showToast(completed + ' translations completed.', completed > 0 ? 'success' : 'warning');
                            }
                        });
                    });
                });
            });
        },

        // -------------------------------------------------------------------
        // Setup Wizard
        // -------------------------------------------------------------------

        initWizard: function() {
            // Dismiss wizard
            $(document).on('click', '.wptranslate-wizard__dismiss', function(e) {
                e.preventDefault();
                var $wizard = $(this).closest('.wptranslate-wizard');

                $.post(wptranslateAdmin.ajaxUrl, {
                    action: 'wptranslate_dismiss_wizard',
                    nonce: wptranslateAdmin.nonce
                });

                $wizard.slideUp(300, function() {
                    $(this).remove();
                });
            });
        },

        // -------------------------------------------------------------------
        // Collapsible Sections
        // -------------------------------------------------------------------

        initCollapsibles: function() {
            $(document).on('click', '.wptranslate-collapsible__toggle', function(e) {
                e.preventDefault();
                var $section = $(this).closest('.wptranslate-collapsible');
                $section.toggleClass('wptranslate-collapsible--open');
            });
        }
    };

    // Initialize when DOM is ready.
    $(document).ready(function() {
        WPTranslate.init();
    });

})(jQuery);
