<?php
/**
 * WPTranslate uninstall handler.
 *
 * Fired when the plugin is deleted via the WordPress admin.
 */

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
    exit;
}

// Only clean up if the user opted in.
$delete_data = get_option( 'wptranslate_delete_data_on_uninstall', false );

if ( $delete_data ) {
    global $wpdb;

    // Drop custom tables.
    $tables = array(
        $wpdb->prefix . 'wpt_languages',
        $wpdb->prefix . 'wpt_translations',
        $wpdb->prefix . 'wpt_translation_status',
        $wpdb->prefix . 'wpt_string_translations',
        $wpdb->prefix . 'wpt_translation_jobs',
        $wpdb->prefix . 'wpt_translation_cache',
        $wpdb->prefix . 'wpt_translation_glossary',
        $wpdb->prefix . 'wpt_translation_corrections',
    );

    foreach ( $tables as $table ) {
        $wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    // Delete all plugin options.
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE 'wptranslate\_%'"
    );

    // Delete translation post meta.
    $wpdb->query(
        "DELETE FROM {$wpdb->postmeta} WHERE meta_key LIKE '\\_wptranslate\\_%'"
    );

    // Delete translation comments/notes.
    $wpdb->query(
        $wpdb->prepare(
            "DELETE FROM {$wpdb->comments} WHERE comment_type = %s",
            'wpt_translation_note'
        )
    );

    // Remove custom roles.
    remove_role( 'wptranslate_translator' );
    remove_role( 'wptranslate_translation_manager' );

    // Remove custom caps from admin.
    $admin = get_role( 'administrator' );
    if ( $admin ) {
        $caps = array(
            'wptranslate_manage_languages',
            'wptranslate_translate_posts',
            'wptranslate_edit_translations',
            'wptranslate_submit_translations',
            'wptranslate_assign_translations',
            'wptranslate_review_translations',
            'wptranslate_publish_translations',
            'wptranslate_manage_translators',
            'wptranslate_manage_settings',
            'wptranslate_manage_glossary',
        );
        foreach ( $caps as $cap ) {
            $admin->remove_cap( $cap );
        }
    }

    // Clear transients.
    $wpdb->query(
        "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\\_transient\\_wptranslate\\_%' OR option_name LIKE '\\_transient\\_timeout\\_wptranslate\\_%'"
    );
}
