<?php
/**
 * Security Utils Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Security_Utils {

    /**
     * Get security information
     *
     * @param bool $force_refresh Force refresh of security info
     * @return array Security information
     */
    public static function get_security_info($force_refresh = false) {
        // Check transient unless force refresh
        if (!$force_refresh) {
            $security_info = get_transient('wordpress_inspector_security_info');
            if ($security_info !== false) {
                return $security_info;
            }
        }

        // Calculate security score and issues
        $security_score = self::calculate_security_score();

        // Build security info array
        $security_info = array(
            'security_score' => $security_score
        );

        // Cache for 5 minutes
        set_transient('wordpress_inspector_security_info', $security_info, 5 * MINUTE_IN_SECONDS);

        return $security_info;
    }

    /**
     * Calculate security score based on security patterns
     */
    public static function calculate_security_score() {
        // Load security patterns
        $patterns = require WPI_PLUGIN_DIR . 'includes/security/security-patterns.php';
        
        $total_score = 0;
        $issues_found = 0;
        $security_issues = array();

        // Run each security check
        foreach ($patterns as $key => $pattern) {
            $check_function = array('WordPress_Inspector_Security_Checks', $pattern['check_function_name']);
            
            // Skip if check function doesn't exist
            if (!is_callable($check_function)) {
                error_log("Security check function not found: " . $pattern['check_function_name']);
                continue;
            }
            
            try {
                // Run the check
                $has_issue = call_user_func($check_function);
                
                // If issue found, add to issues array and include in score calculation
                if ($has_issue) {
                    $issues_found++;
                    $total_score += $pattern['score'];
                    
                    // Add to security issues array
                    $security_issues[$key] = array(
                        'description' => $pattern['description'],
                        'category' => $pattern['category'],
                        'severity' => $pattern['severity'],
                        'score' => $pattern['score'],
                        'grade' => $pattern['grade'],
                        'solution' => $pattern['solution'],
                        'impact' => $pattern['impact']
                    );

                    // Add autofix information if available
                    if (!empty($pattern['autofix'])) {
                        $security_issues[$key]['autofix'] = $pattern['autofix'];
                    }
                }
            } catch (Exception $e) {
                error_log("Error running security check {$pattern['check_function_name']}: " . $e->getMessage());
                continue;
            }
        }

        // Calculate final score
        $final_score = $issues_found > 0 ? round(100 - ($total_score / $issues_found)) : 100;

        // Determine grade based on score
        $grade = self::get_grade_from_score($final_score);
        
        return array(
            'score' => $final_score,
            'grade' => $grade,
            'issues' => $security_issues
        );
    }

    /**
     * Convert score to letter grade
     */
    private static function get_grade_from_score($score) {
        if ($score >= 90) return 'A';
        if ($score >= 80) return 'B';
        if ($score >= 70) return 'C';
        if ($score >= 60) return 'D';
        return 'F';
    }

    /**
     * Get security overview with default values
     * 
     * @return array Complete security overview with all required keys
     */
    public static function get_security_overview() {
        // Get the base security info
        $security_info = self::get_security_info();

        // Define all required keys and their default values
        $required_keys = array(
            // SSL Information
            'ssl' => array(
                'enabled' => false,
                'valid' => false,
                'issuer' => '',
                'valid_from' => '',
                'valid_to' => '',
                'subject' => '',
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                )
            ),

            // File system checks with consistent structure
            'uploads' => array(
                'exists' => true,
                'readable' => true,
                'writable' => true,
                'executable' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'permissions' => '-rwxr-xr-x',
                'permissions_details' => array(
                    'octal' => '0755',
                    'human' => '-rwxr-xr-x'
                ),
                'last_checked' => null
            ),

            // Your existing file system checks...
            'cache' => array(
                'exists' => true,
                'readable' => true,
                'writable' => true,
                'executable' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'permissions' => '-rwxr-xr-x',
                'permissions_details' => array(
                    'octal' => '0755',
                    'human' => '-rwxr-xr-x'
                ),
                'last_checked' => null
            ),
            'backup' => array(
                'exists' => true,
                'readable' => true,
                'writable' => true,
                'executable' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'permissions' => '-rwxr-xr-x',
                'permissions_details' => array(
                    'octal' => '0755',
                    'human' => '-rwxr-xr-x'
                ),
                'last_checked' => null
            ),
            'plugins' => array(
                'exists' => true,
                'readable' => true,
                'writable' => true,
                'executable' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'permissions' => '-rwxr-xr-x',
                'permissions_details' => array(
                    'octal' => '0755',
                    'human' => '-rwxr-xr-x'
                ),
                'last_checked' => null
            ),
            'themes' => array(
                'exists' => true,
                'readable' => true,
                'writable' => true,
                'executable' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'permissions' => '-rwxr-xr-x',
                'permissions_details' => array(
                    'octal' => '0755',
                    'human' => '-rwxr-xr-x'
                ),
                'last_checked' => null
            ),

            // Security checks with consistent structure
            'file_permissions' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'last_checked' => null,
                'issues' => array()
            ),
            'admin_user' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'last_checked' => null,
                'exists' => false
            ),
            'debug_mode' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'enabled' => false,
                'log' => false,
                'display' => false
            ),

            // Your existing arrays with added status structure
            'xmlrpc' => array(
                'enabled' => false,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'pingback' => array(
                    'enabled' => false,
                    'status' => 'Disabled',
                    'last_checked' => null
                )
            ),
            'rest_api' => array(
                'enabled' => true,
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'restricted' => false,
                'version' => 'v2'
            ),

            // Your existing arrays...
            'wp_config' => array(
                'exists' => true,
                'readable' => true,
                'writable' => false,
                'executable' => false,
                'permissions' => '-rw-r--r--',
                'permissions_details' => array(
                    'octal' => '0644',
                    'human' => '-rw-r--r--'
                ),
                'salt_age' => 0,
                'salt_details' => array(
                    'days' => 0,
                    'last_changed' => null
                )
            ),
            'password_security' => array(
                'min_length' => 8,
                'requires_uppercase' => true,
                'requires_lowercase' => true,
                'requires_numbers' => true,
                'requires_special' => true,
                'password_expiry' => 90,
                'history_size' => 5,
                'lockout_attempts' => 5,
                'lockout_duration' => 15,
                'reset_enabled' => true,
                'strength_meter' => true
            ),
            'additional_security' => array(
                'two_factor' => false,
                'force_ssl_admin' => true,
                'disable_file_edit' => true,
                'auto_updates' => true,
                'login_recaptcha' => false,
                'login_whitelist' => false,
                'disable_xmlrpc' => true,
                'disable_rest_api' => false,
                'hide_wp_version' => true,
                'version_visible' => false,
                'login_errors' => false,
                'x_powered_by' => false
            ),
            'security_score' => array(
                'score' => 0,
                'grade' => 'F',
                'issues' => array()
            ),

            // Boolean checks converted to arrays with status
            'db_prefix' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'value' => false
            ),
            'wp_config_access' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'value' => false
            ),

            // Security Headers check
            'security_headers' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'X-Frame-Options' => '',
                'X-Content-Type-Options' => '',
                'X-XSS-Protection' => '',
                'Strict-Transport-Security' => '',
                'Referrer-Policy' => '',
                'Content-Security-Policy' => '',
                'details' => array(
                    'X-Frame-Options' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => 'SAMEORIGIN',
                        'status' => 'Missing'
                    ),
                    'X-Content-Type-Options' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => 'nosniff',
                        'status' => 'Missing'
                    ),
                    'X-XSS-Protection' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => '1; mode=block',
                        'status' => 'Missing'
                    ),
                    'Strict-Transport-Security' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => 'max-age=31536000; includeSubDomains',
                        'status' => 'Missing'
                    ),
                    'Referrer-Policy' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => 'strict-origin-when-cross-origin',
                        'status' => 'Missing'
                    ),
                    'Content-Security-Policy' => array(
                        'present' => false,
                        'value' => '',
                        'recommended' => "default-src 'self'",
                        'status' => 'Missing'
                    )
                ),
                'last_checked' => null
            ),

            // Directory Browsing check
            'directory_browsing' => array(
                'status' => array(
                    'code' => 0,
                    'message' => '',
                    'details' => array()
                ),
                'enabled' => false,
                'locations' => array(
                    'wp-includes' => array(
                        'accessible' => false,
                        'url' => '',
                        'last_checked' => null
                    ),
                    'wp-content' => array(
                        'accessible' => false,
                        'url' => '',
                        'last_checked' => null
                    ),
                    'uploads' => array(
                        'accessible' => false,
                        'url' => '',
                        'last_checked' => null
                    )
                ),
                'last_checked' => null
            )
        );

        // Merge with actual security info
        $complete_info = array_replace_recursive($required_keys, $security_info);

        // Update warning counts
        $complete_info['warning_count'] = count(array_filter($complete_info, function($value) {
            return is_array($value) && isset($value['status']['code']) && $value['status']['code'] > 0;
        }));

        $complete_info['total_checks'] = count(array_filter($required_keys, function($value) {
            return is_array($value) && isset($value['status']);
        }));

        // Ensure all values that might be displayed are strings
        foreach ($complete_info as $key => $value) {
            if (is_array($value) && isset($value['status']) && isset($value['status']['message'])) {
                $complete_info[$key]['status']['message'] = (string)$value['status']['message'];
            }
            if (is_array($value) && isset($value['value'])) {
                $complete_info[$key]['value'] = (string)$value['value'];
            }
        }

        // Ensure security headers are strings
        if (isset($complete_info['security_headers'])) {
            foreach ($complete_info['security_headers'] as $header => $value) {
                if ($header !== 'status' && $header !== 'details' && $header !== 'last_checked') {
                    $complete_info['security_headers'][$header] = (string)$value;
                }
            }
        }

        return $complete_info;
    }

    public static function get_security_stats() {
        // Load security patterns
        $patterns = include(WPI_PLUGIN_DIR . 'includes/security/security-patterns.php');
        
        $total_score = 0;
        $total_checks = 0;
        $categories = [];
        
        foreach ($patterns as $pattern) {
            $total_score += $pattern['score'];
            $total_checks++;
            
            // Group by category
            if (!isset($categories[$pattern['category']])) {
                $categories[$pattern['category']] = [
                    'count' => 0,
                    'score' => 0,
                    'total' => 0
                ];
            }
            
            $categories[$pattern['category']]['count']++;
            $categories[$pattern['category']]['score'] += $pattern['score'];
            $categories[$pattern['category']]['total'] += 100;
        }
        
        // Calculate average score
        $overall_score = round($total_score / $total_checks);
        
        // Calculate category percentages
        foreach ($categories as $key => $category) {
            $categories[$key]['percentage'] = round(($category['score'] / $category['total']) * 100);
        }
        
        return [
            'overall_score' => $overall_score,
            'categories' => $categories
        ];
    }
} 