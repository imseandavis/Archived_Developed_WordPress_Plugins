<?php
/**
 * Broken Links Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Broken_Links {
    
    /**
     * Initialize the class
     */
    public static function init() {
        add_action('wp_ajax_scan_links', array(__CLASS__, 'handle_scan_links'));
        add_action('wp_ajax_stop_scan', array(__CLASS__, 'handle_stop_scan'));
        add_action('wp_ajax_toggle_schedule', array(__CLASS__, 'handle_toggle_schedule'));
    }

    /**
     * Get all links from content
     */
    private static function get_content_links() {
        global $wpdb;
        $links = array();

        // Get links from posts and pages
        $posts = $wpdb->get_results("
            SELECT ID, post_content, post_title, post_type 
            FROM {$wpdb->posts} 
            WHERE post_status = 'publish'
        ");

        foreach ($posts as $post) {
            // Find all links in content
            preg_match_all('/<a[^>]+href=([\'"])(.*?)\1/', $post->post_content, $matches);
            
            if (!empty($matches[2])) {
                foreach ($matches[2] as $url) {
                    $links[] = array(
                        'url' => esc_url($url),
                        'location' => sprintf('%s: %s', ucfirst($post->post_type), $post->post_title),
                        'post_id' => $post->ID
                    );
                }
            }
        }

        // Get links from widgets
        $widget_links = self::get_widget_links();
        $links = array_merge($links, $widget_links);

        // Get menu links
        $menu_links = self::get_menu_links();
        $links = array_merge($links, $menu_links);

        return array_unique($links, SORT_REGULAR);
    }

    /**
     * Get links from widgets
     */
    private static function get_widget_links() {
        $links = array();
        $widgets = get_option('widget_custom_html');
        
        if ($widgets) {
            foreach ($widgets as $widget) {
                if (isset($widget['content'])) {
                    preg_match_all('/<a[^>]+href=([\'"])(.*?)\1/', $widget['content'], $matches);
                    if (!empty($matches[2])) {
                        foreach ($matches[2] as $url) {
                            $links[] = array(
                                'url' => esc_url($url),
                                'location' => 'Widget',
                                'post_id' => null
                            );
                        }
                    }
                }
            }
        }
        
        return $links;
    }

    /**
     * Get links from menus
     */
    private static function get_menu_links() {
        $links = array();
        $menus = wp_get_nav_menus();
        
        foreach ($menus as $menu) {
            $menu_items = wp_get_nav_menu_items($menu);
            if ($menu_items) {
                foreach ($menu_items as $item) {
                    $links[] = array(
                        'url' => esc_url($item->url),
                        'location' => sprintf('Menu: %s', $menu->name),
                        'post_id' => null
                    );
                }
            }
        }
        
        return $links;
    }

    /**
     * Check if a URL is broken
     */
    private static function check_url($url) {
        if (empty($url)) return false;

        $response = wp_remote_head($url, array(
            'timeout' => 5,
            'sslverify' => false
        ));

        if (is_wp_error($response)) {
            return array(
                'broken' => true,
                'status' => $response->get_error_message()
            );
        }

        $status_code = wp_remote_retrieve_response_code($response);
        return array(
            'broken' => $status_code >= 400,
            'status' => $status_code
        );
    }

    /**
     * Handle link scanning AJAX request
     */
    public static function handle_scan_links() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        check_ajax_referer('broken_links_nonce', 'nonce');

        $batch_size = 10;
        $offset = intval($_POST['offset']);
        $all_links = self::get_content_links();
        $total_links = count($all_links);
        
        $batch_links = array_slice($all_links, $offset, $batch_size);
        $results = array();
        
        foreach ($batch_links as $link) {
            $check_result = self::check_url($link['url']);
            if ($check_result['broken']) {
                $results[] = array(
                    'url' => $link['url'],
                    'status' => $check_result['status'],
                    'location' => $link['location']
                );
            }
        }

        $progress = min(100, round(($offset + $batch_size) / $total_links * 100));
        
        wp_send_json_success(array(
            'results' => $results,
            'progress' => $progress,
            'total_links' => $total_links,
            'unique_urls' => count(array_unique(array_column($all_links, 'url'))),
            'broken_count' => count($results),
            'completed' => ($offset + $batch_size) >= $total_links,
            'next_offset' => $offset + $batch_size
        ));
    }

    /**
     * Handle schedule toggle AJAX request
     */
    public static function handle_toggle_schedule() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        check_ajax_referer('broken_links_nonce', 'nonce');

        $enabled = $_POST['enabled'] === 'true';
        update_option('wordpress_inspector_broken_links_schedule', $enabled);

        if ($enabled) {
            wp_schedule_event(time(), 'daily', 'wordpress_inspector_check_links');
        } else {
            wp_clear_scheduled_hook('wordpress_inspector_check_links');
        }

        wp_send_json_success(array('enabled' => $enabled));
    }

    public static function get_broken_links_count() {
        global $wpdb;
        
        // Get count from broken links table if it exists
        $table_name = $wpdb->prefix . 'wpi_broken_links';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") === $table_name) {
            return (int) $wpdb->get_var("SELECT COUNT(*) FROM $table_name");
        }
        
        return 0;
    }
} 