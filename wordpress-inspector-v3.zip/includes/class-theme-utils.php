<?php
/**
 * Theme Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Theme utility functions
 */
class WordPress_Inspector_Theme_Utils {
    /**
     * Get theme information
     *
     * @param string $stylesheet Theme stylesheet
     * @return array Theme details
     */
    public static function get_theme_info($stylesheet) {
        try {
            $theme = wp_get_theme($stylesheet);
            
            if (!$theme->exists()) {
                throw new Exception('Theme not found');
            }

            return array(
                'exists' => true,
                'name' => $theme->get('Name'),
                'version' => $theme->get('Version'),
                'author' => $theme->get('Author'),
                'author_uri' => $theme->get('AuthorURI'),
                'theme_uri' => $theme->get('ThemeURI'),
                'description' => $theme->get('Description'),
                'template' => $theme->get('Template'),
                'is_child' => $theme->parent() !== false,
                'parent_theme' => $theme->parent() ? $theme->parent()->get('Name') : null,
                'directory' => $theme->get_stylesheet_directory(),
                'error' => null
            );
        } catch (Exception $e) {
            WordPress_Inspector_Utils::log_error('Error getting theme info', array(
                'theme' => $stylesheet,
                'error' => $e->getMessage()
            ));
            return array(
                'exists' => false,
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Get theme directory size
     *
     * @param string $stylesheet Theme stylesheet
     * @return array Size information
     */
    public static function get_theme_size($stylesheet) {
        try {
            $theme = wp_get_theme($stylesheet);
            if (!$theme->exists()) {
                throw new Exception('Theme not found');
            }

            $path = $theme->get_stylesheet_directory();
            $size = WordPress_Inspector_Utils::get_directory_size($path);

            return array(
                'size' => $size,
                'formatted' => WordPress_Inspector_Utils::format_size($size),
                'error' => null
            );
        } catch (Exception $e) {
            return array(
                'size' => 0,
                'formatted' => 'N/A',
                'error' => $e->getMessage()
            );
        }
    }
} 