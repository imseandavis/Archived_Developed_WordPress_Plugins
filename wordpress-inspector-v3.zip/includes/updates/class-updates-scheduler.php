<?php
class WordPress_Inspector_Updates_Scheduler {
    // Cache scheduled times
    private static $schedule_hours = array(
        'midnight' => 0,
        'early_morning' => 3,
        'morning' => 6,
        'evening' => 20
    );

    public static function init() {
        // Use object caching for schedules
        wp_cache_add_non_persistent_groups('wpi_schedules');

        add_action('init', array(__CLASS__, 'register_schedules'));
        add_action('wpi_scheduled_update_check', array(__CLASS__, 'process_scheduled_updates'));
        add_action('wpi_send_update_report', array(__CLASS__, 'send_update_report'));
        add_action('wpi_cleanup_logs', array(__CLASS__, 'cleanup_old_logs'));
    }

    public static function register_schedules() {
        // Register custom schedules if needed
        add_filter('cron_schedules', function($schedules) {
            $schedules['weekly'] = array(
                'interval' => 7 * DAY_IN_SECONDS,
                'display' => 'Once Weekly'
            );
            return $schedules;
        });

        // Schedule update checks
        if (!wp_next_scheduled('wpi_scheduled_update_check')) {
            wp_schedule_event(time(), 'daily', 'wpi_scheduled_update_check');
        }

        // Schedule report sending
        $report_frequency = get_option('wpi_update_report_frequency', 'weekly');
        if (get_option('wpi_update_email_reports') && !wp_next_scheduled('wpi_send_update_report')) {
            wp_schedule_event(time(), $report_frequency, 'wpi_send_update_report');
        }

        // Schedule log cleanup
        if (!wp_next_scheduled('wpi_cleanup_logs')) {
            wp_schedule_event(time(), 'daily', 'wpi_cleanup_logs');
        }
    }

    public static function process_scheduled_updates() {
        // Check if another process is already running
        if (get_transient('wpi_processing_updates')) {
            return;
        }

        // Set processing lock for 15 minutes
        set_transient('wpi_processing_updates', true, 15 * MINUTE_IN_SECONDS);

        try {
            $schedule_time = get_option('wpi_update_schedule_time', 'midnight');
            $current_hour = current_time('G');
            
            if ($current_hour !== self::$schedule_hours[$schedule_time]) {
                return;
            }

            // Process delayed updates
            if (get_option('wpi_update_delay_updates')) {
                $delay_days = get_option('wpi_update_delay_days', 1);
                $delayed_updates = get_option('wpi_delayed_updates', array());
                
                // Process updates in batches
                $batch_size = 5;
                $processed = 0;
                
                foreach ($delayed_updates as $key => $update) {
                    if (time() >= $update['scheduled_time']) {
                        self::process_delayed_update($update);
                        unset($delayed_updates[$key]);
                        
                        $processed++;
                        if ($processed >= $batch_size) {
                            break;
                        }
                    }
                }
                
                update_option('wpi_delayed_updates', $delayed_updates);
            }
        } finally {
            // Always remove the processing lock
            delete_transient('wpi_processing_updates');
        }
    }

    private static function process_delayed_update($update) {
        require_once(ABSPATH . 'wp-admin/includes/class-wp-upgrader.php');
        
        switch ($update['type']) {
            case 'core':
                $upgrader = new Core_Upgrader();
                $result = $upgrader->upgrade($update['version']);
                break;
                
            case 'plugin':
                $upgrader = new Plugin_Upgrader();
                $result = $upgrader->upgrade($update['file']);
                break;
                
            case 'theme':
                $upgrader = new Theme_Upgrader();
                $result = $upgrader->upgrade($update['stylesheet']);
                break;
        }

        WordPress_Inspector_Updates_Utils::log_update(
            $update['type'],
            $update['name'],
            $update['version'],
            $result ? 'success' : 'failed'
        );
    }

    public static function send_update_report() {
        // Implement report caching
        $cache_key = 'wpi_update_report_' . date('Y-m-d');
        $report = wp_cache_get($cache_key);

        if (false === $report) {
            $report = self::generate_update_report();
            wp_cache_set($cache_key, $report, '', DAY_IN_SECONDS);
        }

        $admin_email = get_option('admin_email');
        $headers = array('Content-Type: text/html; charset=UTF-8');
        $subject = sprintf('[%s] WordPress Update Report', get_bloginfo('name'));
        
        wp_mail($admin_email, $subject, $report, $headers);
    }

    private static function generate_update_report() {
        ob_start();
        include WPI_PLUGIN_DIR . 'views/emails/update-report.php';
        return ob_get_clean();
    }

    public static function cleanup_old_logs() {
        if (get_option('wpi_update_auto_clear_logs')) {
            $retention_days = get_option('wpi_update_log_retention', 30);
            WordPress_Inspector_Updates_Utils::clear_old_logs($retention_days);
        }
    }
} 