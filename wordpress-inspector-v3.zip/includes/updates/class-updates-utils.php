<?php
class WordPress_Inspector_Updates_Utils {
    // Add nonce verification constant
    const NONCE_ACTION = 'wpi_updates_nonce';

    /**
     * Verify update operations permissions
     */
    public static function verify_update_operation() {
        if (!current_user_can('manage_options')) {
            wp_die(__('Unauthorized access', 'wordpress-inspector'));
        }

        if (!check_ajax_referer(self::NONCE_ACTION, 'nonce', false)) {
            wp_die(__('Invalid security token', 'wordpress-inspector'));
        }
    }

    /**
     * Sanitize update data
     */
    public static function sanitize_update_data($data) {
        return array(
            'type' => sanitize_key($data['type']),
            'name' => sanitize_text_field($data['name']),
            'version' => sanitize_text_field($data['version']),
            'status' => sanitize_key($data['status'])
        );
    }

    /**
     * Check for any settings or constants that might override update controls
     */
    public static function check_update_overrides() {
        // Only apply rate limiting to API calls, not internal checks
        $is_ajax = defined('DOING_AJAX') && DOING_AJAX;
        if ($is_ajax && !self::check_rate_limit('check_overrides', 10)) {
            return array('Rate limit exceeded. Please try again in 10 seconds.');
        }

        $overrides = array();
        
        // Check common constants
        if (defined('AUTOMATIC_UPDATER_DISABLED') && AUTOMATIC_UPDATER_DISABLED) {
            $overrides[] = 'AUTOMATIC_UPDATER_DISABLED constant is set to true';
        }
        
        if (defined('WP_AUTO_UPDATE_CORE') && WP_AUTO_UPDATE_CORE === false) {
            $overrides[] = 'WP_AUTO_UPDATE_CORE constant is preventing core updates';
        }
        
        // Check filters
        if (has_filter('automatic_updater_disabled')) {
            $overrides[] = 'The automatic_updater_disabled filter is active';
        }
        
        if (has_filter('allow_minor_auto_core_updates')) {
            $overrides[] = 'The allow_minor_auto_core_updates filter is active';
        }
        
        // Check wp-config location
        if (file_exists(ABSPATH . 'wp-config.php')) {
            $overrides[] = 'wp-config.php is in the root directory (recommended to move it one level up)';
        }
        
        // Check file permissions
        $wp_config_path = ABSPATH . 'wp-config.php';
        if (file_exists($wp_config_path) && (fileperms($wp_config_path) & 0777) > 0644) {
            $overrides[] = 'wp-config.php has unsafe file permissions';
        }
        
        // Check WordPress core version
        $core = get_site_transient('update_core');
        if ($core && !empty($core->updates)) {
            foreach ($core->updates as $update) {
                if ($update->response === 'upgrade' && version_compare(get_bloginfo('version'), $update->current, '<')) {
                    // Only add to overrides if current version is actually lower
                    $overrides[] = 'WordPress ' . $update->current . ' is available';
                    break;
                }
            }
        }
        
        return $overrides;
    }

    /**
     * Implement rate limiting
     */
    private static function check_rate_limit($key, $seconds) {
        $transient_key = 'wpi_rate_limit_' . $key . '_' . get_current_user_id();
        if (get_transient($transient_key)) {
            return false;
        }
        set_transient($transient_key, true, $seconds);
        return true;
    }

    /**
     * Validate and sanitize log query args
     */
    private static function sanitize_log_args($args) {
        return array(
            'search' => isset($args['search']) ? sanitize_text_field($args['search']) : '',
            'type' => isset($args['type']) ? sanitize_key($args['type']) : '',
            'start_date' => isset($args['start_date']) ? sanitize_text_field($args['start_date']) : '',
            'end_date' => isset($args['end_date']) ? sanitize_text_field($args['end_date']) : '',
            'page' => isset($args['page']) ? absint($args['page']) : 1,
            'per_page' => isset($args['per_page']) ? absint($args['per_page']) : 20
        );
    }

    /**
     * Check plugin health and compatibility
     */
    public static function check_plugins_health() {
        $health = array(
            'unmaintained' => array(),
            'compatibility_issues' => array()
        );
        
        if (!function_exists('plugins_api')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin-install.php');
        }
        
        $all_plugins = get_plugins();
        $wp_version = get_bloginfo('version');
        
        foreach ($all_plugins as $plugin_file => $plugin_data) {
            $slug = dirname($plugin_file);
            if ($slug === '.') continue;
            
            // Check if plugin exists in WordPress.org
            $api = plugins_api('plugin_information', array('slug' => $slug));
            
            if (is_wp_error($api)) {
                $health['unmaintained'][] = array(
                    'name' => $plugin_data['Name'],
                    'file' => $plugin_file
                );
                continue;
            }
            
            // Check compatibility
            if (isset($api->tested) && version_compare($wp_version, $api->tested, '>')) {
                $health['compatibility_issues'][] = array(
                    'name' => $plugin_data['Name'],
                    'file' => $plugin_file,
                    'tested' => $api->tested
                );
            }
        }
        
        return $health;
    }

    /**
     * Get update logs with performance optimizations
     */
    public static function get_update_logs($args = array()) {
        global $wpdb;
        
        // Sanitize input
        $args = self::sanitize_log_args($args);
        
        // Use prepared statements
        $where = array('1=1');
        $prepare_values = array();
        
        if (!empty($args['search'])) {
            $where[] = 'item_name LIKE %s';
            $prepare_values[] = '%' . $wpdb->esc_like($args['search']) . '%';
        }
        
        // Add query caching
        $cache_key = 'wpi_logs_' . md5(serialize($args));
        $cached_results = wp_cache_get($cache_key);
        
        if (false !== $cached_results) {
            return $cached_results;
        }
        
        // Optimize query with LIMIT and indexing
        $offset = ($args['page'] - 1) * $args['per_page'];
        $limit = $args['per_page'] > 0 ? "LIMIT {$offset}, {$args['per_page']}" : '';
        
        $results = array(
            'logs' => $wpdb->get_results($wpdb->prepare(
                "SELECT SQL_CALC_FOUND_ROWS * FROM {$wpdb->prefix}wpi_update_logs 
                 WHERE " . implode(' AND ', $where) . " 
                 ORDER BY update_date DESC $limit",
                $prepare_values
            )),
            'total' => $wpdb->get_var('SELECT FOUND_ROWS()')
        );
        
        // Cache results for 5 minutes
        wp_cache_set($cache_key, $results, '', 300);
        
        return $results;
    }

    /**
     * Log an update with batching support
     */
    public static function log_update($type, $item_name, $version, $status) {
        static $batch = array();
        
        // Add to batch
        $batch[] = self::sanitize_update_data(array(
            'type' => $type,
            'name' => $item_name,
            'version' => $version,
            'status' => $status
        ));
        
        // Process batch if it reaches 50 items or if explicitly requested
        if (count($batch) >= 50 || defined('WPI_PROCESS_LOG_BATCH')) {
            self::process_log_batch($batch);
            $batch = array();
        }
    }

    /**
     * Process a batch of logs
     */
    private static function process_log_batch($batch) {
        global $wpdb;
        
        if (empty($batch)) {
            return;
        }
        
        // Prepare bulk insert
        $values = array();
        $placeholders = array();
        
        foreach ($batch as $log) {
            $values[] = $log['type'];
            $values[] = $log['name'];
            $values[] = $log['version'];
            $values[] = $log['status'];
            $values[] = current_time('mysql');
            $placeholders[] = '(%s, %s, %s, %s, %s)';
        }
        
        $query = $wpdb->prepare(
            "INSERT INTO {$wpdb->prefix}wpi_update_logs 
            (update_type, item_name, version, status, update_date) 
            VALUES " . implode(', ', $placeholders),
            $values
        );
        
        $wpdb->query($query);
    }

    /**
     * Clear old logs
     */
    public static function clear_old_logs($days) {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'wpi_update_logs';
        $date = date('Y-m-d H:i:s', strtotime("-$days days"));
        
        return $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM $table_name WHERE update_date < %s",
                $date
            )
        );
    }

    /**
     * Export logs
     */
    public static function export_logs($format = 'csv', $args = array()) {
        $logs = self::get_update_logs(array_merge($args, array('per_page' => -1)));
        
        if ($format === 'csv') {
            $output = fopen('php://output', 'w');
            fputcsv($output, array('Date', 'Type', 'Item', 'Version', 'Status'));
            
            foreach ($logs['logs'] as $log) {
                fputcsv($output, array(
                    $log->update_date,
                    $log->update_type,
                    $log->item_name,
                    $log->version,
                    $log->status
                ));
            }
            
            fclose($output);
            return true;
        }
        
        if ($format === 'json') {
            return wp_json_encode($logs['logs']);
        }
        
        return false;
    }
} 