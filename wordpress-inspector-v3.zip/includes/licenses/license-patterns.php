<?php
/**
 * License Key Patterns
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

return array(
    array(
        'name' => 'Advanced Custom Fields Pro',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'acf_pro_license'"
    ),
    array(
        'name' => 'Advanced Database Cleaner Pro',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'aDBc_edd_license_key'"
    ),
    array(
        'name' => 'Akismet Anti-spam: Spam Protection',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'wordpress_api_key'"
    ),
    array(
        'name' => 'Content Views Pro',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'pt_cv_options'"
    ),
    array(
        'name' => 'Divi Builder',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'et_automatic_updates_options'"
    ),
    array(
        'name' => 'Elementor Pro',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'elementor_pro_license_key'"
    ),
    array(
        'name' => 'Envato Market',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'envato_market'"
    ),
    array(
        'name' => 'Gravity Forms',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'rg_gforms_key'"
    ),
    array(
        'name' => 'Paid Memberships Pro*',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'pmpro_license_key'"
    ),
    array(
        'name' => 'ShortPixel Image Optimizer',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'spio_key'"
    ),
    array(
        'name' => 'TranslatePress*',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'trp_license_key'"
    ),
    array(
        'name' => 'WooCommerce',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'woocommerce_license_key'"
    ),
    array(
        'name' => 'Wordfence*',
        'type' => 'db',
        'query' => "SELECT val FROM {prefix}wfconfig WHERE name = 'apiKey'"
    ),
    array(
        'name' => 'WP Forms',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'wpforms_license'"
    ),
    array(
        'name' => 'WP Rocket',
        'type' => 'file',
        'query' => array(
            'file' => 'wp-rocket/wp-rocket.php',
            'pattern' => '/[\'"]rocket_license[\'"](?:\s*=>?\s*)[\'"]([a-zA-Z0-9-_]{20,})[\'"]/'
        )
    ),
    array(
        'name' => 'WP ULike*',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'wp_ulike_pro_license_key'"
    ),
    array(
        'name' => 'Yoast SEO Premium',
        'type' => 'db',
        'query' => "SELECT option_value FROM {prefix}options WHERE option_name = 'wordpress_seo_license'"
    )
);
