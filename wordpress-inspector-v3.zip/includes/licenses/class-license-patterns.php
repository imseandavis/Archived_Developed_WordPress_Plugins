<?php
/**
 * License Pattern Detection Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * License pattern detection functions
 */
class WordPress_Inspector_License_Patterns {

    /**
     * Store patterns
     *
     * @var array
     */
    private static $patterns = null;

    /**
     * Get license patterns
     *
     * @return array License patterns
     */
    public static function get_patterns() {
        if (self::$patterns === null) {
            try {
                self::$patterns = require WPI_PLUGIN_DIR . 'includes/licenses/license-patterns.php';
            } catch (Exception $e) {
                error_log('WordPress Inspector: Error loading license patterns: ' . $e->getMessage());
                self::$patterns = array();
            }
        }
        return self::$patterns;
    }

    /**
     * Scan for license keys
     *
     * @return array Found license keys
     */
    public static function scan_for_licenses() {
        global $wpdb;
        $licenses = array();
        $patterns = self::get_patterns();

        foreach ($patterns as $pattern) {
            try {
                if ($pattern['type'] === 'db') {
                    // Get table name from query if not explicitly set
                    $table_name = isset($pattern['table']) 
                        ? str_replace('{prefix}', $wpdb->prefix, $pattern['table'])
                        : $wpdb->prefix . 'options';  // Default to options table
                    
                    // Check if table exists before querying
                    $table_exists = $wpdb->get_var($wpdb->prepare(
                        "SELECT COUNT(1) FROM information_schema.tables WHERE table_schema = DATABASE() AND table_name = %s",
                        $table_name
                    ));
                    
                    if (!$table_exists) {
                        continue;  // Skip to next pattern if table doesn't exist
                    }
                    
                    // Replace prefix placeholder with actual prefix
                    $query = str_replace('{prefix}', $wpdb->prefix, $pattern['query']);
                    
                    // Execute query and catch any database errors
                    $wpdb->suppress_errors(true);
                    $result = $wpdb->get_var($query);
                    $wpdb->suppress_errors(false);
                    
                    // Only add if we found a value
                    if (!empty($result) && !is_wp_error($result)) {
                        $licenses[] = array(
                            'plugin' => $pattern['name'],
                            'file' => 'wp-options',
                            'key' => $result,
                            'type' => 'Database Key'
                        );
                    }
                } elseif ($pattern['type'] === 'file') {
                    $file_path = WP_PLUGIN_DIR . '/' . $pattern['query']['file'];
                    
                    // Only proceed if file exists and is readable
                    if (file_exists($file_path) && is_readable($file_path)) {
                        $content = @file_get_contents($file_path);
                        if ($content !== false && preg_match($pattern['query']['pattern'], $content, $matches)) {
                            $licenses[] = array(
                                'plugin' => $pattern['name'],
                                'file' => $pattern['query']['file'],
                                'key' => $matches[1],
                                'type' => 'File Key'
                            );
                        }
                    }
                }
            } catch (Exception $e) {
                error_log('WordPress Inspector: Error scanning license pattern - ' . $e->getMessage());
                continue;
            }
        }

        // Also scan for generic patterns in all plugin files
        try {
            $plugin_licenses = self::scan_plugin_files();
            $licenses = array_merge($licenses, $plugin_licenses);
        } catch (Exception $e) {
            error_log('WordPress Inspector: Error scanning plugin files - ' . $e->getMessage());
        }

        return $licenses;
    }

    /**
     * Scan plugin files for generic license patterns
     *
     * @return array Found license keys
     */
    private static function scan_plugin_files() {
        $licenses = array();
        $plugin_dir = WP_PLUGIN_DIR;

        if (is_dir($plugin_dir)) {
            try {
                $files = new RecursiveIteratorIterator(
                    new RecursiveDirectoryIterator($plugin_dir, RecursiveDirectoryIterator::SKIP_DOTS)
                );

                foreach ($files as $file) {
                    try {
                        // Skip non-PHP files and directories
                        if ($file->isDir() || $file->getExtension() !== 'php') {
                            continue;
                        }

                        // Skip unreadable files
                        if (!$file->isReadable()) {
                            continue;
                        }

                        // Safely read file contents
                        $content = @file_get_contents($file->getPathname());
                        if ($content === false) {
                            continue;
                        }

                        // Skip if content is empty
                        if (empty($content)) {
                            continue;
                        }

                        $found_licenses = self::find_generic_licenses($content, $file->getPathname());
                        $licenses = array_merge($licenses, $found_licenses);
                    } catch (Exception $e) {
                        // Log error but continue scanning
                        error_log('WordPress Inspector: Error scanning file ' . $file->getPathname() . ': ' . $e->getMessage());
                        continue;
                    }
                }
            } catch (Exception $e) {
                error_log('WordPress Inspector: Error scanning plugin directory: ' . $e->getMessage());
                // Return any licenses found so far
            }
        }

        return $licenses;
    }

    /**
     * Find generic license patterns in content
     *
     * @param string $content Content to search
     * @param string $file File path
     * @return array Found license keys
     */
    private static function find_generic_licenses($content, $file) {
        $licenses = array();
        $patterns = array(
            'license_key' => '/[\'"](?:license_key|license|key)[\'"](?:\s*=>?\s*)[\'"]([a-zA-Z0-9-_]{20,})[\'"]/',
            'api_key' => '/[\'"](?:api_key|apikey)[\'"](?:\s*=>?\s*)[\'"]([a-zA-Z0-9-_]{20,})[\'"]/',
            'token' => '/[\'"](?:token|access_token)[\'"](?:\s*=>?\s*)[\'"]([a-zA-Z0-9-_]{20,})[\'"]/',
            'envato' => '/[\'"](?:envato_key|envato_token)[\'"](?:\s*=>?\s*)[\'"]([a-zA-Z0-9-_]{20,})[\'"]/'
        );

        foreach ($patterns as $type => $pattern) {
            if (preg_match_all($pattern, $content, $matches)) {
                foreach ($matches[1] as $match) {
                    $licenses[] = array(
                        'plugin' => self::get_plugin_name($file),
                        'file' => str_replace(WP_PLUGIN_DIR . '/', '', $file),
                        'key' => $match,
                        'type' => ucfirst(str_replace('_', ' ', $type))
                    );
                }
            }
        }

        return $licenses;
    }

    /**
     * Get plugin name from file path
     *
     * @param string $file File path
     * @return string Plugin name
     */
    private static function get_plugin_name($file) {
        if (!function_exists('get_plugin_data')) {
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');
        }

        $plugin_data = get_plugin_data($file);
        return !empty($plugin_data['Name']) ? $plugin_data['Name'] : basename(dirname($file));
    }

    /**
     * Get license key for a specific plugin
     *
     * @param string $plugin_slug The plugin slug to check
     * @return string The license key if found, empty string otherwise
     */
    public static function get_license_key($plugin_slug) {
        // Special case for Akismet
        if ($plugin_slug === 'akismet') {
            return get_option('wordpress_api_key', '');
        }

        // Get all licenses
        $licenses = self::scan_for_licenses();
        
        // Look for a license for this plugin
        foreach ($licenses as $license) {
            if (strpos($license['file'], $plugin_slug . '/') === 0) {
                return $license['key'];
            }
        }

        return '';
    }

    /**
     * Mask a license key for display
     *
     * @param string $license License key to mask
     * @return string Masked license key
     */
    public static function mask_license($license) {
        if (empty($license)) {
            return '';
        }
        
        $length = strlen($license);
        if ($length <= 8) {
            return str_repeat('*', $length);
        }
        
        return substr($license, 0, 4) . str_repeat('*', $length - 8) . substr($license, -4);
    }

    /**
     * Get license count safely
     *
     * @return int Number of licenses found
     */
    public static function get_license_count() {
        try {
            $licenses = self::scan_for_licenses();
            return count($licenses);
        } catch (Exception $e) {
            error_log('WordPress Inspector: Error counting licenses - ' . $e->getMessage());
            return 0;
        }
    }
} 