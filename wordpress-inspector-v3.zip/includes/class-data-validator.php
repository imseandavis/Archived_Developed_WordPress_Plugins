<?php
namespace WordPressInspector;

/**
 * Data validation class
 */
class Data_Validator {
    /**
     * Validate and sanitize settings
     *
     * @param array $settings Array of settings to validate
     * @return array|WP_Error Validated settings or WP_Error on failure
     */
    public static function validate_settings($settings) {
        $validated = [];
        $errors = new \WP_Error();

        // Validate email settings
        if (isset($settings['email_reports'])) {
            $validated['email_reports'] = (bool) $settings['email_reports'];
        }

        // Validate report frequency
        if (isset($settings['report_frequency'])) {
            $frequency = sanitize_text_field($settings['report_frequency']);
            $allowed_frequencies = ['daily', 'weekly', 'monthly'];
            if (in_array($frequency, $allowed_frequencies)) {
                $validated['report_frequency'] = $frequency;
            } else {
                $errors->add(
                    'invalid_frequency',
                    __('Invalid report frequency selected', 'wordpress-inspector')
                );
            }
        }

        // Validate retention period (must be between 1-365 days)
        if (isset($settings['log_retention'])) {
            $retention = absint($settings['log_retention']);
            if ($retention >= 1 && $retention <= 365) {
                $validated['log_retention'] = $retention;
            } else {
                $errors->add(
                    'invalid_retention',
                    __('Log retention must be between 1 and 365 days', 'wordpress-inspector')
                );
            }
        }

        // Validate delay days (must be between 0-30 days)
        if (isset($settings['delay_days'])) {
            $delay = absint($settings['delay_days']);
            if ($delay >= 0 && $delay <= 30) {
                $validated['delay_days'] = $delay;
            } else {
                $errors->add(
                    'invalid_delay',
                    __('Update delay must be between 0 and 30 days', 'wordpress-inspector')
                );
            }
        }

        // Validate schedule time
        if (isset($settings['schedule_time'])) {
            $time = sanitize_text_field($settings['schedule_time']);
            $allowed_times = ['midnight', 'early_morning', 'morning', 'afternoon', 'evening'];
            if (in_array($time, $allowed_times)) {
                $validated['schedule_time'] = $time;
            } else {
                $errors->add(
                    'invalid_time',
                    __('Invalid schedule time selected', 'wordpress-inspector')
                );
            }
        }

        if ($errors->has_errors()) {
            return $errors;
        }

        return $validated;
    }

    /**
     * Validate and sanitize search/replace data
     *
     * @param array $data Search/replace data to validate
     * @return array|WP_Error Validated data or WP_Error on failure
     */
    public static function validate_search_replace($data) {
        $validated = [];
        $errors = new \WP_Error();

        // Validate search term
        if (empty($data['search'])) {
            $errors->add(
                'empty_search',
                __('Search term is required', 'wordpress-inspector')
            );
        } else {
            $validated['search'] = sanitize_text_field($data['search']);
        }

        // Validate replace term
        if (isset($data['replace'])) {
            $validated['replace'] = sanitize_text_field($data['replace']);
        }

        // Validate tables
        if (empty($data['tables']) || !is_array($data['tables'])) {
            $errors->add(
                'invalid_tables',
                __('At least one table must be selected', 'wordpress-inspector')
            );
        } else {
            global $wpdb;
            $allowed_tables = $wpdb->get_col('SHOW TABLES');
            $validated['tables'] = array_intersect(
                array_map('sanitize_text_field', $data['tables']),
                $allowed_tables
            );

            if (empty($validated['tables'])) {
                $errors->add(
                    'invalid_tables',
                    __('No valid tables selected', 'wordpress-inspector')
                );
            }
        }

        if ($errors->has_errors()) {
            return $errors;
        }

        return $validated;
    }
} 