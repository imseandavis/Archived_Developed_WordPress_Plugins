<?php
/**
 * Security Check Patterns
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

return array(
    'directory_browsing' => array(
        'description' => 'Directory browsing is enabled',
        'category' => 'FILE SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Add "Options -Indexes" to your .htaccess file or disable directory browsing in your web server configuration.',
        'impact' => 'Enabled directory browsing could expose sensitive files and folder structures.',
        'check_function_name' => '_check_directory_browsing',
        'autofix' => array(
            'action' => '_fix_directory_browsing',
            'button_text' => 'Autofix',
            'confirmation' => 'This will add protection against directory browsing to your .htaccess file. Continue?'
        )
    ),
    'admin_user' => array(
        'description' => 'Default "admin" username exists',
        'category' => 'USER SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Create a new administrator account with a different username and delete the "admin" user.',
        'impact' => 'Using the default "admin" username makes your site more vulnerable to brute force attacks.',
        'check_function_name' => '_check_admin_user',
        'autofix' => array(
            'action' => '_fix_admin_user',
            'button_text' => 'Autofix',
            'confirmation' => 'This will create a new admin user and delete the default "admin" account. Continue?'
        )
    ),
    'file_permissions' => array(
        'description' => 'Incorrect file permissions detected',
        'category' => 'FILE SECURITY',
        'severity' => 3,
        'score' => 70,
        'grade' => 'C',
        'solution' => 'Update file permissions to recommended WordPress values (644 for files, 755 for directories).',
        'impact' => 'Incorrect file permissions could allow unauthorized access or modifications to your files.',
        'check_function_name' => '_check_file_permissions',
        'autofix' => array(
            'action' => '_fix_file_permissions',
            'button_text' => 'Autofix',
            'confirmation' => 'This will update file permissions to WordPress recommended values. Continue?'
        )
    ),
    'ssl_certificate' => array(
        'description' => 'SSL certificate issues detected',
        'category' => 'SSL SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Install a valid SSL certificate and ensure proper configuration.',
        'impact' => 'Invalid SSL certificates can expose your site to man-in-the-middle attacks and trigger browser warnings.',
        'check_function_name' => '_check_ssl_certificate',
        'autofix' => null // No quick fix available - requires hosting intervention
    ),
    'wp_debug' => array(
        'description' => 'WordPress debug mode is enabled',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Disable WP_DEBUG in wp-config.php for production sites.',
        'impact' => 'Enabled debug mode could expose sensitive information about your site structure and errors.',
        'check_function_name' => '_check_wp_debug',
        'autofix' => array(
            'action' => '_fix_wp_debug',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable WordPress debug mode in wp-config.php. Continue?'
        )
    ),
    'file_editor' => array(
        'description' => 'WordPress file editor is enabled',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Disable the WordPress file editor by adding DISALLOW_FILE_EDIT constant in wp-config.php.',
        'impact' => 'Enabled file editor could allow attackers to modify theme and plugin files if they gain access.',
        'check_function_name' => '_check_file_editor',
        'autofix' => array(
            'action' => '_fix_file_editor',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable the WordPress file editor. Continue?'
        )
    ),
    'php_version' => array(
        'description' => 'Outdated PHP version detected',
        'category' => 'SERVER SECURITY',
        'severity' => 4,
        'score' => 65,
        'grade' => 'D',
        'solution' => 'Update to a supported PHP version (recommended: 7.4 or higher).',
        'impact' => 'Outdated PHP versions may contain security vulnerabilities and lack important security features.',
        'check_function_name' => '_check_php_version',
        'autofix' => null // No quick fix available - requires hosting intervention
    ),
    'wp_version' => array(
        'description' => 'WordPress core is not up to date',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 4,
        'score' => 65,
        'grade' => 'D',
        'solution' => 'Update WordPress to the latest version.',
        'impact' => 'Outdated WordPress versions may contain known security vulnerabilities.',
        'check_function_name' => '_check_wordpress_version',
        'autofix' => array(
            'action' => '_fix_wordpress_update',
            'button_text' => 'Autofix',
            'confirmation' => 'This will update WordPress to the latest version. Continue?'
        )
    ),
    'user_registration' => array(
        'description' => 'User registration is enabled',
        'category' => 'USER SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Disable user registration if not needed, or ensure proper user role restrictions are in place.',
        'impact' => 'Open user registration could allow unauthorized users to create accounts on your site.',
        'check_function_name' => '_check_user_registration',
        'autofix' => array(
            'action' => '_fix_user_registration',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable public user registration. Continue?'
        )
    ),
    'xmlrpc_enabled' => array(
        'description' => 'XML-RPC is enabled',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Disable XML-RPC if not needed by adding appropriate rules to .htaccess or using a security plugin.',
        'impact' => 'XML-RPC can be exploited for brute force attacks and DDoS attempts.',
        'check_function_name' => '_check_xmlrpc',
        'autofix' => array(
            'action' => '_fix_xmlrpc',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable XML-RPC functionality. Continue?'
        )
    ),
    'rest_api' => array(
        'description' => 'REST API is publicly accessible',
        'category' => 'API SECURITY',
        'severity' => 2,
        'score' => 80,
        'grade' => 'B',
        'solution' => 'Restrict REST API access to authenticated users only if not needed publicly.',
        'impact' => 'Public REST API access could expose sensitive site information.',
        'check_function_name' => '_check_rest_api',
        'autofix' => array(
            'action' => '_fix_rest_api',
            'button_text' => 'Autofix',
            'confirmation' => 'This will restrict REST API access to authenticated users only. Continue?'
        )
    ),
    'db_prefix' => array(
        'description' => 'Default database prefix (wp_) is being used',
        'category' => 'DATABASE SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Change the database prefix in wp-config.php and update database tables accordingly.',
        'impact' => 'Using the default prefix makes it easier for attackers to guess table names.',
        'check_function_name' => '_check_db_prefix',
        'autofix' => null // No quick fix - requires database modification
    ),
    'wp_config_access' => array(
        'description' => 'wp-config.php is publicly accessible',
        'category' => 'FILE SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Move wp-config.php above the web root or protect it with .htaccess rules.',
        'impact' => 'Accessible configuration file could expose sensitive database and security information.',
        'check_function_name' => '_check_wp_config_access',
        'autofix' => array(
            'action' => '_fix_wp_config_access',
            'button_text' => 'Autofix',
            'confirmation' => 'This will add protection rules for wp-config.php to your .htaccess file. Continue?'
        )
    ),
    'wp_config_permissions' => array(
        'description' => 'wp-config.php has incorrect permissions',
        'category' => 'FILE SECURITY',
        'severity' => 3,
        'score' => 70,
        'grade' => 'C',
        'solution' => 'Set wp-config.php permissions to 0600 or 0400.',
        'impact' => 'Incorrect permissions could allow other users on the server to read or modify your configuration.',
        'check_function_name' => '_check_wp_config_permissions',
        'autofix' => array(
            'action' => '_fix_wp_config_permissions',
            'button_text' => 'Autofix',
            'confirmation' => 'This will set wp-config.php permissions to 0600. Continue?'
        )
    ),
    'plugin_theme_editor' => array(
        'description' => 'Plugin/Theme editor is enabled',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Disable the plugin and theme editor by adding DISALLOW_FILE_EDIT to wp-config.php.',
        'impact' => 'Built-in file editor could allow attackers to modify plugin and theme files if they gain access.',
        'check_function_name' => '_check_file_editor',
        'autofix' => array(
            'action' => '_fix_file_editor',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable the WordPress file editor. Continue?'
        )
    ),
    'mixed_content' => array(
        'description' => 'Mixed content detected on site',
        'category' => 'SSL SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Update all content URLs to use HTTPS instead of HTTP.',
        'impact' => 'Mixed content can trigger browser warnings and compromise the security of your HTTPS connection.',
        'check_function_name' => '_check_mixed_content',
        'autofix' => array(
            'action' => '_fix_mixed_content',
            'button_text' => 'Autofix',
            'confirmation' => 'This will attempt to update content URLs to HTTPS. Continue?'
        )
    ),
    'security_headers' => array(
        'description' => 'Missing security headers',
        'category' => 'SERVER SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Add recommended security headers to your server configuration.',
        'impact' => 'Missing security headers can make your site more vulnerable to various attacks.',
        'check_function_name' => '_check_security_headers',
        'autofix' => array(
            'action' => '_fix_security_headers',
            'button_text' => 'Autofix',
            'confirmation' => 'This will add recommended security headers to your .htaccess file. Continue?'
        )
    ),
    'salt_age' => array(
        'description' => 'WordPress salt keys are outdated',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Update WordPress salt keys in wp-config.php.',
        'impact' => 'Old salt keys could make authentication cookies more vulnerable to attacks.',
        'check_function_name' => '_check_salt_age',
        'autofix' => array(
            'action' => '_fix_salt_age',
            'button_text' => 'Autofix',
            'confirmation' => 'This will update WordPress salt keys. All users will be logged out. Continue?'
        )
    ),
    'upload_execution' => array(
        'description' => 'PHP execution allowed in uploads folder',
        'category' => 'FILE SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Disable PHP execution in the uploads directory.',
        'impact' => 'Allowing PHP execution in upload directories could allow attackers to execute malicious code.',
        'check_function_name' => '_check_upload_execution',
        'autofix' => array(
            'action' => '_fix_upload_execution',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable PHP execution in the uploads directory. Continue?'
        )
    ),
    'cache_execution' => array(
        'description' => 'PHP execution allowed in cache folder',
        'category' => 'FILE SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Disable PHP execution in the cache directory.',
        'impact' => 'Allowing PHP execution in cache directories could allow attackers to execute malicious code.',
        'check_function_name' => '_check_cache_execution',
        'autofix' => array(
            'action' => '_fix_cache_execution',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable PHP execution in the cache directory. Continue?'
        )
    ),
    'backup_execution' => array(
        'description' => 'PHP execution allowed in backup folder',
        'category' => 'FILE SECURITY',
        'severity' => 4,
        'score' => 60,
        'grade' => 'D',
        'solution' => 'Disable PHP execution in the backup directory.',
        'impact' => 'Allowing PHP execution in backup directories could allow attackers to execute malicious code.',
        'check_function_name' => '_check_backup_execution',
        'autofix' => array(
            'action' => '_fix_backup_execution',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable PHP execution in the backup directory. Continue?'
        )
    ),
    'version_visible' => array(
        'description' => 'WordPress version is publicly visible',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Remove WordPress version from public view.',
        'impact' => 'Visible version numbers make it easier for attackers to target known vulnerabilities.',
        'check_function_name' => '_check_version_visible',
        'autofix' => array(
            'action' => '_fix_version_visible',
            'button_text' => 'Autofix',
            'confirmation' => 'This will remove WordPress version from public view. Continue?'
        )
    ),
    'powered_by_header' => array(
        'description' => 'X-Powered-By header is visible',
        'category' => 'SERVER SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Remove X-Powered-By header from server responses.',
        'impact' => 'This header can reveal information about your server technology to potential attackers.',
        'check_function_name' => '_check_powered_by_header',
        'autofix' => array(
            'action' => '_fix_powered_by_header',
            'button_text' => 'Autofix',
            'confirmation' => 'This will remove the X-Powered-By header. Continue?'
        )
    ),
    'user_enumeration' => array(
        'description' => 'User enumeration is possible',
        'category' => 'USER SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Disable user enumeration through URLs.',
        'impact' => 'User enumeration makes it easier for attackers to discover valid usernames for attacks.',
        'check_function_name' => '_check_user_enumeration',
        'autofix' => array(
            'action' => '_fix_user_enumeration',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable user enumeration through URLs. Continue?'
        )
    ),
    'login_feedback' => array(
        'description' => 'Login error messages are too detailed',
        'category' => 'USER SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Make login error messages more generic.',
        'impact' => 'Detailed error messages can help attackers determine valid usernames.',
        'check_function_name' => '_check_login_feedback',
        'autofix' => array(
            'action' => '_fix_login_feedback',
            'button_text' => 'Autofix',
            'confirmation' => 'This will make login error messages more generic. Continue?'
        )
    ),
    'pingback_enabled' => array(
        'description' => 'XML-RPC Pingback is enabled',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 3,
        'score' => 75,
        'grade' => 'C',
        'solution' => 'Disable XML-RPC Pingback functionality.',
        'impact' => 'Pingbacks can be used in DDoS attacks against your site.',
        'check_function_name' => '_check_pingback_enabled',
        'autofix' => array(
            'action' => '_fix_pingback_enabled',
            'button_text' => 'Autofix',
            'confirmation' => 'This will disable XML-RPC Pingback functionality. Continue?'
        )
    ),
    'inactive_plugins' => array(
        'description' => 'Inactive plugins detected',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Remove inactive plugins from the system.',
        'impact' => 'Inactive plugins can contain vulnerabilities and should be removed if not needed.',
        'check_function_name' => '_check_inactive_plugins',
        'autofix' => array(
            'action' => '_fix_inactive_plugins',
            'button_text' => 'Autofix',
            'confirmation' => 'This will remove all inactive plugins. Continue?'
        )
    ),
    'inactive_themes' => array(
        'description' => 'Inactive non-parent themes detected',
        'category' => 'WORDPRESS SECURITY',
        'severity' => 2,
        'score' => 85,
        'grade' => 'B',
        'solution' => 'Remove inactive themes that are not parent themes.',
        'impact' => 'Unnecessary themes can contain vulnerabilities and should be removed.',
        'check_function_name' => '_check_inactive_themes',
        'autofix' => array(
            'action' => '_fix_inactive_themes',
            'button_text' => 'Autofix',
            'confirmation' => 'This will remove all inactive non-parent themes. Continue?'
        )
    ),
    'heartbeat_enabled' => array(
        'description' => 'WordPress Heartbeat API enabled',
        'category' => 'PERFORMANCE',
        'severity' => 1,
        'score' => 90,
        'grade' => 'A',
        'solution' => 'Optimize or disable WordPress Heartbeat API.',
        'impact' => 'The Heartbeat API can increase server load and admin-ajax.php requests.',
        'check_function_name' => '_check_heartbeat_enabled',
        'autofix' => array(
            'action' => '_fix_heartbeat_enabled',
            'button_text' => 'Autofix',
            'confirmation' => 'This will optimize the WordPress Heartbeat API settings. Continue?'
        )
    )
);
