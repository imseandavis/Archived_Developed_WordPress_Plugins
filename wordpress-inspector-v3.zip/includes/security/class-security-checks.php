<?php
/**
 * Security Checks Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Security_Checks {

    /**
     * Check directory browsing status
     * Configuration Based Check
     */
    public static function _check_directory_browsing() {
        return !file_exists(ABSPATH . '.htaccess') || 
               !strpos(file_get_contents(ABSPATH . '.htaccess'), 'Options -Indexes');
    }

    /**
     * Check directory browsing status
     * Check from external user perspective
     */
    public static function _check_directory_browsing_external() {
        $test_url = site_url() . '/wp-includes/';
        $response = wp_remote_get($test_url);
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200 
            && strpos(wp_remote_retrieve_body($response), 'Index of') !== false;
    }

    /**
     * Check if admin user exists
     */
    public static function _check_admin_user() {
        $admin_user = get_user_by('login', 'admin');
        return $admin_user > 0;
    }

    /**
     * Check if guest user exists
     */
    public static function _check_guest_user() {
        $guest_user = get_user_by('login', 'guest');
        return $guest_user > 0;
    }

    /**
     * Check file permissions
     */
    public static function _check_file_permissions() {
        return !wp_is_writable(ABSPATH . 'wp-config.php') || 
               !wp_is_writable(ABSPATH . '.htaccess');
    }

    /**
     * Check SSL certificate
     */
    public static function _check_ssl_certificate() {
        return !is_ssl() || !get_option('siteurl') || parse_url(get_option('siteurl'), PHP_URL_SCHEME) !== 'https';
    }


    /**
     * Check SSL certificate
     * Check from external user perspective
     */
    public static function _check_ssl_certificate_external() {
        if (!is_ssl()) {
            return true;
        }

        $response = wp_remote_get(home_url('/', 'https'));
        return is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200;
    }

    /**
     * Check WordPress debug mode
     */
    public static function _check_wp_debug() {
        return defined('WP_DEBUG') && WP_DEBUG === true;
    }

    /**
     * Check file editor status
     */
    public static function _check_file_editor() {
        return !defined('DISALLOW_FILE_EDIT') || !DISALLOW_FILE_EDIT;
    }

    /**
     * Check PHP version
     */
    public static function _check_php_version() {
        return version_compare(PHP_VERSION, '7.4', '<');
    }

    /**
     * Check WordPress version
     */
    public static function _check_wordpress_version() {
        require_once ABSPATH . 'wp-admin/includes/update.php';
        $core_updates = get_core_updates();
        return !empty($core_updates) && $core_updates[0]->response === 'upgrade';
    }

    /**
     * Check user registration status
     * Supports both single and multisite installations
     */
    public static function _check_user_registration() {   
        if (is_multisite()) {
            // Check network-wide registration settings for multisite
            return get_site_option('registration') !== 'none';
        } else {
            // For single-site installations
            return get_option('users_can_register') == 1;
        }
    }

    /**
     * Check XML-RPC status
     * Check from external user perspective
     */
    public static function _check_xmlrpc() {
        $response = wp_remote_post(home_url('/xmlrpc.php'), [
            'body' => ['method' => 'demo.sayHello']
        ]);
        
        if (is_wp_error($response)) {
            // Error occurred (e.g., file blocked or not accessible)
            return false;
        }
        
        if (wp_remote_retrieve_response_code($response) === 200) {
            // XML-RPC is enabled and accessible
            return true;
        }
        
        // XML-RPC is disabled or blocked
        return false;
    }

    /**
     * Check REST API access
     */
    public static function _check_rest_api() {
        $response = wp_remote_get(rest_url());
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }

    /**
     * Check database prefix
     */
    public static function _check_db_prefix() {
        global $wpdb;
        return $wpdb->prefix === 'wp_';
    }

    /**
     * Check wp-config.php access
     */
    public static function _check_wp_config_access() {
        $response = wp_remote_get(site_url('/wp-config.php'));
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 403;
    }

    /**
     * Check wp-config.php permissions
     */
    public static function _check_wp_config_permissions() {
        $wp_config = ABSPATH . 'wp-config.php';
        return file_exists($wp_config) && (fileperms($wp_config) & 0777) > 0600;
    }

    /**
     * Check for mixed content
     */
    public static function _check_mixed_content() {
        global $wpdb;
        
        // Check posts and pages for HTTP content
        $mixed_content = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts} 
            WHERE (post_content LIKE '%http://%' OR post_content LIKE '%src=\"//%') 
            AND post_status = 'publish'"
        );
        
        // Check options table for HTTP content
        $mixed_options = $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->options} 
            WHERE option_value LIKE '%http://%'"
        );
        
        return ($mixed_content > 0 || $mixed_options > 0);
    }

    /**
     * Check security headers
     */
    public static function _check_security_headers() {
        $response = wp_remote_get(home_url());
        if (is_wp_error($response)) {
            return false;
        }

        $headers = wp_remote_retrieve_headers($response);
        $required_headers = array(
            'X-Content-Type-Options',
            'X-XSS-Protection',
            'X-Frame-Options',
            'Strict-Transport-Security',
            'Content-Security-Policy'
        );

        foreach ($required_headers as $header) {
            if (!isset($headers[$header])) {
                return true; // Issue found
            }
        }
        return false;
    }

    /**
     * Check WordPress salt age
     */
    public static function _check_salt_age() {
        $wp_config = ABSPATH . 'wp-config.php';
        if (!file_exists($wp_config)) {
            return false;
        }

        $config_content = file_get_contents($wp_config);
        if (preg_match('/define\(\s*\'AUTH_SALT\',\s*\'([^\']+)\'\s*\)/', $config_content, $matches)) {
            $salt_modified_time = filemtime($wp_config);
            $three_months = 3 * 30 * 24 * 60 * 60; // 3 months in seconds
            return (time() - $salt_modified_time) > $three_months;
        }
        return false;
    }

    /**
     * Check PHP execution in uploads directory
     */
    public static function _check_upload_execution() {
        $upload_dir = wp_upload_dir();
        $test_file = $upload_dir['basedir'] . '/test.php';
        
        // Try to create a test PHP file
        if (@file_put_contents($test_file, '<?php echo "test"; ?>')) {
            $response = wp_remote_get($upload_dir['baseurl'] . '/test.php');
            @unlink($test_file); // Clean up
            
            return !is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 403;
        }
        return false;
    }

    /**
     * Check PHP execution in cache directory
     */
    public static function _check_cache_execution() {
        $cache_dir = WP_CONTENT_DIR . '/cache';
        if (!is_dir($cache_dir)) {
            return false;
        }

        $test_file = $cache_dir . '/test.php';
        if (@file_put_contents($test_file, '<?php echo "test"; ?>')) {
            $response = wp_remote_get(content_url('cache/test.php'));
            @unlink($test_file);
            
            return !is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 403;
        }
        return false;
    }

    /**
     * Check PHP execution in backup directory
     */
    public static function _check_backup_execution() {
        $backup_dir = WP_CONTENT_DIR . '/backup';
        if (!is_dir($backup_dir)) {
            return false;
        }

        $test_file = $backup_dir . '/test.php';
        if (@file_put_contents($test_file, '<?php echo "test"; ?>')) {
            $response = wp_remote_get(content_url('backup/test.php'));
            @unlink($test_file);
            
            return !is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 403;
        }
        return false;
    }

    /**
     * Check if WordPress version is visible
     */
    public static function _check_version_visible() {
        $response = wp_remote_get(home_url());
        if (is_wp_error($response)) {
            return false;
        }

        $body = wp_remote_retrieve_body($response);
        return strpos($body, 'meta name="generator" content="WordPress') !== false;
    }

    /**
     * Check for X-Powered-By header
     */
    public static function _check_powered_by_header() {
        $response = wp_remote_get(home_url());
        if (is_wp_error($response)) {
            return false;
        }

        $headers = wp_remote_retrieve_headers($response);
        return isset($headers['x-powered-by']);
    }

    /**
     * Check for user enumeration vulnerability
     */
    public static function _check_user_enumeration() {
        $response = wp_remote_get(home_url('/?author=1'));
        if (is_wp_error($response)) {
            return false;
        }

        $code = wp_remote_retrieve_response_code($response);
        return $code === 200 || $code === 301 || $code === 302;
    }

    /**
     * Check login error message detail level
     */
    public static function _check_login_feedback() {
        return !has_filter('login_errors', '__return_null');
    }

    /**
     * Check if XML-RPC pingback is enabled
     */
    public static function _check_pingback_enabled() {
        $response = wp_remote_post(site_url('/xmlrpc.php'), array(
            'body' => '<?xml version="1.0" encoding="UTF-8"?><methodCall><methodName>pingback.ping</methodName></methodCall>'
        ));

        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) !== 403;
    }

    /**
     * Check for inactive plugins
     */
    public static function _check_inactive_plugins() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        
        return count($all_plugins) > count($active_plugins);
    }

    /**
     * Check for inactive non-parent themes
     */
    public static function _check_inactive_themes() {
        $themes = wp_get_themes();
        $active_theme = wp_get_theme();
        $parent_theme = $active_theme->parent();
        
        $inactive_count = 0;
        foreach ($themes as $theme) {
            if ($theme->get_stylesheet() !== $active_theme->get_stylesheet() && 
                (!$parent_theme || $theme->get_stylesheet() !== $parent_theme->get_stylesheet())) {
                $inactive_count++;
            }
        }
        
        return $inactive_count > 0;
    }

    /**
     * Check WordPress Heartbeat API status
     */
    public static function _check_heartbeat_enabled() {
        return !has_filter('heartbeat_settings', function($settings) {
            return array('interval' => 60);
        });
    }
} 