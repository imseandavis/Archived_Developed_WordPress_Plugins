<?php
/**
 * Security Fixes Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Security_Fixes {

    /**
     * Fix mixed content
     */
    public static function _fix_mixed_content() {
        global $wpdb;
        
        // Update posts and pages
        $wpdb->query(
            "UPDATE {$wpdb->posts} 
            SET post_content = REPLACE(post_content, 'http://', 'https://'),
                post_content = REPLACE(post_content, 'src=\"//', 'src=\"https://')
            WHERE post_status = 'publish'"
        );
        
        // Update options
        $wpdb->query(
            "UPDATE {$wpdb->options} 
            SET option_value = REPLACE(option_value, 'http://', 'https://')
            WHERE option_value LIKE '%http://%'"
        );
        
        return true;
    }

    /**
     * Fix security headers
     */
    public static function _fix_security_headers() {
        $htaccess = ABSPATH . '.htaccess';
        $rules = "\n# Security Headers\n" .
                "Header set X-Content-Type-Options nosniff\n" .
                "Header set X-XSS-Protection \"1; mode=block\"\n" .
                "Header set X-Frame-Options SAMEORIGIN\n" .
                "Header set Strict-Transport-Security \"max-age=31536000; includeSubDomains\"\n" .
                "Header set Content-Security-Policy \"default-src 'self';\"\n";
        
        return file_put_contents($htaccess, $rules, FILE_APPEND) !== false;
    }

    /**
     * Fix WordPress salt keys
     */
    public static function _fix_salt_age() {
        $wp_config = ABSPATH . 'wp-config.php';
        if (!is_writable($wp_config)) {
            return false;
        }

        $salt_keys = array(
            'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY',
            'AUTH_SALT', 'SECURE_AUTH_SALT', 'LOGGED_IN_SALT', 'NONCE_SALT'
        );

        $response = wp_remote_get('https://api.wordpress.org/secret-key/1.1/salt/');
        if (is_wp_error($response)) {
            return false;
        }

        $salts = wp_remote_retrieve_body($response);
        $config = file_get_contents($wp_config);

        foreach ($salt_keys as $key) {
            $config = preg_replace(
                "/define\(\s*'" . $key . "',\s*'[^']+'\s*\);/",
                "define('" . $key . "', '" . wp_generate_password(64, true, true) . "');",
                $config
            );
        }

        return file_put_contents($wp_config, $config) !== false;
    }

    /**
     * Fix PHP execution in uploads directory
     */
    public static function _fix_upload_execution() {
        $upload_dir = wp_upload_dir();
        $htaccess = $upload_dir['basedir'] . '/.htaccess';
        
        $rules = "<FilesMatch \".php$\">\n" .
                "Order Deny,Allow\n" .
                "Deny from all\n" .
                "</FilesMatch>";
        
        return file_put_contents($htaccess, $rules) !== false;
    }

    /**
     * Fix PHP execution in cache directory
     */
    public static function _fix_cache_execution() {
        $cache_dir = WP_CONTENT_DIR . '/cache';
        if (!is_dir($cache_dir)) {
            return true;
        }

        $htaccess = $cache_dir . '/.htaccess';
        $rules = "<FilesMatch \".php$\">\n" .
                "Order Deny,Allow\n" .
                "Deny from all\n" .
                "</FilesMatch>";
        
        return file_put_contents($htaccess, $rules) !== false;
    }

    /**
     * Fix PHP execution in backup directory
     */
    public static function _fix_backup_execution() {
        $backup_dir = WP_CONTENT_DIR . '/backup';
        if (!is_dir($backup_dir)) {
            return true;
        }

        $htaccess = $backup_dir . '/.htaccess';
        $rules = "<FilesMatch \".php$\">\n" .
                "Order Deny,Allow\n" .
                "Deny from all\n" .
                "</FilesMatch>";
        
        return file_put_contents($htaccess, $rules) !== false;
    }

    /**
     * Fix WordPress version visibility
     */
    public static function _fix_version_visible() {
        // Add filter to remove version
        add_filter('the_generator', '__return_empty_string');
        
        // Remove version from scripts and styles
        add_filter('style_loader_src', array(__CLASS__, '_remove_version_from_url'), 10, 2);
        add_filter('script_loader_src', array(__CLASS__, '_remove_version_from_url'), 10, 2);
        
        return true;
    }

    /**
     * Helper function to remove version from URLs
     */
    public static function _remove_version_from_url($src) {
        if (strpos($src, 'ver=')) {
            $src = remove_query_arg('ver', $src);
        }
        return $src;
    }

    /**
     * Fix X-Powered-By header
     */
    public static function _fix_powered_by_header() {
        $htaccess = ABSPATH . '.htaccess';
        $rules = "\n# Remove X-Powered-By header\n" .
                "Header unset X-Powered-By\n";
        
        return file_put_contents($htaccess, $rules, FILE_APPEND) !== false;
    }

    /**
     * Fix user enumeration
     */
    public static function _fix_user_enumeration() {
        $htaccess = ABSPATH . '.htaccess';
        $rules = "\n# Block user enumeration\n" .
                "RewriteCond %{QUERY_STRING} author=\d+ [NC]\n" .
                "RewriteRule ^ - [F]\n";
        
        return file_put_contents($htaccess, $rules, FILE_APPEND) !== false;
    }

    /**
     * Fix login error messages
     */
    public static function _fix_login_feedback() {
        add_filter('login_errors', '__return_null');
        return true;
    }

    /**
     * Fix XML-RPC pingback
     */
    public static function _fix_pingback_enabled() {
        add_filter('xmlrpc_methods', function($methods) {
            unset($methods['pingback.ping']);
            unset($methods['pingback.extensions.getPingbacks']);
            return $methods;
        });
        
        return true;
    }

    /**
     * Fix inactive plugins
     */
    public static function _fix_inactive_plugins() {
        if (!function_exists('get_plugins')) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins');
        $deleted = true;

        foreach ($all_plugins as $plugin_path => $plugin_data) {
            if (!in_array($plugin_path, $active_plugins)) {
                if (!delete_plugins(array($plugin_path))) {
                    $deleted = false;
                }
            }
        }

        return $deleted;
    }

    /**
     * Fix inactive themes
     */
    public static function _fix_inactive_themes() {
        $themes = wp_get_themes();
        $active_theme = wp_get_theme();
        $parent_theme = $active_theme->parent();
        $deleted = true;

        foreach ($themes as $theme_slug => $theme) {
            if ($theme->get_stylesheet() !== $active_theme->get_stylesheet() && 
                (!$parent_theme || $theme->get_stylesheet() !== $parent_theme->get_stylesheet())) {
                if (!delete_theme($theme_slug)) {
                    $deleted = false;
                }
            }
        }

        return $deleted;
    }

    /**
     * Fix WordPress Heartbeat
     */
    public static function _fix_heartbeat_enabled() {
        add_filter('heartbeat_settings', function($settings) {
            return array(
                'interval' => 60,
                'autostart' => false
            );
        });
        
        return true;
    }

    /**
     * Fix admin user
     */
    public static function _fix_admin_user() {
        $user = get_user_by('login', 'admin');
        if ($user) {
            require_once(ABSPATH . 'wp-admin/includes/user.php');
            return wp_delete_user($user->ID);
        }
        return false;
    }

    /**
     * Fix guest user
     */
    public static function _fix_guest_user() {
        $user = get_user_by('login', 'guest');
        if ($user) {
            require_once(ABSPATH . 'wp-admin/includes/user.php');
            return wp_delete_user($user->ID);
        }
        return false;
    }
} 