<?php
/**
 * Database Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Database utility functions
 */
class WordPress_Inspector_DB_Utils {
    /**
     * Get database size information
     *
     * @return array Database size details
     */
    public static function get_db_size() {
        global $wpdb;
        
        try {
            $query = $wpdb->prepare(
                "SELECT SUM(data_length + index_length) as size 
                FROM information_schema.TABLES 
                WHERE table_schema = %s",
                DB_NAME
            );
            
            $result = $wpdb->get_row($query);
            
            if ($wpdb->last_error) {
                throw new Exception($wpdb->last_error);
            }
            
            return array(
                'size' => $result ? $result->size : 0,
                'formatted' => $result ? WordPress_Inspector_Utils::format_size($result->size) : 'N/A',
                'error' => null
            );
        } catch (Exception $e) {
            WordPress_Inspector_Utils::log_error('Error getting database size', array(
                'error' => $e->getMessage()
            ));
            return array(
                'size' => 0,
                'formatted' => 'N/A',
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Check if user has MySQL SUPER privileges
     *
     * @return bool Whether user has SUPER privileges
     */
    public static function has_super_privileges() {
        global $wpdb;
        try {
            $grants = $wpdb->get_results("SHOW GRANTS FOR CURRENT_USER()", ARRAY_N);
            foreach ($grants as $grant) {
                if (strpos($grant[0], 'SUPER') !== false || strpos($grant[0], 'ALL PRIVILEGES') !== false) {
                    return true;
                }
            }
        } catch (Exception $e) {
            // If we can't check privileges, assume we don't have them
            return false;
        }
        return false;
    }

    /**
     * Configure slow query log if possible
     *
     * @return array Status of slow query log configuration
     */
    public static function configure_slow_query_log() {
        global $wpdb;
        $status = array(
            'success' => false,
            'message' => '',
            'enabled' => false
        );

        if (!self::has_super_privileges()) {
            $status['message'] = 'Insufficient MySQL privileges to configure slow query log';
            return $status;
        }

        try {
            // Only attempt to configure if we have proper privileges
            $wpdb->query("SET GLOBAL slow_query_log = 'ON'");
            $log_file = WP_CONTENT_DIR . '/mysql-slow.log';
            $wpdb->query($wpdb->prepare("SET GLOBAL slow_query_log_file = %s", $log_file));
            $wpdb->query("SET GLOBAL long_query_time = 2");

            $status['success'] = true;
            $status['enabled'] = true;
            $status['message'] = 'Slow query log configured successfully';
        } catch (Exception $e) {
            $status['message'] = 'Error configuring slow query log: ' . $e->getMessage();
        }

        return $status;
    }

    /**
     * Get table information
     *
     * @param string $table_name Table name
     * @return array Table details
     */
    public static function get_table_info($table_name) {
        global $wpdb;
        
        try {
            // Get table status
            $status = $wpdb->get_row($wpdb->prepare(
                "SHOW TABLE STATUS LIKE %s",
                $table_name
            ));

            // Get record count
            $count = $wpdb->get_var("SELECT COUNT(*) FROM `$table_name`");
            
            if ($wpdb->last_error) {
                throw new Exception($wpdb->last_error);
            }

            return array(
                'exists' => true,
                'rows' => $count,
                'size' => $status->Data_length + $status->Index_length,
                'formatted_size' => WordPress_Inspector_Utils::format_size($status->Data_length + $status->Index_length),
                'engine' => $status->Engine,
                'collation' => $status->Collation,
                'error' => null
            );
        } catch (Exception $e) {
            WordPress_Inspector_Utils::log_error('Error getting table info', array(
                'table' => $table_name,
                'error' => $e->getMessage()
            ));
            return array(
                'exists' => false,
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Get total records count across all tables
     */
    public static function get_total_records_count() {
        global $wpdb;
        $total = 0;
        
        $tables = $wpdb->get_results('SHOW TABLES', ARRAY_N);
        foreach ($tables as $table) {
            $count = $wpdb->get_var("SELECT COUNT(*) FROM {$table[0]}");
            $total += intval($count);
        }
        
        return number_format($total);
    }
} 