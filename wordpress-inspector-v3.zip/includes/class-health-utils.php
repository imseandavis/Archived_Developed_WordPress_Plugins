<?php
/**
 * Health Utilities Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Health_Utils {
    
    /**
     * Get site health stats
     */
    public static function get_health_stats() {
        // Get core site health data
        $health_info = get_transient('health-check-site-status-result');
        
        if (!$health_info) {
            // If transient doesn't exist, get fresh data
            if (!class_exists('WP_Site_Health')) {
                require_once(ABSPATH . 'wp-admin/includes/class-wp-site-health.php');
            }
            $site_health = new WP_Site_Health();
            // Initialize site health
            $site_health->init();
            $health_info = $site_health->get_site_status();
            set_transient('health-check-site-status-result', $health_info, 12 * HOUR_IN_SECONDS);
        }
        
        // Set default values if data is invalid
        $good = isset($health_info['good']) ? (int)$health_info['good'] : 0;
        $recommended = isset($health_info['recommended']) ? (int)$health_info['recommended'] : 0;
        $critical = isset($health_info['critical']) ? (int)$health_info['critical'] : 0;
        
        // Calculate percentage score
        $total_tests = $good + $recommended + $critical;
        $score = $total_tests > 0 ? ($good * 100) / $total_tests : 0;
        
        // Get categories
        $categories = array(
            'server' => array(
                'name' => 'Server Health',
                'count' => 0,
                'issues' => 0
            ),
            'database' => array(
                'name' => 'Database Health',
                'count' => 0,
                'issues' => 0
            ),
            'wordpress' => array(
                'name' => 'WordPress Health',
                'count' => 0,
                'issues' => 0
            ),
            'security' => array(
                'name' => 'Security Health',
                'count' => 0,
                'issues' => 0
            )
        );
        
        // Get detailed test results
        $tests = isset($site_health) ? $site_health->get_tests() : array();
        
        if (is_array($tests)) {
            foreach ($tests as $section) {
                if (isset($section['direct']) && is_array($section['direct'])) {
                    foreach ($section['direct'] as $test) {
                        $category = isset($test['type']) ? $test['type'] : 'wordpress';
                        if (isset($categories[$category])) {
                            $categories[$category]['count']++;
                            if (isset($test['status']) && $test['status'] !== 'good') {
                                $categories[$category]['issues']++;
                            }
                        }
                    }
                }
            }
        }
        
        // Calculate category scores
        foreach ($categories as $key => $category) {
            if ($category['count'] > 0) {
                $categories[$key]['score'] = round((($category['count'] - $category['issues']) / $category['count']) * 100);
            } else {
                $categories[$key]['score'] = 100;
            }
        }
        
        return array(
            'overall_score' => round($score),
            'categories' => $categories,
            'good' => $good,
            'recommended' => $recommended,
            'critical' => $critical
        );
    }
} 