<?php
/**
 * AJAX Handler Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_AJAX_Handler {
    /**
     * Initialize AJAX hooks
     */
    public function init() {
        // Debug and WordPress settings
        add_action('wp_ajax_toggle_debug_setting', array($this, 'handle_debug_toggle'));
        add_action('wp_ajax_update_posts_per_page', array($this, 'handle_update_posts_per_page'));
        add_action('wp_ajax_verify_debug_setting', array($this, 'handle_verify_debug_setting'));

        // Plugin actions
        add_action('wp_ajax_deactivate_plugin', array($this, 'handle_deactivate_plugin'));
        add_action('wp_ajax_delete_plugin', array($this, 'handle_delete_plugin'));
        add_action('wp_ajax_toggle_plugin_auto_update', array($this, 'handle_toggle_plugin_auto_update'));
        add_action('wp_ajax_activate_plugin', array($this, 'handle_activate_plugin'));

        // Theme actions
        add_action('wp_ajax_delete_theme', array($this, 'handle_delete_theme'));
        add_action('wp_ajax_switch_theme', array($this, 'handle_switch_theme'));

        // Security actions
        add_action('wp_ajax_wordpress_inspector_toggle_ssl', array($this, 'handle_toggle_ssl'));
        add_action('wp_ajax_wordpress_inspector_scan_passwords', array($this, 'handle_password_scan'));

        // Cleanup actions
        add_action('wp_ajax_wordpress_inspector_cleanup', array($this, 'handle_cleanup_action'));
        add_action('wp_ajax_wordpress_inspector_get_cleanup_items', array($this, 'handle_get_cleanup_items'));

        // Reset actions
        add_action('wp_ajax_wordpress_inspector_reset', array($this, 'handle_reset_action'));

        // Log actions
        add_action('wp_ajax_wordpress_inspector_clear_log', array($this, 'handle_clear_log'));
        add_action('wp_ajax_wordpress_inspector_download_log', array($this, 'handle_download_log'));

        // Security settings
        add_action('wp_ajax_wordpress_inspector_toggle_version_visibility', array($this, 'handle_toggle_version_visibility'));
        add_action('wp_ajax_wordpress_inspector_toggle_login_errors', array($this, 'handle_toggle_login_errors'));
        add_action('wp_ajax_wordpress_inspector_toggle_user_enumeration', array($this, 'handle_toggle_user_enumeration'));
        add_action('wp_ajax_wordpress_inspector_toggle_powered_by', array($this, 'handle_toggle_powered_by'));

        // Update settings
        add_action('wp_ajax_wordpress_inspector_update_core_setting', array($this, 'handle_update_core_setting'));

        // Theme and Plugin Updates
        add_action('wp_ajax_wordpress_inspector_update_theme_setting', array($this, 'handle_update_theme_setting'));
        add_action('wp_ajax_wordpress_inspector_update_plugin_setting', array($this, 'handle_update_plugin_setting'));
        add_action('wp_ajax_wordpress_inspector_update_debug_setting', array($this, 'handle_update_debug_setting'));

        add_action('wp_ajax_update_security_setting', array($this, 'update_security_setting'));

        // Add EZ Mode scan handlers
        add_action('wp_ajax_security_scan', array($this, 'handle_security_scan'));
        add_action('wp_ajax_performance_scan', array($this, 'handle_performance_scan'));
        add_action('wp_ajax_error_scan', array($this, 'handle_error_scan'));

        // Add license scan handler
        add_action('wp_ajax_scan_license_keys', array($this, 'handle_license_scan'));

        // Add security scan handler
        add_action('wp_ajax_run_security_scan', array($this, 'handle_security_scan'));
    }

    /**
     * Handle clearing log files
     */
    public function handle_clear_log() {
        if (!check_ajax_referer('wordpress_inspector_logs', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $log_type = sanitize_text_field($_POST['log_type']);
        $log_file = $log_type === 'debug' 
            ? WordPress_Inspector_Log_Utils::get_debug_log_path()
            : WordPress_Inspector_Log_Utils::get_php_error_log_path();

        if (!$log_file || !file_exists($log_file) || !is_writable($log_file)) {
            wp_send_json_error('Log file not found or not writable');
        }

        if (@file_put_contents($log_file, '') !== false) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to clear log file');
        }
    }

    /**
     * Handle downloading log files
     */
    public function handle_download_log() {
        if (!check_ajax_referer('wordpress_inspector_logs', 'nonce', false)) {
            wp_die('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $log_type = sanitize_text_field($_GET['log_type']);
        $log_file = $log_type === 'debug'
            ? WordPress_Inspector_Log_Utils::get_debug_log_path()
            : WordPress_Inspector_Log_Utils::get_php_error_log_path();

        if (!$log_file || !file_exists($log_file) || !is_readable($log_file)) {
            wp_die('Log file not found or not readable');
        }

        $download_filename = $log_type === 'debug' ? 'WordPress-Debug-Log.log' : 'PHP-Error-Log.log';

        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . $download_filename . '"');
        header('Content-Length: ' . filesize($log_file));
        readfile($log_file);
        exit;
    }

    /**
     * Handle debug setting toggle
     */
    public function handle_debug_toggle() {
        if (!check_ajax_referer('wordpress_inspector_debug_toggle', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $setting = sanitize_text_field($_POST['setting']);
        $allowed_settings = array('WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY');
        
        if (!in_array($setting, $allowed_settings)) {
            wp_send_json_error('Invalid setting');
        }

        // Get wp-config.php path
        $config_path = ABSPATH . 'wp-config.php';
        
        // Check if file exists and is writable
        if (!file_exists($config_path)) {
            wp_send_json_error('wp-config.php not found');
        }
        
        if (!is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable. Please check file permissions.');
        }

        // Read current config
        $config_content = file_get_contents($config_path);
        
        // Determine new state (toggle current state)
        $current_state = false;
        if ($setting === 'WP_DEBUG') {
            $current_state = defined('WP_DEBUG') && WP_DEBUG;
        } elseif ($setting === 'WP_DEBUG_LOG') {
            $current_state = defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;
        } elseif ($setting === 'WP_DEBUG_DISPLAY') {
            $current_state = defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY;
        }
        
        $new_state = !$current_state;

        // If turning off WP_DEBUG, also turn off WP_DEBUG_LOG and WP_DEBUG_DISPLAY
        if ($setting === 'WP_DEBUG' && !$new_state) {
            // Update WP_DEBUG_LOG
            $pattern_log = "/define\s*\(\s*['\"](WP_DEBUG_LOG)['\"].*?\);/i";
            $replacement_log = "define('WP_DEBUG_LOG', false);";
            if (preg_match($pattern_log, $config_content)) {
                $config_content = preg_replace($pattern_log, $replacement_log, $config_content);
            }

            // Update WP_DEBUG_DISPLAY
            $pattern_display = "/define\s*\(\s*['\"](WP_DEBUG_DISPLAY)['\"].*?\);/i";
            $replacement_display = "define('WP_DEBUG_DISPLAY', false);";
            if (preg_match($pattern_display, $config_content)) {
                $config_content = preg_replace($pattern_display, $replacement_display, $config_content);
            }
        }
        
        // Create pattern and replacement for the current setting
        $pattern = "/define\s*\(\s*['\"]" . $setting . "['\"]\s*,\s*(true|false)\s*\);/i";
        $replacement = "define('" . $setting . "', " . ($new_state ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle debug setting verification
     */
    public function handle_verify_debug_setting() {
        if (!check_ajax_referer('wordpress_inspector_verify_debug', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $setting = sanitize_text_field($_POST['setting']);
        $expected_state = (bool) $_POST['expected_state'];
        
        if (!in_array($setting, array('WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY'))) {
            wp_send_json_error('Invalid setting');
        }

        // Verify the actual state
        $actual_state = false;
        if ($setting === 'WP_DEBUG') {
            $actual_state = defined('WP_DEBUG') && WP_DEBUG;
        } elseif ($setting === 'WP_DEBUG_LOG') {
            $actual_state = defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;
        } elseif ($setting === 'WP_DEBUG_DISPLAY') {
            $actual_state = defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY;
        }

        wp_send_json_success(array(
            'state' => $actual_state
        ));
    }

    /**
     * Handle posts per page update
     */
    public function handle_update_posts_per_page() {
        if (!check_ajax_referer('update_posts_per_page', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $posts_per_page = intval($_POST['posts_per_page']);
        if ($posts_per_page < 1) {
            wp_send_json_error('Invalid value');
        }

        if (update_option('posts_per_page', $posts_per_page)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update setting');
        }
    }

    /**
     * Handle plugin deactivation
     */
    public function handle_deactivate_plugin() {
        if (!check_ajax_referer('deactivate_plugin_' . $_POST['plugin'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $plugin = sanitize_text_field($_POST['plugin']);
        if (deactivate_plugins($plugin, true)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to deactivate plugin');
        }
    }

    /**
     * Handle plugin deletion
     */
    public function handle_delete_plugin() {
        if (!check_ajax_referer('delete_plugin_' . $_POST['plugin'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $plugin = sanitize_text_field($_POST['plugin']);
        
        // Deactivate first if active
        if (is_plugin_active($plugin)) {
            deactivate_plugins($plugin, true);
        }

        // Delete the plugin
        if (delete_plugins(array($plugin))) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to delete plugin');
        }
    }

    /**
     * Handle plugin auto-update toggle
     */
    public function handle_toggle_plugin_auto_update() {
        if (!check_ajax_referer('toggle_auto_update_' . $_POST['plugin'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $plugin = sanitize_text_field($_POST['plugin']);
        $enable = (bool) $_POST['enable'];

        $auto_updates = (array) get_site_option('auto_update_plugins', array());

        if ($enable) {
            $auto_updates[] = $plugin;
            $auto_updates = array_unique($auto_updates);
        } else {
            $auto_updates = array_diff($auto_updates, array($plugin));
        }

        if (update_site_option('auto_update_plugins', $auto_updates)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update auto-update setting');
        }
    }

    /**
     * Handle plugin activation
     */
    public function handle_activate_plugin() {
        if (!check_ajax_referer('activate_plugin_' . $_POST['plugin'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $plugin = sanitize_text_field($_POST['plugin']);
        $result = activate_plugin($plugin);

        if (is_wp_error($result)) {
            wp_send_json_error($result->get_error_message());
        } else {
            wp_send_json_success();
        }
    }

    /**
     * Handle theme deletion
     */
    public function handle_delete_theme() {
        if (!check_ajax_referer('delete_theme_' . $_POST['theme'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $theme = sanitize_text_field($_POST['theme']);
        
        // Don't allow deleting active theme
        if ($theme === wp_get_theme()->get_stylesheet()) {
            wp_send_json_error('Cannot delete active theme');
        }

        // Include required file for delete_theme()
        require_once(ABSPATH . 'wp-admin/includes/theme.php');

        $deleted = delete_theme($theme);
        
        if (is_wp_error($deleted)) {
            wp_send_json_error($deleted->get_error_message());
        } else {
            wp_send_json_success();
        }
    }

    /**
     * Handle theme switching
     */
    public function handle_switch_theme() {
        if (!check_ajax_referer('switch_theme_' . $_POST['theme'], 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $theme = sanitize_text_field($_POST['theme']);
        
        // Check if theme exists
        $theme_obj = wp_get_theme($theme);
        if (!$theme_obj->exists()) {
            wp_send_json_error('Theme does not exist');
        }

        // Switch theme
        switch_theme($theme);
        
        wp_send_json_success();
    }

    /**
     * Handle SSL toggle
     */
    public function handle_toggle_ssl() {
        if (!check_ajax_referer('wordpress_inspector_toggle_ssl', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $setting = sanitize_text_field($_POST['setting']);
        $enabled = (bool) $_POST['enabled'];

        if ($setting !== 'FORCE_SSL_ADMIN') {
            wp_send_json_error('Invalid setting');
        }

        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"]" . $setting . "['\"].*?\);/i";
        $replacement = "define('" . $setting . "', " . ($enabled ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle password security scan
     */
    public function handle_password_scan() {
        if (!check_ajax_referer('wordpress_inspector_scan_passwords', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        // Get all users
        $users = get_users();
        $weak_passwords = 0;

        foreach ($users as $user) {
            // Check for common weak password patterns
            $user_data = get_userdata($user->ID);
            $username = $user_data->user_login;
            $email = $user_data->user_email;
            
            // This is a basic check - you might want to expand this
            $weak_patterns = array(
                'password', '123456', 'qwerty', 'admin',
                strtolower($username),
                strtolower(explode('@', $email)[0])
            );

            // Note: We can't check actual passwords as they're hashed
            // This is just checking for known weak patterns in user data
            foreach ($weak_patterns as $pattern) {
                if (strpos(strtolower($username), $pattern) !== false) {
                    $weak_passwords++;
                    break;
                }
            }
        }

        wp_send_json_success(array(
            'weak_passwords' => $weak_passwords
        ));
    }

    /**
     * Handle cleanup actions
     */
    public function handle_cleanup_action() {
        if (!check_ajax_referer('wordpress_inspector_cleanup', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        global $wpdb;
        $type = sanitize_text_field($_POST['type']);

        try {
            switch ($type) {
                case 'transients':
                    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_%'");
                    break;

                case 'revisions':
                    $wpdb->query("DELETE FROM $wpdb->posts WHERE post_type = 'revision'");
                    break;

                case 'auto_drafts':
                    $wpdb->query("DELETE FROM $wpdb->posts WHERE post_status = 'auto-draft'");
                    break;

                case 'trash':
                    $wpdb->query("DELETE FROM $wpdb->posts WHERE post_status = 'trash'");
                    break;

                case 'spam_comments':
                    $wpdb->query("DELETE FROM $wpdb->comments WHERE comment_approved = 'spam'");
                    break;

                case 'trash_comments':
                    $wpdb->query("DELETE FROM $wpdb->comments WHERE comment_approved = 'trash'");
                    break;

                case 'orphaned_meta':
                    $wpdb->query("DELETE pm FROM $wpdb->postmeta pm LEFT JOIN $wpdb->posts p ON p.ID = pm.post_id WHERE p.ID IS NULL");
                    break;

                case 'orphaned_relationships':
                    $wpdb->query("DELETE tr FROM $wpdb->term_relationships tr LEFT JOIN $wpdb->posts p ON p.ID = tr.object_id WHERE p.ID IS NULL");
                    break;

                default:
                    throw new Exception('Invalid cleanup action');
            }

            wp_send_json_success();
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Get cleanup items count
     */
    public function handle_get_cleanup_items() {
        if (!check_ajax_referer('wordpress_inspector_get_cleanup_items', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $type = sanitize_text_field($_POST['type']);
        $items = get_cleanup_items($type);
        wp_send_json_success($items);
    }

    /**
     * Handle reset actions
     */
    public function handle_reset_action() {
        if (!check_ajax_referer('wordpress_inspector_reset', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        global $wpdb;
        $action = sanitize_text_field($_POST['reset_action']);
        $current_user_id = get_current_user_id();

        try {
            switch ($action) {
                case 'reset_content':
                    // Delete all posts, pages, media, comments, and taxonomies
                    $wpdb->query("TRUNCATE TABLE $wpdb->posts");
                    $wpdb->query("TRUNCATE TABLE $wpdb->postmeta");
                    $wpdb->query("TRUNCATE TABLE $wpdb->comments");
                    $wpdb->query("TRUNCATE TABLE $wpdb->commentmeta");
                    $wpdb->query("TRUNCATE TABLE $wpdb->terms");
                    $wpdb->query("TRUNCATE TABLE $wpdb->termmeta");
                    $wpdb->query("TRUNCATE TABLE $wpdb->term_taxonomy");
                    $wpdb->query("TRUNCATE TABLE $wpdb->term_relationships");
                    break;

                case 'reset_users':
                    // Delete all users except current admin
                    $wpdb->query($wpdb->prepare(
                        "DELETE FROM $wpdb->users WHERE ID != %d",
                        $current_user_id
                    ));
                    $wpdb->query($wpdb->prepare(
                        "DELETE FROM $wpdb->usermeta WHERE user_id != %d",
                        $current_user_id
                    ));
                    break;

                case 'reset_themes':
                    $active_theme = wp_get_theme()->get_stylesheet();
                    $themes = wp_get_themes();
                    foreach ($themes as $theme_slug => $theme) {
                        if ($theme_slug !== $active_theme) {
                            delete_theme($theme_slug);
                        }
                    }
                    break;

                case 'reset_plugins':
                    $our_plugin = plugin_basename(WPI_PLUGIN_FILE);
                    $plugins = get_plugins();
                    foreach ($plugins as $plugin_path => $plugin) {
                        if ($plugin_path !== $our_plugin) {
                            if (is_plugin_active($plugin_path)) {
                                deactivate_plugins($plugin_path, true);
                            }
                            delete_plugins(array($plugin_path));
                        }
                    }
                    break;

                case 'reset_options':
                    // Preserve essential options
                    $preserve = array(
                        'siteurl', 'home', 'admin_email', 
                        'wp_user_roles', 'active_plugins'
                    );
                    
                    $saved_options = array();
                    foreach ($preserve as $option) {
                        $saved_options[$option] = get_option($option);
                    }

                    // Delete all options
                    $wpdb->query("TRUNCATE TABLE $wpdb->options");

                    // Restore preserved options
                    foreach ($saved_options as $option => $value) {
                        update_option($option, $value);
                    }

                    // Restore default options
                    wp_install_defaults($current_user_id);
                    break;

                case 'factory_reset':
                    // Perform all resets
                    $this->handle_reset_action('reset_content');
                    $this->handle_reset_action('reset_users');
                    $this->handle_reset_action('reset_themes');
                    $this->handle_reset_action('reset_plugins');
                    $this->handle_reset_action('reset_options');

                    // Clear cache and temporary data
                    wp_cache_flush();
                    $wpdb->query("DELETE FROM $wpdb->options WHERE option_name LIKE '_transient_%'");
                    
                    // Optionally recreate default content
                    wp_install_defaults($current_user_id);
                    break;

                default:
                    throw new Exception('Invalid reset action');
            }

            wp_send_json_success();
        } catch (Exception $e) {
            wp_send_json_error($e->getMessage());
        }
    }

    /**
     * Handle WordPress version visibility toggle
     */
    public function handle_toggle_version_visibility() {
        if (!check_ajax_referer('wordpress_inspector_security', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $enabled = (bool) $_POST['enabled'];
        
        // Remove or add version meta tag
        if ($enabled) {
            remove_action('wp_head', 'wp_generator');
        } else {
            add_action('wp_head', 'wp_generator');
        }

        wp_send_json_success();
    }

    /**
     * Handle login error messages toggle
     */
    public function handle_toggle_login_errors() {
        if (!check_ajax_referer('wordpress_inspector_security', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $enabled = (bool) $_POST['enabled'];
        
        // Update wp-config.php
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"](LOGIN_ERROR_MESSAGES)['\"].*?\);/i";
        $replacement = "define('LOGIN_ERROR_MESSAGES', " . ($enabled ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle user enumeration toggle
     */
    public function handle_toggle_user_enumeration() {
        if (!check_ajax_referer('wordpress_inspector_security', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $enabled = (bool) $_POST['enabled'];
        
        // Add or remove the filter that blocks user enumeration
        if (!$enabled) {
            add_filter('redirect_canonical', function($redirect, $request) {
                if (preg_match('/\?author=([0-9]*)/', $request)) {
                    return home_url();
                }
                return $redirect;
            }, 10, 2);
        }

        wp_send_json_success();
    }

    /**
     * Handle X-Powered-By header toggle
     */
    public function handle_toggle_powered_by() {
        if (!check_ajax_referer('wordpress_inspector_security', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $enabled = (bool) $_POST['enabled'];
        
        // Update .htaccess to remove header
        $htaccess_path = ABSPATH . '.htaccess';
        if (!file_exists($htaccess_path) || !is_writable($htaccess_path)) {
            wp_send_json_error('.htaccess is not writable');
        }

        $htaccess_content = file_get_contents($htaccess_path);
        $header_rule = "Header unset X-Powered-By\n";

        if (!$enabled && strpos($htaccess_content, $header_rule) === false) {
            $htaccess_content = $header_rule . $htaccess_content;
        } elseif ($enabled) {
            $htaccess_content = str_replace($header_rule, '', $htaccess_content);
        }

        if (file_put_contents($htaccess_path, $htaccess_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update .htaccess');
        }
    }

    /**
     * Handle updating WP_AUTO_UPDATE_CORE setting
     */
    public function handle_update_core_setting() {
        if (!check_ajax_referer('wordpress_inspector_update_core', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $value = sanitize_text_field($_POST['value']);
        $allowed_values = array('true', 'minor', 'false');
        
        if (!in_array($value, $allowed_values)) {
            wp_send_json_error('Invalid value');
        }

        // Get wp-config.php path
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"]WP_AUTO_UPDATE_CORE['\"].*?\);/i";
        
        // Convert value to proper PHP
        if ($value === 'true') {
            $replacement = "define('WP_AUTO_UPDATE_CORE', true);";
        } elseif ($value === 'minor') {
            $replacement = "define('WP_AUTO_UPDATE_CORE', 'minor');";
        } else {
            $replacement = "define('WP_AUTO_UPDATE_CORE', false);";
        }

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle updating WP_AUTO_UPDATE_THEME setting
     */
    public function handle_update_theme_setting() {
        if (!check_ajax_referer('wordpress_inspector_update_theme', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $value = sanitize_text_field($_POST['value']);
        if (!in_array($value, array('true', 'false'))) {
            wp_send_json_error('Invalid value');
        }

        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"]WP_AUTO_UPDATE_THEME['\"].*?\);/i";
        $replacement = "define('WP_AUTO_UPDATE_THEME', " . ($value === 'true' ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle updating WP_AUTO_UPDATE_PLUGIN setting
     */
    public function handle_update_plugin_setting() {
        if (!check_ajax_referer('wordpress_inspector_update_plugin', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $value = sanitize_text_field($_POST['value']);
        if (!in_array($value, array('true', 'false'))) {
            wp_send_json_error('Invalid value');
        }

        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"]WP_AUTO_UPDATE_PLUGIN['\"].*?\);/i";
        $replacement = "define('WP_AUTO_UPDATE_PLUGIN', " . ($value === 'true' ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    /**
     * Handle updating debug settings
     */
    public function handle_update_debug_setting() {
        if (!check_ajax_referer('wordpress_inspector_debug', 'nonce', false)) {
            wp_send_json_error('Invalid nonce');
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $setting = sanitize_text_field($_POST['setting']);
        $value = sanitize_text_field($_POST['value']);

        if (!in_array($setting, array('WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY', 'SCRIPT_DEBUG', 'SAVEQUERIES'))) {
            wp_send_json_error('Invalid setting');
        }

        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error('wp-config.php is not writable');
        }

        $config_content = file_get_contents($config_path);
        $pattern = "/define\s*\(\s*['\"]" . $setting . "['\"].*?\);/i";
        $replacement = "define('" . $setting . "', " . ($value === '1' ? 'true' : 'false') . ");";

        if (preg_match($pattern, $config_content)) {
            $new_content = preg_replace($pattern, $replacement, $config_content);
        } else {
            $new_content = preg_replace(
                "/(\/\* That's all, stop editing! Happy publishing\. \*\/)/i",
                $replacement . "\n\n$1",
                $config_content
            );
        }

        if (file_put_contents($config_path, $new_content)) {
            wp_send_json_success();
        } else {
            wp_send_json_error('Failed to update wp-config.php');
        }
    }

    public function update_security_setting() {
        check_ajax_referer('security_settings_nonce', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $setting = sanitize_text_field($_POST['setting']);
        $value = sanitize_text_field($_POST['value']);

        switch ($setting) {
            case 'default_role':
                update_option('default_role', $value);
                break;
            case 'users_can_register':
                update_option('users_can_register', $value === 'true');
                break;
            // Other cases...
        }

        wp_send_json_success();
    }

    public function handle_security_scan() {
        try {
            check_ajax_referer('security_scan_nonce', 'nonce');
            
            if (!current_user_can('manage_options')) {
                wp_send_json_error(array('message' => 'Insufficient permissions'));
                return;
            }

            // Run security scan
            $security_info = WordPress_Inspector_Security_Utils::get_security_info(true); // Pass true to force refresh
            
            wp_send_json_success();

        } catch (Exception $e) {
            wp_send_json_error(array('message' => $e->getMessage()));
        }
    }

    public function handle_performance_scan() {
        check_ajax_referer('wpi_scan_nonce', 'nonce');
        
        $performance_info = WordPress_Inspector_Performance_Utils::get_performance_info();
        $issues = array();
        
        // Process performance info
        // Add performance checks...
        
        $this->render_scan_results('Performance Scan Results', $issues);
        wp_die();
    }

    public function handle_license_scan() {
        try {
            error_log('Starting license scan...');
            
            check_ajax_referer('scan_license_keys', 'nonce');
            
            if (!current_user_can('manage_options')) {
                error_log('License scan: Insufficient permissions');
                wp_send_json_error('Insufficient permissions');
                return;
            }

            global $wpdb;
            
            // 1. Get all installed plugins
            if (!function_exists('get_plugins')) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            $all_plugins = get_plugins();
            error_log('Found ' . count($all_plugins) . ' installed plugins');
            
            // 2. Get license patterns
            $patterns = WordPress_Inspector_License_Patterns::get_patterns();
            error_log('Loaded ' . count($patterns) . ' license patterns');
            
            // 3. Format plugins and check for licenses
            $formatted_plugins = array();
            
            foreach ($all_plugins as $plugin_file => $plugin_data) {
                if (empty($plugin_data['Name'])) {
                    continue;
                }

                $plugin_name = $plugin_data['Name'];
                $plugin_info = array(
                    'plugin' => $plugin_name,
                    'plugin_slug' => dirname($plugin_file),  // Add plugin slug for thickbox URL
                    'plugin_url' => !empty($plugin_data['PluginURI']) ? $plugin_data['PluginURI'] : '',
                    'version' => $plugin_data['Version'] ?? '',
                    'author' => $plugin_data['Author'] ?? '',
                    'author_url' => !empty($plugin_data['AuthorURI']) ? $plugin_data['AuthorURI'] : '',
                    'has_license' => false,
                    'key' => '',
                    'masked_key' => 'N/A'
                );

                // Check if this plugin has a pattern
                foreach ($patterns as $pattern) {
                    $pattern_name = rtrim($pattern['name'], '*');
                    $is_wildcard = substr($pattern['name'], -1) === '*';
                    
                    // Check if plugin name matches pattern (exact match or wildcard match)
                    if ($pattern['name'] === $plugin_name || 
                        ($is_wildcard && stripos($plugin_name, $pattern_name) === 0)) {
                        
                        error_log("Found pattern match for plugin: {$plugin_name}");
                        
                        try {
                            if ($pattern['type'] === 'db') {
                                $query = str_replace('{prefix}', $wpdb->prefix, $pattern['query']);
                                error_log("Executing query: {$query}");
                                
                                $safe_query = $wpdb->prepare($query);
                                $result = $wpdb->get_var($safe_query);
                                
                                if (!empty($result)) {
                                    $plugin_info['has_license'] = true;
                                    $plugin_info['key'] = $result;
                                    $plugin_info['masked_key'] = WordPress_Inspector_License_Patterns::mask_license($result);
                                    error_log("Found DB license for plugin: {$plugin_name}");
                                    break;
                                }
                            } elseif ($pattern['type'] === 'file') {
                                $file_path = WP_PLUGIN_DIR . '/' . $pattern['query']['file'];
                                if (file_exists($file_path) && is_readable($file_path)) {
                                    $content = file_get_contents($file_path);
                                    if ($content && preg_match($pattern['query']['pattern'], $content, $matches)) {
                                        $plugin_info['has_license'] = true;
                                        $plugin_info['key'] = $matches[1];
                                        $plugin_info['masked_key'] = WordPress_Inspector_License_Patterns::mask_license($matches[1]);
                                        error_log("Found file license for plugin: {$plugin_name}");
                                        break;
                                    }
                                }
                            }
                        } catch (Exception $e) {
                            error_log("Error processing pattern for {$plugin_name}: " . $e->getMessage());
                            continue;
                        }
                    }
                }

                // Sanitize all values before adding to response
                foreach ($plugin_info as $key => $value) {
                    if (is_string($value)) {
                        $plugin_info[$key] = esc_html($value);
                    }
                }

                $formatted_plugins[] = $plugin_info;
            }

            error_log('License scan completed successfully');
            
            wp_send_json_success($formatted_plugins);

        } catch (Exception $e) {
            error_log('License scan error: ' . $e->getMessage());
            wp_send_json_error(array('message' => 'Error scanning license keys: ' . $e->getMessage()));
        }
    }

    public function handle_error_scan() {
        check_ajax_referer('wpi_scan_nonce', 'nonce');
        
        $issues = array();
        
        // Check error log
        $debug_log = WordPress_Inspector_Log_Utils::get_debug_log_path();
        if (file_exists($debug_log)) {
            $log_size = size_format(filesize($debug_log));
            $issues[] = "Debug log found: {$log_size}";
        }
        
        // Add more error checks...
        
        $this->render_scan_results('Error Scan Results', $issues);
        wp_die();
    }

    private function render_scan_results($title, $issues) {
        ?>
        <div class="wpi-scan-results-content">
            <h3><?php echo esc_html($title); ?></h3>
            <?php if (empty($issues)) : ?>
                <p class="wpi-success">No issues found!</p>
            <?php else : ?>
                <ul class="wpi-issues-list">
                    <?php foreach ($issues as $issue) : ?>
                        <li><?php echo esc_html($issue); ?></li>
                    <?php endforeach; ?>
                </ul>
            <?php endif; ?>
        </div>
        <style>
            .wpi-scan-results-content {
                margin: 20px 0;
            }
            .wpi-success {
                color: #00a32a;
                font-weight: 500;
            }
            .wpi-issues-list {
                margin: 0;
                padding: 0;
            }
            .wpi-issues-list li {
                margin: 10px 0;
                padding: 10px;
                background: #f0f6fc;
                border-left: 4px solid #2271b1;
            }
        </style>
        <?php
    }
} 