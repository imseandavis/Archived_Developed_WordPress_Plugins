<?php
/**
 * View Helper Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Helper functions for views
 */
class WordPress_Inspector_View_Helper {
    /**
     * Render a template
     *
     * @param string $template Template name
     * @param array $data Data to pass to template
     * @return void
     */
    public static function render($template, $data = array()) {
        $template_path = WPI_PLUGIN_DIR . 'views/' . $template . '.php';
        
        if (!file_exists($template_path)) {
            self::render_error('Template not found: ' . $template);
            return;
        }

        extract($data);
        include $template_path;
    }

    /**
     * Render error message
     *
     * @param string $message Error message
     * @return void
     */
    public static function render_error($message) {
        ?>
        <div class="notice notice-error">
            <p><?php echo esc_html($message); ?></p>
        </div>
        <?php
    }

    /**
     * Render loading spinner
     *
     * @return void
     */
    public static function render_spinner() {
        ?>
        <div class="spinner-wrapper">
            <span class="spinner is-active"></span>
        </div>
        <?php
    }
} 