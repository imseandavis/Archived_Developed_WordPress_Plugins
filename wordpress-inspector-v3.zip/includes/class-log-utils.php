<?php
/**
 * Log utilities class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

class WordPress_Inspector_Log_Utils {
    /**
     * Initialize logging
     */
    public static function init() {
        // Hook into WordPress cron events if enabled
        if (defined('WP_CRON_LOGGING') && WP_CRON_LOGGING) {
            add_action('wp_loaded', array(__CLASS__, 'setup_cron_logging'));
        }

        // Hook into WordPress email if enabled
        if (defined('WP_EMAIL_LOGGING') && WP_EMAIL_LOGGING) {
            add_filter('wp_mail', array(__CLASS__, 'log_email'));
        }

        // Add AJAX handlers
        add_action('wp_ajax_clear_log', array(__CLASS__, 'ajax_clear_log'));
        add_action('wp_ajax_download_log', array(__CLASS__, 'ajax_download_log'));
        add_action('wp_ajax_toggle_logging', array(__CLASS__, 'ajax_toggle_logging'));
    }

    /**
     * Setup cron logging
     */
    public static function setup_cron_logging() {
        add_action('pre_schedule_event', array(__CLASS__, 'log_cron_scheduled'), 10, 2);
        add_action('pre_reschedule_event', array(__CLASS__, 'log_cron_rescheduled'), 10, 2);
        add_action('pre_unschedule_event', array(__CLASS__, 'log_cron_unscheduled'), 10, 2);
        add_action('pre_clear_scheduled_hook', array(__CLASS__, 'log_cron_cleared'), 10, 1);
        add_action('wp_scheduled_delete', array(__CLASS__, 'log_cron_execution'));
        add_action('wp_scheduled_auto_draft_delete', array(__CLASS__, 'log_cron_execution'));
        add_action('delete_expired_transients', array(__CLASS__, 'log_cron_execution'));
    }

    /**
     * Log cron event scheduling
     */
    public static function log_cron_scheduled($event, $hook) {
        if ($event) {
            $message = sprintf(
                '[%s] Scheduled cron event: %s (Next run: %s)',
                current_time('mysql'),
                $hook,
                date('Y-m-d H:i:s', $event->timestamp)
            );
            self::write_to_log('cron', $message);
        }
        return $event;
    }

    /**
     * Log cron event rescheduling
     */
    public static function log_cron_rescheduled($event, $hook) {
        if ($event) {
            $message = sprintf(
                '[%s] Rescheduled cron event: %s (Next run: %s)',
                current_time('mysql'),
                $hook,
                date('Y-m-d H:i:s', $event->timestamp)
            );
            self::write_to_log('cron', $message);
        }
        return $event;
    }

    /**
     * Log cron event unscheduling
     */
    public static function log_cron_unscheduled($event, $hook) {
        if ($event) {
            $message = sprintf(
                '[%s] Unscheduled cron event: %s',
                current_time('mysql'),
                $hook
            );
            self::write_to_log('cron', $message);
        }
        return $event;
    }

    /**
     * Log cron hook clearing
     */
    public static function log_cron_cleared($hook) {
        $message = sprintf(
            '[%s] Cleared all scheduled events for hook: %s',
            current_time('mysql'),
            $hook
        );
        self::write_to_log('cron', $message);
    }

    /**
     * Log cron event execution
     */
    public static function log_cron_execution() {
        $current_hook = current_filter();
        $message = sprintf(
            '[%s] Executing cron event: %s',
            current_time('mysql'),
            $current_hook
        );
        self::write_to_log('cron', $message);
    }

    /**
     * Log email sending
     */
    public static function log_email($args) {
        $message = sprintf(
            "[%s] Email sent:\nTo: %s\nSubject: %s\nHeaders: %s\nMessage: %s",
            current_time('mysql'),
            is_array($args['to']) ? implode(', ', $args['to']) : $args['to'],
            $args['subject'],
            is_array($args['headers']) ? implode("\n", $args['headers']) : $args['headers'],
            wp_trim_words($args['message'], 50, '...')
        );
        self::write_to_log('email', $message);
        return $args;
    }

    /**
     * Write message to log file
     */
    private static function write_to_log($type, $message) {
        $log_file = WP_CONTENT_DIR . '/' . $type . '.log';
        
        // Create directory if it doesn't exist
        $dir = dirname($log_file);
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }

        // Append to log file
        //error_log($message . "\n", 3, $log_file);
    }

    /**
     * Clear log file
     */
    public static function clear_log($type) {
        // Get the correct log file path based on type
        $log_file = self::get_log_file_path($type);
        if (!$log_file) {
            return false;
        }

        // Special handling for PHP error log
        if ($type === 'php') {
            // For PHP error log, we need to truncate the file directly
            if (is_writable($log_file)) {
                $handle = fopen($log_file, 'w');
                if ($handle) {
                    ftruncate($handle, 0);
                    fclose($handle);
                    return true;
                }
            }
            return false;
        }

        // Create directory if it doesn't exist
        $dir = dirname($log_file);
        if (!file_exists($dir)) {
            wp_mkdir_p($dir);
        }
        
        // Create/truncate log file
        if (file_put_contents($log_file, '') !== false) {
            // Set proper permissions
            chmod($log_file, 0644);
            return true;
        }
        
        return false;
    }

    /**
     * Get WordPress Debug log path
     */
    public static function get_debug_log_path() {
        if (defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG)) {
            //error_log('Debug Log Path (from constant): ' . WP_DEBUG_LOG);
            return WP_DEBUG_LOG;
        }
        //error_log('Debug Log Path (default): ' . WP_CONTENT_DIR . '/debug.log');
        return WP_CONTENT_DIR . '/debug.log';
    }

    /**
     * Get PHP Error log path
     */
    public static function get_php_error_log_path() {
        $error_log_path = ini_get('error_log');
        if (empty($error_log_path)) {
            // Default PHP error log locations
            $possible_paths = array(
                '/var/log/php-error.log',
                '/var/log/php_errors.log',
                '/var/log/apache2/error.log',
                '/var/log/httpd/error_log'
            );
            foreach ($possible_paths as $path) {
                if (file_exists($path) && is_readable($path)) {
                    //error_log('PHP Error Log Path (from common locations): ' . $path);
                    return $path;
                }
            }
            //error_log('PHP Error Log Path not found');
            return false;
        }
        //error_log('PHP Error Log Path (from ini): ' . $error_log_path);
        return $error_log_path;
    }

    /**
     * Handle AJAX clear log request
     */
    public static function ajax_clear_log() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        if (!check_ajax_referer('wordpress_inspector_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
        }

        $log_type = sanitize_text_field($_POST['log_type']);
        $log_file = self::get_log_file_path($log_type);

        if (!$log_file) {
            wp_send_json_error(array('message' => 'Invalid log type'));
        }

        if (self::clear_log($log_type)) {
            wp_send_json_success();
        } else {
            wp_send_json_error(array('message' => 'Failed to clear log file'));
        }
    }

    /**
     * Handle AJAX download log request
     */
    public static function ajax_download_log() {
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        if (!check_ajax_referer('wordpress_inspector_nonce', 'nonce', false)) {
            wp_die('Invalid nonce');
        }

        $log_type = sanitize_text_field($_POST['log_type']);
        $log_file = self::get_log_file_path($log_type);

        if (!$log_file || !file_exists($log_file)) {
            wp_die('Log file not found');
        }

        // Set headers for download
        header('Content-Type: text/plain');
        header('Content-Disposition: attachment; filename="' . basename($log_file) . '"');
        header('Content-Length: ' . filesize($log_file));
        header('Cache-Control: no-cache, must-revalidate');
        header('Pragma: no-cache');
        header('Expires: 0');

        // Output file contents
        readfile($log_file);
        exit;
    }

    /**
     * Get log file path by type
     */
    private static function get_log_file_path($type) {
        switch ($type) {
            case 'debug':
                return self::get_debug_log_path();
            case 'php':
                return self::get_php_error_log_path();
            case 'mysql':
                global $wpdb;
                return $wpdb->get_var("SHOW VARIABLES LIKE 'log_error'", 1);
            case 'slow':
                global $wpdb;
                return $wpdb->get_var("SHOW VARIABLES LIKE 'slow_query_log_file'", 1);
            case 'cron':
                return WP_CONTENT_DIR . '/cron.log';
            case 'email':
                return WP_CONTENT_DIR . '/email.log';
            case 'htaccess':
                return ABSPATH . '.htaccess';
            default:
                return false;
        }
    }

    /**
     * Handle AJAX toggle logging request
     */
    public static function ajax_toggle_logging() {
        //error_log('Toggle Logging Request - Type: ' . $_POST['type'] . ', Enable: ' . $_POST['enable']);

        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        if (!check_ajax_referer('wordpress_inspector_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
        }

        $type = sanitize_text_field($_POST['type']);
        $enable = (bool)$_POST['enable'];
        //error_log('Processed Toggle Values - Type: ' . $type . ', Enable: ' . ($enable ? 'true' : 'false'));

        // Get wp-config.php path
        $config_path = ABSPATH . 'wp-config.php';
        if (!file_exists($config_path)) {
            $config_path = dirname(ABSPATH) . '/wp-config.php';
        }

        if (!file_exists($config_path) || !is_writable($config_path)) {
            wp_send_json_error(array('message' => 'wp-config.php not found or not writable'));
        }

        // Read wp-config.php
        $config_content = file_get_contents($config_path);

        // Define constants based on type
        $constant = $type === 'cron' ? 'WP_CRON_LOGGING' : 'WP_EMAIL_LOGGING';
        // Convert enable to boolean and then to string for the define statement
        $enable = (bool)$enable;
        $define_line = sprintf("define('%s', %s);", $constant, $enable ? 'true' : 'false');

        // Check if constant already exists
        $pattern = "/define\s*\(\s*['\"]" . $constant . "['\"]\s*,\s*(true|false)\s*\)\s*;/i";
        
        if (preg_match($pattern, $config_content)) {
            // Update existing constant
            $config_content = preg_replace($pattern, $define_line, $config_content);
        } else {
            // Add new constant after WordPress core config
            $insert_point = "/* That's all, stop editing! Happy publishing. */";
            $config_content = str_replace(
                $insert_point,
                $define_line . "\n\n" . $insert_point,
                $config_content
            );
        }

        // Backup wp-config.php
        $backup_path = $config_path . '.backup.' . time();
        if (!copy($config_path, $backup_path)) {
            wp_send_json_error(array('message' => 'Failed to create backup of wp-config.php'));
        }

        // Write updated content
        if (file_put_contents($config_path, $config_content)) {
            // If enabling logging, create the log file
            if ($enable) {
                $log_file = WP_CONTENT_DIR . '/' . $type . '.log';
                if (!file_exists($log_file)) {
                    // Create directory if it doesn't exist
                    $dir = dirname($log_file);
                    if (!file_exists($dir)) {
                        wp_mkdir_p($dir);
                    }
                    // Create empty log file
                    file_put_contents($log_file, '');
                    // Set proper permissions
                    chmod($log_file, 0644);
                }
            }

            // Clear opcode cache to ensure constant is updated
            if (function_exists('opcache_reset')) {
                opcache_reset();
            }
            
            // Clear WordPress cache
            wp_cache_flush();

            wp_send_json_success(array(
                'message' => ($enable ? 'Enabled' : 'Disabled') . ' ' . $type . ' logging'
            ));
        } else {
            // Restore backup if update failed
            copy($backup_path, $config_path);
            wp_send_json_error(array('message' => 'Failed to update wp-config.php'));
        }
    }
} 