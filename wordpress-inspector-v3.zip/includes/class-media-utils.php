<?php
/**
 * Media Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Media utility functions
 */
class WordPress_Inspector_Media_Utils {
    /**
     * Get media library statistics
     *
     * @return array Media library details
     */
    public static function get_media_stats() {
        global $wpdb;
        
        try {
            // Get total count and size
            $stats = $wpdb->get_row("
                SELECT 
                    COUNT(*) as total_files,
                    SUM(meta_value) as total_size
                FROM {$wpdb->postmeta}
                WHERE meta_key = '_wp_attachment_metadata'
            ");

            // Get file types
            $file_types = $wpdb->get_results("
                SELECT 
                    post_mime_type,
                    COUNT(*) as count
                FROM {$wpdb->posts}
                WHERE post_type = 'attachment'
                GROUP BY post_mime_type
            ");

            $mime_stats = array();
            foreach ($file_types as $type) {
                $mime_stats[$type->post_mime_type] = $type->count;
            }

            return array(
                'total_files' => (int)$stats->total_files,
                'total_size' => WordPress_Inspector_Utils::format_size((int)$stats->total_size),
                'mime_types' => $mime_stats,
                'upload_dir' => wp_upload_dir(),
                'error' => null
            );
        } catch (Exception $e) {
            WordPress_Inspector_Utils::log_error('Error getting media stats', array(
                'error' => $e->getMessage()
            ));
            return array(
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Get image sizes information
     *
     * @return array Image sizes configuration
     */
    public static function get_image_sizes() {
        $sizes = array();
        $wp_sizes = wp_get_registered_image_subsizes();
        
        foreach ($wp_sizes as $size_name => $size_data) {
            $sizes[$size_name] = array(
                'width' => $size_data['width'],
                'height' => $size_data['height'],
                'crop' => $size_data['crop'],
                'generated' => self::is_size_generated($size_name)
            );
        }

        return $sizes;
    }

    /**
     * Check if image size is being generated
     *
     * @param string $size_name Size name
     * @return boolean Whether size is generated
     */
    private static function is_size_generated($size_name) {
        $sizes = get_option('_wp_keep_backup_sizes', array());
        return isset($sizes[$size_name]);
    }
} 