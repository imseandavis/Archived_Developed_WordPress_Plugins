<?php
/**
 * Cache Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Cache utility functions
 */
class WordPress_Inspector_Cache_Utils {
    /**
     * Get cache information
     *
     * @return array Cache information
     */
    public static function get_cache_info() {
        $active_plugins = array();

        // Check for LiteSpeed Cache
        if (defined('LSCWP_V') || class_exists('LiteSpeed_Cache')) {
            $active_plugins[] = array(
                'name' => 'LiteSpeed Cache',
                'slug' => 'litespeed',
                'version' => defined('LSCWP_V') ? LSCWP_V : 'Unknown'
            );
        }

        // Check for W3 Total Cache
        if (defined('W3TC_VERSION')) {
            $active_plugins[] = array(
                'name' => 'W3 Total Cache',
                'slug' => 'w3tc',
                'version' => W3TC_VERSION
            );
        }

        return array(
            'object_cache' => array(
                'status' => wp_using_ext_object_cache() ? 'enabled' : 'disabled',
                'type' => self::get_object_cache_type()
            ),
            'page_cache' => array(
                'status' => self::is_page_cache_enabled() ? 'enabled' : 'disabled',
                'type' => self::get_page_cache_type()
            ),
            'transients' => self::get_transients_info(),
            'autoload_size' => self::get_autoload_options_info()['size'],
            'active_plugins' => $active_plugins
        );
    }

    /**
     * Check if page caching is enabled
     */
    private static function is_page_cache_enabled() {
        // Check for common page caching plugins and methods
        if (defined('WP_CACHE') && WP_CACHE) {
            return true;
        }

        $caching_plugins = array(
            'wp-super-cache/wp-cache.php',
            'w3-total-cache/w3-total-cache.php',
            'wp-fastest-cache/wpFastestCache.php',
            'litespeed-cache/litespeed-cache.php',
            'wp-rocket/wp-rocket.php'
        );

        foreach ($caching_plugins as $plugin) {
            if (is_plugin_active($plugin)) {
                return true;
            }
        }

        return false;
    }

    /**
     * Get object cache type
     */
    private static function get_object_cache_type() {
        global $wp_object_cache;
        
        if (wp_using_ext_object_cache()) {
            if (isset($wp_object_cache->cache_type)) {
                return $wp_object_cache->cache_type;
            }
            if (class_exists('Redis') || defined('WP_REDIS_CLIENT')) {
                return 'Redis';
            }
            if (class_exists('Memcache') || class_exists('Memcached')) {
                return 'Memcached';
            }
            return 'External';
        }
        
        return 'Default';
    }

    /**
     * Get page cache type
     */
    private static function get_page_cache_type() {
        if (defined('W3TC')) {
            return 'W3 Total Cache';
        }
        if (defined('WPFC_MAIN_PATH')) {
            return 'WP Fastest Cache';
        }
        if (defined('LSCWP_V')) {
            return 'LiteSpeed Cache';
        }
        if (defined('WP_ROCKET_VERSION')) {
            return 'WP Rocket';
        }
        if (defined('WP_CACHE') && WP_CACHE) {
            return 'WP Super Cache';
        }
        return 'None';
    }

    /**
     * Get transients information
     *
     * @return array Transients details
     */
    private static function get_transients_info() {
        global $wpdb;

        try {
            $count = $wpdb->get_var("
                SELECT COUNT(*) 
                FROM $wpdb->options 
                WHERE option_name LIKE '_transient_%'
            ");

            $size = $wpdb->get_var("
                SELECT SUM(LENGTH(option_value)) 
                FROM $wpdb->options 
                WHERE option_name LIKE '_transient_%'
            ");

            return array(
                'count' => (int)$count,
                'size' => $size ? size_format($size) : '0 B'
            );
        } catch (Exception $e) {
            return array(
                'count' => 0,
                'size' => '0 B'
            );
        }
    }

    /**
     * Get autoloaded options information
     *
     * @return array Autoloaded options details
     */
    private static function get_autoload_options_info() {
        global $wpdb;

        try {
            $stats = $wpdb->get_row("
                SELECT 
                    COUNT(*) as count,
                    SUM(LENGTH(option_value)) as size
                FROM $wpdb->options
                WHERE autoload = 'yes'
            ");

            return array(
                'count' => (int)$stats->count,
                'size' => (int)$stats->size,
                'formatted_size' => size_format((int)$stats->size)
            );
        } catch (Exception $e) {
            return array(
                'count' => 0,
                'size' => 0,
                'formatted_size' => '0 B'
            );
        }
    }

    /**
     * Detect active cache plugins
     *
     * @return array Active cache plugins
     */
    private static function detect_cache_plugins() {
        $cache_plugins = array(
            'wp-super-cache/wp-cache.php' => 'WP Super Cache',
            'w3-total-cache/w3-total-cache.php' => 'W3 Total Cache',
            'wp-fastest-cache/wpFastestCache.php' => 'WP Fastest Cache',
            'litespeed-cache/litespeed-cache.php' => 'LiteSpeed Cache',
            'wp-rocket/wp-rocket.php' => 'WP Rocket'
        );

        $active = array();
        foreach ($cache_plugins as $plugin => $name) {
            if (is_plugin_active($plugin)) {
                $active[$plugin] = $name;
            }
        }

        return $active;
    }
} 