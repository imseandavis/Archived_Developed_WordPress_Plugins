<?php
/**
 * Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Utility functions for WordPress Inspector
 */
class WordPress_Inspector_Utils {
    /**
     * Format size in bytes to human readable format
     *
     * @param int $bytes Size in bytes
     * @return string Formatted size
     */
    public static function format_size($bytes) {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        }
        return $bytes . ' B';
    }

    /**
     * Convert size string to bytes
     *
     * @param string $size Size string (e.g., "1GB", "512MB")
     * @return int Size in bytes
     */
    public static function size_to_bytes($size) {
        $size = trim($size);
        
        // Extract number and unit
        preg_match('/^(\d+(?:\.\d+)?)\s*([KMG]?B)?$/i', $size, $matches);
        
        if (!isset($matches[1])) {
            return 0;
        }
        
        $num = (float)$matches[1];
        $unit = strtoupper(isset($matches[2]) ? $matches[2] : '');
        
        switch ($unit) {
            case 'GB':
                return $num * 1024 * 1024 * 1024;
            case 'MB':
                return $num * 1024 * 1024;
            case 'KB':
                return $num * 1024;
            default:
                return $num;
        }
    }

    /**
     * Get the document root path
     *
     * @return string The document root path
     */
    public static function get_document_root() {
        if (isset($_SERVER['DOCUMENT_ROOT'])) {
            return $_SERVER['DOCUMENT_ROOT'];
        }
        
        // Fallback: Try to determine from ABSPATH
        $abspath = ABSPATH;
        $possible_doc_root = str_replace('/wp-admin', '', dirname($_SERVER['SCRIPT_FILENAME']));
        
        if (file_exists($possible_doc_root)) {
            return $possible_doc_root;
        }
        
        // If all else fails, return ABSPATH
        return rtrim($abspath, '/');
    }

    /**
     * Get cleanup information
     *
     * @return array Cleanup information
     */
    public static function get_cleanup_info() {
        global $wpdb;
        
        return array(
            'revisions' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = 'revision'"),
            'auto_drafts' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'auto-draft'"),
            'trash' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'trash'"),
            'spam' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = 'spam'"),
            'trash_comments' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = 'trash'"),
            'pending_comments' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = '0'"),
            'transients' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->options WHERE option_name LIKE '%_transient_%' AND option_name NOT LIKE '%_transient_timeout_%'"),
            'orphaned_postmeta' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->postmeta pm LEFT JOIN $wpdb->posts p ON p.ID = pm.post_id WHERE p.ID IS NULL"),
            'orphaned_commentmeta' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->commentmeta cm LEFT JOIN $wpdb->comments c ON c.comment_ID = cm.comment_id WHERE c.comment_ID IS NULL"),
            'orphaned_usermeta' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->usermeta um LEFT JOIN $wpdb->users u ON u.ID = um.user_id WHERE u.ID IS NULL"),
            'orphaned_termmeta' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->termmeta tm LEFT JOIN $wpdb->terms t ON t.term_id = tm.term_id WHERE t.term_id IS NULL"),
            'orphaned_relationships' => $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->term_relationships tr LEFT JOIN $wpdb->posts p ON p.ID = tr.object_id WHERE p.ID IS NULL")
        );
    }

    /**
     * Convert memory size string to bytes
     *
     * @param string $size_str Memory size string (e.g., "1G", "512M", "2048K")
     * @return int Size in bytes
     */
    public static function convert_to_bytes($size_str) {
        $size_str = trim($size_str);
        $last = strtolower($size_str[strlen($size_str)-1]);
        $value = intval($size_str);
        
        switch($last) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }

    /**
     * Get color based on usage percentage
     *
     * @param float $percentage Usage percentage
     * @return string Color in hex format
     */
    public static function get_usage_color($percentage) {
        if ($percentage <= 60) {
            // Green to Yellow (60% and below)
            return '#22c55e';
        } elseif ($percentage <= 80) {
            // Yellow to Orange (61-80%)
            return '#fbbf24';
        } elseif ($percentage <= 90) {
            // Orange to Red (81-90%)
            return '#f97316';
        } else {
            // Red (above 90%)
            return '#ef4444';
        }
    }

    /**
     * Format size with appropriate unit
     *
     * @param int $bytes Size in bytes
     * @return string Formatted size with unit
     */
    public static function format_size_dynamic($bytes) {
        $units = array('B', 'KB', 'MB', 'GB', 'TB');
        $bytes = max($bytes, 0);
        
        // Start with bytes and work up
        $pow = 0;
        while ($bytes >= 1024 && $pow < count($units) - 1) {
            $bytes /= 1024;
            $pow++;
        }
        
        $pow = min($pow, count($units) - 1);
        
        return round($bytes, 1) . $units[$pow];
    }

    /**
     * Parse size string to bytes
     */
    public static function parse_size($size) {
        if (empty($size)) {
            return 0;
        }

        $size = trim($size);
        if (empty($size)) {
            return 0;
        }

        if (!preg_match('/^(\d+)([KMGT])?$/i', $size, $matches)) {
            return 0;
        }

        $value = (int) $matches[1];
        $unit = isset($matches[2]) ? strtolower($matches[2]) : '';
        
        switch ($unit) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }
} 