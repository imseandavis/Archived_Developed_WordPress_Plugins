<?php
/**
 * Plugin Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Plugin utility functions
 */
class WordPress_Inspector_Plugin_Utils {
    /**
     * Get plugin information
     *
     * @param string $plugin_file Plugin file path
     * @return array Plugin details
     */
    public static function get_plugin_info($plugin_file) {
        try {
            if (!file_exists(WP_PLUGIN_DIR . '/' . $plugin_file)) {
                throw new Exception('Plugin file not found');
            }

            $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin_file);
            $is_active = is_plugin_active($plugin_file);
            $auto_update = in_array($plugin_file, (array) get_site_option('auto_update_plugins', array()));

            return array(
                'exists' => true,
                'name' => $plugin_data['Name'],
                'version' => $plugin_data['Version'],
                'author' => $plugin_data['Author'],
                'author_uri' => $plugin_data['AuthorURI'],
                'description' => $plugin_data['Description'],
                'is_active' => $is_active,
                'auto_update' => $auto_update,
                'error' => null
            );
        } catch (Exception $e) {
            WordPress_Inspector_Utils::log_error('Error getting plugin info', array(
                'plugin' => $plugin_file,
                'error' => $e->getMessage()
            ));
            return array(
                'exists' => false,
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Get plugin directory size
     *
     * @param string $plugin_dir Plugin directory
     * @return array Size information
     */
    public static function get_plugin_size($plugin_dir) {
        try {
            $path = WP_PLUGIN_DIR . '/' . $plugin_dir;
            if (!is_dir($path)) {
                throw new Exception('Plugin directory not found');
            }

            $size = self::get_directory_size($path);
            return array(
                'size' => $size,
                'formatted' => WordPress_Inspector_Utils::format_size($size),
                'error' => null
            );
        } catch (Exception $e) {
            return array(
                'size' => 0,
                'formatted' => 'N/A',
                'error' => $e->getMessage()
            );
        }
    }

    /**
     * Calculate directory size recursively
     *
     * @param string $path Directory path
     * @return int Total size in bytes
     */
    private static function get_directory_size($path) {
        $size = 0;
        $files = scandir($path);
        
        foreach ($files as $file) {
            if ($file === '.' || $file === '..') continue;
            
            $filepath = $path . '/' . $file;
            if (is_dir($filepath)) {
                $size += self::get_directory_size($filepath);
            } else {
                $size += filesize($filepath);
            }
        }
        
        return $size;
    }
} 