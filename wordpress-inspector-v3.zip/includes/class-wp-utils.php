<?php
/**
 * WordPress Core Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * WordPress core utility functions
 */
class WordPress_Inspector_WP_Utils {
    /**
     * Get WordPress core information
     *
     * @return array WordPress details
     */
    public static function get_wp_info() {
        return array(
            'version' => array(
                'current' => get_bloginfo('version'),
                'db_version' => get_option('db_version'),
                'updates' => self::get_update_info()
            ),
            'site' => array(
                'name' => get_bloginfo('name'),
                'description' => get_bloginfo('description'),
                'url' => get_site_url(),
                'home' => get_home_url(),
                'admin_email' => get_option('admin_email'),
                'language' => get_locale(),
                'timezone' => wp_timezone_string(),
                'multisite' => is_multisite()
            ),
            'constants' => self::get_wp_constants(),
            'cron' => self::get_cron_info()
        );
    }

    /**
     * Get WordPress update information
     *
     * @return array Update details
     */
    private static function get_update_info() {
        $core_updates = get_core_updates();
        $latest = !empty($core_updates[0]) ? $core_updates[0] : null;

        return array(
            'latest_version' => $latest ? $latest->version : null,
            'update_available' => $latest && $latest->response === 'upgrade',
            'update_type' => $latest ? $latest->response : null
        );
    }

    /**
     * Get WordPress cron information
     *
     * @return array Cron details
     */
    private static function get_cron_info() {
        $cron = _get_cron_array();
        $events = array();

        if ($cron) {
            foreach ($cron as $timestamp => $hooks) {
                foreach ($hooks as $hook => $hook_events) {
                    foreach ($hook_events as $key => $event) {
                        $events[] = array(
                            'hook' => $hook,
                            'timestamp' => $timestamp,
                            'schedule' => $event['schedule'] ?? 'single',
                            'args' => $event['args']
                        );
                    }
                }
            }
        }

        return array(
            'disabled' => defined('DISABLE_WP_CRON') && DISABLE_WP_CRON,
            'events' => $events
        );
    }

    /**
     * Get WordPress constants
     *
     * @return array Constants and their values
     */
    private static function get_wp_constants() {
        $constants = array(
            'WP_DEBUG', 'WP_DEBUG_LOG', 'WP_DEBUG_DISPLAY',
            'SCRIPT_DEBUG', 'WP_CACHE', 'CONCATENATE_SCRIPTS',
            'COMPRESS_SCRIPTS', 'COMPRESS_CSS', 'WP_LOCAL_DEV',
            'DB_CHARSET', 'DB_COLLATE', 'WP_MEMORY_LIMIT',
            'WP_MAX_MEMORY_LIMIT', 'WP_CONTENT_DIR', 'WP_CONTENT_URL',
            'WP_PLUGIN_DIR', 'WP_PLUGIN_URL', 'WPMU_PLUGIN_DIR',
            'WPMU_PLUGIN_URL', 'WP_POST_REVISIONS', 'EMPTY_TRASH_DAYS',
            'WP_ALLOW_MULTISITE', 'MULTISITE', 'WP_CACHE'
        );

        $values = array();
        foreach ($constants as $constant) {
            $values[$constant] = array(
                'defined' => defined($constant),
                'value' => defined($constant) ? constant($constant) : null
            );
        }

        return $values;
    }
} 