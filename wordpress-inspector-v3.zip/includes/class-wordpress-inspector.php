<?php
/**
 * Main WordPress Inspector class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Main plugin class
 */
class WordPress_Inspector {
    /**
     * Initialize the plugin
     *
     * @since 1.0.0
     */
    public function __construct() {
        // Check if upgrade is needed
        $this->maybe_upgrade();
        
        // Load required files
        require_once WPI_PLUGIN_DIR . 'includes/class-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/updates/class-updates-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/updates/class-updates-scheduler.php';         
        require_once WPI_PLUGIN_DIR . 'includes/licenses/class-license-patterns.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-security-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-db-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-media-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-cache-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-log-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-ajax-handler.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-system-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-performance-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-widget-utils.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-broken-links.php';
        require_once WPI_PLUGIN_DIR . 'includes/class-health-utils.php';

        // Initialize logging
        WordPress_Inspector_Log_Utils::init();
        WordPress_Inspector_Updates_Scheduler::init();

        // Change from admin_init to admin_head which runs later
        add_action('admin_head', array($this, 'suppress_admin_notices'), 1);

        // Add AJAX handlers for WordPress page
        add_action('wp_ajax_load_wp_tab', array($this, 'handle_load_wp_tab'));
        
        // WordPress Page Hooks
        add_action('wp_ajax_switch_theme', array($this, 'handle_switch_theme'));
        add_action('wp_ajax_delete_theme', array($this, 'handle_delete_theme'));
        
        // Add hook for logging theme updates
        add_action('upgrader_process_complete', array($this, 'log_manual_updates'), 10, 2);

        // Add plugin management AJAX handlers
        add_action('wp_ajax_activate_plugin', array($this, 'handle_activate_plugin'));
        add_action('wp_ajax_deactivate_plugin', array($this, 'handle_deactivate_plugin'));
        add_action('wp_ajax_delete_plugin', array($this, 'handle_delete_plugin'));
    }

    /**
     * Check if plugin needs upgrade
     */
    private function maybe_upgrade() {
        $current_version = get_option('wordpress_inspector_version', '1.0.0');
        
        if (version_compare($current_version, WPI_VERSION, '<')) {
            // Run upgrade routines
            $this->upgrade($current_version);
            
            // Update version
            update_option('wordpress_inspector_version', WPI_VERSION);
        }
    }

    /**
     * Upgrade plugin
     *
     * @param string $from_version Version upgrading from
     */
    private function upgrade($from_version) {
        global $wpdb;
        
        // Create tables if they don't exist
        $table_name = $wpdb->prefix . 'wpi_update_logs';
        if ($wpdb->get_var("SHOW TABLES LIKE '$table_name'") != $table_name) {
            $charset_collate = $wpdb->get_charset_collate();
            
            $sql = "CREATE TABLE IF NOT EXISTS $table_name (
                id bigint(20) NOT NULL AUTO_INCREMENT,
                update_date datetime NOT NULL,
                update_type varchar(50) NOT NULL,
                item_name varchar(255) NOT NULL,
                version varchar(50) NOT NULL,
                status varchar(50) NOT NULL,
                details text,
                PRIMARY KEY  (id),
                KEY update_date (update_date),
                KEY update_type (update_type),
                KEY status (status)
            ) $charset_collate;";

            require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
            dbDelta($sql);
        }
        
        // Add more version-specific upgrades here
        if (version_compare($from_version, '2.0.0', '<')) {
            // Upgrade routines for versions before 2.0.0
        }
        
        if (version_compare($from_version, '3.0.0', '<')) {
            // Upgrade routines for versions before 3.0.0
        }
    }

    public static function activate() {
        global $wpdb;
        
        // Verify database prefix
        if (empty($wpdb->prefix)) {
            deactivate_plugins(plugin_basename(__FILE__));
            wp_die(__('WordPress Inspector requires a database prefix to be set.', 'wordpress-inspector'));
        }
        
        // Other activation code...
        
        // Create updates log table
        global $wpdb;
        $table_name = $wpdb->prefix . 'wpi_update_logs';
        $charset_collate = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS $table_name (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            update_type varchar(20) NOT NULL,
            item_name varchar(255) NOT NULL,
            version varchar(50) NOT NULL,
            status varchar(50) NOT NULL,
            update_date datetime NOT NULL,
           PRIMARY KEY  (id)
       ) $charset_collate;";

       require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
       dbDelta($sql);

       // Set default options
       add_option('wpi_update_email_reports', false);
       add_option('wpi_update_report_frequency', 'weekly');
       add_option('wpi_update_log_retention', 30);
       add_option('wpi_update_delay_days', 1);
       add_option('wpi_update_schedule_time', 'midnight');
    }

    public static function deactivate() {
        // Remove scheduled tasks
        wp_clear_scheduled_hook('wpi_scheduled_update_check');
        wp_clear_scheduled_hook('wpi_send_update_report');
        wp_clear_scheduled_hook('wpi_cleanup_logs');
    }

    public static function uninstall() {
        // Verify uninstall is intentional
        if (!defined('WP_UNINSTALL_PLUGIN')) {
            exit;
        }

        // Clean up all plugin options
        $options = [
            'wpi_update_email_reports',
            'wpi_update_report_frequency',
            'wpi_update_log_retention',
            'wpi_update_delay_days',
            'wpi_update_schedule_time',
            'wpi_delayed_updates'
        ];

        foreach ($options as $option) {
            delete_option($option);
            delete_site_option($option);
        }

        // Remove database tables
        global $wpdb;
        $tables = [
            $wpdb->prefix . 'wpi_update_logs',
            // Add other plugin tables here
        ];

        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS {$table}");
        }

        // Clear any scheduled hooks
        wp_clear_scheduled_hook('wpi_scheduled_update_check');
        wp_clear_scheduled_hook('wpi_send_update_report');
        wp_clear_scheduled_hook('wpi_cleanup_logs');
    }


    /**
     * Initialize the plugin with error handling
     */
    public function init() {
        try {
            // Add error logging
            if (!defined('WP_DEBUG_LOG')) {
                define('WP_DEBUG_LOG', true);
            }

            // Initialize required components
            if (!$this->initialize_components()) {
                throw new Exception('Failed to initialize plugin components');
            }

            // Add admin menu
            add_action('admin_menu', array($this, 'add_admin_menu'));
            
            // Add admin styles
            add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
            
            // Add dashboard widget
            add_action('wp_dashboard_setup', array($this, 'add_dashboard_widget'));
            
            // Add update page hooks
            add_filter('auto_update_core', array($this, 'handle_core_updates'), 10, 2);
            add_filter('auto_update_plugin', array($this, 'handle_plugin_updates'), 10, 2);
            add_filter('auto_update_theme', array($this, 'handle_theme_updates'), 10, 2);

            // Add update notification hooks
            add_action('automatic_updates_complete', array($this, 'log_automatic_updates'));
            add_action('upgrader_process_complete', array($this, 'log_manual_updates'), 10, 2);

            // Add AJAX handlers
            add_action('wp_ajax_search_database', array($this, 'handle_search_database'));
            add_action('wp_ajax_replace_database', array($this, 'handle_replace_database'));
            add_action('wp_ajax_save_updates_settings', array($this, 'save_updates_settings'));
            add_action('wp_ajax_force_updates_check', array($this, 'force_updates_check'));
            add_action('wp_ajax_get_update_logs', array($this, 'get_update_logs'));
            add_action('wp_ajax_export_update_logs', array($this, 'export_update_logs'));
            add_action('wp_ajax_clear_update_logs', array($this, 'clear_update_logs'));
            add_action('wp_ajax_remove_update_filter', array($this, 'handle_remove_update_filter'));
            add_action('wp_ajax_generate_update_report', array($this, 'handle_generate_report'));
            add_action('wp_ajax_disable_option_autoload', array($this, 'handle_disable_option_autoload'));
            
            // Create tabs directory if it doesn't exist
            $tabs_dir = WPI_PLUGIN_DIR . 'views/tabs';
            if (!file_exists($tabs_dir)) {
                wp_mkdir_p($tabs_dir);
            }

            // Add hooks
            $this->add_hooks();

        } catch (Exception $e) {
            error_log(sprintf(
                '[WordPress Inspector] Initialization error: %s in %s:%d', 
                $e->getMessage(),
                $e->getFile(),
                $e->getLine()
            ));
            
            add_action('admin_notices', function() use ($e) {
                printf(
                    '<div class="notice notice-error"><p>%s</p></div>',
                    esc_html__('WordPress Inspector encountered an error during initialization. Please check the error logs.', 'wordpress-inspector')
                );
            });
        }
    }

    /**
     * Initialize plugin hooks and filters
     *
     * @since 1.0.0
     * @return void
     */
    public function add_hooks() {
        add_action('admin_menu', array($this, 'add_admin_menu'));
        add_action('admin_enqueue_scripts', array($this, 'enqueue_admin_styles'));
        
        // Add dashboard widget
        add_action('wp_dashboard_setup', array($this, 'add_dashboard_widget'));
        
        // Initialize AJAX handlers
        $ajax_handler = new WordPress_Inspector_AJAX_Handler();
        $ajax_handler->init();

        // Add AJAX handlers for search & replace
        add_action('wp_ajax_search_database', array($this, 'handle_search_database'));
        add_action('wp_ajax_replace_database', array($this, 'handle_replace_database'));

        // Add AJAX handlers for updates page
        add_action('wp_ajax_save_updates_settings', array($this, 'save_updates_settings'));
        add_action('wp_ajax_force_updates_check', array($this, 'force_updates_check'));
        add_action('wp_ajax_get_update_logs', array($this, 'get_update_logs'));
        add_action('wp_ajax_export_update_logs', array($this, 'export_update_logs'));
       add_action('wp_ajax_clear_update_logs', array($this, 'clear_update_logs'));
        
        // Add update page hooks
        add_filter('auto_update_core', array($this, 'handle_core_updates'), 10, 2);
        add_filter('auto_update_plugin', array($this, 'handle_plugin_updates'), 10, 2);
        add_filter('auto_update_theme', array($this, 'handle_theme_updates'), 10, 2);

        // Add update notification hooks
        add_action('automatic_updates_complete', array($this, 'log_automatic_updates'));
        add_action('upgrader_process_complete', array($this, 'log_manual_updates'), 10, 2);

        // Update Plugin Hooks
        add_action('wp_ajax_remove_update_filter', array($this, 'handle_remove_update_filter'));
        add_action('wp_ajax_generate_update_report', array($this, 'handle_generate_report'));

        //database page hooks
        add_action('wp_ajax_disable_option_autoload', array($this, 'handle_disable_option_autoload'));

        WordPress_Inspector_Broken_Links::init();

        // Add AJAX handlers for Wordpress page
        add_action('wp_ajax_load_wp_tab', array($this, 'handle_load_wp_tab'));

        // Wordpress Page Hooks
        add_action('wp_ajax_switch_theme', array($this, 'handle_switch_theme'));
        add_action('wp_ajax_delete_theme', array($this, 'handle_delete_theme'));
    }

    /**
     * Add admin menu items with capability checks
     */
    public function add_admin_menu() {
        // Define required capability
        $capability = apply_filters('wordpress_inspector_capability', 'manage_options');
        
        if (!current_user_can($capability)) {
            return;
        }

        // Add main menu with escaped values
        add_menu_page(
            esc_html__('WP Inspector', 'wordpress-inspector'),
            esc_html__('WP Inspector', 'wordpress-inspector'),
            $capability,
            'wordpress-inspector',
            array($this, 'render_overview_page'),
            'dashicons-visibility'
        );

        // Define submenus with localization
        $submenus = array(
            array(
                __('Overview', 'wordpress-inspector'),
                __('Overview', 'wordpress-inspector'),
                'wordpress-inspector',
                'overview'
            ),
            array(
                __('Hosting', 'wordpress-inspector'),
                __('Hosting', 'wordpress-inspector'),
                'inspector-hosting',
                'hosting'
            ),
            array(
                __('Database', 'wordpress-inspector'),
                __('Database', 'wordpress-inspector'),
                'inspector-database',
                'database'
            ),
            array(
                __('Plugins', 'wordpress-inspector'),
                __('Plugins', 'wordpress-inspector'),
                'inspector-plugins',
                'plugins'
            ),
            array(
                __('Media', 'wordpress-inspector'),
                __('Media', 'wordpress-inspector'),
                'inspector-media',
                'media'
            ),
            array(
                __('License Keys', 'wordpress-inspector'),
                __('License Keys', 'wordpress-inspector'),
                'inspector-licenses',
                'licenses'
            ),
            array(
                __('Security', 'wordpress-inspector'),
                __('Security', 'wordpress-inspector'),
                'inspector-security',
                'security'
            ),
            array(
                __('Search & Replace', 'wordpress-inspector'),
                __('Search & Replace', 'wordpress-inspector'),
                'inspector-search-replace',
                'search_replace'
            ),
            array(
                __('Broken Links', 'wordpress-inspector'),
                __('Broken Links', 'wordpress-inspector'),
                'inspector-broken-links',
                'broken_links'
            ),
            array(
                __('Cron Jobs', 'wordpress-inspector'),
                __('Cron Jobs', 'wordpress-inspector'),
                'inspector-cron',
                'cron'
            ),
            array(
                __('Settings', 'wordpress-inspector'),
                __('Settings', 'wordpress-inspector'),
                'inspector-settings',
                'settings'
            ),
            array(
                __('EZ Wizard', 'wordpress-inspector'),
                __('EZ Mode', 'wordpress-inspector'),
                'inspector-ez-mode',
                'ez_mode'
            ),
            array(
                __('Updates', 'wordpress-inspector'),
                __('Updates', 'wordpress-inspector'),
                'inspector-updates',
                'updates'
            ),
            array(
                __('Logs', 'wordpress-inspector'),
                __('Logs', 'wordpress-inspector'),
                'inspector-logs',
                'logs'
            ),
            array(
                __('Troubleshooting', 'wordpress-inspector'),
                __('Troubleshooting', 'wordpress-inspector'),
                'inspector-troubleshooting',
                'troubleshooting'
            ),
            array(
                __('Performance', 'wordpress-inspector'),
                __('Performance', 'wordpress-inspector'),
                'inspector-performance',
                'performance'
            ),
            array(
                __('Quality of Life', 'wordpress-inspector'),
                __('Quality of Life', 'wordpress-inspector'),
                'inspector-qol',
                'qol'
            ),
            array(
                __('WordPress', 'wordpress-inspector'),
                __('WordPress', 'wordpress-inspector'),
                'inspector-wp',
                'wordpress'
            ),
            array(
                __('Reset', 'wordpress-inspector'),
                __('Reset', 'wordpress-inspector'),
                'inspector-reset',
                'reset'
            ),
        );

        foreach ($submenus as $submenu) {
            add_submenu_page(
                'wordpress-inspector',
                esc_html($submenu[0]),
                esc_html($submenu[1]),
                $capability,
                $submenu[2],
                array($this, 'render_' . $submenu[3] . '_page')
            );
        }
    }

    public function enqueue_admin_styles($hook) {     
        // Enqueue Dashicons
        wp_enqueue_style('dashicons');
        
        // Always load admin styles
        wp_enqueue_style('wordpress-inspector-admin', plugins_url('assets/css/admin.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));
        
        // Get current screen
        $screen = get_current_screen();
        
        // Load page-specific styles
        if ($screen->id === 'toplevel_page_wordpress-inspector-hosting') {
            wp_enqueue_style('wordpress-inspector-hosting', plugins_url('assets/css/hosting.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));
        }
    }

    public function render_dashboard_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/dashboard.php';
    }

    public function render_hosting_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/hosting.php';
    }

    public function render_database_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/database.php';
    }

    public function render_plugins_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/plugins.php';
    }

    public function render_media_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/media.php';
    }

    public function render_licenses_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/licenses.php';
    }

    public function render_security_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/security.php';
    }

    public function render_search_replace_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/search-replace.php';
    }

    public function render_broken_links_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/broken-links.php';
    }

    public function render_cron_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/cron.php';
    }

    public function render_settings_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/settings.php';
    }

    public function render_ez_mode_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/ez-mode.php';
    }

    public function render_reset_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/reset.php';
    }

    public function render_overview_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/overview.php';
    }

    public function render_logs_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/logs.php';
    }

    public function render_updates_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/updates.php';
    }

    public function render_troubleshooting_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/troubleshooting.php';
    }

    public function render_performance_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/performance.php';
    }

    public function render_qol_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/qol.php';
    }

    public function render_wordpress_page() {
        require_once WPI_PLUGIN_DIR . 'views/pages/wordpress.php';
    }

    /**
     * Add dashboard widget
     */
    public function add_dashboard_widget() {
        wp_add_dashboard_widget(
            'wordpress_inspector_health',
            'WP Inspector Health Check',
            array($this, 'render_dashboard_widget')
        );
    }

    /**
     * Render dashboard widget content
     */
    public function render_dashboard_widget() {
        // Get widget information
        $widget_info = WordPress_Inspector_Widget_Utils::get_widget_info();
        ?>
        <div class="wordpress-inspector-widget">
            <div class="widget-row <?php echo $widget_info['security_warnings'] > 0 ? 'has-warning' : ''; ?>">
                <span class="dashicons dashicons-shield<?php echo $widget_info['security_warnings'] > 0 ? '-alt' : ''; ?>"></span>
                <a href="<?php echo admin_url('admin.php?page=inspector-security'); ?>">
                    Security Warnings <span class="count">(<?php echo intval($widget_info['security_warnings']); ?>)</span>
                </a>
            </div>
            
            <div class="widget-row <?php echo $widget_info['filesystem_errors'] > 0 ? 'has-warning' : ''; ?>">
                <span class="dashicons dashicons-portfolio"></span>
                <a href="<?php echo admin_url('admin.php?page=inspector-filesystem'); ?>">
                    File System Errors <span class="count">(<?php echo intval($widget_info['filesystem_errors']); ?>)</span>
                </a>
            </div>
            
            <?php if ($widget_info['cache_warnings'] > 0): ?>
            <div class="widget-row has-warning">
                <span class="dashicons dashicons-warning"></span>
                <a href="<?php echo admin_url('admin.php?page=inspector-performance'); ?>">
                    Cache Warnings <span class="count">(<?php echo intval($widget_info['cache_warnings']); ?>)</span>
                </a>
            </div>
            <?php endif; ?>
            
            <?php if ($widget_info['log_size'] > 0): ?>
            <div class="widget-row has-info">
                <span class="dashicons dashicons-media-text"></span>
                <a href="<?php echo admin_url('admin.php?page=inspector-logs'); ?>">
                    Log Size <span class="count">(<?php echo esc_html(size_format($widget_info['log_size'])); ?>)</span>
                </a>
            </div>
            <?php endif; ?>
        </div>
        <?php
    }

    /**
     * Handle database search with improved validation
     */
    public function handle_search_database() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'wordpress-inspector')]);
        }

        if (!check_ajax_referer('search_replace_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed', 'wordpress-inspector')]);
        }

        // Validate search data
        $data = Data_Validator::validate_search_replace($_POST);
        
        if (is_wp_error($data)) {
            wp_send_json_error([
                'message' => $data->get_error_message(),
                'errors' => $data->get_error_messages()
            ]);
        }

        $results = [];
        global $wpdb;

        foreach ($data['tables'] as $table) {
            $columns = $wpdb->get_results("SHOW COLUMNS FROM $table");
            
            foreach ($columns as $column) {
                $matches = $wpdb->get_results($wpdb->prepare(
                    "SELECT * FROM $table WHERE {$column->Field} LIKE %s",
                    '%' . $wpdb->esc_like($data['search']) . '%'
                ));

                foreach ($matches as $match) {
                    if (isset($match->{$column->Field}) && 
                        stripos($match->{$column->Field}, $data['search']) !== false) {
                        $results[] = [
                            'table' => $table,
                            'column' => $column->Field,
                            'row_id' => isset($match->ID) ? $match->ID : '',
                            'value' => wp_html_excerpt($match->{$column->Field}, 100, '...')
                        ];
                    }
                }
            }
        }

        wp_send_json_success(['results' => $results]);
    }

    /**
     * Handle database replace
     */
    public function handle_replace_database() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(array('message' => 'Insufficient permissions'));
        }

        if (!check_ajax_referer('search_replace_nonce', 'nonce', false)) {
            wp_send_json_error(array('message' => 'Invalid nonce'));
        }

        global $wpdb;
        $search = sanitize_text_field($_POST['search']);
        $replace = sanitize_text_field($_POST['replace']);
        $tables = array_map('sanitize_text_field', $_POST['tables']);
        $count = 0;

        foreach ($tables as $table) {
            $columns = $wpdb->get_results("SHOW COLUMNS FROM $table");
            
            foreach ($columns as $column) {
                $result = $wpdb->query(
                    $wpdb->prepare(
                        "UPDATE $table SET {$column->Field} = REPLACE({$column->Field}, %s, %s) 
                         WHERE {$column->Field} LIKE %s",
                        $search,
                        $replace,
                        '%' . $wpdb->esc_like($search) . '%'
                    )
                );
                if ($result !== false) {
                    $count += $result;
                }
            }
        }

        wp_send_json_success(array('count' => $count));
    }

    /**
     * Suppress admin notices on plugin pages
     * 
     * @since 1.0.0
     * @return void
     */
    public function suppress_admin_notices() {
        global $pagenow;
        
        // Check if we're on an admin page
        if (!is_admin()) {
            return;
        }

        // Check if we're on our plugin's pages
        $is_plugin_page = (
            $pagenow === 'admin.php' && 
            isset($_GET['page']) && 
            (
                $_GET['page'] === 'wordpress-inspector' ||
                strpos($_GET['page'], 'inspector-') === 0
            )
        );

        if ($is_plugin_page) {
            // Remove all notices
            remove_all_actions('admin_notices');
            remove_all_actions('all_admin_notices');
            remove_all_actions('user_admin_notices');
            remove_all_actions('network_admin_notices');

            // Optional: Add back our plugin's notices if needed
            add_action('admin_notices', array($this, 'show_plugin_notices'));
        }
    }

    /**
     * Show only our plugin's notices
     * 
     * @since 1.0.0
     * @return void
     */
    public function show_plugin_notices() {
        // Get any notices we want to show from our plugin
        $notices = apply_filters('wordpress_inspector_admin_notices', array());
        
        foreach ($notices as $notice) {
            echo wp_kses_post($notice);
        }
    }

    /**
     * Handle saving update settings with validation
     */
    public function save_updates_settings() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => __('Insufficient permissions', 'wordpress-inspector')]);
        }

        if (!check_ajax_referer('wpi_settings_nonce', 'nonce', false)) {
            wp_send_json_error(['message' => __('Security check failed', 'wordpress-inspector')]);
        }

        // Validate settings
        $settings = Data_Validator::validate_settings($_POST);
        
        if (is_wp_error($settings)) {
            wp_send_json_error([
                'message' => $settings->get_error_message(),
                'errors' => $settings->get_error_messages()
            ]);
        }

        // Save validated settings
        foreach ($settings as $key => $value) {
            update_option("wpi_update_{$key}", $value);
        }

        wp_send_json_success(['message' => __('Settings saved successfully', 'wordpress-inspector')]);
    }

    /**
     * Force WordPress to check for updates
     */
    public function force_updates_check() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        // Force WP to check for updates
        wp_version_check(array(), true);
        wp_update_plugins();
        wp_update_themes();

        wp_send_json_success();
    }

    /**
     * Get update logs via AJAX
     */
    public function get_update_logs() {
        if (!current_user_can('manage_options')) {
            wp_send_json_error('Insufficient permissions');
        }

        $args = array(
            'search' => isset($_GET['search']) ? sanitize_text_field($_GET['search']) : '',
            'type' => isset($_GET['type']) ? sanitize_text_field($_GET['type']) : '',
            'start_date' => isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '',
            'end_date' => isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : '',
            'page' => isset($_GET['page']) ? intval($_GET['page']) : 1
        );

        $logs = WordPress_Inspector_Updates_Utils::get_update_logs($args);
        wp_send_json_success($logs);
    }

    /**
     * Export update logs
     */
    public function export_update_logs() {
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }

        $format = isset($_GET['format']) ? sanitize_text_field($_GET['format']) : 'csv';
        $args = array(
            'start_date' => isset($_GET['start_date']) ? sanitize_text_field($_GET['start_date']) : '',
            'end_date' => isset($_GET['end_date']) ? sanitize_text_field($_GET['end_date']) : ''
        );

        if ($format === 'csv') {
            header('Content-Type: text/csv');
            header('Content-Disposition: attachment; filename="update-logs.csv"');
        } else {
            header('Content-Type: application/json');
            header('Content-Disposition: attachment; filename="update-logs.json"');
        }

        WordPress_Inspector_Updates_Utils::export_logs($format, $args);
        exit;
    }

    /**
     * Log automatic updates
     */
    public function log_automatic_updates($results) {
        if (!empty($results['core'])) {
            foreach ($results['core'] as $core) {
                WordPress_Inspector_Updates_Utils::log_update(
                    'core',
                    'WordPress Core',
                    $core->item->version,
                    $core->result ? 'success' : 'failed'
                );
            }
        }

        if (!empty($results['plugins'])) {
            foreach ($results['plugins'] as $plugin) {
                WordPress_Inspector_Updates_Utils::log_update(
                    'plugin',
                    $plugin->item->slug,
                    $plugin->item->version,
                    $plugin->result ? 'success' : 'failed'
                );
            }
        }

        if (!empty($results['themes'])) {
            foreach ($results['themes'] as $theme) {
                WordPress_Inspector_Updates_Utils::log_update(
                    'theme',
                    $theme->item->slug,
                    $theme->item->version,
                    $theme->result ? 'success' : 'failed'
                );
            }
        }
    }

    /**
     * Handle core update filtering
     */
    public function handle_core_updates($update, $item) {
         if (get_option('wpi_update_delay_updates')) {
             $this->delay_update('core', $item);
             return false;
         }
         return $update;
    }

     /**
      * Handle plugin update filtering
      */
     public function handle_plugin_updates($update, $item) {
         if (get_option('wpi_update_delay_updates')) {
             $this->delay_update('plugin', $item);
             return false;
         }
         return $update;
     }

     /**
      * Handle theme update filtering
      */
     public function handle_theme_updates($update, $item) {
         if (get_option('wpi_update_delay_updates')) {
             $this->delay_update('theme', $item);
             return false;
         }
         return $update;
     }

     /**
      * Process update results
      */
     public function process_update_results($results) {
         foreach ($results as $type => $items) {
             foreach ($items as $item) {
                 WordPress_Inspector_Updates_Utils::log_update(
                     $type,
                     $item->name,
                     $item->version,
                     $item->result ? 'success' : 'failed'
                 );
             }
         }
     }

     /**
      * Delay an update
      */
     private function delay_update($type, $item) {
         $delay_days = get_option('wpi_update_delay_days', 1);
         $delayed_updates = get_option('wpi_delayed_updates', array());
         
         $delayed_updates[] = array(
             'type' => $type,
            'name' => $item->name,
             'version' => $item->version,
             'scheduled_time' => time() + ($delay_days * DAY_IN_SECONDS)
         );
         
         update_option('wpi_delayed_updates', $delayed_updates);
    }

    /**
     * Handle removing the automatic update filter
     */
    public function handle_remove_update_filter() {
         WordPress_Inspector_Updates_Utils::verify_update_operation();
         
         // Remove the filter
         remove_all_filters('automatic_updater_disabled');
         
         // Try to update wp-config if possible
         $config_path = ABSPATH . 'wp-config.php';
         if (is_writable($config_path)) {
             $config = file_get_contents($config_path);
             $config = preg_replace('/define\s*\(\s*[\'"]AUTOMATIC_UPDATER_DISABLED[\'"]\s*,\s*true\s*\)\s*;/i', '', $config);
             file_put_contents($config_path, $config);
         }
         
         wp_send_json_success();
    }
     
     /**
      * Handle generating and sending a report
      */
    public function handle_generate_report() {
        WordPress_Inspector_Updates_Utils::verify_update_operation();
        WordPress_Inspector_Updates_Scheduler::send_update_report();
        wp_send_json_success();
    }

    /**
     * Handle disabling autoload for options
     */
    public function handle_disable_option_autoload() {
         check_ajax_referer('wpi_database_nonce', 'nonce');
         
         if (!current_user_can('manage_options')) {
             wp_send_json_error('Unauthorized');
         }
         
         $option = sanitize_text_field($_POST['option']);
         
         global $wpdb;
         $result = $wpdb->update(
             $wpdb->options,
             array('autoload' => 'no'),
             array('option_name' => $option),
             array('%s'),
             array('%s')
         );
         
         if ($result !== false) {
             wp_send_json_success();
         } else {
             wp_send_json_error('Database error');
         }
    }

    /**
     * Initialize required components
     *
     * @return bool True if initialization successful, false otherwise
     */
    private function initialize_components() {
        try {
            // Initialize logging
            WordPress_Inspector_Log_Utils::init();
            
            // Initialize update scheduler
            WordPress_Inspector_Updates_Scheduler::init();
            
            // Initialize broken links
            WordPress_Inspector_Broken_Links::init();
            
            // Add AJAX handlers
            $ajax_handler = new WordPress_Inspector_AJAX_Handler();
            $ajax_handler->init();

            return true;
        } catch (Exception $e) {
            error_log(sprintf(
                '[WordPress Inspector] Component initialization error: %s in %s:%d',
                $e->getMessage(),
                $e->getFile(),
                $e->getLine()
            ));
            return false;
        }
    }

    /**
     * Handle WordPress tab loading via AJAX
     */
    public function handle_load_wp_tab() {
        try {
            check_ajax_referer('wp_ajax_nonce', 'nonce');

            if (!current_user_can('manage_options')) {
                wp_send_json_error('Insufficient permissions');
            }

            $tab = sanitize_key($_POST['tab']);
            $content = '';
            $file_path = WPI_PLUGIN_DIR . 'views/tabs/' . $tab . '.php';
            
            // Debug information
            error_log('Loading tab: ' . $tab);
            error_log('File path: ' . $file_path);
            
            if (!file_exists($file_path)) {
                wp_send_json_error('Tab file not found: ' . $file_path);
            }

            // Simplify the switch statement since we're already checking the file exists
            ob_start();
            include $file_path;
            $content = ob_get_clean();

            if (empty($content)) {
                wp_send_json_error('No content loaded for tab: ' . $tab);
            }

            wp_send_json_success($content);
        } catch (Exception $e) {
            error_log('WordPress Inspector WP Tab Error: ' . $e->getMessage());
            wp_send_json_error('Error loading tab: ' . $e->getMessage());
        }
    }

    /**
     * Handle theme switching via AJAX
     */
    public function handle_switch_theme() {
        try {
            // Verify nonce and capabilities
            check_ajax_referer('wp_ajax_nonce', 'nonce');
            if (!current_user_can('switch_themes')) {
                wp_send_json_error(array(
                    'message' => __('You do not have permission to switch themes.', 'wordpress-inspector')
                ));
            }

            // Get and validate theme
            $theme = sanitize_text_field($_POST['theme']);
            if (!wp_get_theme($theme)->exists()) {
                wp_send_json_error(array(
                    'message' => __('Theme does not exist.', 'wordpress-inspector')
                ));
            }

            // Switch theme
            switch_theme($theme);

            wp_send_json_success(array(
                'message' => __('Theme activated successfully.', 'wordpress-inspector')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

    /**
     * Handle theme deletion via AJAX
     */
    public function handle_delete_theme() {
        try {
            // Verify nonce and capabilities
            check_ajax_referer('wp_ajax_nonce', 'nonce');
            if (!current_user_can('delete_themes')) {
                wp_send_json_error(array(
                    'message' => __('You do not have permission to delete themes.', 'wordpress-inspector')
                ));
            }

            // Get and validate theme
            $theme = sanitize_text_field($_POST['theme']);
            if (!wp_get_theme($theme)->exists()) {
                wp_send_json_error(array(
                    'message' => __('Theme does not exist.', 'wordpress-inspector')
                ));
            }

            // Don't allow deleting active theme
            if (wp_get_theme($theme)->get_stylesheet() === get_stylesheet()) {
                wp_send_json_error(array(
                    'message' => __('Cannot delete the active theme.', 'wordpress-inspector')
                ));
            }

            // Include necessary file for delete_theme_mod function
            require_once(ABSPATH . 'wp-admin/includes/theme.php');

            // Delete the theme
            $deleted = delete_theme($theme);

            if (is_wp_error($deleted)) {
                wp_send_json_error(array(
                    'message' => $deleted->get_error_message()
                ));
            }

            wp_send_json_success(array(
                'message' => __('Theme deleted successfully.', 'wordpress-inspector')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

    /**
     * Log manual theme updates
     *
     * @param WP_Upgrader $upgrader Upgrader object
     * @param array $hook_extra Extra information about the upgrade
     * @return void
     */
    public function log_manual_updates($upgrader, $hook_extra) {
        if (!empty($hook_extra['type']) && $hook_extra['type'] === 'theme') {
            // Log theme update
            $theme = isset($hook_extra['theme']) ? $hook_extra['theme'] : '';
            $this->log_theme_update($theme);
        }
    }

    /**
     * Log theme update details
     *
     * @param string $theme Theme slug
     * @return void
     */
    private function log_theme_update($theme) {
        if (empty($theme)) return;

        $theme_data = wp_get_theme($theme);
        $log_entry = array(
            'type' => 'theme_update',
            'theme' => $theme,
            'version' => $theme_data->get('Version'),
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id()
        );

        // You can store this in a custom table or use WordPress options
        $logs = get_option('wordpress_inspector_theme_logs', array());
        array_unshift($logs, $log_entry);
        
        // Keep only last 100 entries
        $logs = array_slice($logs, 0, 100);
        
        update_option('wordpress_inspector_theme_logs', $logs);
    }

    /**
     * Handle plugin activation via AJAX
     */
    public function handle_activate_plugin() {
        try {
            check_ajax_referer('wp_ajax_nonce', 'nonce');
            if (!current_user_can('activate_plugins')) {
                wp_send_json_error(array(
                    'message' => __('You do not have permission to activate plugins.', 'wordpress-inspector')
                ));
            }

            $plugin = sanitize_text_field($_POST['plugin']);
            $result = activate_plugin($plugin);

            if (is_wp_error($result)) {
                wp_send_json_error(array(
                    'message' => $result->get_error_message()
                ));
            }

            wp_send_json_success(array(
                'message' => __('Plugin activated successfully.', 'wordpress-inspector')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

    /**
     * Handle plugin deactivation via AJAX
     */
    public function handle_deactivate_plugin() {
        try {
            check_ajax_referer('wp_ajax_nonce', 'nonce');
            if (!current_user_can('deactivate_plugins')) {
                wp_send_json_error(array(
                    'message' => __('You do not have permission to deactivate plugins.', 'wordpress-inspector')
                ));
            }

            $plugin = sanitize_text_field($_POST['plugin']);
            deactivate_plugins($plugin);

            wp_send_json_success(array(
                'message' => __('Plugin deactivated successfully.', 'wordpress-inspector')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

    /**
     * Handle plugin deletion via AJAX
     */
    public function handle_delete_plugin() {
        try {
            check_ajax_referer('wp_ajax_nonce', 'nonce');
            if (!current_user_can('delete_plugins')) {
                wp_send_json_error(array(
                    'message' => __('You do not have permission to delete plugins.', 'wordpress-inspector')
                ));
            }

            $plugin = sanitize_text_field($_POST['plugin']);
            
            // Don't allow deleting active plugins
            if (is_plugin_active($plugin)) {
                wp_send_json_error(array(
                    'message' => __('Cannot delete an active plugin.', 'wordpress-inspector')
                ));
            }

            // Include necessary file for delete_plugins function
            require_once(ABSPATH . 'wp-admin/includes/plugin.php');

            $deleted = delete_plugins(array($plugin));

            if (is_wp_error($deleted)) {
                wp_send_json_error(array(
                    'message' => $deleted->get_error_message()
                ));
            }

            wp_send_json_success(array(
                'message' => __('Plugin deleted successfully.', 'wordpress-inspector')
            ));

        } catch (Exception $e) {
            wp_send_json_error(array(
                'message' => $e->getMessage()
            ));
        }
    }

} 