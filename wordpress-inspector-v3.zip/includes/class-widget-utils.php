<?php
/**
 * Widget Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Widget utility functions
 */
class WordPress_Inspector_Widget_Utils {
    /**
     * Get all issues for dashboard widget
     *
     * @return array Widget information
     */
    public static function get_widget_info() {
        return array(
            'security_warnings' => self::get_security_warnings(),
            'filesystem_errors' => self::get_filesystem_errors(),
            'license_count' => self::get_license_count(),
            'broken_links' => WordPress_Inspector_Broken_Links::get_broken_links_count(),
            'database_errors' => self::get_database_errors(),
            'performance_score' => self::get_performance_score(),
            'cache_warnings' => self::get_cache_warnings(),
            'log_size' => self::get_log_size()
        );
    }

    /**
     * Get security warnings count
     */
    private static function get_security_warnings() {
        $warnings = 0;

        // Check SSL
        if (!is_ssl()) {
            $warnings++;
        }

        // Check wp-config.php
        if (is_writable(ABSPATH . 'wp-config.php')) {
            $warnings++;
        }

        // Check uploads directory
        $upload_dir = wp_upload_dir();
        if (self::is_directory_executable($upload_dir['basedir'])) {
            $warnings++;
        }

        // Check directory browsing
        if (self::check_directory_browsing()) {
            $warnings++;
        }

        // Check XML-RPC
        if (self::is_xmlrpc_enabled()) {
            $warnings++;
        }

        // Check version visibility
        if (self::is_version_visible()) {
            $warnings++;
        }

        return $warnings;
    }

    /**
     * Get filesystem errors count
     */
    private static function get_filesystem_errors() {
        $errors = 0;
        $paths = array(
            'wp-config.php' => ABSPATH . 'wp-config.php',
            'wp-content' => WP_CONTENT_DIR,
            'uploads' => wp_upload_dir()['basedir'],
            'plugins' => WP_PLUGIN_DIR,
            'themes' => get_theme_root()
        );

        foreach ($paths as $name => $path) {
            if (!file_exists($path)) {
                if ($name !== '.htaccess') {
                    $errors++;
                }
                continue;
            }

            $perms = self::get_file_permissions($path);

            switch ($name) {
                case 'wp-config.php':
                    if (!is_readable($path) || is_writable($path)) {
                        $errors++;
                    }
                    break;

                case 'wp-content':
                case 'uploads':
                case 'plugins':
                case 'themes':
                    if (!is_readable($path) || !is_writable($path)) {
                        $errors++;
                    }
                    break;
            }

            // Check for world-writable permissions
            if (substr($perms, -1) === '7') {
                $errors++;
            }
        }

        // Check disk space
        if (function_exists('disk_free_space') && disk_free_space(ABSPATH) < 100 * 1024 * 1024) {
            $errors++;
        }

        return $errors;
    }

    /**
     * Get license keys count
     */
    public static function get_license_count() {
        try {
            return WordPress_Inspector_License_Patterns::scan_for_licenses();
        } catch (Exception $e) {
            return 0;
        }
    }

    /**
     * Get cache warnings count
     */
    private static function get_cache_warnings() {
        $warnings = 0;

        // Check object cache
        if (!wp_using_ext_object_cache()) {
            $warnings++;
        }

        // Check page cache
        if (!self::is_page_cache_enabled()) {
            $warnings++;
        }

        // Check autoload size
        global $wpdb;
        $autoload_size = $wpdb->get_var(
            "SELECT SUM(LENGTH(option_value)) 
            FROM $wpdb->options 
            WHERE autoload = 'yes'"
        );
        if ($autoload_size > 1000000) { // 1MB
            $warnings++;
        }

        return $warnings;
    }

    /**
     * Get cleanup items count
     */
    private static function get_cleanup_items() {
        global $wpdb;
        $count = 0;

        // Count revisions
        $count += $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_type = 'revision'");

        // Count trash
        $count += $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->posts WHERE post_status = 'trash'");

        // Count spam comments
        $count += $wpdb->get_var("SELECT COUNT(*) FROM $wpdb->comments WHERE comment_approved = 'spam'");

        return $count;
    }

    /**
     * Get log size
     */
    private static function get_log_size() {
        $size = 0;

        // Check debug.log
        $debug_log = WP_CONTENT_DIR . '/debug.log';
        if (file_exists($debug_log)) {
            $size += filesize($debug_log);
        }

        // Check PHP error log
        $error_log = ini_get('error_log');
        if (file_exists($error_log)) {
            $size += filesize($error_log);
        }

        return $size;
    }

    /**
     * Helper functions
     */
    private static function get_file_permissions($path) {
        return substr(sprintf('%o', fileperms($path)), -4);
    }

    private static function is_directory_executable($directory) {
        if (!is_dir($directory)) {
            return false;
        }

        // Check .htaccess
        $htaccess = trailingslashit($directory) . '.htaccess';
        if (file_exists($htaccess)) {
            $contents = file_get_contents($htaccess);
            if (strpos($contents, 'php_flag engine off') !== false) {
                return false;
            }
        }

        return true;
    }

    private static function check_directory_browsing() {
        $upload_dir = wp_upload_dir();
        
        // Try HTTPS first
        $https_url = str_replace('http://', 'https://', $upload_dir['baseurl']);
        $response = wp_remote_get($https_url, array(
            'timeout' => 5,
            'sslverify' => true
        ));
        
        // If HTTPS fails, try HTTP as fallback
        if (is_wp_error($response)) {
            $response = wp_remote_get($upload_dir['baseurl'], array(
                'timeout' => 5,
                'sslverify' => false
            ));
        }
        
        if (!is_wp_error($response)) {
            $response_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            
            // If we get a 403 Forbidden, directory browsing is disabled (good)
            if ($response_code === 403) {
                return false;
            }
            
            // If we get a 200 OK, check if it shows directory listing
            if ($response_code === 200) {
                return strpos($body, 'Index of') !== false;
            }
        }
        
        // If we can't determine the status, assume it's secure
        return false;
    }

    private static function is_xmlrpc_enabled() {
        return apply_filters('xmlrpc_enabled', true);
    }

    private static function is_version_visible() {
        return !has_filter('the_generator');
    }

    private static function is_page_cache_enabled() {
        return defined('WP_CACHE') && WP_CACHE;
    }

    /**
     * Get database errors count
     */
    private static function get_database_errors() {
        global $wpdb;
        $errors = 0;
        
        // Check for database connection errors
        if (!empty($wpdb->last_error)) {
            $errors++;
        }
        
        // Check for tables with overhead
        $tables = $wpdb->get_results("SHOW TABLE STATUS");
        foreach ($tables as $table) {
            if ($table->Data_free > 0) {
                $errors++;
            }
        }
        
        // Check for slow queries if log exists
        $slow_log = ini_get('slow_query_log_file');
        if (file_exists($slow_log) && filesize($slow_log) > 0) {
            $errors++;
        }
        
        return $errors;
    }

    /**
     * Get performance score
     */
    private static function get_performance_score() {
        // Placeholder for now - can be implemented later
        return 0;
    }
} 