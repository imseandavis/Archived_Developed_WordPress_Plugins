<?php
/**
 * System Utility Class
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

/**
 * System utility functions
 */
class WordPress_Inspector_System_Utils {
    /**
     * Get system information
     *
     * @return array System details
     */
    public static function get_system_info() {
        return array(
            'os' => array(
                'name' => php_uname('s'),
                'release' => php_uname('r'),
                'version' => php_uname('v'),
                'machine' => php_uname('m')
            ),
            'server' => array(
                'software' => $_SERVER['SERVER_SOFTWARE'] ?? 'Unknown',
                'protocol' => $_SERVER['SERVER_PROTOCOL'] ?? 'Unknown',
                'address' => $_SERVER['SERVER_ADDR'] ?? 'Unknown',
                'name' => $_SERVER['SERVER_NAME'] ?? 'Unknown',
                'port' => $_SERVER['SERVER_PORT'] ?? 'Unknown'
            ),
            'php' => array(
                'version' => phpversion(),
                'sapi' => php_sapi_name(),
                'memory_limit' => ini_get('memory_limit'),
                'max_execution_time' => ini_get('max_execution_time'),
                'upload_max_filesize' => ini_get('upload_max_filesize'),
                'post_max_size' => ini_get('post_max_size'),
                'max_input_vars' => ini_get('max_input_vars'),
                'display_errors' => ini_get('display_errors'),
                'error_reporting' => ini_get('error_reporting')
            ),
            'mysql' => array(
                'version' => self::get_mysql_version(),
                'client_info' => mysqli_get_client_info(),
                'client_version' => mysqli_get_client_version()
            ),
            'disk' => array(
                'free_space' => self::get_disk_free_space(),
                'total_space' => self::get_disk_total_space()
            ),
            'loopback_enabled' => self::check_loopback_requests()
        );
    }

    /**
     * Get MySQL version safely
     *
     * @return string MySQL version
     */
    private static function get_mysql_version() {
        global $wpdb;
        try {
            return $wpdb->get_var('SELECT VERSION()');
        } catch (Exception $e) {
            return 'Unknown';
        }
    }

    /**
     * Get disk free space safely
     *
     * @return string|null Formatted free space or null
     */
    private static function get_disk_free_space() {
        if (function_exists('disk_free_space')) {
            $bytes = @disk_free_space(ABSPATH);
            return $bytes ? WordPress_Inspector_Utils::format_size($bytes) : null;
        }
        return null;
    }

    /**
     * Get disk total space safely
     *
     * @return string|null Formatted total space or null
     */
    private static function get_disk_total_space() {
        if (function_exists('disk_total_space')) {
            $bytes = @disk_total_space(ABSPATH);
            return $bytes ? WordPress_Inspector_Utils::format_size($bytes) : null;
        }
        return null;
    }

    /**
     * Detect hosting provider
     */
    public static function detect_hosting_provider() {
        // Common hosting signatures in environment variables
        $signatures = array(
            'H_PLATFORM'              => 'H Platform',
            'WPENGINE_ACCOUNT'        => 'WP Engine',
            'IS_PRESSABLE'            => 'Pressable',
            'DH_USER'                 => 'DreamHost',
            'KINSTA_CACHE_ZONE'       => 'Kinsta',
            'PANTHEON_ENVIRONMENT'    => 'Pantheon',
            'FLYWHEEL_CONFIG'         => 'Flywheel',
            'PAGELY_ACCOUNT'          => 'Pagely',
            'CLOUDWAYS_APPLICATION_ID'=> 'Cloudways',
            'BLUEHOST_SYSTEM'         => 'Bluehost',
            'SITEGROUND_SETTINGS'     => 'SiteGround',
            'GODADDY_ACCOUNT'         => 'GoDaddy',
            'A2_OPTIMIZED'            => 'A2 Hosting',
            'LIQUIDWEB_SERVER'        => 'Liquid Web',
            'INMOTION_USER'           => 'InMotion Hosting',
            'HOSTGATOR_ACCOUNT'       => 'HostGator',
            'IONOS_ACCOUNT'           => 'IONOS',
            'NAMECHEAP_ACCOUNT'       => 'Namecheap',
            'WPX_ACCOUNT'             => 'WPX Hosting',
            'FASTCOMET_ACCOUNT'       => 'FastComet',
            'SCALAHOSTING_ACCOUNT'    => 'ScalaHosting',
            'OVH_ACCOUNT'             => 'OVH Hosting',
            'NETLIFY_CONFIG'          => 'Netlify',
            'VERCEL_ENV'              => 'Vercel',
            'HOSTINGER_SYSTEM'        => 'Hostinger',
            'EASYWP_SITE'             => 'EasyWP'
        ); 

        foreach ($signatures as $env_var => $provider) {
            if ($env_var === 'H_PLATFORM') {
                $platform = getenv($env_var);
                if ($platform !== false) {
                    return $platform;  // Return the actual platform value
                }
            } elseif (getenv($env_var) !== false) {
                return $provider;
            }
        }

        // Check for common hosting paths
        $paths = array(
            '/etc/cloudways' => 'Cloudways',
            '/etc/wpengine' => 'WP Engine',
            '/etc/kinsta' => 'Kinsta',
            '/etc/bluehost' => 'Bluehost',
            '/etc/siteground' => 'SiteGround'
        );

        foreach ($paths as $path => $provider) {
            if (file_exists($path)) {
                return $provider;
            }
        }

        return 'Unknown';
    }

    /**
     * Get CPU information
     */
    public static function get_cpu_info() {
        $cpu_info = array(
            'cores' => 1,
            'allocated_cores' => 0,
            'model' => 'Unknown'
        );

        // Try to get CPU info from /proc/cpuinfo on Linux systems
        if (is_readable('/proc/cpuinfo')) {
            $cpuinfo = file_get_contents('/proc/cpuinfo');
            
            // Get CPU cores
            preg_match_all('/^processor/m', $cpuinfo, $matches);
            $cpu_info['cores'] = count($matches[0]);
            
            // Get CPU model
            if (preg_match('/^model name.*: (.+)$/m', $cpuinfo, $matches)) {
                $cpu_info['model'] = trim($matches[1]);
            }
        }

        // Try to get allocated cores from cgroups (container limits)
        if (is_readable('/sys/fs/cgroup/cpu/cpu.cfs_quota_us') && is_readable('/sys/fs/cgroup/cpu/cpu.cfs_period_us')) {
            $quota = (int)file_get_contents('/sys/fs/cgroup/cpu/cpu.cfs_quota_us');
            $period = (int)file_get_contents('/sys/fs/cgroup/cpu/cpu.cfs_period_us');
            if ($period > 0) {
                $cpu_info['allocated_cores'] = $quota / $period;
            }
        }
        // Fallback to Docker limits
        elseif (is_readable('/sys/fs/cgroup/cpu.max')) {
            $cpu_max = file_get_contents('/sys/fs/cgroup/cpu.max');
            if (preg_match('/^(\d+)\s+(\d+)/', $cpu_max, $matches)) {
                $quota = (int)$matches[1];
                $period = (int)$matches[2];
                if ($period > 0) {
                    $cpu_info['allocated_cores'] = $quota / $period;
                }
            }
        }

        // Fallback to PHP's sys_getloadavg() for basic info
        if (function_exists('sys_getloadavg')) {
            $cpu_info['load'] = sys_getloadavg();
        }

        return $cpu_info;
    }

    /**
     * Get memory information
     */
    public static function get_memory_info() {
        $memory_info = array(
            'total' => 0,
            'used' => 0,
            'free' => 0
        );
        
        // Try to get memory info from PHP
        $memory_info['total'] = wp_convert_hr_to_bytes(ini_get('memory_limit'));
        $memory_info['used'] = memory_get_usage(true);
        $memory_info['free'] = $memory_info['total'] - $memory_info['used'];

        // Try Linux /proc/meminfo if available
        if (is_readable('/proc/meminfo')) {
            try {
                $meminfo = @file_get_contents('/proc/meminfo');
                if ($meminfo) {
                    // Get total memory
                    if (preg_match('/MemTotal:\s+(\d+)/', $meminfo, $matches)) {
                        $memory_info['total'] = $matches[1] * 1024;
                    }
                    
                    // Get free memory
                    if (preg_match('/MemFree:\s+(\d+)/', $meminfo, $matches)) {
                        $memory_info['free'] = $matches[1] * 1024;
                    }
                    
                    // Calculate used memory
                    $memory_info['used'] = $memory_info['total'] - $memory_info['free'];
                }
            } catch (Exception $e) {
                // Silently fail and use PHP memory info instead
            }
        }
        
        return $memory_info;
    }

    /**
     * Convert human readable memory value to bytes
     * 
     * @param string $value Memory value (e.g., '128M', '1G')
     * @return int Value in bytes
     */
    private static function wp_convert_hr_to_bytes($value) {
        $value = trim($value);
        $last = strtolower($value[strlen($value)-1]);
        $value = (int)$value;
        
        switch($last) {
            case 'g':
                $value *= 1024;
            case 'm':
                $value *= 1024;
            case 'k':
                $value *= 1024;
        }
        
        return $value;
    }

    /**
     * Get filesystem information
     *
     * @return array Filesystem information
     */
    public static function get_filesystem_info() {
        $filesystem_info = array(
            'permissions' => array(),
            'storage' => array(
                'total' => function_exists('disk_total_space') ? @disk_total_space(ABSPATH) : 0,
                'free' => function_exists('disk_free_space') ? @disk_free_space(ABSPATH) : 0,
            )
        );

        // Calculate used space if we have valid total and free values
        if ($filesystem_info['storage']['total'] > 0 && $filesystem_info['storage']['free'] >= 0) {
            $filesystem_info['storage']['used'] = $filesystem_info['storage']['total'] - $filesystem_info['storage']['free'];
        } else {
            $filesystem_info['storage']['used'] = 0;
            $filesystem_info['storage']['total'] = 0;
            $filesystem_info['storage']['free'] = 0;
        }

        $paths = array(
            'wp-config.php' => ABSPATH . 'wp-config.php',
            'wp-content' => WP_CONTENT_DIR,
            'uploads' => wp_upload_dir()['basedir'],
            'plugins' => WP_PLUGIN_DIR,
            'themes' => get_theme_root(),
            '.htaccess' => ABSPATH . '.htaccess'
        );

        $permissions = array();
        foreach ($paths as $name => $path) {
            $permissions[$name] = array(
                'path' => $path,
                'exists' => file_exists($path),
                'readable' => is_readable($path),
                'writable' => is_writable($path),
                'permissions' => self::get_file_permissions($path),
                'owner' => function_exists('posix_getpwuid') ? posix_getpwuid(fileowner($path))['name'] : fileowner($path),
                'group' => function_exists('posix_getgrgid') ? posix_getgrgid(filegroup($path))['name'] : filegroup($path)
            );
        }

        $filesystem_info['permissions'] = $permissions;
        $filesystem_info['disk_free_space'] = disk_free_space(ABSPATH);
        $filesystem_info['disk_total_space'] = disk_total_space(ABSPATH);
        $filesystem_info['upload_max_filesize'] = wp_max_upload_size();
        $filesystem_info['php_memory_limit'] = ini_get('memory_limit');
        $filesystem_info['temp_directory'] = sys_get_temp_dir();
        $filesystem_info['temp_directory_writable'] = is_writable(sys_get_temp_dir());

        return $filesystem_info;
    }

    /**
     * Get file permissions in octal format
     *
     * @param string $path File path
     * @return array Permissions information
     */
    private static function get_file_permissions($path) {
        $info = array(
            'exists' => file_exists($path) && is_readable($path),
            'octal' => '0000',
            'human' => ''
        );

        if (!$info['exists']) {
            return $info;
        }
        
        $perms = fileperms($path);
        $info['octal'] = substr(sprintf('%o', $perms), -4);
        
        // Get human readable permissions
        // Determine file type
        if (($perms & 0xC000) == 0xC000) {
            $type = 's'; // Socket
        } elseif (($perms & 0xA000) == 0xA000) {
            $type = 'l'; // Symbolic Link
        } elseif (($perms & 0x8000) == 0x8000) {
            $type = '-'; // Regular
        } elseif (($perms & 0x6000) == 0x6000) {
            $type = 'b'; // Block special
        } elseif (($perms & 0x4000) == 0x4000) {
            $type = 'd'; // Directory
        } elseif (($perms & 0x2000) == 0x2000) {
            $type = 'c'; // Character special
        } elseif (($perms & 0x1000) == 0x1000) {
            $type = 'p'; // FIFO pipe
        } else {
            $type = 'u'; // Unknown
        }

        // Owner
        $info['human'] = $type;
        $info['human'] .= (($perms & 0x0100) ? 'r' : '-');
        $info['human'] .= (($perms & 0x0080) ? 'w' : '-');
        $info['human'] .= (($perms & 0x0040) ? (($perms & 0x0800) ? 's' : 'x') : (($perms & 0x0800) ? 'S' : '-'));

        // Group
        $info['human'] .= (($perms & 0x0020) ? 'r' : '-');
        $info['human'] .= (($perms & 0x0010) ? 'w' : '-');
        $info['human'] .= (($perms & 0x0008) ? (($perms & 0x0400) ? 's' : 'x') : (($perms & 0x0400) ? 'S' : '-'));

        // World
        $info['human'] .= (($perms & 0x0004) ? 'r' : '-');
        $info['human'] .= (($perms & 0x0002) ? 'w' : '-');
        $info['human'] .= (($perms & 0x0001) ? (($perms & 0x0200) ? 't' : 'x') : (($perms & 0x0200) ? 'T' : '-'));

        return $info;
    }

    /**
     * Get all important WordPress directory permissions
     *
     * @return array Directory permissions
     */
    public static function get_wp_directory_permissions() {
        $directories = array(
            'WordPress Root' => ABSPATH,
            'Admin Directory' => ABSPATH . 'wp-admin',
            'Configuration File' => ABSPATH . 'wp-config.php',
            'Content Directory' => WP_CONTENT_DIR,
            'Plugin Directory' => WP_PLUGIN_DIR,
            'Theme Directory' => get_theme_root(),
            'Must Use Plugins Directory' => WPMU_PLUGIN_DIR,
            'Upload Directory' => wp_upload_dir()['basedir'],
            'Fonts Directory' => WP_CONTENT_DIR . '/fonts'
        );

        $permissions = array();
        foreach ($directories as $name => $path) {
            $permissions[$name] = array(
                'path' => $path,
                'perms' => self::get_file_permissions($path)
            );
        }

        return $permissions;
    }

    /**
     * Detect the domain name provider
     *
     * @return string Domain name provider or 'Unknown'
     */
    public static function detect_domain_name_provider() {
        // Get the domain name
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        
        // Method 1: Try DNS NS records
        if (function_exists('dns_get_record')) {
            $ns_records = @dns_get_record($domain, DNS_NS);
            
            if (!empty($ns_records)) {
                $nameserver = strtolower($ns_records[0]['target']);
                $provider = self::match_nameserver_to_provider($nameserver);
                if ($provider !== 'Unknown') {
                    return $provider;
                }
            }
        }
        
        // Method 2: Try WHOIS lookup if available
        if (function_exists('shell_exec') && self::is_function_enabled('shell_exec')) {
            $whois = @shell_exec('whois ' . escapeshellarg($domain));
            if ($whois) {
                // Look for registrar information in WHOIS output
                $patterns = array(
                    '/Registrar:\s*(.*?)(?:\n|$)/i',
                    '/Registrar URL:\s*(.*?)(?:\n|$)/i',
                    '/Registrar WHOIS Server:\s*(.*?)(?:\n|$)/i'
                );
                
                foreach ($patterns as $pattern) {
                    if (preg_match($pattern, $whois, $matches)) {
                        $registrar = strtolower(trim($matches[1]));
                        $provider = self::match_registrar_to_provider($registrar);
                        if ($provider !== 'Unknown') {
                            return $provider;
                        }
                    }
                }
            }
        }
        
        // Method 3: Try cURL to fetch domain headers
        if (function_exists('curl_init')) {
            $ch = curl_init('https://' . $domain);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_HEADER, true);
            curl_setopt($ch, CURLOPT_NOBODY, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, 5);
            $headers = curl_exec($ch);
            curl_close($ch);
            
            if ($headers) {
                // Check for hosting provider signatures in headers
                $signatures = array(
                    'x-powered-by: Cloudflare' => 'Cloudflare',
                    'server: cloudflare' => 'Cloudflare',
                    'server: gws' => 'Google Cloud',
                    'x-powered-by: WP Engine' => 'WP Engine',
                    'x-kinsta-cache' => 'Kinsta',
                    'x-powered-by: Flywheel' => 'Flywheel'
                );
                
                foreach ($signatures as $signature => $provider) {
                    if (stripos($headers, $signature) !== false) {
                        return $provider;
                    }
                }
            }
        }
        
        return 'Unknown';
    }

    /**
     * Match nameserver to provider
     *
     * @param string $nameserver
     * @return string
     */
    private static function match_nameserver_to_provider($nameserver) {
        $providers = array(
            'godaddy' => 'GoDaddy',
            'namecheap' => 'Namecheap',
            'cloudflare' => 'Cloudflare',
            'dns-parking' => 'Hostinger',
            'name.com' => 'Name.com',
            'bluehost' => 'Bluehost',
            'dreamhost' => 'DreamHost',
            'siteground' => 'SiteGround',
            'wpengine' => 'WP Engine',
            'digitalocean' => 'DigitalOcean',
            'aws' => 'Amazon AWS',
            'google' => 'Google Domains',
            'hostgator' => 'HostGator',
            'ionos' => 'IONOS',
            'ovh' => 'OVH',
            'networksolutions' => 'Network Solutions'
        );

        foreach ($providers as $key => $provider) {
            if (strpos($nameserver, $key) !== false) {
                return $provider;
            }
        }

        return 'Unknown';
    }

    /**
     * Match registrar information to provider
     *
     * @param string $registrar
     * @return string
     */
    private static function match_registrar_to_provider($registrar) {
        $providers = array(
            'godaddy' => 'GoDaddy',
            'namecheap' => 'Namecheap',
            'name.com' => 'Name.com',
            'google domains' => 'Google Domains',
            'network solutions' => 'Network Solutions',
            'tucows' => 'Tucows',
            'enom' => 'eNom',
            'ionos' => 'IONOS',
            'ovh' => 'OVH',
            'gandi' => 'Gandi',
            'hostinger' => 'Hostinger'
        );

        foreach ($providers as $key => $provider) {
            if (strpos($registrar, $key) !== false) {
                return $provider;
            }
        }

        return 'Unknown';
    }

    /**
     * Check if a PHP function is enabled
     *
     * @param string $function_name
     * @return bool
     */
    private static function is_function_enabled($function_name) {
        $disabled = explode(',', ini_get('disable_functions'));
        return !in_array($function_name, $disabled);
    }

    /**
     * Check if loopback requests are working
     *
     * @return bool True if loopback requests work, false otherwise
     */
    private static function check_loopback_requests() {
        $response = wp_remote_get(admin_url('admin-ajax.php'), array(
            'timeout' => 10,
            'cookies' => wp_unslash($_COOKIE)
        ));
        
        return !is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200;
    }

    /**
     * Get domain registrar information
     *
     * @return string|null Registrar name or null if not found
     */
    public static function get_domain_registrar() {
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($domain)) {
            return null;
        }

        // Remove www. if present
        $domain = preg_replace('/^www\./', '', $domain);

        // Try to get WHOIS information
        try {
            $whois_server = 'whois.iana.org';
            $conn = @fsockopen($whois_server, 43, $errno, $errstr, 10);
            if ($conn) {
                fputs($conn, $domain . "\r\n");
                $response = '';
                while (!feof($conn)) {
                    $response .= fgets($conn, 128);
                }
                fclose($conn);

                // Common registrars and their identification patterns
                $registrars = array(
                    'GoDaddy' => array('GoDaddy', 'godaddy'),
                    'Namecheap' => array('Namecheap', 'NAMECHEAP'),
                    'Google Domains' => array('Google Domains', 'Google LLC'),
                    'Name.com' => array('Name.com', 'NAME.COM'),
                    'Domain.com' => array('Domain.com', 'DOMAIN.COM'),
                    'Cloudflare' => array('Cloudflare', 'cloudflare'),
                    'NameSilo' => array('NameSilo', 'NAMESILO'),
                    'Hover' => array('Hover', 'HOVER'),
                    'Bluehost' => array('Bluehost', 'BLUEHOST'),
                    'HostGator' => array('HostGator', 'HOSTGATOR'),
                    'Network Solutions' => array('Network Solutions', 'NETWORK SOLUTIONS'),
                    'Dynadot' => array('Dynadot', 'DYNADOT'),
                    'Porkbun' => array('Porkbun', 'PORKBUN'),
                    'Gandi' => array('Gandi', 'GANDI SAS'),
                    'Register.com' => array('Register.com', 'REGISTER.COM'),
                    'IONOS' => array('IONOS', '1&1 IONOS'),
                    'Epik' => array('Epik', 'EPIK'),
                    'DreamHost' => array('DreamHost', 'DREAMHOST'),
                    'OVH' => array('OVH', 'OVH SAS')
                );

                foreach ($registrars as $name => $patterns) {
                    foreach ($patterns as $pattern) {
                        if (stripos($response, $pattern) !== false) {
                            return $name;
                        }
                    }
                }
            }
        } catch (Exception $e) {
            error_log('WordPress Inspector: Error getting domain registrar - ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Get domain registration date
     *
     * @return string Registration date or 'Unknown'
     */
    public static function get_domain_registration_date() {
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($domain)) {
            return 'Unknown';
        }

        try {
            $whois_server = 'whois.iana.org';
            $conn = @fsockopen($whois_server, 43, $errno, $errstr, 10);
            if ($conn) {
                fputs($conn, $domain . "\r\n");
                $response = '';
                while (!feof($conn)) {
                    $response .= fgets($conn, 128);
                }
                fclose($conn);

                // Try to find creation date
                if (preg_match('/Creation Date: (.+)/', $response, $matches)) {
                    return date('Y-m-d', strtotime($matches[1]));
                }
            }
        } catch (Exception $e) {
            error_log('WordPress Inspector: Error getting domain registration date - ' . $e->getMessage());
        }

        return 'Unknown';
    }

    /**
     * Get domain expiry date
     *
     * @return string Expiry date or 'Unknown'
     */
    public static function get_domain_expiry_date() {
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($domain)) {
            return 'Unknown';
        }

        try {
            $whois_server = 'whois.iana.org';
            $conn = @fsockopen($whois_server, 43, $errno, $errstr, 10);
            if ($conn) {
                fputs($conn, $domain . "\r\n");
                $response = '';
                while (!feof($conn)) {
                    $response .= fgets($conn, 128);
                }
                fclose($conn);

                // Try to find expiry date
                if (preg_match('/Expiry Date: (.+)/', $response, $matches)) {
                    return date('Y-m-d', strtotime($matches[1]));
                }
            }
        } catch (Exception $e) {
            error_log('WordPress Inspector: Error getting domain expiry date - ' . $e->getMessage());
        }

        return 'Unknown';
    }

    /**
     * Get nameserver provider information
     *
     * @param string $nameserver The nameserver to check
     * @return string The provider name or empty string
     */
    private static function get_nameserver_provider($nameserver) {
        $providers = array(
            'registrar-servers.com' => 'Namecheap',
            'cloudflare.com' => 'Cloudflare',
            'cloudflaredns.com' => 'Cloudflare',
            'awsdns' => 'Amazon AWS',
            'azure-dns' => 'Microsoft Azure',
            'googledomains.com' => 'Google Domains',
            'godaddy.com' => 'GoDaddy',
            'domaincontrol.com' => 'GoDaddy',
            'worldnic.com' => 'Network Solutions',
            'name-services.com' => 'NameCheap',
            'bluehost.com' => 'Bluehost',
            'hostgator.com' => 'HostGator',
            'dreamhost.com' => 'DreamHost',
            'dnsmadeeasy' => 'DNS Made Easy',
            'dnsimple.com' => 'DNSimple',
            'dynadot.com' => 'Dynadot',
            'hover.com' => 'Hover',
            'namesilo.com' => 'NameSilo',
            'ovh.net' => 'OVH',
            'gandi.net' => 'Gandi',
            'digitalocean.com' => 'DigitalOcean',
            'linode.com' => 'Linode',
            'vultr.com' => 'Vultr',
            'ns.cloudflare.com' => 'Cloudflare',
            'wpengine.com' => 'WP Engine',
            'kinsta.com' => 'Kinsta',
            'siteground.com' => 'SiteGround',
            'hostinger.com' => 'Hostinger',
            'ionos.com' => 'IONOS',
            'namebright.com' => 'NameBright',
            'cloudns.net' => 'ClouDNS',
            'dnspod.net' => 'DNSPod',
            'easydns.com' => 'easyDNS',
            'he.net' => 'Hurricane Electric',
            'route53' => 'Amazon Route 53'
        );

        foreach ($providers as $domain => $provider) {
            if (stripos($nameserver, $domain) !== false) {
                return $provider;
            }
        }

        return '';
    }

    /**
     * Get DNS servers for the domain
     *
     * @return array Array of DNS servers with provider information
     */
    public static function get_dns_servers() {
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($domain)) {
            error_log('WordPress Inspector: Empty domain');
            return array();
        }

        error_log('WordPress Inspector: Checking DNS for domain: ' . $domain);
        $nameservers = array();

        // Try to get nameservers for the parent domain
        $domain_parts = explode('.', $domain);
        if (count($domain_parts) > 2) {
            // Get the parent domain (e.g., seanasaservice.com from wpdemo.seanasaservice.com)
            $parent_domain = implode('.', array_slice($domain_parts, -2));
            error_log('WordPress Inspector: Checking parent domain: ' . $parent_domain);
            
            try {
                if (function_exists('dns_get_record')) {
                    $ns_records = @dns_get_record($parent_domain, DNS_NS);
                    error_log('WordPress Inspector: Parent domain DNS records: ' . print_r($ns_records, true));
                    if (!empty($ns_records)) {
                        foreach ($ns_records as $record) {
                            if (isset($record['target'])) {
                                $nameservers[] = strtolower($record['target']);
                                error_log('WordPress Inspector: Found nameserver from parent domain: ' . $record['target']);
                            }
                        }
                    }
                }
            } catch (Exception $e) {
                error_log('WordPress Inspector: Parent domain DNS lookup error - ' . $e->getMessage());
            }
        }

        // If no nameservers found, try Google's DNS-over-HTTPS API
        if (empty($nameservers)) {
            error_log('WordPress Inspector: Trying Google DNS API');
            try {
                // Try for the parent domain first if it exists
                $lookup_domain = isset($parent_domain) ? $parent_domain : $domain;
                $url = 'https://dns.google/resolve?name=' . urlencode($lookup_domain) . '&type=NS';
                error_log('WordPress Inspector: Google DNS API URL: ' . $url);
                
                $response = wp_remote_get($url, array(
                    'timeout' => 5,
                    'headers' => array(
                        'Accept' => 'application/dns-json'
                    )
                ));

                if (!is_wp_error($response)) {
                    error_log('WordPress Inspector: Google DNS API response code: ' . wp_remote_retrieve_response_code($response));
                    $body = wp_remote_retrieve_body($response);
                    error_log('WordPress Inspector: Google DNS API response: ' . $body);
                    
                    $data = json_decode($body, true);
                    
                    // Check for NS records in the Answer section
                    if (isset($data['Answer']) && is_array($data['Answer'])) {
                        foreach ($data['Answer'] as $answer) {
                            if (isset($answer['data'])) {
                                $ns = rtrim($answer['data'], '.');
                                $nameservers[] = strtolower($ns);
                                error_log('WordPress Inspector: Found nameserver from Google API Answer: ' . $ns);
                            }
                        }
                    }
                    
                    // Check for NS records in the Authority section
                    if (empty($nameservers) && isset($data['Authority']) && is_array($data['Authority'])) {
                        foreach ($data['Authority'] as $auth) {
                            if (isset($auth['data']) && strpos($auth['data'], 'hostmaster') !== false) {
                                // This is an SOA record, extract the primary nameserver
                                $parts = explode(' ', $auth['data']);
                                if (!empty($parts[0])) {
                                    $ns = rtrim($parts[0], '.');
                                    $nameservers[] = strtolower($ns);
                                    error_log('WordPress Inspector: Found nameserver from SOA record: ' . $ns);
                                }
                            }
                        }
                    }
                } else {
                    error_log('WordPress Inspector: Google DNS API error: ' . $response->get_error_message());
                }
            } catch (Exception $e) {
                error_log('WordPress Inspector: Google DNS API error - ' . $e->getMessage());
            }
        }

        // Remove duplicates and sort
        $nameservers = array_unique($nameservers);
        sort($nameservers);

        // Clean up nameserver formatting
        $nameservers = array_map(function($ns) {
            return rtrim(strtolower($ns), '.');
        }, $nameservers);

        $final_nameservers = array_values(array_filter($nameservers));
        error_log('WordPress Inspector: Final nameservers: ' . print_r($final_nameservers, true));
        
        // Before returning the nameservers, add provider information
        $nameservers_with_providers = array();
        foreach ($final_nameservers as $nameserver) {
            $provider = self::get_nameserver_provider($nameserver);
            $nameservers_with_providers[] = array(
                'server' => $nameserver,
                'provider' => $provider
            );
        }

        error_log('WordPress Inspector: Final nameservers with providers: ' . print_r($nameservers_with_providers, true));
        
        return $nameservers_with_providers;
    }

    /**
     * Get SSL certificate information
     *
     * @return array|null SSL certificate information or null if not found
     */
    public static function get_ssl_info() {
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        if (empty($domain)) {
            return null;
        }

        try {
            $context = stream_context_create([
                'ssl' => [
                    'capture_peer_cert' => true,
                    'verify_peer' => false,
                    'verify_peer_name' => false,
                ]
            ]);

            $client = @stream_socket_client(
                "ssl://{$domain}:443",
                $errno,
                $errstr,
                30,
                STREAM_CLIENT_CONNECT,
                $context
            );

            if ($client) {
                $params = stream_context_get_params($client);
                if (isset($params['options']['ssl']['peer_certificate'])) {
                    $cert = openssl_x509_parse($params['options']['ssl']['peer_certificate']);
                    
                    if ($cert) {
                        $now = time();
                        $days_until_expiration = ceil(($cert['validTo_time_t'] - $now) / (60 * 60 * 24));
                        
                        return array(
                            'issued_to' => $cert['subject']['CN'] ?? 'Unknown',
                            'issued_by' => $cert['issuer']['O'] ?? 'Unknown',
                            'valid_from' => date('n/j/Y, g:i:s A', $cert['validFrom_time_t']),
                            'valid_to' => date('n/j/Y, g:i:s A', $cert['validTo_time_t']),
                            'days_remaining' => $days_until_expiration,
                            'is_valid' => $days_until_expiration > 0
                        );
                    }
                }
                fclose($client);
            }
        } catch (Exception $e) {
            error_log('WordPress Inspector: SSL Info Error - ' . $e->getMessage());
        }

        return null;
    }

    /**
     * Get domain registration information using RDAP API
     * 
     * @return array|false Domain info array or false on failure
     */
    public static function get_domain_info() {
        // Get the domain from site URL
        $domain = parse_url(get_site_url(), PHP_URL_HOST);
        error_log('WordPress Inspector: Full domain from site URL: ' . $domain);
        
        // Remove www. if present
        $domain = preg_replace('/^www\./', '', $domain);
        
        // Extract root domain from potential subdomain
        $domain_parts = explode('.', $domain);
        $parts_count = count($domain_parts);
        
        if ($parts_count >= 2) {
            // Get the last two parts of the domain (e.g., example.com from sub.example.com)
            $root_domain = $domain_parts[$parts_count - 2] . '.' . $domain_parts[$parts_count - 1];
        } else {
            error_log('WordPress Inspector: Invalid domain format');
            return false;
        }
        
        error_log('WordPress Inspector: Root domain for API request: ' . $root_domain);
        
        // Extract TLD
        $parts = explode('.', $root_domain);
        $tld = end($parts);
        error_log('WordPress Inspector: TLD detected: ' . $tld);
        
        // Construct RDAP API URL based on TLD
        $api_url = '';
        switch ($tld) {
            case 'com':
                $api_url = 'https://rdap.verisign.com/com/v1/domain/' . $root_domain;
                break;
            case 'net':
                $api_url = 'https://rdap.verisign.com/net/v1/domain/' . $root_domain;
                break;
            case 'org':
                $api_url = 'https://rdap.pir.org/v1/domain/' . $root_domain;
                break;
            default:
                error_log('WordPress Inspector: Unsupported TLD: ' . $tld);
                return false;
        }
        
        error_log('WordPress Inspector: RDAP API URL: ' . $api_url);
        
        // Make API request
        $response = wp_remote_get($api_url);
        
        if (is_wp_error($response)) {
            error_log('WordPress Inspector: API request error - ' . $response->get_error_message());
            return false;
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        error_log('WordPress Inspector: API response code: ' . $status_code);
        
        if ($status_code !== 200) {
            error_log('WordPress Inspector: API request failed with status ' . $status_code);
            return false;
        }
        
        $data = json_decode(wp_remote_retrieve_body($response), true);
        
        if (empty($data)) {
            error_log('WordPress Inspector: Empty response data');
            return false;
        }
        
        if (!isset($data['events'])) {
            error_log('WordPress Inspector: No events data in response: ' . print_r($data, true));
            return false;
        }
        
        // Extract registration and expiration dates
        $domain_info = array(
            'registration_date' => '',
            'expiration_date' => '',
            'registrar' => ''
        );
        
        foreach ($data['events'] as $event) {
            if ($event['eventAction'] === 'registration') {
                $domain_info['registration_date'] = $event['eventDate'];
                error_log('WordPress Inspector: Found registration date: ' . $event['eventDate']);
            }
            if ($event['eventAction'] === 'expiration') {
                $domain_info['expiration_date'] = $event['eventDate'];
                error_log('WordPress Inspector: Found expiration date: ' . $event['eventDate']);
            }
        }
        
        // Get registrar info if available
        if (!empty($data['entities'])) {
            foreach ($data['entities'] as $entity) {
                if (isset($entity['roles']) && in_array('registrar', $entity['roles'])) {
                    if (!empty($entity['vcardArray'][1][1][3])) {
                        $domain_info['registrar'] = $entity['vcardArray'][1][1][3];
                        error_log('WordPress Inspector: Found registrar: ' . $entity['vcardArray'][1][1][3]);
                    }
                }
            }
        }
        
        return $domain_info;
    }

    /**
     * Check if memory limit is low
     * 
     * @param string $memory_limit Memory limit string (e.g., '128M')
     * @return bool True if memory limit is low
     */
    public static function is_memory_limit_low($memory_limit) {
        $memory_limit = self::convert_to_bytes($memory_limit);
        $recommended = 128 * 1024 * 1024; // 128M in bytes
        return $memory_limit < $recommended;
    }

    /**
     * Check if post max size is low
     * 
     * @param string $post_max_size Post max size string (e.g., '8M')
     * @return bool True if post max size is low
     */
    public static function is_post_max_size_low($post_max_size) {
        $post_max_size = self::convert_to_bytes($post_max_size);
        $recommended = 8 * 1024 * 1024; // 8M in bytes
        return $post_max_size < $recommended;
    }

    /**
     * Check if upload max filesize is low
     * 
     * @param string $upload_max_filesize Upload max filesize string (e.g., '2M')
     * @return bool True if upload max filesize is low
     */
    public static function is_upload_max_filesize_low($upload_max_filesize) {
        $upload_max_filesize = self::convert_to_bytes($upload_max_filesize);
        $recommended = 2 * 1024 * 1024; // 2M in bytes
        return $upload_max_filesize < $recommended;
    }

    /**
     * Convert PHP size string to bytes
     * 
     * @param string $size Size string (e.g., '128M')
     * @return int Size in bytes
     */
    private static function convert_to_bytes($size) {
        $unit = strtoupper(substr($size, -1));
        $value = (int)substr($size, 0, -1);
        
        switch ($unit) {
            case 'G':
                $value *= 1024;
            case 'M':
                $value *= 1024;
            case 'K':
                $value *= 1024;
        }
        
        return $value;
    }
} 