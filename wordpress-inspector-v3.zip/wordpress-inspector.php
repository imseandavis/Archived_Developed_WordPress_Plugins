<?php
/**
 * Plugin Name: WordPress Inspector
 * Plugin URI: https://github.com/imseandavis/wordpress-inspector
 * Description: A comprehensive WordPress inspection and debugging tool that provides detailed insights into your WordPress installation, including system information, file permissions, plugin licenses, and more.
 * Version: 3.0.1
 * Requires at least: 5.2
 * Requires PHP: 7.2
 * Author: Sean Davis
 * Author URI: https://imseandavis.com
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: wordpress-inspector
 * Domain Path: /languages
 *
 * @package WordPress_Inspector
 */

if (!defined('ABSPATH')) {
    exit;
}

// Define plugin constants
define('WPI_VERSION', '3.0.1');
define('WPI_PLUGIN_DIR', trailingslashit(plugin_dir_path(__FILE__)));
define('WPI_PLUGIN_URL', plugin_dir_url(__FILE__));
define('WPI_PLUGIN_BASENAME', plugin_basename(__FILE__));

// Improved autoloader with namespace support
spl_autoload_register(function ($class) {
    // Base namespace for the plugin
    $namespace = 'WordPressInspector\\';
    
    // Check if the class is from our plugin namespace
    if (strpos($class, $namespace) !== 0) {
        return;
    }
    
    // Remove namespace from class name
    $class_name = str_replace($namespace, '', $class);
    
    // Convert class name to file path
    $file = str_replace('\\', DIRECTORY_SEPARATOR, $class_name);
    $file = WPI_PLUGIN_DIR . 'includes/' . strtolower($file) . '.php';
    
    // Include the file if it exists
    if (file_exists($file)) {
        require_once $file;
    }
});

/**
 * Initialize the plugin
 */
function wordpress_inspector_init() {
    // Load the main plugin class
    require_once WPI_PLUGIN_DIR . 'includes/class-wordpress-inspector.php';
    
    // Initialize plugin
    $wordpress_inspector = new WordPress_Inspector();
    $wordpress_inspector->init();
}

// Hook into WordPress
add_action('plugins_loaded', 'wordpress_inspector_init');

// Register activation hook
register_activation_hook(__FILE__, 'wordpress_inspector_activate');

/**
 * Plugin activation function
 */
function wordpress_inspector_activate() {
    global $wpdb;
    
    // Verify database prefix
    if (empty($wpdb->prefix)) {
        deactivate_plugins(plugin_basename(__FILE__));
        wp_die(__('WordPress Inspector requires a database prefix to be set.', 'wordpress-inspector'));
    }
    
    // Create updates log table
    $table_name = $wpdb->prefix . 'wpi_update_logs';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE IF NOT EXISTS $table_name (
        id bigint(20) NOT NULL AUTO_INCREMENT,
        update_date datetime NOT NULL,
        update_type varchar(50) NOT NULL,
        item_name varchar(255) NOT NULL,
        version varchar(50) NOT NULL,
        status varchar(50) NOT NULL,
        details text,
        PRIMARY KEY  (id),
        KEY update_date (update_date),
        KEY update_type (update_type),
        KEY status (status)
    ) $charset_collate;";

    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
    dbDelta($sql);

    // Set version in options
    update_option('wordpress_inspector_version', WPI_VERSION);
}

// Register deactivation hook
register_deactivation_hook(__FILE__, 'wordpress_inspector_deactivate');
function wordpress_inspector_deactivate() {
    // Add deactivation tasks if needed
    flush_rewrite_rules();
}

// Register uninstall hook
register_uninstall_hook(__FILE__, 'wordpress_inspector_uninstall');
function wordpress_inspector_uninstall() {
    // Clean up plugin data if needed
    // Example: delete_option('wordpress_inspector_settings');
}

// In the init function or autoloader
require_once WPI_PLUGIN_DIR . 'includes/security/class-security-checks.php';
require_once WPI_PLUGIN_DIR . 'includes/security/class-security-fixes.php';
require_once WPI_PLUGIN_DIR . 'includes/class-wp-utils.php';

// Register CSS
wp_register_style('wordpress-inspector-admin', plugins_url('assets/css/admin.css', __FILE__));
wp_register_style('wordpress-inspector-overview', plugins_url('assets/css/overview.css', __FILE__));
wp_register_style('wordpress-inspector-logs', plugins_url('assets/css/logs.css', __FILE__));
wp_register_style('wordpress-inspector-database', plugins_url('assets/css/database.css', __FILE__));

// Initialize localization early
add_action('init', 'wordpress_inspector_load_textdomain');

/**
 * Load plugin text domain for translations
 */
function wordpress_inspector_load_textdomain() {
    load_plugin_textdomain(
        'wordpress-inspector',
        false,
        dirname(plugin_basename(__FILE__)) . '/languages'
    );
} 