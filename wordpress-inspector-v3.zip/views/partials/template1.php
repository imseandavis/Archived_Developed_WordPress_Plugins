<?php
if (!defined('ABSPATH')) {
    exit;
}

// Add CSS
wp_enqueue_style('wordpress-inspector-tools', plugins_url('assets/css/tools.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-tools', plugins_url('assets/js/tools.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery'));

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}
?>

<div class="wrap wordpress-inspector">
    <h1>WordPress Tools</h1>

    <!-- Stats Overview -->
    <div class="tools-stats">
        <div class="stat-card">
            <div class="stat-value">312,862</div>
            <div class="stat-label">Total Actions</div>
            <div class="stat-trend positive">↑ 2.4% in last 7 days</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">2,345,670</div>
            <div class="stat-label">Total Requests</div>
            <div class="stat-trend positive">↑ 3.1% in last 7 days</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">670,457</div>
            <div class="stat-label">Total Responses</div>
            <div class="stat-trend positive">↑ 4.5% in last 7 days</div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <div class="tools-tabs-wrapper">
        <div class="tools-tabs">
            <button class="tab-button active" data-tab="optimization">
                <span class="dashicons dashicons-performance"></span>
                Optimization
            </button>
            <button class="tab-button" data-tab="maintenance">
                <span class="dashicons dashicons-admin-tools"></span>
                Maintenance
            </button>
            <button class="tab-button" data-tab="cleanup">
                <span class="dashicons dashicons-trash"></span>
                Cleanup
            </button>
            <button class="tab-button" data-tab="monitoring">
                <span class="dashicons dashicons-chart-bar"></span>
                Monitoring
            </button>
        </div>
    </div>

    <!-- Tab Content -->
    <div class="tab-content-wrapper">
        <div id="optimization" class="tab-content active"></div>
        <div id="maintenance" class="tab-content"></div>
        <div id="cleanup" class="tab-content"></div>
        <div id="monitoring" class="tab-content"></div>
    </div>
</div> 