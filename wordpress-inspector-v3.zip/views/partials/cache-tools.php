<div class="dashboard-row">
    <div class="dashboard-col col-12">
        <div class="dashboard-card">
            <div class="card-header">
                <h3>Cache Tools</h3>
                <div class="header-actions">
                    <button class="button cache-button" data-action="all">
                        <span class="dashicons dashicons-trash"></span>
                        Clear All Caches
                    </button>
                </div>
            </div>
            <div class="card-content">
                <?php if (empty($cache_info['active_plugins'])): ?>
                    <div class="no-cache-plugins">
                        <span class="dashicons dashicons-warning"></span>
                        No caching plugins detected
                    </div>
                <?php else: ?>
                    <?php foreach ($cache_info['active_plugins'] as $plugin): ?>
                        <div class="info-item">
                            <span class="label"><?php echo esc_html($plugin['name']); ?></span>
                            <span class="value">
                                <button class="button cache-button" data-action="<?php echo esc_attr($plugin['slug']); ?>">
                                    Clear Cache
                                </button>
                            </span>
                        </div>
                    <?php endforeach; ?>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div> 