<?php if (!defined('ABSPATH')) exit; ?>

<div class="themes-list">
    <div class="themes-grid">
        <?php
        $themes = wp_get_themes();
        $sorted_themes = array();
        
        // Separate active and inactive themes
        foreach ($themes as $theme_slug => $theme) {
            $is_active = ($theme->get('Name') === wp_get_theme()->get('Name'));
            if ($is_active) {
                array_unshift($sorted_themes, $theme);
            } else {
                $sorted_themes[] = $theme;
            }
        }
        
        foreach ($sorted_themes as $theme) :
            $is_active = ($theme->get('Name') === wp_get_theme()->get('Name'));
            $stylesheet = $theme->get_stylesheet();
        ?>
            <div class="theme-card <?php echo $is_active ? 'active' : 'inactive'; ?>">
                <?php if (!$is_active): ?>
                <div class="theme-actions">
                    <button class="button make-primary-button" data-theme="<?php echo esc_attr($stylesheet); ?>">Make Primary</button>
                    <button class="button button-link-delete delete-theme-button" data-theme="<?php echo esc_attr($stylesheet); ?>">Delete</button>
                </div>
                <?php endif; ?>
                <div class="theme-content">
                    <div class="theme-header">
                        <h3>
                            <?php 
                            $theme_uri = $theme->get('ThemeURI');
                            if ($theme_uri) {
                                echo '<a href="' . esc_url($theme_uri) . '" target="_blank">' . $theme->get('Name') . '</a>';
                            } else {
                                echo $theme->get('Name');
                            }
                            ?>
                            <?php if ($theme->parent()): ?>
                            <span class="child-theme-badge" title="Child theme of <?php echo esc_attr($theme->parent()->get('Name')); ?>">Child Theme</span>
                            <?php endif; ?>
                        </h3>
                        <p class="theme-version">v<?php echo $theme->get('Version'); ?></p>
                    </div>
                    <div class="theme-meta">
                        <p class="theme-author">By 
                            <?php 
                            $author_uri = $theme->get('AuthorURI');
                            if ($author_uri) {
                                echo '<a href="' . esc_url($author_uri) . '" target="_blank">' . $theme->get('Author') . '</a>';
                            } else {
                                echo $theme->get('Author');
                            }
                            ?>
                        </p>
                        <p class="theme-description"><?php echo $theme->get('Description'); ?></p>
                        <p class="theme-directory"><?php echo 'Directory: ' . $theme->get_stylesheet_directory(); ?></p>
                    </div>
                </div>
            </div>
        <?php 
        endforeach; 
        ?>
    </div>
</div> 