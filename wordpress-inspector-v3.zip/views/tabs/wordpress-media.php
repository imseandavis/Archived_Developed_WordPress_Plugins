<?php if (!defined('ABSPATH')) exit; ?>

<div class="tools-card">
    <h3>Site Monitoring</h3>
    <div class="card-content">
        <div class="monitoring-tools">
            <div class="tool-item">
                <span class="dashicons dashicons-chart-line"></span>
                <div class="tool-info">
                    <h4>Performance Monitoring</h4>
                    <p>Monitor site performance and speed</p>
                    <button class="button monitor-performance-button">
                        View Performance
                    </button>
                </div>
            </div>

            <div class="tool-item">
                <span class="dashicons dashicons-warning"></span>
                <div class="tool-info">
                    <h4>Error Monitoring</h4>
                    <p>Track and analyze PHP and JavaScript errors</p>
                    <button class="button monitor-errors-button">
                        View Errors
                    </button>
                </div>
            </div>

            <div class="tool-item">
                <span class="dashicons dashicons-clock"></span>
                <div class="tool-info">
                    <h4>Uptime Monitoring</h4>
                    <p>Monitor site availability and response time</p>
                    <button class="button monitor-uptime-button">
                        View Uptime
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> 