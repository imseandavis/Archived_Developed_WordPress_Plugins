<?php if (!defined('ABSPATH')) exit; ?>

<div class="wp-card">
    <h3>WordPress Tools Overview</h3>
    <div class="card-content">
        <div class="overview-description">
            <p>Welcome to the WordPress Tools section. This area provides comprehensive tools to manage and maintain your WordPress installation:</p>
            
            <ul class="features-list">
                <li>
                    <span class="dashicons dashicons-admin-appearance"></span>
                    <div>
                        <strong>Themes Management</strong>
                        <p>Install, update, and manage your WordPress themes</p>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-admin-plugins"></span>
                    <div>
                        <strong>Plugins Management</strong>
                        <p>Control your plugins and their settings</p>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-admin-media"></span>
                    <div>
                        <strong>Media Management</strong>
                        <p>Organize and optimize your media files</p>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-update"></span>
                    <div>
                        <strong>Updates Control</strong>
                        <p>Manage WordPress core, theme, and plugin updates</p>
                    </div>
                </li>
                <li>
                    <span class="dashicons dashicons-admin-users"></span>
                    <div>
                        <strong>User Management</strong>
                        <p>Handle user accounts and permissions</p>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</div> 