<?php if (!defined('ABSPATH')) exit; ?>

<div class="plugins-list">
    <div class="plugins-grid">
        <?php
        $plugins = get_plugins();
        $active_plugins = get_option('active_plugins', array());
        $sorted_plugins = array();
        
        // Separate active and inactive plugins
        foreach ($plugins as $plugin_file => $plugin) {
            $is_active = in_array($plugin_file, $active_plugins);
            if ($is_active) {
                array_unshift($sorted_plugins, array('file' => $plugin_file, 'data' => $plugin));
            } else {
                $sorted_plugins[] = array('file' => $plugin_file, 'data' => $plugin);
            }
        }
        
        foreach ($sorted_plugins as $plugin) :
            $plugin_file = $plugin['file'];
            $plugin_data = $plugin['data'];
            $is_active = in_array($plugin_file, $active_plugins);
        ?>
            <div class="plugin-card <?php echo $is_active ? 'active' : 'inactive'; ?>">
                <?php if (!$is_active): ?>
                <div class="plugin-actions">
                    <button class="button activate-plugin-button" data-plugin="<?php echo esc_attr($plugin_file); ?>">Activate</button>
                    <button class="button button-link-delete delete-plugin-button" data-plugin="<?php echo esc_attr($plugin_file); ?>">Delete</button>
                </div>
                <?php else: ?>
                <div class="plugin-actions">
                    <button class="button deactivate-plugin-button" data-plugin="<?php echo esc_attr($plugin_file); ?>">Deactivate</button>
                </div>
                <?php endif; ?>
                <div class="plugin-content">
                    <div class="plugin-header">
                        <h3>
                            <?php 
                            if (!empty($plugin_data['PluginURI'])) {
                                echo '<a href="' . esc_url($plugin_data['PluginURI']) . '" target="_blank">' . $plugin_data['Name'] . '</a>';
                            } else {
                                echo $plugin_data['Name'];
                            }
                            ?>
                        </h3>
                        <p class="plugin-version">v<?php echo $plugin_data['Version']; ?></p>
                    </div>
                    <div class="plugin-meta">
                        <p class="plugin-author">By 
                            <?php 
                            if (!empty($plugin_data['AuthorURI'])) {
                                echo '<a href="' . esc_url($plugin_data['AuthorURI']) . '" target="_blank">' . $plugin_data['Author'] . '</a>';
                            } else {
                                echo $plugin_data['Author'];
                            }
                            ?>
                        </p>
                        <p class="plugin-description"><?php echo $plugin_data['Description']; ?></p>
                        <p class="plugin-directory">Directory: <?php echo plugin_dir_path(WP_PLUGIN_DIR . '/' . $plugin_file); ?></p>
                    </div>
                </div>
            </div>
        <?php 
        endforeach; 
        ?>
    </div>
</div> 