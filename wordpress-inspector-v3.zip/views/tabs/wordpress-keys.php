<?php if (!defined('ABSPATH')) exit; ?>

<div class="tools-card">
    <h3>Site Maintenance</h3>
    <div class="card-content">
        <div class="maintenance-tools">
            <div class="tool-item">
                <span class="dashicons dashicons-admin-links"></span>
                <div class="tool-info">
                    <h4>Broken Links Checker</h4>
                    <p>Scan and fix broken links across your site</p>
                    <button class="button check-links-button">
                        Check Links
                    </button>
                </div>
            </div>

            <div class="tool-item">
                <span class="dashicons dashicons-shield"></span>
                <div class="tool-info">
                    <h4>Security Scan</h4>
                    <p>Scan for potential security issues</p>
                    <button class="button security-scan-button">
                        Run Scan
                    </button>
                </div>
            </div>

            <div class="tool-item">
                <span class="dashicons dashicons-backup"></span>
                <div class="tool-info">
                    <h4>Backup Management</h4>
                    <p>Create and manage site backups</p>
                    <button class="button backup-button">
                        Manage Backups
                    </button>
                </div>
            </div>
        </div>
    </div>
</div> 