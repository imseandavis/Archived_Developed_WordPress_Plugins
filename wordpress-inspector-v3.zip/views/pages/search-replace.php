<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Enqueue required scripts
wp_enqueue_script('jquery');
?>

<div class="wrap wordpress-inspector">
    <h1>Search & Replace</h1>
    
    <div class="inspector-card search-replace-card">
        <div class="search-replace-form">
            <div class="form-row">
                <div class="form-group">
                    <label for="search">Search for</label>
                    <input type="text" id="search" name="search" class="regular-text" placeholder="Text to search for">
                </div>
                <div class="form-group">
                    <label for="replace">Replace with</label>
                    <input type="text" id="replace" name="replace" class="regular-text" placeholder="Text to replace with">
                </div>
            </div>

            <div class="form-row tables-selection">
                <h3>Select tables to update</h3>
                <div class="tables-grid">
                    <?php
                    global $wpdb;
                    $tables = $wpdb->get_results('SHOW TABLES');
                    foreach ($tables as $table) {
                        $table = (array) $table;
                        $table_name = reset($table);
                        ?>
                        <div class="table-checkbox">
                            <label>
                                <input type="checkbox" name="tables[]" value="<?php echo esc_attr($table_name); ?>">
                                <?php echo esc_html($table_name); ?>
                            </label>
                        </div>
                        <?php
                    }
                    ?>
                </div>
                <div class="table-actions">
                    <button type="button" class="button select-all-tables">Select All</button>
                    <button type="button" class="button deselect-all-tables">Deselect All</button>
                </div>
            </div>

            <div class="form-actions">
                <button type="button" class="button button-primary search-button">Search</button>
                <button type="button" class="button button-secondary replace-button" disabled>Replace</button>
                <div class="loading-spinner spinner"></div>
            </div>
        </div>

        <div class="search-results" style="display: none;">
            <h3>Search Results</h3>
            <div class="results-table-wrapper">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Table</th>
                            <th>Column</th>
                            <th>Row</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<style>
.search-replace-card {
    padding: 20px;
    background: #fff;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.form-row {
    display: flex;
    gap: 20px;
    margin-bottom: 20px;
}

.form-group {
    flex: 1;
}

.form-group label {
    display: block;
    margin-bottom: 5px;
    font-weight: 600;
}

.form-group input {
    width: 100%;
}

.tables-selection {
    display: block;
}

.tables-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
    gap: 10px;
    margin: 15px 0;
    max-height: 300px;
    overflow-y: auto;
    padding: 10px;
    border: 1px solid #ddd;
    background: #f9f9f9;
}

.table-checkbox label {
    display: flex;
    align-items: center;
    gap: 5px;
}

.table-actions {
    margin-top: 10px;
}

.form-actions {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-top: 20px;
}

.loading-spinner {
    float: none;
}

.results-table-wrapper {
    margin-top: 15px;
    max-height: 400px;
    overflow-y: auto;
}
</style>

<script>
jQuery(document).ready(function($) {
    const $searchInput = $('#search');
    const $replaceInput = $('#replace');
    const $searchButton = $('.search-button');
    const $replaceButton = $('.replace-button');
    const $spinner = $('.loading-spinner');
    const $searchResults = $('.search-results');
    const $resultsTable = $('.search-results tbody');

    // Handle table selection buttons
    $('.select-all-tables').on('click', function() {
        $('input[name="tables[]"]').prop('checked', true);
    });

    $('.deselect-all-tables').on('click', function() {
        $('input[name="tables[]"]').prop('checked', false);
    });

    // Handle search button click
    $searchButton.on('click', function() {
        const search = $searchInput.val();
        const tables = $('input[name="tables[]"]:checked').map(function() {
            return this.value;
        }).get();

        if (!search || !tables.length) {
            alert('Please enter a search term and select at least one table.');
            return;
        }

        $spinner.addClass('is-active');
        $searchButton.prop('disabled', true);
        $searchResults.hide();
        $resultsTable.empty();

        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'search_database',
                nonce: '<?php echo wp_create_nonce("search_replace_nonce"); ?>',
                search: search,
                tables: tables
            },
            success: function(response) {
                if (response.success) {
                    if (response.data.results.length) {
                        response.data.results.forEach(function(result) {
                            $resultsTable.append(`
                                <tr>
                                    <td>${result.table}</td>
                                    <td>${result.column}</td>
                                    <td>${result.row_id}</td>
                                    <td>${result.value}</td>
                                </tr>
                            `);
                        });
                        $replaceButton.prop('disabled', false);
                    } else {
                        $resultsTable.append('<tr><td colspan="4">No results found.</td></tr>');
                        $replaceButton.prop('disabled', true);
                    }
                    $searchResults.show();
                } else {
                    alert('Error: ' + response.data.message);
                }
            },
            error: function() {
                alert('Error performing search. Please try again.');
            },
            complete: function() {
                $spinner.removeClass('is-active');
                $searchButton.prop('disabled', false);
            }
        });
    });

    // Handle replace button click
    $replaceButton.on('click', function() {
        if (confirm('Are you sure you want to replace all occurrences? This cannot be undone.')) {
            const search = $searchInput.val();
            const replace = $replaceInput.val();
            const tables = $('input[name="tables[]"]:checked').map(function() {
                return this.value;
            }).get();

            $spinner.addClass('is-active');
            $replaceButton.prop('disabled', true);
            $searchButton.prop('disabled', true);

            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: 'replace_database',
                    nonce: '<?php echo wp_create_nonce("search_replace_nonce"); ?>',
                    search: search,
                    replace: replace,
                    tables: tables
                },
                success: function(response) {
                    if (response.success) {
                        alert('Successfully replaced ' + response.data.count + ' occurrences.');
                        location.reload();
                    } else {
                        alert('Error: ' + response.data.message);
                    }
                },
                error: function() {
                    alert('Error performing replace. Please try again.');
                },
                complete: function() {
                    $spinner.removeClass('is-active');
                    $replaceButton.prop('disabled', false);
                    $searchButton.prop('disabled', false);
                }
            });
        }
    });
});
</script> 