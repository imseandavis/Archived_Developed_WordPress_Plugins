<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Get upload directory info
$upload_dir = wp_upload_dir();
?>

<div class="wrap wordpress-inspector">
    <h1>Media Information</h1>
    
    <div class="inspector-card">
        <h2>Upload Settings</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Upload Server Directory</th>
                <td><?php echo esc_html($upload_dir['basedir']); ?></td>
            </tr>
            <tr>
                <th>Upload URL</th>
                <td><?php echo esc_url($upload_dir['baseurl']); ?></td>
            </tr>
            <tr>
                <th>Max Upload Size</th>
                <td><?php echo esc_html(size_format(wp_max_upload_size())); ?></td>
            </tr>
            <?php if (!empty($upload_dir['error'])): ?>
            <tr>
                <th>Upload Directory Error</th>
                <td class="error"><?php echo esc_html($upload_dir['error']); ?></td>
            </tr>
            <?php endif; ?>
        </table>
    </div>

    <div class="inspector-card">
        <h2>Image Sizes</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Size Name</th>
                <th>Width</th>
                <th>Height</th>
                <th>Crop</th>
            </tr>
            <?php
            try {
                $sizes = wp_get_registered_image_subsizes();
                if (empty($sizes)) {
                    throw new Exception('No registered image sizes found.');
                }
                
                foreach($sizes as $size => $details) {
                    ?>
                    <tr>
                        <td><?php echo esc_html($size); ?></td>
                        <td><?php echo esc_html($details['width']); ?>px</td>
                        <td><?php echo esc_html($details['height']); ?>px</td>
                        <td><?php echo $details['crop'] ? 'Yes' : 'No'; ?></td>
                    </tr>
                <?php }
            } catch (Exception $e) {
                ?>
                <tr>
                    <td colspan="4" class="error">
                        <?php echo esc_html($e->getMessage()); ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>

    <?php
    // Add media statistics if available
    $attachment_count = wp_count_posts('attachment');
    if ($attachment_count): 
    ?>
    <div class="inspector-card">
        <h2>Media Statistics</h2>
        <table class="inspector-info-table">
            <?php
            // Get attachment counts
            $total_attachments = wp_count_attachments();
            $total_count = 0;
            $total_size = 0;

            // Get all attachments to calculate total size
            $attachments = get_posts(array(
                'post_type' => 'attachment',
                'posts_per_page' => -1,
                'post_status' => 'any'
            ));

            foreach ($attachments as $attachment) {
                $file = get_attached_file($attachment->ID);
                if (file_exists($file)) {
                    $total_size += filesize($file);
                }

                // Also add sizes for image attachments
                if (wp_attachment_is_image($attachment->ID)) {
                    $meta = wp_get_attachment_metadata($attachment->ID);
                    if (!empty($meta['sizes'])) {
                        $upload_dir = wp_upload_dir();
                        $base_dir = $upload_dir['basedir'] . '/' . dirname($meta['file']) . '/';
                        
                        foreach ($meta['sizes'] as $size) {
                            $size_file = $base_dir . $size['file'];
                            if (file_exists($size_file)) {
                                $total_size += filesize($size_file);
                            }
                        }
                    }
                }
            }
            ?>
            <tr>
                <th>Total Media Files</th>
                <td><?php echo array_sum((array)$total_attachments); ?></td>
            </tr>
            <tr>
                <th>Total Media Size</th>
                <td><?php echo size_format($total_size); ?></td>
            </tr>
            <?php
            // Show breakdown by mime type
            foreach ($total_attachments as $mime => $count) {
                if ($count > 0) {
                    ?>
                    <tr>
                        <th><?php echo esc_html(ucfirst($mime)); ?> Files</th>
                        <td><?php echo esc_html(number_format($count)); ?></td>
                    </tr>
                    <?php
                }
            }
            ?>
        </table>
    </div>
    <?php endif; ?>
</div>

<style>
.error {
    color: #d63638;
}
</style> 