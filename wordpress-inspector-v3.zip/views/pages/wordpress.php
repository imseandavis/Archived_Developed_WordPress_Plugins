<?php
if (!defined('ABSPATH')) {
    exit;
}

// Load plugin functions if not already loaded
if (!function_exists('get_plugins')) {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
$css_file = WPI_PLUGIN_DIR . 'assets/css/wordpress.css';
wp_enqueue_style('wordpress-inspector-wordpress', plugins_url('assets/css/wordpress.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array(), filemtime($css_file));
$themes_css_file = WPI_PLUGIN_DIR . 'assets/css/wordpress-themes.css';
wp_enqueue_style('wordpress-inspector-themes', plugins_url('assets/css/wordpress-themes.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('wordpress-inspector-wordpress'), filemtime($themes_css_file));

// Add JS
$js_file = WPI_PLUGIN_DIR . 'assets/js/wordpress.js';
wp_enqueue_script('wordpress-inspector-wordpress', plugins_url('assets/js/wordpress.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery'), filemtime($js_file));
$themes_js_file = WPI_PLUGIN_DIR . 'assets/js/wordpress-themes.js';
wp_enqueue_script('wordpress-inspector-themes', plugins_url('assets/js/wordpress-themes.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery', 'wordpress-inspector-wordpress'), filemtime($themes_js_file));

// Add nonce for AJAX
wp_localize_script('wordpress-inspector-wordpress', 'wordpress_inspector', array(
    'nonce' => wp_create_nonce('wp_ajax_nonce'),
    'ajaxurl' => admin_url('admin-ajax.php'),
    'admin_url' => admin_url('admin.php')
));
?>

<div class="wrap wordpress-inspector">
    <!-- <h1>WordPress Tools</h1> -->

    <!-- Stats Overview -->
    <div class="wp-stats">
        <?php 
        $security_stats = WordPress_Inspector_Security_Utils::get_security_stats();
        $overall_score = $security_stats['overall_score'];
        $score_class = $overall_score >= 90 ? 'positive' : ($overall_score >= 70 ? 'neutral' : 'negative');
        ?>
        <div class="wp-stat-card">
            <div class="wp-stat-value"><?php echo $overall_score; ?>%</div>
            <div class="wp-stat-label">Security Score</div>
            <div class="wp-stat-breakdown">
                <?php foreach ($security_stats['categories'] as $category => $data): ?>
                <div class="score-item">
                    <span class="category"><?php echo $category; ?></span>
                    <span class="score <?php echo $data['percentage'] >= 90 ? 'positive' : ($data['percentage'] >= 70 ? 'neutral' : 'negative'); ?>">
                        <?php echo $data['percentage']; ?>%
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="wp-stat-card">
            <?php 
            $performance_stats = WordPress_Inspector_Performance_Utils::get_performance_stats();
            $performance_score = $performance_stats['overall_score'];
            $score_class = $performance_score >= 90 ? 'positive' : ($performance_score >= 70 ? 'neutral' : 'negative');
            ?>
            <div class="wp-stat-value"><?php echo $performance_score; ?>%</div>
            <div class="wp-stat-label">Performance Score</div>
            <div class="wp-stat-breakdown">
                <div class="core-metrics">
                    <?php foreach ($performance_stats['core_scores'] as $key => $metric): ?>
                    <div class="core-score <?php echo $metric['score'] >= 90 ? 'positive' : ($metric['score'] >= 70 ? 'neutral' : 'negative'); ?>">
                        <span class="score"><?php echo $metric['score']; ?></span>
                        <span class="label"><?php echo $metric['name']; ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
                <div class="metric-divider"></div>
                <?php foreach ($performance_stats['metrics'] as $key => $metric): ?>
                <div class="score-item">
                    <span class="category"><?php echo $metric['name']; ?></span>
                    <span class="score <?php echo $metric['score'] >= 90 ? 'positive' : ($metric['score'] >= 70 ? 'neutral' : 'negative'); ?>">
                        <?php echo $metric['value']; ?>
                    </span>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <div class="wp-stat-card">
            <?php 
            $health_stats = WordPress_Inspector_Health_Utils::get_health_stats();
            $health_score = $health_stats['overall_score'];
            $score_class = $health_score >= 90 ? 'positive' : ($health_score >= 70 ? 'neutral' : 'negative');
            ?>
            <div class="wp-stat-value"><?php echo $health_score; ?>%</div>
            <div class="wp-stat-label">Site Health</div>
            <div class="wp-stat-breakdown">
                <?php foreach ($health_stats['categories'] as $key => $category): ?>
                <div class="score-item">
                    <span class="category"><?php echo $category['name']; ?></span>
                    <span class="score <?php echo $category['score'] >= 90 ? 'positive' : ($category['score'] >= 70 ? 'neutral' : 'negative'); ?>">
                        <?php echo $category['score']; ?>%
                    </span>
                </div>
                <?php endforeach; ?>
                <div class="metric-divider"></div>
                <div class="health-summary">
                    <div class="health-item positive">
                        <span class="count"><?php echo $health_stats['good']; ?></span>
                        <span class="label">Good</span>
                    </div>
                    <div class="health-item neutral">
                        <span class="count"><?php echo $health_stats['recommended']; ?></span>
                        <span class="label">Recommended</span>
                    </div>
                    <div class="health-item negative">
                        <span class="count"><?php echo $health_stats['critical']; ?></span>
                        <span class="label">Critical</span>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Tabs Navigation -->
    <div class="wp-tabs-wrapper">
        <div class="wp-tabs">
            <button class="wp-tab-button active" data-tab="overview">
                <span class="dashicons dashicons-performance"></span>
                Overview
            </button>
            <button class="wp-tab-button" data-tab="themes">
                <span class="dashicons dashicons-performance"></span>
                Themes
                <span class="count-badge"><?php echo count(wp_get_themes()); ?></span>
            </button>
            <button class="wp-tab-button" data-tab="plugins">
                <span class="dashicons dashicons-admin-plugins"></span>
                Plugins
                <span class="count-badge"><?php echo count(get_plugins()); ?></span>
            </button>
            <button class="wp-tab-button" data-tab="media">
                <span class="dashicons dashicons-trash"></span>
                Media
                <span class="count-badge"><?php 
                    $attachments = wp_count_attachments();
                    $total = array_sum((array)$attachments);
                    echo $total;
                ?></span>
            </button>
            <button class="wp-tab-button" data-tab="updates">
                <span class="dashicons dashicons-trash"></span>
                Updates
            </button>            
            <button class="wp-tab-button" data-tab="users">
                <span class="dashicons dashicons-trash"></span>
                Users
                <span class="count-badge"><?php echo count_users()['total_users']; ?></span>
            </button>
            <button class="wp-tab-button" data-tab="keys">
                <span class="dashicons dashicons-chart-bar"></span>
                License Keys
            </button>
            <button class="wp-tab-button danger-tab" data-tab="reset">
                <span class="dashicons dashicons-chart-bar"></span>
                Reset
            </button>
        </div>
    </div>

    <!-- Tab Content -->
    <div class="wp-tab-content-wrapper">
        <div id="overview" class="wp-tab-content active"></div>
        <div id="themes" class="wp-tab-content"></div>
        <div id="plugins" class="wp-tab-content"></div>
        <div id="media" class="wp-tab-content"></div>
        <div id="updates" class="wp-tab-content"></div>
        <div id="users" class="wp-tab-content"></div>        
        <div id="keys" class="wp-tab-content"></div>
        <div id="reset" class="wp-tab-content"></div>
    </div>
</div> 