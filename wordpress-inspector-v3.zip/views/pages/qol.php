<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
wp_enqueue_style('wordpress-inspector-qol', plugins_url('assets/css/qol.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-qol', plugins_url('assets/js/qol.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));
?>

<div class="wrap wordpress-inspector">
    <h1>Quality of Life</h1>
    
    <div class="qol-container">
        <!-- Admin UI Section -->
        <div class="section admin-ui-section">
            <h2>Admin Interface</h2>
            <!-- Admin UI customization options -->
        </div>

        <!-- Workflow Section -->
        <div class="section workflow-section">
            <h2>Workflow Tools</h2>
            <!-- Workflow enhancement tools -->
        </div>

        <!-- Notifications Section -->
        <div class="section notifications-section">
            <h2>Notifications</h2>
            <!-- Notification management -->
        </div>
    </div>
</div> 