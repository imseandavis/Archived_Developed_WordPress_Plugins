<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;

// Add CSS
$css_file = WPI_PLUGIN_DIR . 'assets/css/overview.css';
wp_enqueue_style('wordpress-inspector-overview', plugins_url('assets/css/overview.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array(), filemtime($css_file));

// Add JS
$js_file = WPI_PLUGIN_DIR . 'assets/js/overview.js';
wp_enqueue_script('wordpress-inspector-overview', plugins_url('assets/js/overview.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array(), filemtime($js_file));

// Add ThickBox support
wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');

// Get database information
$db_size = WordPress_Inspector_DB_Utils::get_db_size();
$tables = $wpdb->get_results("SHOW TABLE STATUS");

// Calculate table totals
$total_rows = 0;
$total_data = 0;
$total_index = 0;
$total_size = 0;
$total_overhead = 0;

foreach ($tables as $table) {
    $total_rows += $table->Rows;
    $total_data += $table->Data_length;
    $total_index += $table->Index_length;
    $total_size += ($table->Data_length + $table->Index_length);
    $total_overhead += $table->Data_free;
}

// Initialize database errors array
$db_errors = array();
if (isset($slow_query_vars) && !empty($wpdb->last_error)) {
    $db_errors[] = array(
        'header' => 'Database Error',
        'message' => $wpdb->last_error
    );
}

// Near the top of the file, add these variable definitions
$php_percent = 0;
if (isset($memory_info['php_used']) && isset($memory_info['php_limit'])) {
    $php_percent = ($memory_info['php_limit'] > 0) ? 
        round(($memory_info['php_used'] / $memory_info['php_limit']) * 100) : 0;
}

// Add translations array definition
$translations = array(
    'success' => __('Success', 'wordpress-inspector'),
    'error' => __('Error', 'wordpress-inspector'),
    'warning' => __('Warning', 'wordpress-inspector'),
    'info' => __('Info', 'wordpress-inspector')
);

?>

<!-- Toast Container -->
<div class="toast-container"></div>

<div class="wrap wordpress-inspector" style="margin-top: 10px;">

    <div id="database-info">
        <div class="dashboard-row">

            <div class="dashboard-col col-12">
                <div class="inspector-card">
                    <h2>
                        <span>Platform Overview</span>
                        <div class="header-icons">
                            <button type="button" class="info-modal-button" data-modal="raw-data-info-modal">
                                <span class="dashicons dashicons-info"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="database-tables-modal">
                                <span class="dashicons dashicons-list-view"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="env-variables-modal">
                                <span class="dashicons dashicons-code-standards"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="file-permissions-modal">
                                <span class="dashicons dashicons-shield"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="wp-constants-modal">
                                <span class="dashicons dashicons-editor-code"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="system-limits-modal">
                                <span class="dashicons dashicons-performance"></span>
                            </button>
                            <button type="button" class="info-modal-button" data-modal="php-info-modal">
                                <span class="dashicons dashicons-info-outline"></span>
                            </button>
                        </div>
                    </h2>
                    <div class="card-content database-infographic">
                        <!-- Cloud Container -->
                        <div class="cloud-container">
                            <div class="cloud-info-icon">
                                <span class="dashicons dashicons-info-outline" data-modal="cloud-info-modal"></span>
                            </div>
                            <?php
                            // Check if site is reachable
                            $site_url = get_site_url();
                            $response = wp_remote_get($site_url, array(
                                'timeout' => 5,
                                'sslverify' => false
                            ));
                            $is_online = !is_wp_error($response) && wp_remote_retrieve_response_code($response) < 400;
                            ?>
                            <div class="container-label <?php echo $is_online ? 'status-online' : 'status-offline'; ?>" 
                                 title="<?php echo $is_online ? 'Website is online and reachable' : 'Website appears to be offline or unreachable'; ?>">
                                Website
                            </div>
                            <div class="cloud-icon">
                                <span class="dashicons dashicons-cloud"></span>
                                <div class="website-info">
                                    <div class="website-url">
                                        <a href="<?php echo esc_url($site_url); ?>" target="_blank">
                                            <?php echo esc_url($site_url); ?>
                                        </a>
                                    </div>
                                    
                                    <div class="provider-card">
                                        <?php
                                        $dns_servers = WordPress_Inspector_System_Utils::get_dns_servers();
                                        $provider = !empty($dns_servers) ? $dns_servers[0]['provider'] : 'Unknown';
                                        ?>
                                        <div class="provider-header">DNS Provider</div>
                                        <div class="provider-name"><?php echo esc_html($provider); ?></div>
                                        <div class="nameservers">
                                            <?php
                                            if (!empty($dns_servers)):
                                                foreach ($dns_servers as $server):
                                                    echo '<span class="provider-tag">' . esc_html($server['server']) . '</span>';
                                                endforeach;
                                            else:
                                                echo '<span class="warning-text">No nameservers detected</span>';
                                            endif;
                                            ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <!-- Hosting Provider Container -->
                        <div class="hosting-provider-container">
                            <button class="collapse-button" title="Toggle container">
                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                            </button>
                            <?php
                            // Calculate if any resources are critical
                            $memory_info = WordPress_Inspector_System_Utils::get_memory_info();
                            $memory_used = $memory_info['used'] ?? 0;
                            $memory_total = $memory_info['total'] ?? 0;
                            $memory_percentage = $memory_total > 0 ? ($memory_used / $memory_total) * 100 : 0;
                            
                            $filesystem_info = WordPress_Inspector_System_Utils::get_filesystem_info();
                            $storage = $filesystem_info['storage'];
                            $storage_percentage = $storage['total'] > 0 ? ($storage['used'] / $storage['total']) * 100 : 0;
                            $is_critical = ($memory_percentage > 90 || $storage_percentage > 90);
                            $status_class = $is_critical ? 'status-critical' : 'status-healthy';
                            ?>
                            <div class="container-label <?php echo esc_attr($status_class); ?>">
                                Hosting Provider: <?php 
                                $provider = WordPress_Inspector_System_Utils::detect_hosting_provider();
                                    
                                echo esc_html($provider !== 'Unknown' ? $provider : 'Provider Unknown');
                            ?></div>
                            <?php if ($is_critical): ?>
                                <div class="critical-warning expand-container-trigger">
                                    <?php
                                    if ($memory_percentage > 90) {
                                        echo '<span style="color: #fff; font-size: 12px; cursor: pointer;">Hosting Server RAM is ' . round($memory_percentage) . '% utilized. You may experience decreased site performance. Click for more information.</span>';
                                    }
                                    if ($storage_percentage > 90) {
                                        if ($memory_percentage > 90) echo '<br>';
                                        echo '<span style="color: #d63638; cursor: pointer;">Hosting Server Storage is ' . round($storage_percentage) . '% utilized. You may experience decreased site performance. Click for more information.</span>';
                                    }
                                    ?>
                                </div>
                            <?php endif; ?>
                            <div class="container-content hosting-info-content">
                            <div class="hosting-info-grid">
                                    <div class="server-info-item">
                                        <span class="dashicons dashicons-admin-site"></span>
                                        <span class="info-label">Server IP</span>
                                        <span class="info-value"><?php echo esc_html($_SERVER['SERVER_ADDR'] ?? 'N/A'); ?></span>
                                    </div>
                                    
                                    <div class="server-info-item">
                                        <span class="dashicons dashicons-tag"></span>
                                        <span class="info-label">Server Name</span>
                                        <span class="info-value"><?php echo esc_html(php_uname('n')); ?></span>
                                    </div>
                                    
                                    <div class="server-info-item">
                                        <span class="dashicons dashicons-desktop"></span>
                                        <span class="info-label">Server OS</span>
                                        <span class="info-value"><?php echo esc_html(php_uname('s') . ' ' . php_uname('r')); ?></span>
                                    </div>
                                    
                                    <div class="server-info-item">
                                    <span class="dashicons dashicons-networking"></span>
                                        <span class="info-label">CPU Model</span>
                                        <div class="info-value">
                                            <?php 
                                            $cpu_info = WordPress_Inspector_System_Utils::get_cpu_info();
                                            if (!empty($cpu_info['model'])): 
                                                echo esc_html($cpu_info['model']);
                                                if (!empty($cpu_info['cores'])): 
                                                    echo '<br>(' . esc_html($cpu_info['cores']) . ' Threads)';
                                                endif;
                                            else: 
                                            ?>
                                                <span class="restricted-info">Restricted By Host</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                    <div class="server-info-item">
                                        <span class="dashicons dashicons-performance"></span>
                                        <span class="info-label">Server RAM</span>
                                        <div class="info-value">
                                            <?php 
                                            $memory_info = WordPress_Inspector_System_Utils::get_memory_info();
                                            $memory_used = $memory_info['used'] ?? 0;
                                            $memory_total = $memory_info['total'] ?? 0;
                                            $memory_percentage = $memory_total > 0 ? ($memory_used / $memory_total) * 100 : 0;
                                            
                                            if ($memory_info['total'] > 0): 
                                            ?>
                                                <div class="usage-text">
                                                    <?php echo esc_html(size_format($memory_used) . ' of ' . size_format($memory_total)); ?>
                                                </div>
                                                <div class="progress-bar-container">
                                                    <div class="progress-bar" 
                                                         style="width: <?php echo esc_attr($memory_percentage); ?>%;
                                                                background-color: <?php echo esc_attr(WordPress_Inspector_Utils::get_usage_color($memory_percentage)); ?>"
                                                         title="<?php echo esc_attr(size_format($memory_used) . ' used of ' . size_format($memory_total)); ?>"
                                                         data-percentage="<?php echo esc_attr(round($memory_percentage)); ?>%">
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="restricted-info">Restricted By Host</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>

                                    <div class="server-info-item">
                                        <span class="dashicons dashicons-database"></span>
                                        <span class="info-label">Server Storage</span>
                                        <div class="info-value">
                                            <?php 
                                            $filesystem_info = WordPress_Inspector_System_Utils::get_filesystem_info();
                                            $storage = $filesystem_info['storage'];
                                            $storage_percentage = $storage['total'] > 0 ? ($storage['used'] / $storage['total']) * 100 : 0;
                                            $storage_usage_color = WordPress_Inspector_Utils::get_usage_color($storage_percentage);
                                            
                                            if ($storage['total'] > 0): 
                                            ?>
                                                <div class="usage-text">
                                                    <?php echo esc_html(WordPress_Inspector_Utils::format_size_dynamic($storage['used']) . ' of ' . WordPress_Inspector_Utils::format_size_dynamic($storage['total'])); ?>
                                                </div>
                                                <div class="progress-bar-container">
                                                    <div class="progress-bar" 
                                                         style="width: <?php echo esc_attr($storage_percentage); ?>%;
                                                                background-color: <?php echo esc_attr($storage_usage_color); ?>"
                                                         title="<?php echo esc_attr(WordPress_Inspector_Utils::format_size_dynamic($storage['used']) . ' used of ' . WordPress_Inspector_Utils::format_size_dynamic($storage['total'])); ?>"
                                                         data-percentage="<?php echo esc_attr(round($storage_percentage)); ?>%">
                                                    </div>
                                                </div>
                                            <?php else: ?>
                                                <span class="restricted-info">Restricted By Host</span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- Keep instance container outside of collapsible content -->
                            <!-- Your Hosting Instance Container -->
                            <div class="instance-container">
                                <button class="collapse-button" title="Toggle container">
                                    <span class="dashicons dashicons-arrow-up-alt2"></span>
                                </button>
                                <?php
                                // Calculate PHP RAM usage percentage
                                $memory_limit = ini_get('memory_limit');
                                $php_limit = WordPress_Inspector_Utils::parse_size($memory_limit);
                                $php_usage = memory_get_usage(true);
                                $php_peak = memory_get_peak_usage(true);
                                
                                // Calculate CPU load percentage
                                $cpu_load = !empty($cpu_info['load']) ? max($cpu_info['load']) : 0;
                                $cpu_percent = $cpu_info['cores'] > 0 ? ($cpu_load / $cpu_info['cores']) * 100 : 0;
                                
                                // Check if either CPU or RAM is critical
                                $is_instance_critical = $php_percent > 90 || $cpu_percent > 90;
                                ?>
                                <div class="container-label <?php echo $is_instance_critical ? 'status-critical' : 'status-healthy'; ?>">
                                    Your Hosting Instance
                                </div>
                                <?php if ($is_instance_critical): ?>
                                    <div class="critical-warning">
                                        <?php if ($php_percent > 90): ?>
                                            <span class="warning-text">PHP RAM Usage is <?php echo round($php_percent); ?>% utilized. Expand for more information.</span>
                                        <?php endif; ?>
                                        <?php if ($cpu_percent > 90): ?>
                                            <?php if ($php_percent > 90) echo '<br>'; ?>
                                            <span class="warning-text">CPU Load is <?php echo round($cpu_percent, 1); ?>% utilized. Expand for more information.</span>
                                        <?php endif; ?>
                                    </div>
                                <?php endif; ?>
                                <div class="container-content instance-info-content">
                                    <div class="instance-info-grid">
                                        <div class="instance-info-item">
                                            <span class="dashicons dashicons-performance"></span>
                                            <span class="info-label">Dedicated Cores</span>
                                        <span class="info-value">
                                            <?php if ($cpu_info['allocated_cores'] > 0): ?>
                                                <?php echo esc_html(number_format($cpu_info['allocated_cores'], 1)); ?>
                                            <?php else: ?>
                                                <span class="restricted-info">Restricted By Hosting Provider</span>
                                            <?php endif; ?>
                                        </span>
                                    </div>

                                        <div class="instance-info-item">
                                            <span class="dashicons dashicons-chart-line"></span>
                                            <span class="info-label">CPU Load</span>
                                        <span class="info-value">
                                            <?php 
                                            if (!empty($cpu_info['load'])) {
                                                    $cpu_load = max($cpu_info['load']);
                                                    $cpu_percent = ($cpu_load / $cpu_info['cores']) * 100;
                                                    $cpu_usage_color = WordPress_Inspector_Utils::get_usage_color($cpu_percent);
                                                    
                                                echo esc_html(implode(', ', array_map(function($load) { 
                                                    return number_format($load, 2); 
                                                    }, $cpu_info['load']))) . ' (' . number_format($cpu_percent, 1) . '%)';
                                                    
                                                    echo '<div class="progress-bar-container cpu-load-bar">
                                                        <div class="progress-bar" 
                                                             style="width: ' . esc_attr($cpu_percent) . '%;
                                                                    background-color: ' . esc_attr($cpu_usage_color) . '"
                                                             title="' . esc_attr(number_format($cpu_percent, 1) . '% CPU utilization') . '"
                                                             data-percentage="' . esc_attr(round($cpu_percent)) . '%">
                                                        </div>
                                                    </div>';
                                            } else {
                                                echo '<span class="restricted-info">Not Available</span>';
                                            }
                                            ?>
                                        </span>
                                    </div>

                                        <div class="instance-info-item">
                                            <span class="dashicons dashicons-database"></span>
                                            <span class="info-label">PHP RAM Usage</span>
                                            <span class="info-value">
                                        <?php
                                        // Get PHP memory limit and convert to bytes if needed
                                        $memory_limit = ini_get('memory_limit');
                                        $php_limit = WordPress_Inspector_Utils::parse_size($memory_limit);
                                        
                                        // Get current memory usage
                                        $php_usage = memory_get_usage(true);
                                        $php_peak = memory_get_peak_usage(true);
                                        
                                        // Calculate percentage
                                        $php_percent = $php_limit > 0 ? round(($php_usage / $php_limit) * 100, 1) : 0;
                                        $php_usage_color = WordPress_Inspector_Utils::get_usage_color($php_percent);
                                        echo esc_html(sprintf(
                                            '%s (Peak: %s) / %s',
                                            size_format($php_usage),
                                            size_format($php_peak),
                                            size_format($php_limit)
                                        ));
                                        
                                        ?>
                                        <div class="progress-bar-container cpu-load-bar">
                                            <div class="progress-bar" 
                                                 style="width: <?php echo esc_attr($php_percent); ?>%;
                                                        background-color: <?php echo esc_attr($php_usage_color); ?>"
                                                 title="<?php echo esc_attr(size_format($php_usage) . ' used of ' . size_format($php_limit)); ?>"
                                                 data-percentage="<?php echo esc_attr($php_percent); ?>%">
                                            </div>
                                        </div>
                                        </span>
                                    </div>
                                </div>
                                </div>
                                <div class="server-containers-wrapper">
                                    <!-- First Row - App Server -->
                                    <div class="server-row">
                                        <!-- WordPress Application Server Container -->
                                        <div class="application-container">
                                            <button class="collapse-button" title="Toggle container">
                                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                                            </button>
                                            <?php
                                            $security_info = WordPress_Inspector_Security_Utils::get_security_info();
                                            $security_score = isset($security_info['security_score']['score']) ? $security_info['security_score']['score'] : 0;
                                            $security_grade = isset($security_info['security_score']['grade']) ? $security_info['security_score']['grade'] : 'A';
                                            $score_class = '';
                                            
                                            // Set class based on score
                                            if ($security_score >= 90) {
                                                $score_class = 'status-healthy';
                                            } elseif ($security_score >= 70 && $security_score < 90) {
                                                $score_class = 'status-warning';
                                            } else {
                                                $score_class = 'status-critical';
                                            }
                                            ?>
                                            <a href="<?php echo admin_url('admin.php?page=inspector-security'); ?>" class="container-label <?php echo $score_class; ?>">
                                                App Server: WordPress
                                                <span class="mini-security-score">Security Grade: <?php echo esc_html($security_grade); ?><?php echo $security_score > 0 ? ' (' . esc_html($security_score) . '%)' : ''; ?></span>
                                            </a>
                                            <div class="container-content">
                                            <div class="application-info-grid">
                                                
                                                <a href="<?php echo admin_url('options-general.php'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-site"></span>
                                                        <span class="info-label">Site Title</span>
                                                        <span class="info-value">
                                                            <?php echo esc_html(get_bloginfo('name')); ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <a href="<?php echo admin_url('options-general.php'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-tagcloud"></span>
                                                        <span class="info-label">Site Tagline</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $tagline = get_bloginfo('description');
                                                            if (empty(trim($tagline))): ?>
                                                                <span class="empty-value">Empty</span>
                                                            <?php else: ?>
                                                                <?php echo esc_html($tagline); ?>
                                                            <?php endif; ?>
                                                        </span>
                                                    </div> 
                                                </a>
                                                
                                                <a href="<?php echo admin_url('options-general.php'); ?>" target="_blank" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-links"></span>
                                                        <span class="info-label">Site URL</span>
                                                        <span class="info-value url-text">
                                                            <?php echo esc_html(get_site_url()); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                                
                                                <a href="<?php echo admin_url('options-general.php'); ?>" target="_blank" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-home"></span>
                                                        <span class="info-label">Home URL</span>
                                                        <span class="info-value url-text">
                                                            <?php echo esc_html(get_home_url()); ?>
                                                        </span>
                                                    </div>
                                                </a>
                                                
                                                <a href="<?php echo esc_url(admin_url()); ?>" target="_blank" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-dashboard"></span>
                                                        <span class="info-label">Admin URL</span>
                                                        <span class="info-value url-text">
                                                            <?php echo esc_html(admin_url()); ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <a href="<?php echo admin_url('admin.php?page=inspector-plugins'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-plugins"></span>
                                                        <span class="info-label">Plugins</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $plugin_updates = get_plugin_updates();
                                                            $all_plugins = get_plugins();
                                                            $plugin_count = count($all_plugins);
                                                            $active_plugins = get_option('active_plugins', array());
                                                            $inactive_plugins = $plugin_count - count($active_plugins);
                                                            
                                                            if (!empty($plugin_updates)) {
                                                                echo '<span class="warning-text">' . count($plugin_updates) . ' Updates Available</span>';
                                                            } else {
                                                                echo '<span class="success-text">Up to Date</span>';
                                                            }
                                                            echo ' (' . $plugin_count . ' Total, ';
                                                            if ($inactive_plugins > 0) {
                                                                echo '<span class="error-text">' . $inactive_plugins . ' Inactive</span>';
                                                            } else {
                                                                echo $inactive_plugins . ' Inactive';
                                                            }
                                                            echo ')';
                                                            echo '<br>';
                                                            $plugin_updates_setting = get_site_option('auto_update_plugins', false);
                                                            echo 'Auto Updates: ';
                                                            echo $plugin_updates_setting ? 
                                                                '<span class="success-text">Enabled</span>' : 
                                                                '<span class="warning-text">Disabled</span>';
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <a href="<?php echo admin_url('admin.php?page=inspector-themes'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-appearance"></span>
                                                        <span class="info-label">Themes</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $theme_updates = get_theme_updates();
                                                            $theme_count = count(wp_get_themes());
                                                            $active_theme = wp_get_theme();
                                                            $inactive_themes = $theme_count - 1;
                                                            
                                                            if (!empty($theme_updates)) {
                                                                echo '<span class="warning-text">' . count($theme_updates) . ' Updates Available</span>';
                                                            } else {
                                                                echo '<span class="success-text">Up to Date</span>';
                                                            }
                                                            echo ' (' . $theme_count . ' Total, ';
                                                            if ($inactive_themes > 1) {
                                                                echo '<span class="error-text">' . $inactive_themes . ' Inactive</span>';
                                                            } else {
                                                                echo $inactive_themes . ' Inactive';
                                                            }
                                                            echo ')';
                                                            echo '<br>';
                                                            $theme_updates_setting = get_site_option('auto_update_themes', false);
                                                            echo 'Auto Updates: ';
                                                            echo $theme_updates_setting ? 
                                                                '<span class="success-text">Enabled</span>' : 
                                                                '<span class="warning-text">Disabled</span>';
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-admin-post"></span>
                                                    <span class="info-label">Posts (Published / Draft / Pending)</span>
                                                    <span class="info-value"><?php echo wp_count_posts()->publish; ?> / <?php echo wp_count_posts()->draft; ?> / <?php echo wp_count_posts()->pending; ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-admin-page"></span>
                                                    <span class="info-label">Pages (Published / Draft / Pending)</span>
                                                    <span class="info-value"><?php echo wp_count_posts('page')->publish; ?> / <?php echo wp_count_posts('page')->draft; ?> / <?php echo wp_count_posts('page')->pending; ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-admin-comments"></span>
                                                    <span class="info-label">Comments (Approved / Pending / Spam)</span>
                                                    <span class="info-value">
                                                        <?php 
                                                        $comments = wp_count_comments();
                                                        echo intval($comments->total_comments ?? 0) . ' / ' . 
                                                             intval($comments->pending_comments ?? 0) . ' / ' . 
                                                             intval($comments->spam_comments ?? 0); 
                                                        ?>
                                                    </span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-category"></span>
                                                    <span class="info-label">Categories (Published / Draft / Pending)</span>
                                                    <span class="info-value"><?php echo wp_count_terms('category'); ?> / <?php echo wp_count_terms('category', ['status' => 'draft']); ?> / <?php echo wp_count_terms('category', ['status' => 'pending']); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-tag"></span>
                                                    <span class="info-label">Tags</span>
                                                    <span class="info-value"><?php echo wp_count_terms('post_tag'); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-admin-users"></span>
                                                    <span class="info-label">Users (Total / Admins)</span>
                                                    <span class="info-value"><?php echo count_users()['total_users']; ?> / <?php echo count(get_users(['role' => 'administrator'])); ?></span>
                                                </div>
                                                
                                                <a href="<?php echo admin_url('admin.php?page=inspector-media'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-media"></span>
                                                        <span class="info-label">Media (Count / Total Size)</span>
                                                        <span class="info-value"><?php echo wp_count_posts('attachment')->inherit; ?> / <?php echo size_format(wp_count_posts('attachment')->inherit * 1024 * 1024); ?></span> 
                                                    </div>
                                                </a>

                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-menu"></span>
                                                    <span class="info-label">Menus (Total / Active)</span>
                                                    <span class="info-value"><?php echo count(wp_get_nav_menus()); ?> / <?php echo count(wp_get_nav_menus(['active' => true])); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-layout"></span>
                                                    <span class="info-label">Widgets (Total / Active)</span>
                                                    <span class="info-value"><?php echo count($GLOBALS['wp_widget_factory']->widgets); ?> / <?php echo count(wp_get_sidebars_widgets()); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-portfolio"></span>
                                                    <span class="info-label">Custom Post Types (Total / Active)</span>
                                                    <span class="info-value"><?php echo count(get_post_types(['_builtin' => false])); ?> / <?php echo count(get_post_types(['_builtin' => false, 'public' => true])); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-tag"></span>
                                                    <span class="info-label">Custom Taxonomies (Total / Active)</span>
                                                    <span class="info-value"><?php echo count(get_taxonomies(['_builtin' => false])); ?> / <?php echo count(get_taxonomies(['_builtin' => false, 'public' => true])); ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-networking"></span>
                                                    <span class="info-label">Multisite</span>
                                                    <span class="info-value"><?php echo is_multisite() ? 'Enabled' : 'Disabled'; ?></span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-translation"></span>
                                                    <span class="info-label">Primary Language</span>
                                                    <span class="info-value">
                                                        <?php 
                                                        $locale = get_locale();
                                                        $languages = get_available_languages();
                                                        if (is_array($translations) && isset($translations[$locale])) {
                                                            echo esc_html($translations[$locale]['native_name'] . ' (' . $locale . ')');
                                                        } else {
                                                            echo esc_html($locale);
                                                        }
                                                        ?>
                                                    </span>
                                                </div>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-update"></span>
                                                    <span class="info-label">WordPress Updates</span>
                                                    <span class="info-value">
                                                        <?php 
                                                        wp_update_plugins();
                                                        wp_update_themes();
                                                        
                                                        $core_updates = get_core_updates();
                                                        $plugin_updates = get_plugin_updates();
                                                        $theme_updates = get_theme_updates();
                                                        
                                                        $has_core_update = !empty($core_updates) && $core_updates[0]->response !== 'latest';
                                                        $plugin_count = count($plugin_updates);
                                                        $theme_count = count($theme_updates);
                                                        
                                                        $total_updates = ($has_core_update ? 1 : 0) + $plugin_count + $theme_count;
                                                        
                                                        if ($total_updates > 0) {
                                                            echo '<span class="warning-text">';
                                                            $updates = array();
                                                            if ($has_core_update) $updates[] = 'Core';
                                                            if ($plugin_count > 0) $updates[] = $plugin_count . ' Plugin' . ($plugin_count > 1 ? 's' : '');
                                                            if ($theme_count > 0) $updates[] = $theme_count . ' Theme' . ($theme_count > 1 ? 's' : '');
                                                            echo implode(', ', $updates) . ' Available';
                                                            echo '</span>';
                                                        } else {
                                                            echo '<span class="success-text">Up to Date</span>';
                                                        }
                                                        ?>
                                                    </span>
                                                </div>
                                                
                                                <?php if (function_exists('get_available_languages')): ?>
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-translation"></span>
                                                    <span class="info-label">Other Languages</span>
                                                    <span class="info-value"><?php echo count(get_available_languages()); ?></span>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-clock"></span>
                                                    <span class="info-label">WordPress Time</span>
                                                    <span class="info-value">
                                                        <?php echo current_time('Y-m-d H:i:s (T)'); ?>
                                                    </span>
                                                </div>
                                                
                                                <?php 
                                                $sitemap_url = get_site_url(null, 'sitemap.xml');
                                                $sitemap_exists = @get_headers($sitemap_url);
                                                if ($sitemap_exists && strpos($sitemap_exists[0], '200')): 
                                                ?>
                                                <div class="application-info-item">
                                                    <span class="dashicons dashicons-media-spreadsheet"></span>
                                                    <span class="info-label">Sitemap</span>
                                                    <span class="info-value">
                                                        <a href="<?php echo esc_url($sitemap_url); ?>" target="_blank">View Sitemap</a>
                                                    </span>
                                                </div>
                                                <?php endif; ?>
                                                
                                                <a href="<?php echo admin_url('options-general.php'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-email"></span>
                                                        <span class="info-label">Admin Email</span>
                                                        <span class="info-value"><?php echo esc_html(get_option('admin_email')); ?></span>
                                                    </div>
                                                </a>

                                                <a href="<?php echo admin_url('options-general.php'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-users"></span>
                                                        <span class="info-label">Anyone Can Register</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $users_can_register = get_option('users_can_register');
                                                            if ($users_can_register) {
                                                                echo '<span class="warning-text">True</span>';
                                                            } else {
                                                                echo '<span class="success-text">False</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                 <a href="<?php echo admin_url('options-general.php'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-admin-users"></span>
                                                        <span class="info-label">Default User Role</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $default_role = get_option('default_role');
                                                            if ($default_role === 'administrator') {
                                                                echo '<span class="warning-text">' . esc_html(ucfirst($default_role)) . '</span>';
                                                            } else {
                                                                echo esc_html(ucfirst($default_role));
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-heart"></span>
                                                        <span class="info-label">WordPress Heartbeat</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $heartbeat_status = wp_script_is('heartbeat', 'registered');
                                                            $heartbeat_frequency = get_option('heartbeat_frequency', 60);
                                                            
                                                            if ($heartbeat_status) {
                                                                echo '<span class="success-text">Enabled</span>';
                                                                echo ' (' . esc_html($heartbeat_frequency) . 's)';
                                                            } else {
                                                                echo '<span class="warning-text">Disabled</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                 <a href="<?php echo admin_url('admin.php?page=inspector-cron'); ?>" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-calendar-alt"></span>
                                                        <span class="info-label">Cron Jobs</span>
                                                        <span class="info-value">
                                                        <?php 
                                                        $cron_status = defined('DISABLE_WP_CRON') && DISABLE_WP_CRON;
                                                        $cron_jobs = _get_cron_array();
                                                        $cron_count = 0;
                                                        
                                                        if (is_array($cron_jobs)) {
                                                            foreach ($cron_jobs as $timestamp => $hooks) {
                                                                foreach ($hooks as $hook => $jobs) {
                                                                    // Count each scheduled job for this hook
                                                                    $cron_count += count($jobs);
                                                                }
                                                            }
                                                        }
                                                        
                                                        if ($cron_status) {
                                                            echo '<span class="warning-text">Disabled</span>';
                                                        } else {
                                                            echo '<span class="success-text">Enabled</span>';
                                                        }
                                                        echo ' (' . esc_html($cron_count) . ' Jobs)';
                                                        ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-wordpress"></span>
                                                        <span class="info-label">Version</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            require_once ABSPATH . 'wp-admin/includes/update.php';
                                                            // Show current version
                                                            echo 'Version: ' . get_bloginfo('version');
                                                            echo '<br>';
                                                            // Show core update setting
                                                            $core_updates_setting = get_site_option('auto_update_core_major', 'unset');
                                                            echo 'Updates: ';
                                                            if ($core_updates_setting === 'enabled') {
                                                                echo '<span class="success-text">All Updates</span>';
                                                            } elseif ($core_updates_setting === 'minor') {
                                                                echo '<span class="warning-text">Minor Only</span>';
                                                            } else {
                                                                echo '<span class="error-text">Disabled</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>
                                                
                                                
                                                <?php
                                                    $has_sitemap = false;
                                                    $sitemap_info = '';

                                                    // Check WordPress core sitemap
                                                    if (function_exists('wp_sitemaps_get_server')) {
                                                        $sitemap_url = get_site_url(null, '/wp-sitemap.xml');
                                                        $response = wp_remote_head($sitemap_url);
                                                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                            $has_sitemap = true;
                                                            $sitemap_info = '<span class="success-text">WordPress Core</span>';
                                                        }
                                                    }

                                                    // Check Yoast SEO sitemap
                                                    if (!$has_sitemap && is_plugin_active('wordpress-seo/wp-seo.php')) {
                                                        $sitemap_url = get_site_url(null, '/sitemap_index.xml');
                                                        $response = wp_remote_head($sitemap_url);
                                                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                            $has_sitemap = true;
                                                            $sitemap_info = '<span class="success-text">Yoast SEO</span>';
                                                        }
                                                    }

                                                    // Check Rank Math sitemap
                                                    if (!$has_sitemap && is_plugin_active('seo-by-rank-math/rank-math.php')) {
                                                        $sitemap_url = get_site_url(null, '/sitemap_index.xml');
                                                        $response = wp_remote_head($sitemap_url);
                                                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                            $has_sitemap = true;
                                                            $sitemap_info = '<span class="success-text">Rank Math</span>';
                                                        }
                                                    }

                                                    // Check All in One SEO sitemap
                                                    if (!$has_sitemap && is_plugin_active('all-in-one-seo-pack/all_in_one_seo_pack.php')) {
                                                        $sitemap_url = get_site_url(null, '/sitemap.xml');
                                                        $response = wp_remote_head($sitemap_url);
                                                        if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                            $has_sitemap = true;
                                                            $sitemap_info = '<span class="success-text">All in One SEO</span>';
                                                        }
                                                    }
                                                ?>
                                                
                                                <?php if ($has_sitemap): ?>
                                                    <a href="<?php echo esc_url($sitemap_url); ?>" target="_blank" style="text-decoration: none; color: inherit;">
                                                <?php endif; ?>
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-networking"></span>
                                                        <span class="info-label">XML Sitemap</span>
                                                        <span class="info-value">
                                                            <?php echo $has_sitemap ? $sitemap_info : '<span class="warning-text">Not Found</span>'; ?>
                                                        </span>
                                                    </div>
                                                <?php if ($has_sitemap): ?>
                                                    </a>
                                                <?php endif; ?>

                                                <!-- Add this inside the application-container's container-content div -->
                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-shield"></span>
                                                        <span class="info-label">Security Keys Age</span>
                                                        <span class="info-value">
                                                            <?php
                                                            // Get security keys from wp-config.php
                                                            $security_keys = array(
                                                                'AUTH_KEY',
                                                                'SECURE_AUTH_KEY',
                                                                'LOGGED_IN_KEY',
                                                                'NONCE_KEY',
                                                                'AUTH_SALT',
                                                                'SECURE_AUTH_SALT',
                                                                'LOGGED_IN_SALT',
                                                                'NONCE_SALT'
                                                            );
                                                            
                                                            $keys_defined = 0;
                                                            $keys_age = null;
                                                            
                                                            foreach ($security_keys as $key) {
                                                                if (defined($key)) {
                                                                    $keys_defined++;
                                                                }
                                                            }
                                                            
                                                            // Get wp-config.php modification time
                                                            $wp_config_path = ABSPATH . 'wp-config.php';
                                                            if (file_exists($wp_config_path)) {
                                                                $mtime = filemtime($wp_config_path);
                                                                $now = time();
                                                                $days_old = floor(($now - $mtime) / (60 * 60 * 24));
                                                                
                                                                if ($keys_defined > 0) {
                                                                    if ($days_old > 365) {
                                                                        echo '<span class="warning-text">' . floor($days_old/365) . ' years old</span>';
                                                                        echo '<span class="warning-text">Recommended to update yearly</span>';
                                                                    } else if ($days_old > 180) {
                                                                        echo '<span class="warning-text">' . $days_old . ' days old</span>';
                                                                        echo '<span class="warning-text">Consider updating soon</span>';
                                                                    } else {
                                                                        echo '<span>' . $days_old . ' days old</span>';
                                                                    }
                                                                    
                                                                    if ($keys_defined < 8) {
                                                                        echo '<span class="warning-text">Only ' . $keys_defined . '/8 keys defined</span>';
                                                                    }
                                                                } else {
                                                                    echo '<span class="warning-text">No security keys defined</span>';
                                                                }
                                                            } else {
                                                                echo '<span class="empty-value">Unable to determine</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <!-- Add this inside the application-container's container-content div -->
                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-media-default"></span>
                                                        <span class="info-label">Allowed File Types</span>
                                                        <span class="info-value">
                                                            <?php 
                                                            $allowed_types = get_allowed_mime_types();
                                                            $total_types = count($allowed_types);
                                                            $dangerous_types = array_intersect(
                                                                array_map('strtolower', $allowed_types),
                                                                array('application/x-php', 'text/x-php', 'text/php', 'application/php', 'application/x-httpd-php')
                                                            );
                                                            
                                                            if (!empty($dangerous_types)) {
                                                                echo '<span class="warning-text">' . $total_types . ' Types</span>';
                                                                echo '<span class="warning-text">PHP uploads enabled!</span>';
                                                            } else {
                                                                echo '<span>' . $total_types . ' Types</span>';
                                                                
                                                                // Group by main type
                                                                $type_groups = array();
                                                                foreach ($allowed_types as $ext => $mime) {
                                                                    $main_type = explode('/', $mime)[0];
                                                                    if (!isset($type_groups[$main_type])) {
                                                                        $type_groups[$main_type] = 0;
                                                                    }
                                                                    $type_groups[$main_type]++;
                                                                }
                                                                
                                                                // Show breakdown
                                                                foreach ($type_groups as $type => $count) {
                                                                    echo '<span class="type-count">' . ucfirst($type) . ': ' . $count . '</span>';
                                                                }
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                                <!-- Add this inside the application-container's container-content div -->
                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="application-info-item">
                                                        <span class="dashicons dashicons-smiley"></span>
                                                        <span class="info-label">WordPress Emoji</span>
                                                        <span class="info-value">
                                                            <?php
                                                            $emoji_status = array();
                                                            
                                                            // Check if emoji script is registered
                                                            if (wp_script_is('wp-emoji', 'registered')) {
                                                                $emoji_status[] = 'Script Registered';
                                                            }
                                                            
                                                            // Check if emoji is disabled via filters
                                                            if (has_filter('emoji_svg_url', '__return_false') || 
                                                                has_filter('wp_emoji', '__return_false') ||
                                                                has_action('wp_head', 'print_emoji_detection_script') === false) {
                                                                $emoji_status[] = 'Disabled via Filter';
                                                            }
                                                            
                                                            // Check if DNS prefetching is enabled for emoji
                                                            $has_dns_prefetch = false;
                                                            ob_start();
                                                            wp_resource_hints();
                                                            $resource_hints = ob_get_clean();
                                                            if (strpos($resource_hints, 's.w.org') !== false) {
                                                                $emoji_status[] = 'DNS Prefetch Active';
                                                            }
                                                            
                                                            if (empty($emoji_status)) {
                                                                echo '<span class="success-text">Enabled</span>';
                                                            } else {
                                                                if (in_array('Disabled via Filter', $emoji_status)) {
                                                                    echo '<span class="warning-text">Disabled</span>';
                                                                } else {
                                                                    echo '<span class="success-text">Enabled</span>';
                                                                }
                                                                echo '<div class="details-text">' . implode(', ', $emoji_status) . '</div>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                            </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <!-- Second Row - PHP and Database -->
                                    <div class="server-row">
                                    <!-- PHP Container -->
                                    <div class="php-container">
                                            <button class="collapse-button" title="Toggle container">
                                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                                            </button>
                                            <div class="container-label">PHP Server</div>
                                            <div class="container-content">
                                                <div class="php-info-grid">
                                                    
                                                    <div class="php-info-item">
                                                        <span class="dashicons dashicons-info"></span>
                                                        <span class="info-label">Version</span>
                                                        <span class="info-value <?php echo preg_match('/^[567]/', PHP_VERSION) ? 'eol-warning' : ''; ?>">
                                                            v<?php echo phpversion(); ?> (<?php echo PHP_INT_SIZE * 8; ?>-bit)
                                                        </span>
                                                    </div>

                                                    <a href="#" class="info-modal-button" data-modal="php-extensions-modal" style="text-decoration: none; color: inherit;">
                                                        <div class="php-info-item">
                                                            <span class="dashicons dashicons-admin-plugins"></span>
                                                            <span class="info-label">PHP Extensions</span>
                                                            <span class="info-value">
                                                                <?php 
                                                                $loaded_extensions = get_loaded_extensions();
                                                                if (!empty($loaded_extensions)) {
                                                                    echo count($loaded_extensions) . ' Extensions Enabled';
                                                                } else {
                                                                    echo '<span class="warning-text">No Extensions Enabled</span>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>
                                                    
                                                    <div class="php-info-item">
                                                        <span class="dashicons dashicons-admin-settings"></span>
                                                        <span class="info-label">SAPI</span>
                                                        <span class="info-value"><?php echo php_sapi_name(); ?></span>
                                                    </div>
                                                    
                                                    <div class="php-info-item">
                                                        <span class="dashicons dashicons-shield<?php echo extension_loaded('suhosin') ? '' : '-alt'; ?>"></span>
                                                        <span class="info-label">SUHOSIN</span>
                                                        <span class="info-value"><?php echo extension_loaded('suhosin') ? 'Enabled' : 'Disabled'; ?></span>
                                                    </div>
                                                    
                                                    <div class="php-info-item">
                                                        <span class="dashicons dashicons-format-image"></span>
                                                        <span class="info-label">Imagick</span>
                                                        <span class="info-value"><?php echo extension_loaded('imagick') ? 'Enabled' : 'Disabled'; ?></span>
                                                    </div>
                                                    
                                                    <div class="php-info-item">
                                                        <span class="dashicons dashicons-controls-repeat"></span>
                                                        <span class="info-label">Thread Safe</span>
                                                        <span class="info-value"><?php echo PHP_ZTS ? 'Yes' : 'No'; ?></span>
                                                    </div>
                                                    
                                                    <a href="#" class="info-modal-button" data-modal="system-limits-modal" style="text-decoration: none; color: inherit;">
                                                        <div class="php-info-item">    
                                                            <span class="dashicons dashicons-admin-settings"></span>
                                                            <span class="info-label">Limits</span>
                                                            <span class="info-value">
                                                                <?php echo 'Memory Limit: ' . esc_html(ini_get('memory_limit')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                                <br>
                                                                <?php echo 'Max Execution Time: ' . esc_html(ini_get('max_execution_time')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                                <br>
                                                                <?php echo 'Max Input Time: ' . esc_html(ini_get('max_input_time')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                                <br>
                                                                <?php echo 'Post Max Size: ' . esc_html(ini_get('post_max_size')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                                <br>
                                                                <?php echo 'Upload Max Filesize: ' . esc_html(ini_get('upload_max_filesize')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                                <br>
                                                                <?php echo 'Max Input Vars: ' . esc_html(ini_get('max_input_vars')); ?>
                                                                <?php if (WordPress_Inspector_System_Utils::is_memory_limit_low(ini_get('memory_limit'))): ?>
                                                                    <span class="warning-text">Consider increasing</span>
                                                                <?php endif; ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                    <!-- Replace the GZIP compression check code -->
                                                    <a href="#" class="info-modal-button" data-modal="gzip-info-modal" style="text-decoration: none; color: inherit;">
                                                        <div class="php-info-item">
                                                            <span class="dashicons dashicons-performance"></span>
                                                            <span class="info-label">GZIP Compression</span>
                                                            <span class="info-value">
                                                                <?php
                                                                $gzip_enabled = false;
                                                                $gzip_status = '';
                                                                
                                                                // Check zlib.output_compression
                                                                if (ini_get('zlib.output_compression')) {
                                                                    $gzip_enabled = true;
                                                                    $gzip_status = 'PHP zlib';
                                                                }
                                                                // Check if mod_deflate is loaded (Apache)
                                                                else if (function_exists('apache_get_modules') && in_array('mod_deflate', apache_get_modules())) {
                                                                    $gzip_enabled = true;
                                                                    $gzip_status = 'Apache mod_deflate';
                                                                }
                                                                // Check if output_handler is set to gzip
                                                                else if (ini_get('output_handler') === 'ob_gzhandler') {
                                                                    $gzip_enabled = true;
                                                                    $gzip_status = 'ob_gzhandler';
                                                                }
                                                                
                                                                if ($gzip_enabled):
                                                                    echo '<span class="status-good">' . esc_html($gzip_status) . '</span>';
                                                                else:
                                                                    echo '<span class="status-warning">Not Enabled</span>';
                                                                    echo '<div class="warning-text">Consider enabling GZIP compression</div>';
                                                                endif;
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                </div>
                                            </div>
                                    </div>

                                    <!-- MySQL Instance Container -->
                                    <div class="database-container">
                                            <button class="collapse-button" title="Toggle container">
                                                <span class="dashicons dashicons-arrow-up-alt2"></span>
                                            </button>
                                        <div class="container-label">Database Server: MySQL</div>
                                            <div class="container-content">
                                            <div class="database-info-grid">
                                                

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-info"></span>
                                                    <span class="info-label">Versions</span>
                                                    <span class="info-value">
                                                        Server: <?php echo $wpdb->get_var("SELECT VERSION()"); ?><br>
                                                        Client: <?php echo esc_html(mysqli_get_client_info()); ?>
                                                    </span>
                                                </div>
                                                
                                                <a href="#" class="info-modal-button" data-modal="system-limits-modal" style="text-decoration: none; color: inherit;">
                                                    <div class="database-info-item">
                                                        <span class="dashicons dashicons-admin-settings"></span>
                                                        <span class="info-label">Limits</span>
                                                        <span class="info-value">
                                                        <?php 
                                                        $max_connections = $wpdb->get_var("SHOW VARIABLES LIKE 'max_connections'", 1);
                                                        $max_packet = $wpdb->get_var("SHOW VARIABLES LIKE 'max_allowed_packet'", 1);
                                                        echo 'Max Connections: ' . esc_html($max_connections) . '<br>';
                                                        echo 'Max Packet Size: ' . size_format($max_packet);
                                                        ?>
                                                        </span>
                                                    </div>
                                                </a>
                                            
                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-admin-users"></span>
                                                    <span class="info-label">Database Credentials</span>
                                                    <span class="info-value">
                                                        User: <?php echo esc_html(DB_USER); ?><br>
                                                        <span class="info-value password-field">
                                                            Password:
                                                        <span class="password-dots">••••••••</span>
                                                        <button type="button" class="toggle-password" title="Toggle password visibility">
                                                            <span class="dashicons dashicons-visibility"></span>
                                                        </button>
                                                            <span class="password-text" style="display: none;"><?php echo esc_html(DB_PASSWORD); ?></span>
                                                        </span>
                                                    </span>
                                                </div>
                                            
                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-tag"></span>
                                                    <span class="info-label">Prefixes</span>
                                                    <span class="info-value">
                                                        Database: 
                                                        <span <?php if ($wpdb->prefix === 'wp_') echo 'class="error-text" title="Using default database prefix. Consider changing for security."'; ?>>
                                                            <?php echo esc_html($wpdb->prefix); ?>
                                                        </span>
                                                        <br>
                                                        Table: 
                                                        <span <?php if ($wpdb->prefix === 'wp_') echo 'class="error-text" title="Using default table prefix. Consider changing for security."'; ?>>
                                                            <?php echo esc_html($wpdb->prefix); ?>
                                                        </span>
                                                    </span>
                                                </div> 

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-admin-site"></span>
                                                    <span class="info-label">Database Host</span>
                                                    <span class="info-value"><?php echo esc_html(DB_HOST); ?></span>
                                                </div>

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-database"></span>
                                                    <span class="info-label">Database Name</span>
                                                    <span class="info-value"><?php echo esc_html(DB_NAME); ?></span>
                                                </div>

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-performance"></span>
                                                    <span class="info-label">Database Size</span>
                                                    <span class="info-value"><?php echo size_format($total_size); ?></span>
                                                </div>

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-chart-bar"></span>
                                                    <span class="info-label">Total Tables</span>
                                                    <span class="info-value"><?php echo count($tables); ?></span>
                                                </div>

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-editor-table"></span>
                                                    <span class="info-label">Total Rows</span>
                                                    <span class="info-value"><?php echo number_format($total_rows); ?></span>
                                                </div>

                                                <div class="database-info-item">
                                                    <span class="dashicons dashicons-warning"></span>
                                                    <span class="info-label">Overhead</span>
                                                    <span class="info-value"><?php echo $total_overhead > 0 ? '<span class="warning">' . size_format($total_overhead) . '</span>' : '0 B'; ?></span>
                                            </div>  

                                                <!-- Add this inside the database container's container-content div -->
                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                    <div class="database-info-item">
                                                        <span class="dashicons dashicons-translation"></span>
                                                        <span class="info-label">Character Set & Collation</span>
                                                        <span class="info-value">
                                                            <?php
                                                            $charset_info = $wpdb->get_row("SHOW VARIABLES LIKE 'character_set_database'");
                                                            $collation_info = $wpdb->get_row("SHOW VARIABLES LIKE 'collation_database'");
                                                            
                                                            if ($charset_info && $collation_info) {
                                                                echo '<span>Charset: ' . esc_html($charset_info->Value) . '</span>';
                                                                echo '<span>Collation: ' . esc_html($collation_info->Value) . '</span>';
                                                                
                                                                // Check if using recommended settings
                                                                $recommended_charset = 'utf8mb4';
                                                                $recommended_collation = 'utf8mb4_unicode_ci';
                                                                
                                                                if ($charset_info->Value !== $recommended_charset) {
                                                                    echo '<span class="warning-text">Recommended: ' . esc_html($recommended_charset) . '</span>';
                                                                }
                                                                if ($collation_info->Value !== $recommended_collation) {
                                                                    echo '<span class="warning-text">Recommended: ' . esc_html($recommended_collation) . '</span>';
                                                                }
                                                            } else {
                                                                echo '<span class="empty-value">Not Available</span>';
                                                            }
                                                            ?>
                                                        </span>
                                                    </div>
                                                </a>

                                            </div>
                                            </div>
                                        </div>
                                            </div>

                                <!-- Third Row - Web Server -->
                                <div class="server-row">
                                       <!-- Web Server Container -->
                                    <div class="webserver-container">
                                        
                                        <button class="collapse-button" title="Toggle container">
                                            <span class="dashicons dashicons-arrow-up-alt2"></span>
                                        </button>
                                        
                                        <?php 
                                            $ssl_info = WordPress_Inspector_System_Utils::get_ssl_info();
                                            $is_ssl_valid = $ssl_info && $ssl_info['is_valid'];
                                        ?>

                                        <div class="container-label <?php echo $is_ssl_valid ? 'status-healthy' : 'status-critical'; ?>">
                                            <div class="label-content">
                                                <div>Web Server: <?php echo esc_html($_SERVER['SERVER_SOFTWARE']); ?></div>
                                                <div>SSL Cert: <?php echo $is_ssl_valid ? 'Valid' : 'Not Valid'; ?></div>
                                            </div>
                                        </div>
                                        <?php if (!$is_ssl_valid): ?>
                                            <div class="ssl-warning-notice">
                                                <span class="dashicons dashicons-warning"></span>
                                                SSL certificate is invalid or expired. This may affect your website's security and search engine ranking.
                                            </div>
                                        <?php endif; ?>
                                            
                                            <div class="container-content">
                                                
                                                <div class="webserver-info-grid">
                                                    
                                                <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-admin-site-alt3"></span>
                                                            <span class="info-label">Protocol</span>
                                                            <span class="info-value"><?php echo esc_html($_SERVER['SERVER_PROTOCOL']); ?></span>
                                                        </div>
                                                    </a>

                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-update"></span>
                                                            <span class="info-label">Loopback Requests</span>
                                                            <span class="info-value">
                                                                <?php if (function_exists('wp_remote_get')): ?>
                                                                    <?php $response = wp_remote_get(home_url()); ?>
                                                                    <?php if (!is_wp_error($response)): ?>
                                                                        <span class="success-text">Working</span>
                                                                    <?php else: ?>
                                                                        <span class="status-error">Not Working</span>
                                                                    <?php endif; ?>
                                                                <?php else: ?>
                                                                    <span class="status-error">Unable To Determine</span>
                                                                <?php endif; ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                  
                                                    <?php
                                                    $registrar = WordPress_Inspector_System_Utils::get_domain_registrar();
                                                    $domain = parse_url(get_site_url(), PHP_URL_HOST);
                                                    ?>

                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-networking"></span>
                                                            <span class="info-label">Port</span>
                                                            <span class="info-value"><?php echo esc_html($_SERVER['SERVER_PORT']); ?></span>
                                                        </div>
                                                    </a>

                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-lock"></span>
                                                            <span class="info-label">SSL Certificate</span>
                                                            <span class="info-value">
                                                                <?php 
                                                                $ssl_info = WordPress_Inspector_System_Utils::get_ssl_info();
                                                                if ($ssl_info):
                                                                    if ($ssl_info['days_remaining'] < 30): ?>
                                                                        <span class="status-indicator status-warning"></span>
                                                                    <?php endif; ?>
                                                                    <span>Issued To: <?php echo esc_html($ssl_info['issued_to']); ?></span>
                                                                    <span>Issued By: <?php echo esc_html($ssl_info['issued_by']); ?></span>
                                                                    <span>Valid From: <?php echo esc_html($ssl_info['valid_from']); ?></span>
                                                                    <span>Valid To: <?php echo esc_html($ssl_info['valid_to']); ?></span>
                                                                    <span class="<?php echo $ssl_info['days_remaining'] < 30 ? 'warning-text' : ''; ?>">
                                                                        <?php echo esc_html($ssl_info['days_remaining']); ?> days remaining
                                                                    </span>
                                                                <?php else: ?>
                                                                    <span class="warning-text">Not Available</span>
                                                                <?php endif; ?>
                                                            </span>
                                                        </div>
                                                    </a>
                                                
                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-clock"></span>
                                                            <span class="info-label">Server Time</span>
                                                            <span class="info-value"><?php echo esc_html(date('Y-m-d H:i:s T')); ?></span>
                                                        </div>
                                                    </a>
                                                    
                                                    <a href="#" class="info-modal-button" data-modal="apache-modules-modal" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">  
                                                            <span class="dashicons dashicons-admin-plugins"></span>
                                                            <span class="info-label">Apache Modules</span>
                                                            <span class="info-value">
                                                                <?php 
                                                                if (function_exists('apache_get_modules')) {
                                                                    $modules = apache_get_modules();
                                                                    if (!empty($modules)) {
                                                                        echo '<span>' . count($modules) . ' Modules Enabled</span>';
                                                                    } else {
                                                                        echo '<span class="warning-text">No Modules Enabled</span>';
                                                                    }
                                                                } else {
                                                                    echo '<span class="empty-value">Not Available</span>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-calendar"></span>
                                                            <span class="info-label">Domain Registration</span>
                                                            <span class="info-value">
                                                                <?php 
                                                                $domain_info = WordPress_Inspector_System_Utils::get_domain_info();
                                                                if ($domain_info && !empty($domain_info['registration_date'])) {
                                                                    $reg_date = new DateTime($domain_info['registration_date']);
                                                                    echo esc_html($reg_date->format('M j, Y'));
                                                                } else {
                                                                    echo '<span class="empty-value">Not Available</span>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                    <a href="javascript:void(0)" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-backup"></span>
                                                            <span class="info-label">Domain Expiration</span>
                                                            <span class="info-value">
                                                                <?php 
                                                                if ($domain_info && !empty($domain_info['expiration_date'])) {
                                                                    $exp_date = new DateTime($domain_info['expiration_date']);
                                                                    $now = new DateTime();
                                                                    $days_remaining = $now->diff($exp_date)->days;
                                                                    
                                                                    if ($days_remaining < 30) {
                                                                        echo '<span class="status-indicator status-warning"></span>';
                                                                    }
                                                                    echo '<span class="' . ($days_remaining < 30 ? 'warning-text' : '') . '">';
                                                                    echo esc_html($exp_date->format('M j, Y'));
                                                                    echo ' (' . $days_remaining . ' days)';
                                                                    echo '</span>';
                                                                } else {
                                                                    echo '<span class="empty-value">Not Available</span>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                    <a href="#" class="info-modal-button" data-modal="cache-info-modal" style="text-decoration: none; color: inherit;">
                                                        <div class="webserver-info-item">
                                                            <span class="dashicons dashicons-database"></span>
                                                            <span class="info-label">Cache Status</span>
                                                            <span class="info-value">
                                                                <?php
                                                                // Check browser caching
                                                                $browser_cache_enabled = false;
                                                                if (function_exists('apache_get_modules') && in_array('mod_expires', apache_get_modules())) {
                                                                    $browser_cache_enabled = true;
                                                                }
                                                                
                                                                // Check object caching
                                                                $object_cache_enabled = wp_using_ext_object_cache();
                                                                
                                                                if ($browser_cache_enabled && $object_cache_enabled) {
                                                                    echo '<span class="status-good">All Caches Active</span>';
                                                                } elseif (!$browser_cache_enabled && !$object_cache_enabled) {
                                                                    echo '<span class="status-warning">No Caches Active</span>';
                                                                    echo '<div class="warning-text">Consider enabling caching</div>';
                                                                } else {
                                                                    echo '<span class="status-warning">Partially Active</span>';
                                                                    echo '<div class="details-text">';
                                                                    echo 'Browser Cache: ' . ($browser_cache_enabled ? '<span class="success-text">Enabled</span>' : '<span class="warning-text">Disabled</span>') . '<br>';
                                                                    echo 'Object Cache: ' . ($object_cache_enabled ? '<span class="success-text">Enabled</span>' : '<span class="warning-text">Disabled</span>');
                                                                    echo '</div>';
                                                                }
                                                                ?>
                                                            </span>
                                                        </div>
                                                    </a>

                                                </div>

                                            </div>

                                        </div>

                                    </div>

                                </div>

                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
</div>

<div id="permissions-help-modal" style="display:none;">
    <div class="permissions-help-content">
        <h2>How to Fix Permissions for Slow Query Log</h2>
        <div class="steps-container">
            <p>Follow these steps to enable slow query logging:</p>
            <ol>
                <li>Connect to your server via SSH or FTP</li>
                <li>Navigate to your WordPress content directory:<br>
                    <code><?php echo esc_html(WP_CONTENT_DIR); ?></code>
                </li>
                <li>Set the correct permissions using these commands:
                    <pre>touch mysql-slow.log
chmod 666 mysql-slow.log</pre>
                </li>
                <li>If using SSH, ensure MySQL has access:
                    <pre>chown mysql:mysql mysql-slow.log</pre>
                </li>
                <li>Alternative method through FTP:
                    <ul>
                        <li>Create an empty file named 'mysql-slow.log'</li>
                        <li>Set file permissions to 666 (rw-rw-rw-)</li>
                    </ul>
                </li>
            </ol>
            <div class="note">
                <strong>Note:</strong> If these steps don't work, you may need to:
                <ul>
                    <li>Contact your hosting provider for assistance</li>
                    <li>Ensure your hosting plan allows changing MySQL global variables</li>
                    <li>Request the hosting provider to enable slow query logging</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="raw-data-info-modal" class="inspector-modal">
    <div class="inspector-modal-content">
        <div class="inspector-modal-header">
            <h2>Platform Information</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="accordion">
                <!-- Website Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-admin-site"></span>
                        Website
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">Website URL</span>
                                <span class="info-value"><a href="<?php echo esc_url(get_site_url()); ?>" target="_blank"><?php echo esc_url(get_site_url()); ?></a></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Status</span>
                                <span class="info-value"><?php echo $is_online ? '<span class="status-online">Online</span>' : '<span class="status-offline">Offline</span>'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Hosting Provider Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-cloud"></span>
                        Hosting Provider
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">Provider</span>
                                <span class="info-value"><?php echo esc_html($provider); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Server Name</span>
                                <span class="info-value"><?php echo esc_html(php_uname('n')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Server IP</span>
                                <span class="info-value"><?php echo esc_html($_SERVER['SERVER_ADDR'] ?? 'N/A'); ?></span>
                            </div>

                            <div class="info-item">
                                <span class="info-label">Server OS</span>
                                <span class="info-value"><?php echo esc_html(php_uname('s') . ' ' . php_uname('r')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">CPU Model</span>
                                <span class="info-value">
                                    <span class="dashicons dashicons-admin-network"></span>
                                    <?php echo !empty($cpu_info['model']) ? esc_html($cpu_info['model']) : '<span class="restricted-text">Restricted By Hosting Provider</span>'; ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total CPU Cores</span>
                                <span class="info-value"><?php echo !empty($cpu_info['cores']) ? esc_html($cpu_info['cores']) : '<span class="restricted-text">Restricted By Hosting Provider</span>'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Server Ram Usage</span>
                                <span class="info-value"><?php echo esc_html(size_format($memory_used) . ' of ' . size_format($memory_total)); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Server Storage Usage</span>
                                <span class="info-value"><?php echo esc_html(WordPress_Inspector_Utils::format_size_dynamic($storage['used']) . ' of ' . WordPress_Inspector_Utils::format_size_dynamic($storage['total'])); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Hosting Instance Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-desktop"></span>
                        Your Hosting Instance
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                        <div class="info-item">
                                <span class="info-label">Document Root</span>
                                <span class="info-value"><?php echo esc_html(WordPress_Inspector_Utils::get_document_root()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Dedicated Cores</span>
                                <span class="info-value"><?php echo $cpu_info['allocated_cores'] > 0 ? esc_html(number_format($cpu_info['allocated_cores'], 1)) : '<span class="restricted-text">Restricted By Hosting Provider</span>'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">CPU Load</span>
                                <span class="info-value"><?php echo !empty($cpu_info['load']) ? esc_html(implode(', ', array_map(function($load) { return number_format($load, 2); }, $cpu_info['load']))) : 'N/A'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Web Server Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-networking"></span>
                        Web Server
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">Server Software</span>
                                <span class="info-value"><?php echo esc_html($_SERVER['SERVER_SOFTWARE']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Protocol</span>
                                <span class="info-value"><?php echo esc_html($_SERVER['SERVER_PROTOCOL']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Port</span>
                                <span class="info-value"><?php echo esc_html($_SERVER['SERVER_PORT']); ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- PHP Server Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-editor-code"></span>
                        PHP Server
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">PHP Version</span>
                                <span class="info-value"><?php echo PHP_VERSION; ?> (<?php echo PHP_INT_SIZE * 8; ?>-bit)</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Memory Limit</span>
                                <span class="info-value"><?php echo ini_get('memory_limit'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Max Execution Time</span>
                                <span class="info-value"><?php echo ini_get('max_execution_time'); ?>s</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Max Input Time</span>
                                <span class="info-value"><?php echo ini_get('max_input_time'); ?> seconds</span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Max Input Vars</span>
                                <span class="info-value"><?php echo ini_get('max_input_vars'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Upload Max Size</span>
                                <span class="info-value"><?php echo ini_get('upload_max_filesize'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Post Max Size</span>
                                <span class="info-value"><?php echo ini_get('post_max_size'); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">PHP SAPI</span>
                                <span class="info-value"><?php echo php_sapi_name(); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">SUHOSIN</span>
                                <span class="info-value"><?php echo extension_loaded('suhosin') ? 'Enabled' : 'Disabled'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Imagick</span>
                                <span class="info-value"><?php echo extension_loaded('imagick') ? 'Enabled' : 'Disabled'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Thread Safe</span>
                                <span class="info-value"><?php echo PHP_ZTS ? 'Yes' : 'No'; ?></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Database Server Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-database"></span>
                        Database Server
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">MySQL Server Version</span>
                                <span class="info-value"><?php echo $wpdb->get_var("SELECT VERSION()"); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">MySQL Client Version</span>
                                <span class="info-value"><?php echo esc_html(mysqli_get_client_info()); ?></span>    
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Username</span>
                                <span class="info-value"><?php echo esc_html(DB_USER); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Password</span>
                                <span class="info-value password-field">
                                    <span class="password-dots">••••••••</span>
                                    <span class="password-text" style="display:none"><?php echo esc_html(DB_PASSWORD); ?></span>
                                    <button type="button" class="toggle-password">
                                        <span class="dashicons dashicons-visibility"></span>
                                    </button>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Prefix</span>
                                <span class="info-value">
                                    <span class="db-prefix <?php echo $wpdb->prefix === 'wp_' ? 'warning' : ''; ?>" 
                                          <?php if ($wpdb->prefix === 'wp_') echo 'title="Using default prefix. Consider changing for security."'; ?>>
                                        <?php echo esc_html($wpdb->prefix); ?>
                                    </span>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Host</span>
                                <span class="info-value"><?php echo esc_html(DB_HOST); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Name</span>
                                <span class="info-value"><?php echo esc_html(DB_NAME); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Database Size</span>
                                <span class="info-value"><?php echo esc_html($db_size['formatted']); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Table Prefix</span>
                                <span class="info-value"><?php echo esc_html($wpdb->prefix); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Tables</span>
                                <span class="info-value"><?php echo count($tables); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Records</span>
                                <span class="info-value"><?php echo number_format($total_rows); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Character Set</span>
                                <span class="info-value"><?php echo esc_html(DB_CHARSET); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Collation</span>
                                <span class="info-value"><?php echo esc_html(DB_COLLATE ? DB_COLLATE : $wpdb->get_var("SELECT @@collation_database")); ?></span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- Wordpress Server Section -->
                <div class="accordion-item">
                    <button class="accordion-header">
                        <span class="dashicons dashicons-wordpress"></span>
                        Wordpress
                        <span class="dashicons dashicons-arrow-down-alt2"></span>
                    </button>
                    <div class="accordion-content">
                        <div class="info-list">
                            <div class="info-item">
                                <span class="info-label">Site Title</span>
                                <span class="info-value"><?php echo esc_html(get_bloginfo('name')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Site Tagline</span>
                                <span class="info-value"><?php echo esc_html(get_bloginfo('description')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Site URL</span>
                                <span class="info-value">
                                    <a href="<?php echo esc_url(get_site_url()); ?>" target="_blank">
                                        <?php echo esc_html(get_site_url()); ?>
                                    </a>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Home URL</span>
                                <span class="info-value">
                                    <a href="<?php echo esc_url(get_home_url()); ?>" target="_blank">
                                        <?php echo esc_html(get_home_url()); ?>
                                    </a>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Admin URL</span>
                                <span class="info-value">
                                    <a href="<?php echo esc_url(admin_url()); ?>" target="_blank">
                                        <?php echo esc_html(admin_url()); ?>
                                    </a>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Plugins</span>
                                <span class="info-value"><?php echo count(get_plugins()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Themes</span>
                                <span class="info-value"><?php echo count(wp_get_themes()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Posts</span>
                                <span class="info-value"><?php echo count(get_posts()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Pages</span>
                                <span class="info-value"><?php echo count(get_pages()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Comments</span>
                                <span class="info-value"><?php echo count(get_comments()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Categories</span>
                                <span class="info-value"><?php echo count(get_categories()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Tags</span>
                                <span class="info-value"><?php echo count(get_tags()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Users</span>
                                <span class="info-value"><?php echo count(get_users()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Media</span>
                                <span class="info-value"><?php echo count(get_posts(array('post_type' => 'attachment'))); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Menus</span>
                                <span class="info-value"><?php echo count(wp_get_nav_menus()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Widgets</span>
                                <span class="info-value"><?php echo count(get_option('sidebars_widgets')); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Custom Post Types</span>
                                <span class="info-value"><?php echo count(get_post_types(array('_builtin' => false))); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Total Custom Taxonomies</span>
                                <span class="info-value"><?php echo count(get_taxonomies(array('_builtin' => false))); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Multisite Enabled?</span>
                                <span class="info-value"><?php echo is_multisite() ? 'Enabled' : 'Disabled'; ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Primary Language</span>
                                <span class="info-value"><?php echo esc_html(get_locale()); ?></span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Other Languages</span>
                                <span class="info-value">
                                    <?php 
                                    $languages = get_available_languages();
                                    if (!empty($languages)) {
                                        echo esc_html(implode(', ', $languages));
                                    } else {
                                        echo '<span class="text-muted">No additional languages installed</span>';
                                    }
                                    ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Wordpress Local Time</span>
                                <span class="info-value">
                                    <?php 
                                    $timezone = wp_timezone();
                                    $datetime = new DateTime("now", $timezone);
                                    echo esc_html($datetime->format('Y-m-d H:i:s (T)')); 
                                    ?>
                                </span>
                            </div>
                            <div class="info-item">
                                <span class="info-label">Sitemap</span>
                                <span class="info-value">
                                    <?php
                                        $has_sitemap = false;
                                        $sitemap_info = '';

                                        // Check WordPress core sitemap
                                        if (function_exists('wp_sitemaps_get_server')) {
                                            $sitemap_url = get_site_url(null, '/wp-sitemap.xml');
                                            $response = wp_remote_head($sitemap_url);
                                            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                $has_sitemap = true;
                                                $sitemap_info = '<span class="success-text">WordPress Core</span> <a href="' . esc_url($sitemap_url) . '" target="_blank" style="text-decoration: none; border:none;"><span class="dashicons dashicons-external" style="font-size: 16px; width: 16px; height: 16px;"></span></a>';
                                            }
                                        }

                                        // Check Yoast SEO sitemap
                                        if (!$has_sitemap && is_plugin_active('wordpress-seo/wp-seo.php')) {
                                            $sitemap_url = get_site_url(null, '/sitemap_index.xml');
                                            $response = wp_remote_head($sitemap_url);
                                            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                $has_sitemap = true;
                                                $sitemap_info = '<span class="success-text">Yoast SEO</span> <a href="' . esc_url($sitemap_url) . '" target="_blank" style="text-decoration: none;"><span class="dashicons dashicons-external" style="font-size: 16px; width: 16px; height: 16px;"></span></a>';
                                            }
                                        }

                                        // Check Rank Math sitemap
                                        if (!$has_sitemap && is_plugin_active('seo-by-rank-math/rank-math.php')) {
                                            $sitemap_url = get_site_url(null, '/sitemap_index.xml');
                                            $response = wp_remote_head($sitemap_url);
                                            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                $has_sitemap = true;
                                                $sitemap_info = '<span class="success-text">Rank Math</span> <a href="' . esc_url($sitemap_url) . '" target="_blank" style="text-decoration: none;"><span class="dashicons dashicons-external" style="font-size: 16px; width: 16px; height: 16px;"></span></a>';
                                            }
                                        }

                                        // Check All in One SEO sitemap
                                        if (!$has_sitemap && is_plugin_active('all-in-one-seo-pack/all_in_one_seo_pack.php')) {
                                            $sitemap_url = get_site_url(null, '/sitemap.xml');
                                            $response = wp_remote_head($sitemap_url);
                                            if (!is_wp_error($response) && wp_remote_retrieve_response_code($response) === 200) {
                                                $has_sitemap = true;
                                                $sitemap_info = '<span class="success-text">All in One SEO</span> <a href="' . esc_url($sitemap_url) . '" target="_blank" style="text-decoration: none;"><span class="dashicons dashicons-external" style="font-size: 16px; width: 16px; height: 16px;"></span></a>';
                                            }
                                        }

                                        echo $has_sitemap ? $sitemap_info : 'No';
                                    ?>
                                </span>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<div id="database-tables-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>Database Tables</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="table-header">
                <div class="table-filter">
                    <input type="text" id="modal-table-search" placeholder="Filter tables..." class="regular-text">
                </div>
            </div>
            <!-- Totals Table -->
            <table class="widefat totals-table">
                <thead>
                    <tr class="totals-row">
                        <th>Totals</th>
                        <th></th>
                        <th><?php echo "Total Rows: " . number_format($total_rows); ?></th>
                        <th><?php echo "Total Data: " . size_format($total_data); ?></th>
                        <th><?php echo "Total Index: " . size_format($total_index); ?></th>
                        <th><?php echo "Total Size: " . size_format($total_size); ?></th>
                        <th><?php 
                            echo "Total Overhead: " . ($total_overhead > 0 ? 
                                '<span class="warning">' . size_format($total_overhead) . '</span>' : 
                                '0 B'
                            ); 
                        ?></th>
                    </tr>
                </thead>
            </table>
            <br>
            <!-- Main Table -->
            <table class="widefat" id="modal-database-tables">
                <thead>
                    <tr>
                        <th class="column-name">Table Name</th>
                        <th class="column-engine">Engine</th>
                        <th class="column-number">Rows</th>
                        <th class="column-number">Data Size</th>
                        <th class="column-number">Index Size</th>
                        <th class="column-number">Total Size</th>
                        <th class="column-number">Overhead</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($tables as $table): ?>
                    <tr>
                        <td><?php echo esc_html($table->Name); ?></td>
                        <td><?php echo esc_html($table->Engine); ?></td>
                        <td><?php echo number_format($table->Rows); ?></td>
                        <td><?php echo $table->Data_length ? size_format($table->Data_length) : '0 B'; ?></td>
                        <td><?php echo $table->Index_length ? size_format($table->Index_length) : '0 B'; ?></td>
                        <td><?php echo size_format(($table->Data_length ?? 0) + ($table->Index_length ?? 0)); ?></td>
                        <td>
                            <?php if ($table->Data_free > 0): ?>
                                <span class="warning"><?php echo size_format($table->Data_free); ?></span>
                            <?php else: ?>
                                0 B
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="apache-modules-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>Apache Modules</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="info-list">
                <?php
                if (function_exists('apache_get_modules')):
                    $apache_modules = apache_get_modules();
                    sort($apache_modules);
                    foreach ($apache_modules as $module):
                ?>
                    <div class="info-item">
                        <span class="info-label"><?php echo esc_html($module); ?></span>
                        <span class="info-value status-online">Enabled</span>
                    </div>
                <?php
                    endforeach;
                else:
                ?>
                    <p class="restricted-info">Apache module information is not available. This could be because the site is not running on Apache or the function is restricted.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<div id="env-variables-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>Environment Variables</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="permissions-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Variable</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $env_vars = $_SERVER;
                    if (!empty($env_vars)):
                        ksort($env_vars);
                        foreach ($env_vars as $key => $value):
                            if (!is_string($value) || empty($value)) {
                                continue;
                            }
                            // Skip sensitive environment variables
                            if (stripos($key, 'key') !== false || 
                                stripos($key, 'pass') !== false || 
                                stripos($key, 'secret') !== false || 
                                stripos($key, 'salt') !== false ||
                                stripos($key, 'auth') !== false) {
                                $value = '********';
                            }
                    ?>
                        <tr>
                            <td><?php echo esc_html($key); ?></td>
                            <td><?php echo esc_html($value); ?></td>
                        </tr>
                    <?php
                        endforeach;
                    else:
                    ?>
                        <tr>
                            <td colspan="2" class="restricted-info">Environment variables are not available or access is restricted.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<div id="file-permissions-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>WordPress Directory Permissions</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="permissions-table">
                <table>
                    <thead>
                        <tr>
                            <th>Name</th>
                            <th>Path</th>
                            <th>Permissions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $wp_root = ABSPATH;
                        $paths = array(
                            'WordPress Root' => $wp_root,
                            'Admin Directory' => $wp_root . 'wp-admin',
                            'Configuration File' => $wp_root . 'wp-config.php',
                            'Content Directory' => WP_CONTENT_DIR,
                            'Plugin Directory' => WP_PLUGIN_DIR,
                            'Theme Directory' => get_theme_root(),
                            'Must Use Plugins Directory' => WPMU_PLUGIN_DIR,
                            'Upload Directory' => wp_upload_dir()['basedir'],
                            'Fonts Directory' => WP_CONTENT_DIR . '/fonts',
                            'Language Directory' => WP_LANG_DIR
                        );
                        
                        foreach ($paths as $name => $path):
                            $perms = file_exists($path) ? substr(sprintf('%o', fileperms($path)), -4) : 'Directory Not Found';
                            $perms_class = file_exists($path) ? '' : 'restricted-info';
                        ?>
                        <tr>
                            <td><?php echo esc_html($name); ?></td>
                            <td><?php echo esc_html($path); ?></td>
                            <td class="<?php echo $perms_class; ?>"><?php echo esc_html($perms); ?></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- WordPress Constants Modal -->
<div id="wp-constants-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>WordPress Constants</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="constants-controls">
                <div class="filter-box">
                    <input type="text" id="constants-filter" placeholder="Filter constants..." class="widefat">
                </div>
                <div class="toggle-controls">
                    <label><input type="checkbox" id="show-blank-values" checked> Show Blank Values</label>
                    <label><input type="checkbox" id="show-undefined-values" checked> Show Undefined Values</label>
                </div>
            </div>
            <div class="permissions-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Constant</th>
                            <th>Value</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $constants = get_defined_constants(true);
                    $wp_constants = array_keys($constants['user']);
                    sort($wp_constants);
                    
                    foreach ($wp_constants as $constant):
                        $value = $constants['user'][$constant];
                        // Skip sensitive data
                        if (stripos($constant, 'key') !== false || 
                            stripos($constant, 'pass') !== false || 
                            stripos($constant, 'salt') !== false || 
                            stripos($constant, 'nonce') !== false) {
                            $value = '<span class="password-field">
                                <span class="password-dots">••••••••</span>
                                <span class="password-text" style="display:none">' . esc_html($value) . '</span>
                                <button type="button" class="toggle-password">
                                    <span class="dashicons dashicons-visibility"></span>
                                </button>
                            </span>';
                            echo '<tr class="constant-row ' . $value_class . '">
                                <td>' . esc_html($constant) . '</td>
                                <td>' . $value . '</td>
                            </tr>';
                            continue;
                        }
                        $value_class = '';
                        if (!defined($constant)) {
                            $value = 'Not defined';
                            $value_class = 'undefined-value';
                        } elseif (empty($value) && !is_numeric($value)) {
                            $value = 'Blank';
                            $value_class = 'blank-value';
                        }
                    ?>
                        <tr class="constant-row <?php echo $value_class; ?>">
                            <td><?php echo esc_html($constant); ?></td>
                            <td><?php echo is_bool($value) ? ($value ? 'true' : 'false') : esc_html($value); ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- PHP Extensions Modal -->
<div id="php-extensions-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>PHP Loaded Extensions</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="permissions-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Extension</th>
                            <th>Version</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php
                    $extensions = get_loaded_extensions();
                    sort($extensions);
                    foreach ($extensions as $extension):
                        $version = phpversion($extension);
                    ?>
                        <tr>
                            <td><?php echo esc_html($extension); ?></td>
                            <td><?php echo $version ? esc_html($version) : '<span class="restricted-info">Version Unknown</span>'; ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- System Limits Modal -->
<div id="system-limits-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>System Limits</h2>
            <button type="button" class="modal-close">
                    <span class="dashicons dashicons-no-alt"></span>
                </button>
            </div>
        <div class="inspector-modal-body">
            <div class="permissions-table">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>Limit Type</th>
                            <th>Current Value</th>
                        </tr>
                    </thead>
                    <tbody>
                        <!-- PHP Limits -->
                        <tr class="section-header">
                            <td colspan="2">PHP Limits</td>
                        </tr>
                        <tr>
                            <td>Memory Limit</td>
                            <td><?php echo ini_get('memory_limit'); ?></td>
                        </tr>
                        <tr>
                            <td>Max Execution Time</td>
                            <td><?php echo ini_get('max_execution_time'); ?> seconds</td>
                        </tr>
                        <tr>
                            <td>Max Input Time</td>
                            <td><?php echo ini_get('max_input_time'); ?> seconds</td>
                        </tr>
                        <tr>
                            <td>Max Input Vars</td>
                            <td><?php echo ini_get('max_input_vars'); ?></td>
                        </tr>
                        <tr>
                            <td>Upload Max Filesize</td>
                            <td><?php echo ini_get('upload_max_filesize'); ?></td>
                        </tr>
                        <tr>
                            <td>Post Max Size</td>
                            <td><?php echo ini_get('post_max_size'); ?></td>
                        </tr>
                        
                        <!-- MySQL Limits -->
                        <tr class="section-header">
                            <td colspan="2">MySQL Limits</td>
                        </tr>
                        <tr>
                            <td>Max Connections</td>
                            <td><?php echo $wpdb->get_var("SHOW VARIABLES LIKE 'max_connections'", 1); ?></td>
                        </tr>
                        <tr>
                            <td>Max Allowed Packet</td>
                            <td><?php echo size_format($wpdb->get_var("SHOW VARIABLES LIKE 'max_allowed_packet'", 1)); ?></td>
                        </tr>
                        
                        <!-- WordPress Limits -->
                        <tr class="section-header">
                            <td colspan="2">Wordpress Limits</td>
                        </tr>
                        <tr>
                            <td>Max Upload Size</td>
                            <td><?php echo size_format(wp_max_upload_size()); ?></td>
                        </tr>
                        <tr>
                            <td>Memory Limit</td>
                            <td><?php echo WP_MEMORY_LIMIT; ?></td>
                        </tr>
                        <tr>
                            <td>Admin Memory Limit</td>
                            <td><?php echo WP_MAX_MEMORY_LIMIT; ?></td>
                        </tr>
                        
                        <!-- Server Limits -->
                        <tr class="section-header">
                            <td colspan="2">Server Limits</td>
                        </tr>
                        <?php
                        $cpu_info = WordPress_Inspector_System_Utils::get_cpu_info();
                        if (!empty($cpu_info['allocated_cores'])): ?>
                        <tr>
                            <td>CPU Cores</td>
                            <td><?php echo number_format($cpu_info['allocated_cores'], 1); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php
                        $memory_info = WordPress_Inspector_System_Utils::get_memory_info();
                        if (!empty($memory_info['total'])): ?>
                        <tr>
                            <td>Total RAM</td>
                            <td><?php echo size_format($memory_info['total']); ?></td>
                        </tr>
                        <?php endif; ?>
                        <?php
                        $filesystem_info = WordPress_Inspector_System_Utils::get_filesystem_info();
                        if (!empty($filesystem_info['storage']['total'])): ?>
                        <tr>
                            <td>Total Storage</td>
                            <td><?php echo size_format($filesystem_info['storage']['total']); ?></td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- PHP Info Modal -->
<div id="php-info-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>PHP Information</h2>
            <button class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <div class="phpinfo">
                <?php
                ob_start();
                phpinfo();
                $phpinfo = ob_get_clean();

                // Extract PHP version first
                preg_match('/<h1 class="p">(.*?)<\/h1>/s', $phpinfo, $version);
                $php_version = strip_tags($version[1] ?? '');

                // Convert the phpinfo output to be more WordPress-friendly
                $phpinfo = preg_replace(
                    array(
                        '#^.*<body>(.*)</body>.*$#ms',
                        '#<h2>PHP License</h2>.*$#ms',
                        '#<h1.*?>(.*?)</h1>#',
                        '#<tr class="h">(.*?)</tr>#',
                        '#<tr class="v">(.*?)</tr>#',
                        '#<img[^>]*>#',
                        '#<a[^>]*>(.*?)</a>#',
                        '#<th[^>]*>([^<]*?)</th>#',
                        '#<td class="e">(.*?)</td>#',
                        '#<td class="v">(.*?)</td>#',
                        '#<tr[^>]*>(.*?)</tr>#s',
                        '#<table[^>]*>#',
                        '#<hr.*?>#',
                        '#<h2>(.*?)</h2>#'
                    ),
                    array(
                        '$1',
                        '',
                        '',
                        '<tr>$1</tr>',
                        '<tr>$1</tr>',
                        '',
                        '$1',
                        '<th>$1</th>',
                        '<td>$1</td>',
                        '<td>$1</td>',
                        '<tr>$1</tr>',
                        '<table class="widefat">',
                        '',
                        '<h3>$1</h3>'
                    ),
                    $phpinfo
                );

                // Add PHP version at the top
                echo '<h3>PHP Version</h3>';
                echo '<div class="php-version">' . esc_html($php_version) . '</div>';
                echo $phpinfo;
                ?>
            </div>
        </div>
    </div>
</div>

<!-- Cloud Information Modal -->
<div id="cloud-info-modal" class="inspector-modal">
    <div class="inspector-modal-content inspector-modal-content-wide">
        <div class="inspector-modal-header">
            <h2>Domain Information</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <?php
            $domain = parse_url(get_site_url(), PHP_URL_HOST);
            $domain_info = WordPress_Inspector_System_Utils::get_domain_info();
            $dns_servers = WordPress_Inspector_System_Utils::get_dns_servers();
            
            // Remove www. if present for root domain
            $root_domain = preg_replace('/^www\./', '', $domain);
            ?>
            
            <table class="widefat">
                <tbody>
                    <tr>
                        <th>Domain Name</th>
                        <td><?php echo esc_html($domain); ?></td>
                    </tr>
                    <tr>
                        <th>Root Domain</th>
                        <td><?php echo esc_html($root_domain); ?></td>
                    </tr>
                    <tr>
                        <th>Registration Date</th>
                        <td>
                            <?php 
                            if ($domain_info && !empty($domain_info['registration_date'])) {
                                $reg_date = new DateTime($domain_info['registration_date']);
                                echo esc_html($reg_date->format('F j, Y'));
                            } else {
                                echo '<span class="empty-value">Not Available</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Expiration Date</th>
                        <td>
                            <?php 
                            if ($domain_info && !empty($domain_info['expiration_date'])) {
                                $exp_date = new DateTime($domain_info['expiration_date']);
                                $now = new DateTime();
                                $days_remaining = $now->diff($exp_date)->days;
                                
                                if ($days_remaining < 90) {
                                    echo '<span class="warning-text">';
                                }
                                echo esc_html($exp_date->format('F j, Y'));
                                if ($days_remaining < 90) {
                                    echo ' (' . $days_remaining . ' days remaining)</span>';
                                }
                            } else {
                                echo '<span class="empty-value">Not Available</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>DNS Provider</th>
                        <td><?php echo esc_html(!empty($dns_servers) ? $dns_servers[0]['provider'] : 'Unknown'); ?></td>
                    </tr>
                    <tr>
                        <th>Nameservers</th>
                        <td>
                            <?php
                            if (!empty($dns_servers)) {
                                echo '<ul class="modal-nameserver-list">';
                                foreach ($dns_servers as $server) {
                                    echo '<li>' . esc_html($server['server']) . '</li>';
                                }
                                echo '</ul>';
                            } else {
                                echo '<span class="empty-value">No nameservers detected</span>';
                            }
                            ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div id="gzip-info-modal" class="inspector-modal">
    <div class="inspector-modal-content">
        <div class="inspector-modal-header">
            <h2>GZIP Compression Information</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <table class="widefat">
                <tbody>
                    <tr>
                        <th>Status</th>
                        <td>
                            <?php if ($gzip_enabled): ?>
                                <span class="status-good">Enabled</span>
                                <p>GZIP compression is active using <?php echo esc_html($gzip_status); ?></p>
                            <?php else: ?>
                                <span class="status-warning">Not Enabled</span>
                                <p>GZIP compression is not currently active on your site.</p>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Compression Methods</th>
                        <td>
                            <ul class="modal-list">
                                <li>
                                    <strong>PHP zlib:</strong> 
                                    <?php echo ini_get('zlib.output_compression') ? 
                                        '<span class="status-good">Active</span>' : 
                                        '<span class="status-normal">Not Active</span>'; ?>
                                </li>
                                <li>
                                    <strong>Apache mod_deflate:</strong> 
                                    <?php echo (function_exists('apache_get_modules') && in_array('mod_deflate', apache_get_modules())) ? 
                                        '<span class="status-good">Active</span>' : 
                                        '<span class="status-normal">Not Active</span>'; ?>
                                </li>
                                <li>
                                    <strong>Output Handler:</strong> 
                                    <?php echo (ini_get('output_handler') === 'ob_gzhandler') ? 
                                        '<span class="status-good">GZIP Handler Active</span>' : 
                                        '<span class="status-normal">No GZIP Handler</span>'; ?>
                                </li>
                            </ul>
                        </td>
                    </tr>
                    <tr>
                        <th>Benefits</th>
                        <td>
                            <p>GZIP compression can:</p>
                            <ul class="modal-list">
                                <li>Reduce file transfer size by up to 70%</li>
                                <li>Improve page load times</li>
                                <li>Reduce bandwidth usage</li>
                                <li>Enhance overall site performance</li>
                            </ul>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Add this modal div at the bottom of the page -->
<div id="cache-info-modal" class="inspector-modal">
    <div class="inspector-modal-content">
        <div class="inspector-modal-header">
            <h2>Cache Information</h2>
            <button type="button" class="modal-close">
                <span class="dashicons dashicons-no-alt"></span>
            </button>
        </div>
        <div class="inspector-modal-body">
            <table class="widefat">
                <tbody>
                    <tr>
                        <th>Browser Cache</th>
                        <td>
                            <?php if ($browser_cache_enabled): ?>
                                <span class="status-good">Enabled</span>
                                <p>Browser caching is properly configured through Apache mod_expires.</p>
                            <?php else: ?>
                                <span class="status-warning">Disabled</span>
                                <p>Browser caching is not configured. This can be enabled through:</p>
                                <ul class="modal-list">
                                    <li>Apache mod_expires module</li>
                                    <li>Nginx configuration</li>
                                    <li>Caching plugin</li>
                                </ul>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Object Cache</th>
                        <td>
                            <?php if ($object_cache_enabled): ?>
                                <span class="status-good">Enabled</span>
                                <?php
                                $cache_type = '';
                                if (class_exists('Redis')) {
                                    $cache_type = 'Redis';
                                } elseif (class_exists('Memcached')) {
                                    $cache_type = 'Memcached';
                                }
                                if ($cache_type) {
                                    echo "<p>Using $cache_type for object caching.</p>";
                                }
                                ?>
                            <?php else: ?>
                                <span class="status-warning">Disabled</span>
                                <p>Object caching is not configured. Consider implementing:</p>
                                <ul class="modal-list">
                                    <li>Redis</li>
                                    <li>Memcached</li>
                                    <li>APCu</li>
                                </ul>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Benefits</th>
                        <td>
                            <p>Proper caching can:</p>
                            <ul class="modal-list">
                                <li>Reduce server load</li>
                                <li>Improve page load times</li>
                                <li>Enhance user experience</li>
                                <li>Reduce bandwidth usage</li>
                                <li>Improve SEO rankings</li>
                            </ul>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    // Show stored database errors as toasts
    <?php foreach ($db_errors as $error): ?>
        showToast(
            <?php echo json_encode($error['header']); ?>,
            <?php echo json_encode($error['message']); ?>
        );
    <?php endforeach; ?>
</script>