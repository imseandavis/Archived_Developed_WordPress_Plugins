<?php
if (!defined('ABSPATH')) {
    exit;
}

// Add CSS
wp_enqueue_style('wordpress-inspector-database', plugins_url('assets/css/database.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-database', plugins_url('assets/js/database.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery'));

// Add nonce
wp_nonce_field('wpi_database_nonce', 'wpi_database_nonce');

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;

// Set custom slow query log path in wp-content directory
$slow_log_path = WP_CONTENT_DIR . '/mysql-slow.log';

// Try to create/check log file
if (!file_exists($slow_log_path)) {
    @touch($slow_log_path);
    @chmod($slow_log_path, 0666);
}

// Check for SUPER privilege
$has_super_privilege = false;
$wpdb->suppress_errors(true);
$result = $wpdb->get_row("SHOW GRANTS FOR CURRENT_USER()");
$wpdb->suppress_errors(false);

if ($result && (
    stripos($wpdb->last_result[0]->{'Grants for ' . $wpdb->dbuser . '@' . $wpdb->dbhost} ?? '', 'SUPER') !== false ||
    stripos($wpdb->last_result[0]->{'Grants for ' . $wpdb->dbuser . '@' . $wpdb->dbhost} ?? '', 'ALL PRIVILEGES') !== false
)) {
    $has_super_privilege = true;
}

// Get current slow query settings without trying to modify them
$slow_query_settings = array();
try {
    $slow_query_settings = $wpdb->get_results("
        SHOW VARIABLES WHERE Variable_name IN (
            'slow_query_log',
            'slow_query_log_file',
            'long_query_time'
        )
    ", OBJECT_K);
} catch (Exception $e) {
    // Silently fail - we'll show a notice about limited access
}

// Show appropriate notice based on privileges
if (!$has_super_privilege) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-info">
            <p>
                <strong>Limited Database Access:</strong> 
                Slow query logging configuration requires additional database privileges. 
                This is normal in shared hosting environments.
                <button type="button" class="button button-secondary open-permissions-help">
                    <span class="dashicons dashicons-editor-help"></span>
                    Learn More
                </button>
            </p>
        </div>';
    });
} elseif (!is_writable($slow_log_path)) {
    add_action('admin_notices', function() {
        echo '<div class="notice notice-warning">
            <p>
                Unable to create slow query log file. Please check directory permissions.
                <button type="button" class="button button-secondary open-permissions-help">
                    <span class="dashicons dashicons-editor-help"></span>
                    How to fix this?
                </button>
            </p>
        </div>';
    });
}

// Get database information
$db_size = WordPress_Inspector_DB_Utils::get_db_size();
$tables = $wpdb->get_results("SHOW TABLE STATUS");

// Initialize database errors array
$db_errors = array();
if (!empty($wpdb->last_error)) {
    $db_errors[] = array(
        'header' => 'Database Error',
        'message' => $wpdb->last_error
    );
}

?>

<!-- Toast Container -->
<div class="toast-container"></div>

<div class="wrap wordpress-inspector">
    <h1>Database Tools</h1>
    <div class="database-container">
        <div class="database-section full-width">
            <h2>Database Overview</h2>
            <div class="database-actions">
                <button type="button" class="button button-secondary view-tables-button">
                    <span class="dashicons dashicons-database"></span>
                    View All Tables
                </button>
            </div>
            <!-- Database stats content -->
        </div>
        
        <!-- Autoload Options Management -->
        <div class="database-section full-width">
            <h2>
                Autoload Options Management
                <span class="dashicons dashicons-editor-help" 
                      title="Autoloaded options are loaded on every page request. Large autoloaded options can impact site performance."></span>
            </h2>
            <div class="header-actions">
                <button class="button optimize-button" data-action="autoload">
                    <span class="dashicons dashicons-performance"></span>
                    Optimize Autoload
                </button>
            </div>
            <div class="section-content">
                <?php
                // Get autoload stats
                $autoload_query = $wpdb->prepare("
                    SELECT COUNT(*) as count, SUM(LENGTH(option_value)) as size 
                    FROM $wpdb->options 
                    WHERE autoload = %s",
                    'yes'
                );
                $autoload_size_query = $wpdb->get_row($autoload_query);
                $autoload_count = $autoload_size_query->count;
                $autoload_size = $autoload_size_query->size;
                $size_warning = $autoload_size >= 1000000; // 1MB threshold
                ?>
                
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Total Autoloaded Options</span>
                        <span class="value"><?php echo number_format($autoload_count); ?></span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Total Size</span>
                        <span class="value">
                            <?php 
                            echo size_format($autoload_size);
                            if ($size_warning) {
                                echo '<div class="warning-text">Over 1MB of autoloaded data may impact performance</div>';
                            }
                            ?>
                        </span>
                    </div>
                </div>

                <?php if ($autoload_count > 0): ?>
                    <h3>Largest Autoloaded Options</h3>
                <table class="database-table">
                    <thead>
                        <tr>
                            <th>Option Name</th>
                            <th>Size</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                            <?php
                            $large_options = $wpdb->get_results(
                                "SELECT option_name, LENGTH(option_value) as size 
                                FROM $wpdb->options 
                                WHERE autoload = 'yes' 
                                ORDER BY LENGTH(option_value) DESC 
                                LIMIT 10"
                            );
                            
                            foreach ($large_options as $option): ?>
                            <tr>
                                <td><?php echo esc_html($option->option_name); ?></td>
                                    <td><?php echo size_format($option->size); ?></td>
                                <td>
                                    <button type="button" 
                                            class="button button-small disable-autoload" 
                                            data-option="<?php echo esc_attr($option->option_name); ?>">
                                        Disable Autoload
                                    </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Cleanup Tools Section -->
        <div class="database-section">
            <h2>Cleanup Tools</h2>
            <div class="header-actions">
                <button class="button cleanup-button" data-action="all">
                    <span class="dashicons dashicons-trash"></span>
                    Clean All
                </button>
            </div>
            <div class="section-content">
                <div class="info-item">
                    <span class="label">Post Revisions</span>
                    <span class="value">
                        <?php 
                        $revisions = wp_count_posts('revision');
                        $revision_count = $revisions->inherit ?? 0;
                        echo $revision_count > 0 ? 
                            '<button class="button cleanup-button" data-action="revisions">' . 
                            'Clean (' . number_format($revision_count) . ')' . 
                            '</button>' : 
                            '<span class="empty-value">No revisions found</span>';
                        ?>
                    </span>
                </div>

                <div class="info-item">
                    <span class="label">Auto-Drafts</span>
                    <span class="value">
                        <?php 
                        $autodrafts = wp_count_posts('post');
                        $autodraft_count = $autodrafts->auto_draft ?? 0;
                        echo $autodraft_count > 0 ? 
                            '<button class="button cleanup-button" data-action="autodrafts">' . 
                            'Clean (' . number_format($autodraft_count) . ')' . 
                            '</button>' : 
                            '<span class="empty-value">No auto-drafts found</span>';
                        ?>
                    </span>
                </div>

                <div class="info-item">
                    <span class="label">Trashed Posts</span>
                    <span class="value">
                        <?php 
                        $trash = wp_count_posts('post');
                        $trash_count = $trash->trash ?? 0;
                        echo $trash_count > 0 ? 
                            '<button class="button cleanup-button" data-action="trash">' . 
                            'Clean (' . number_format($trash_count) . ')' . 
                            '</button>' : 
                            '<span class="empty-value">No trashed posts found</span>';
                        ?>
                    </span>
                </div>

                <div class="info-item">
                    <span class="label">Spam Comments</span>
                    <span class="value">
                        <?php 
                        $spam_count = wp_count_comments()->spam ?? 0;
                        echo $spam_count > 0 ? 
                            '<button class="button cleanup-button" data-action="spam">' . 
                            'Clean (' . number_format($spam_count) . ')' . 
                            '</button>' : 
                            '<span class="empty-value">No spam comments found</span>';
                        ?>
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Transient Management Section -->
        <div class="database-section full-width">
            <h2>
                Transient Management
                <span class="dashicons dashicons-editor-help" 
                      title="Transients are temporary data stored in the WordPress database with an expiration time"></span>
            </h2>
            <div class="header-actions">
                <button class="button cleanup-button" data-action="expired-transients">
                    <span class="dashicons dashicons-trash"></span>
                    Clear Expired
                </button>
                <button class="button cleanup-button" data-action="all-transients">
                    <span class="dashicons dashicons-trash"></span>
                    Clear All
                </button>
            </div>
            <div class="section-content">
                <?php
                // Get transient counts
                $total_transients = $wpdb->get_var(
                    "SELECT COUNT(*) FROM $wpdb->options 
                    WHERE option_name LIKE '_transient_%' 
                    OR option_name LIKE '_site_transient_%'"
                );
                
                $expired_transients = $wpdb->get_var(
                    "SELECT COUNT(*) FROM $wpdb->options 
                    WHERE (option_name LIKE '_transient_timeout_%' 
                    OR option_name LIKE '_site_transient_timeout_%')
                    AND option_value < " . time()
                );
                
                // Calculate size
                $transient_size = $wpdb->get_var(
                    "SELECT SUM(LENGTH(option_value)) 
                    FROM $wpdb->options 
                    WHERE option_name LIKE '_transient_%' 
                    OR option_name LIKE '_site_transient_%'"
                );
                ?>
                
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Total Transients</span>
                        <span class="value"><?php echo number_format($total_transients); ?></span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Expired Transients</span>
                        <span class="value">
                            <?php 
                            echo number_format($expired_transients);
                            if ($expired_transients > 100) {
                                echo '<div class="warning-text">High number of expired transients</div>';
                            }
                            ?>
                        </span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Total Size</span>
                        <span class="value">
                            <?php 
                            echo size_format($transient_size);
                            if ($transient_size > 5 * MB_IN_BYTES) {
                                echo '<div class="warning-text">Consider cleaning expired transients</div>';
                            }
                            ?>
                        </span>
                    </div>
                </div>

                <?php
                // Get largest transients
                $largest_transients = $wpdb->get_results(
                    "SELECT option_name, LENGTH(option_value) as size 
                    FROM $wpdb->options 
                    WHERE option_name LIKE '_transient_%' 
                    OR option_name LIKE '_site_transient_%'
                    ORDER BY LENGTH(option_value) DESC 
                    LIMIT 5"
                );
                
                if (!empty($largest_transients)): ?>
                    <h3>Largest Transients</h3>
                    <table class="database-table">
                        <thead>
                            <tr>
                                <th>Name</th>
                                <th>Size</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($largest_transients as $transient): 
                                $name = str_replace(array('_transient_', '_site_transient_'), '', $transient->option_name);
                                $timeout = get_option("_transient_timeout_$name");
                                $is_expired = $timeout && $timeout < time();
                                ?>
                                <tr>
                                    <td><?php echo esc_html($name); ?></td>
                                    <td><?php echo size_format($transient->size); ?></td>
                                    <td>
                                        <?php if ($is_expired): ?>
                                            <span class="status-expired">Expired</span>
                                        <?php else: ?>
                                            <span class="status-active">Active</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </div>
        
        <!-- Content Management Section -->
        <div class="database-section full-width">
            <h2>
                Content Management
                <span class="dashicons dashicons-editor-help" 
                      title="Overview of your WordPress content types and their database usage"></span>
            </h2>
            <div class="section-content">
                <?php
                // Get all registered post types
                $post_types = get_post_types(['public' => true], 'objects');
                $post_counts = wp_count_posts();
                $total_posts = 0;
                
                // Get all taxonomies
                $taxonomies = get_taxonomies(['public' => true], 'objects');
                ?>
                
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Total Content Types</span>
                        <span class="value"><?php echo count($post_types); ?> Types</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Total Taxonomies</span>
                        <span class="value"><?php echo count($taxonomies); ?> Taxonomies</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Database Tables</span>
                        <span class="value">
                            <?php 
                            $content_tables = $wpdb->get_results("SHOW TABLES LIKE '{$wpdb->prefix}posts'");
                            echo count($content_tables) . ' Tables';
                            ?>
                        </span>
                    </div>
                </div>

                <h3>Post Types Overview</h3>
                <table class="database-table">
                    <thead>
                        <tr>
                            <th>Post Type</th>
                            <th>Published</th>
                            <th>Draft</th>
                            <th>Trash</th>
                            <th>Total Size</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($post_types as $post_type): 
                            $counts = wp_count_posts($post_type->name);
                            $size_query = $wpdb->get_var($wpdb->prepare(
                                "SELECT SUM(LENGTH(post_content)) 
                                FROM {$wpdb->posts} 
                                WHERE post_type = %s",
                                $post_type->name
                            ));
                            ?>
                            <tr>
                                <td><?php echo esc_html($post_type->labels->name); ?></td>
                                <td><?php echo number_format($counts->publish ?? 0); ?></td>
                                <td><?php echo number_format($counts->draft ?? 0); ?></td>
                                <td><?php echo number_format($counts->trash ?? 0); ?></td>
                                <td><?php echo size_format($size_query); ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>

                <h3>Taxonomy Overview</h3>
                <table class="database-table">
                    <thead>
                        <tr>
                            <th>Taxonomy</th>
                            <th>Terms</th>
                            <th>Relationships</th>
                            <th>Post Types</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($taxonomies as $taxonomy): 
                            $term_count = wp_count_terms(['taxonomy' => $taxonomy->name]);
                            $relationship_count = $wpdb->get_var($wpdb->prepare(
                                "SELECT COUNT(*) 
                                FROM {$wpdb->term_relationships} tr 
                                JOIN {$wpdb->term_taxonomy} tt 
                                ON tr.term_taxonomy_id = tt.term_taxonomy_id 
                                WHERE tt.taxonomy = %s",
                                $taxonomy->name
                            ));
                            ?>
                            <tr>
                                <td><?php echo esc_html($taxonomy->labels->name); ?></td>
                                <td><?php echo number_format($term_count); ?></td>
                                <td><?php echo number_format($relationship_count); ?></td>
                                <td>
                                    <?php 
                                    $post_types = get_object_taxonomies($taxonomy->name, 'names');
                                    echo esc_html(implode(', ', $post_types)); 
                                    ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
        <!-- Table Information Section -->
        <div class="database-section">
            <h2>Table Information</h2>
            <table class="database-table">
                <!-- Table info content -->
            </table>
        </div>
        
        <!-- Optimization Tools Section -->
        <div class="database-section full-width">
            <h2>
                Database Optimization
                <span class="dashicons dashicons-editor-help" 
                      title="Tools to optimize and maintain your WordPress database performance"></span>
            </h2>
            <div class="header-actions">
                <button class="button optimize-button" data-action="all">
                    <span class="dashicons dashicons-database"></span>
                    Optimize All Tables
                </button>
                <button class="button optimize-button" data-action="indexes">
                    <span class="dashicons dashicons-search"></span>
                    Analyze Indexes
                </button>
            </div>
            <div class="section-content">
                <?php
                $tables = $wpdb->get_results('SHOW TABLE STATUS');
                $total_overhead = 0;
                $tables_to_optimize = array();
                $total_indexes = 0;
                
                foreach ($tables as $table) {
                    if ($table->Data_free > 0) {
                        $total_overhead += $table->Data_free;
                        $tables_to_optimize[] = $table;
                    }
                    // Get index information
                    $indexes = $wpdb->get_results("SHOW INDEX FROM {$table->Name}");
                    $total_indexes += count($indexes);
                }
                ?>
                
                <div class="info-grid">
                    <div class="info-item">
                        <span class="label">Total Tables</span>
                        <span class="value"><?php echo count($tables); ?> Tables</span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Total Indexes</span>
                        <span class="value">
                            <?php echo number_format($total_indexes); ?> Indexes
                            <?php if ($total_indexes > 50): ?>
                                <div class="warning-text">High number of indexes may impact performance</div>
                            <?php endif; ?>
                        </span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Tables with Overhead</span>
                        <span class="value">
                            <?php 
                            echo count($tables_to_optimize);
                            if (count($tables_to_optimize) > 0) {
                                echo '<div class="warning-text">Tables need optimization</div>';
                            }
                            ?>
                        </span>
                    </div>
                    
                    <div class="info-item">
                        <span class="label">Total Overhead</span>
                        <span class="value">
                            <?php 
                            echo size_format($total_overhead);
                            if ($total_overhead > 1 * MB_IN_BYTES) {
                                echo '<div class="warning-text">Consider optimizing tables</div>';
                            }
                            ?>
                        </span>
                    </div>
                </div>

                <?php if (!empty($tables_to_optimize)): ?>
                    <h3>Tables Needing Optimization</h3>
                    <table class="database-table">
                        <thead>
                            <tr>
                                <th>Table Name</th>
                                <th>Engine</th>
                                <th>Rows</th>
                                <th>Size</th>
                                <th>Overhead</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($tables_to_optimize as $table): ?>
                                <tr>
                                    <td><?php echo esc_html($table->Name); ?></td>
                                    <td><?php echo esc_html($table->Engine); ?></td>
                                    <td><?php echo number_format($table->Rows); ?></td>
                                    <td><?php echo size_format($table->Data_length + $table->Index_length); ?></td>
                                    <td><?php echo size_format($table->Data_free); ?></td>
                                    <td>
                                        <button class="button button-small optimize-table-button" 
                                                data-table="<?php echo esc_attr($table->Name); ?>">
                                            Optimize
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    
                    <div class="optimization-note">
                        <p>
                            <span class="dashicons dashicons-info"></span>
                            Table optimization can temporarily lock tables. Consider running during low-traffic periods.
                        </p>
                    </div>
                <?php endif; ?>

                <h3>Index Analysis</h3>
                <table class="database-table">
                    <thead>
                        <tr>
                            <th>Table</th>
                            <th>Index</th>
                            <th>Type</th>
                            <th>Cardinality</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        foreach ($tables as $table):
                            $indexes = $wpdb->get_results("SHOW INDEX FROM {$table->Name}");
                            foreach ($indexes as $index):
                                // Skip primary keys
                                if ($index->Key_name === 'PRIMARY') continue;
                                
                                // Calculate index efficiency
                                $cardinality = $index->Cardinality;
                                $total_rows = $table->Rows;
                                $efficiency = $total_rows > 0 ? ($cardinality / $total_rows) * 100 : 0;
                                $needs_optimization = $efficiency < 70;
                                ?>
                                <tr class="<?php echo $needs_optimization ? 'needs-optimization' : ''; ?>">
                                    <td><?php echo esc_html($table->Name); ?></td>
                                    <td><?php echo esc_html($index->Key_name); ?></td>
                                    <td><?php echo esc_html($index->Index_type); ?></td>
                                    <td>
                                        <?php 
                                        echo number_format($cardinality);
                                        if ($needs_optimization) {
                                            echo '<div class="warning-text">Low selectivity</div>';
                                        }
                                        ?>
                                    </td>
                                    <td>
                                        <button class="button button-small analyze-index-button" 
                                                data-table="<?php echo esc_attr($table->Name); ?>"
                                                data-index="<?php echo esc_attr($index->Key_name); ?>">
                                            Analyze
                                        </button>
                                    </td>
                                </tr>
                            <?php endforeach;
                        endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        
    </div>
</div>

<div id="permissions-help-modal" style="display:none;">
    <div class="permissions-help-content">
        <h2>How to Fix Permissions for Slow Query Log</h2>
        <div class="steps-container">
            <p>Follow these steps to enable slow query logging:</p>
            <ol>
                <li>Connect to your server via SSH or FTP</li>
                <li>Navigate to your WordPress content directory:<br>
                    <code><?php echo esc_html(WP_CONTENT_DIR); ?></code>
                </li>
                <li>Set the correct permissions using these commands:
                    <pre>touch mysql-slow.log
chmod 666 mysql-slow.log</pre>
                </li>
                <li>If using SSH, ensure MySQL has access:
                    <pre>chown mysql:mysql mysql-slow.log</pre>
                </li>
                <li>Alternative method through FTP:
                    <ul>
                        <li>Create an empty file named 'mysql-slow.log'</li>
                        <li>Set file permissions to 666 (rw-rw-rw-)</li>
                    </ul>
                </li>
            </ol>
            <div class="note">
                <strong>Note:</strong> If these steps don't work, you may need to:
                <ul>
                    <li>Contact your hosting provider for assistance</li>
                    <li>Ensure your hosting plan allows changing MySQL global variables</li>
                    <li>Request the hosting provider to enable slow query logging</li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div id="database-tables-modal" class="database-modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Database Tables</h2>
            <button class="close-modal">&times;</button>
        </div>
        <div class="modal-body">
            <!-- Totals Table -->
            <table class="database-table totals-table">
                <thead>
                    <tr class="totals-row">
                        <?php
                        $tables = $wpdb->get_results('SHOW TABLE STATUS', ARRAY_A);
                        $total_rows = 0;
                        $total_data = 0;
                        $total_index = 0;
                        $total_overhead = 0;
                        
                        foreach ($tables as $table) {
                            $total_rows += $table['Rows'];
                            $total_data += $table['Data_length'];
                            $total_index += $table['Index_length'];
                            $total_overhead += $table['Data_free'];
                        }
                        $total_size = $total_data + $total_index;
                        ?>
                        <th>Total Tables: <?php echo count($tables); ?></th>
                        <th>Total Rows: <?php echo number_format($total_rows); ?></th>
                        <th>Total Size: <?php echo size_format($total_size); ?></th>
                        <th>Total Overhead: <?php echo size_format($total_overhead); ?></th>
                    </tr>
                </thead>
            </table>
            
            <!-- Main Table -->
            <table class="database-table">
                <thead>
                    <tr>
                        <th>Table Name</th>
                        <th>Engine</th>
                        <th>Records</th>
                        <th>Data Size</th>
                        <th>Index Size</th>
                        <th>Total Size</th>
                        <th>Overhead</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $tables = $wpdb->get_results('SHOW TABLE STATUS', ARRAY_A);
                    foreach ($tables as $table) {
                        $status = '';
                        if ($table['Engine'] !== 'InnoDB') {
                            $status = '<span class="status-warning">Not InnoDB</span>';
                        }
                        ?>
                        <tr>
                            <td><?php echo esc_html($table['Name']); ?></td>
                            <td><?php echo esc_html($table['Engine']) . ' ' . $status; ?></td>
                            <td><?php echo number_format($table['Rows']); ?></td>
                            <td><?php echo size_format($table['Data_length']); ?></td>
                            <td><?php echo size_format($table['Index_length']); ?></td>
                            <td><?php echo size_format($table['Data_length'] + $table['Index_length']); ?></td>
                            <td><?php echo size_format($table['Data_free']); ?></td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.inspector-modal-content {
    position: relative;
    background: #fff;
    margin: 30px auto;
    padding: 0;
    border-radius: 8px;
    max-width: 800px;  /* Default width */
}

/* Add a wider variant for the platform information modal */
#raw-data-info-modal .inspector-modal-content {
    max-width: 1000px;  /* Increased width for platform info */
}

/* Keep existing modal styles */
.inspector-modal-content-wide {
    max-width: 90%;
}

/* Database Page Layout */
.database-container {
    max-width: 1200px;
    margin: 20px 0;
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(350px, 1fr));
    gap: 20px;
}

/* Make certain sections full width */
.database-section.full-width {
    grid-column: 1 / -1;
}

/* Card Styling */
.database-section {
    background: #fff;
    border: 1px solid #ccd0d4;
    border-radius: 8px;
    padding: 20px;
    margin-bottom: 20px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    transition: box-shadow 0.3s ease;
}

.database-section:hover {
    box-shadow: 0 4px 8px rgba(0,0,0,0.1);
}

.database-section h2 {
    margin-top: 0;
    padding-bottom: 12px;
    border-bottom: 2px solid #f0f0f1;
    font-size: 1.2em;
    color: #1d2327;
    display: flex;
    align-items: center;
    gap: 10px;
}

/* Table Styling */
.database-table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
}

.database-table th,
.database-table td {
    padding: 12px;
    text-align: left;
    border-bottom: 1px solid #f0f0f1;
}

.database-table th {
    background: #f8f9fa;
    font-weight: 600;
}

.database-table tr:hover {
    background-color: #f8f9fa;
}

/* Action Buttons */
.database-actions {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.database-actions .button {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 6px 12px;
    height: auto;
}

/* Status Indicators */
.status-indicator {
    display: inline-flex;
    align-items: center;
    gap: 5px;
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

.status-good {
    background: #edf7ed;
    color: #2e7d32;
}

.status-warning {
    background: #fff4e5;
    color: #ed6c02;
}

.status-error {
    background: #fdeded;
    color: #d32f2f;
}

/* Progress Bars */
.progress-bar {
    height: 8px;
    background: #e9ecef;
    border-radius: 4px;
    overflow: hidden;
    margin-top: 8px;
}

.progress-bar .fill {
    height: 100%;
    background: #0073aa;
    transition: width 0.3s ease;
}

/* Mobile Responsiveness */
@media screen and (max-width: 782px) {
    .database-container {
        grid-template-columns: 1fr;
    }

    .database-actions {
        flex-direction: column;
    }

    .database-actions .button {
        width: 100%;
        justify-content: center;
    }

    .database-table {
        display: block;
        overflow-x: auto;
    }
}

/* Modal Styles */
.database-modal {
    display: none;
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background: rgba(0, 0, 0, 0.6);
    z-index: 100000;
}

.database-modal.show {
    display: block;
}

.modal-content {
    position: relative;
    background: #fff;
    margin: 5vh auto;
    padding: 20px;
    width: 90%;
    max-width: 800px;
    max-height: 90vh;
    border-radius: 8px;
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.3);
}

.modal-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding-bottom: 15px;
    border-bottom: 1px solid #e5e5e5;
    margin-bottom: 15px;
}

.modal-header h2 {
    margin: 0;
    padding: 0;
    border: none;
}

.modal-body {
    max-height: calc(85vh - 130px);
    overflow-y: auto;
}

.close-modal {
    background: none;
    border: none;
    font-size: 24px;
    cursor: pointer;
    color: #666;
    padding: 0;
    width: 30px;
    height: 30px;
    line-height: 30px;
    text-align: center;
}

.close-modal:hover {
    color: #000;
}

/* Database Tables Modal */
.totals-table {
    margin-bottom: 20px;
    background: #f8f9fa;
}

.totals-table th {
    font-size: 13px;
    color: #1d2327;
    background: transparent;
}

.totals-row th {
    text-align: left;
    padding: 15px;
}

/* Index Analysis Styles */
.needs-optimization {
    background-color: #fff9c0;
}

.analyze-index-button {
    min-width: 70px;
}

.database-table tr.needs-optimization:hover {
    background-color: #fff5b3;
}
</style>