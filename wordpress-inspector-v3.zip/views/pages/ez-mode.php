<?php
if (!defined('ABSPATH')) {
    exit;
}

// Get current step from URL parameter, default to 1
$current_step = isset($_GET['step']) ? intval($_GET['step']) : 1;
$total_steps = 4;

// Define steps
$steps = array(
    1 => array(
        'title' => 'Security Scan',
        'description' => 'Scanning your site for security vulnerabilities...',
        'action' => 'security_scan'
    ),
    2 => array(
        'title' => 'Performance Scan',
        'description' => 'Analyzing your site\'s performance...',
        'action' => 'performance_scan'
    ),
    3 => array(
        'title' => 'License Key Scan',
        'description' => 'Scanning for license keys in your installation...',
        'action' => 'license_scan'
    ),
    4 => array(
        'title' => 'Error Scan',
        'description' => 'Checking for errors and warnings...',
        'action' => 'error_scan'
    )
);
?>
HEY!
<div class="wrap">
    <h1><?php echo esc_html(get_admin_page_title()); ?></h1>

    <!-- Progress Bar -->
    <div class="wpi-wizard-progress">
        <div class="wpi-progress-bar">
            <div class="wpi-progress" style="width: <?php echo ($current_step / $total_steps) * 100; ?>%"></div>
        </div>
        <div class="wpi-steps">
            <?php for ($i = 1; $i <= $total_steps; $i++) : ?>
                <div class="wpi-step <?php echo $i <= $current_step ? 'active' : ''; ?>">
                    <div class="wpi-step-number"><?php echo $i; ?></div>
                    <div class="wpi-step-title"><?php echo esc_html($steps[$i]['title']); ?></div>
                </div>
            <?php endfor; ?>
        </div>
    </div>

    <!-- Current Step Content -->
    <div class="wpi-wizard-content">
        <h2><?php echo esc_html($steps[$current_step]['title']); ?></h2>
        <p><?php echo esc_html($steps[$current_step]['description']); ?></p>
        
        <div class="wpi-scan-results" id="scanResults">
            <!-- Results will be loaded here via AJAX -->
            <div class="wpi-loading">
                <span class="spinner is-active"></span>
                <span class="loading-text">Running scan...</span>
            </div>
        </div>

        <!-- Navigation Buttons -->
        <div class="wpi-wizard-buttons">
            <?php if ($current_step > 1) : ?>
                <a href="<?php echo add_query_arg('step', $current_step - 1); ?>" class="button button-secondary">Previous</a>
            <?php endif; ?>
            
            <?php if ($current_step < $total_steps) : ?>
                <a href="<?php echo add_query_arg('step', $current_step + 1); ?>" class="button button-primary next-step" style="display: none;">Next</a>
            <?php else : ?>
                <a href="<?php echo admin_url('admin.php?page=wordpress-inspector'); ?>" class="button button-primary finish-wizard" style="display: none;">Finish</a>
            <?php endif; ?>
        </div>
    </div>
</div>

<style>
.wpi-wizard-progress {
    margin: 30px 0;
}

.wpi-progress-bar {
    height: 8px;
    background: #e5e5e5;
    border-radius: 4px;
    margin-bottom: 20px;
}

.wpi-progress {
    height: 100%;
    background: #2271b1;
    border-radius: 4px;
    transition: width 0.3s ease;
}

.wpi-steps {
    display: flex;
    justify-content: space-between;
}

.wpi-step {
    text-align: center;
    flex: 1;
    max-width: 150px;
}

.wpi-step-number {
    width: 30px;
    height: 30px;
    border-radius: 50%;
    background: #e5e5e5;
    color: #50575e;
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 10px;
}

.wpi-step.active .wpi-step-number {
    background: #2271b1;
    color: #fff;
}

.wpi-step-title {
    font-size: 13px;
    color: #50575e;
}

.wpi-wizard-content {
    background: #fff;
    padding: 20px;
    border: 1px solid #c3c4c7;
    box-shadow: 0 1px 1px rgba(0,0,0,.04);
    margin-top: 20px;
}

.wpi-scan-results {
    min-height: 200px;
    margin: 20px 0;
}

.wpi-loading {
    text-align: center;
    padding: 40px 0;
}

.wpi-loading .spinner {
    float: none;
    margin: 0 10px 0 0;
}

.wpi-wizard-buttons {
    display: flex;
    justify-content: space-between;
    margin-top: 20px;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Start the scan when page loads
    runScan();

    function runScan() {
        var data = {
            'action': '<?php echo $steps[$current_step]['action']; ?>',
            'nonce': '<?php echo wp_create_nonce('wpi_scan_nonce'); ?>'
        };

        $.post(ajaxurl, data, function(response) {
            $('#scanResults').html(response);
            $('.next-step, .finish-wizard').show();
        });
    }
});
</script>
