<?php
/**
 * Reset Information view
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}
?>

<div class="wrap wordpress-inspector">
    <h1>Reset WordPress</h1>

    <div class="inspector-card">
        <h2>Warning</h2>
        <div class="warning-message">
            These actions are irreversible. Please make sure you have a backup before proceeding.
        </div>
    </div>

    <div class="inspector-card">
        <h2>Reset Options</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Reset Content</th>
                <td>
                    <button class="button reset-button" data-action="reset_content">Reset All Content</button>
                    <div class="details warning">Deletes all posts, pages, media, comments, and taxonomies</div>
                </td>
            </tr>
            <tr>
                <th>Reset Users</th>
                <td>
                    <button class="button reset-button" data-action="reset_users">Reset All Users</button>
                    <div class="details warning">Deletes all users except the current administrator</div>
                </td>
            </tr>
            <tr>
                <th>Reset Themes</th>
                <td>
                    <button class="button reset-button" data-action="reset_themes">Reset All Themes</button>
                    <div class="details warning">Deletes all themes except the active theme</div>
                </td>
            </tr>
            <tr>
                <th>Reset Plugins</th>
                <td>
                    <button class="button reset-button" data-action="reset_plugins">Reset All Plugins</button>
                    <div class="details warning">Deactivates and deletes all plugins except WordPress Inspector</div>
                </td>
            </tr>
            <tr>
                <th>Reset Options</th>
                <td>
                    <button class="button reset-button" data-action="reset_options">Reset All Options</button>
                    <div class="details warning">Resets all WordPress options to default values</div>
                </td>
            </tr>
            <tr>
                <th>Factory Reset</th>
                <td>
                    <button class="button reset-button danger" data-action="factory_reset">Factory Reset WordPress</button>
                    <div class="details danger">Complete reset of WordPress to default state</div>
                </td>
            </tr>
        </table>
    </div>
</div>

<style>
.warning-message {
    background-color: #fff3cd;
    color: #856404;
    padding: 15px;
    border-radius: 4px;
    margin-bottom: 15px;
    border: 1px solid #ffeeba;
}

.reset-button {
    background-color: #dc3545 !important;
    border-color: #dc3545 !important;
    color: #fff !important;
}

.reset-button:hover {
    background-color: #c82333 !important;
    border-color: #bd2130 !important;
}

.reset-button.danger {
    background-color: #dc3545 !important;
    border-color: #dc3545 !important;
    color: #fff !important;
    font-weight: bold;
}

.details.warning {
    color: #856404;
}

.details.danger {
    color: #dc3545;
    font-weight: bold;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('.reset-button').on('click', function() {
        const button = $(this);
        const action = button.data('action');
        const originalText = button.text();
        
        // Double confirmation for safety
        if (!confirm('Are you absolutely sure you want to perform this reset action?')) {
            return;
        }
        if (!confirm('This action cannot be undone. Do you really want to proceed?')) {
            return;
        }
        
        button.prop('disabled', true).text('Processing...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_reset',
                reset_action: action,
                nonce: '<?php echo wp_create_nonce('wordpress_inspector_reset'); ?>'
            },
            success: function(response) {
                if (response.success) {
                    const message = $('<span class="success-message">').text('Reset Complete!');
                    button.after(message);
                    setTimeout(() => {
                        message.fadeOut(() => {
                            message.remove();
                            if (action === 'factory_reset') {
                                window.location.href = '<?php echo wp_login_url(); ?>';
                            } else {
                                location.reload();
                            }
                        });
                    }, 2000);
                } else {
                    const message = $('<span class="error-message">').text(response.data || 'Error occurred');
                    button.after(message);
                    setTimeout(() => message.fadeOut(() => message.remove()), 3000);
                    button.prop('disabled', false).text(originalText);
                }
            },
            error: function() {
                const message = $('<span class="error-message">').text('Failed to perform reset');
                button.after(message);
                setTimeout(() => message.fadeOut(() => message.remove()), 3000);
                button.prop('disabled', false).text(originalText);
            }
        });
    });
});
</script> 