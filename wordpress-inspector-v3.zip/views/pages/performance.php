<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
wp_enqueue_style('wordpress-inspector-performance', plugins_url('assets/css/performance.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-performance', plugins_url('assets/js/performance.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));
?>

<div class="wrap wordpress-inspector">
    <h1>Performance</h1>
    
    <div class="performance-container">
        <!-- Cache Section -->
        <div class="section cache-section">
            <h2>Cache Management</h2>
            <!-- Cache controls -->
        </div>

        <!-- Database Optimization -->
        <div class="section database-section">
            <h2>Database Optimization</h2>
            <!-- Database tools -->
        </div>

        <!-- Asset Optimization -->
        <div class="section assets-section">
            <h2>Asset Optimization</h2>
            <!-- Asset management tools -->
        </div>
    </div>
</div> 