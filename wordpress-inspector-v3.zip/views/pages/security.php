<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Get security information
$security_info = WordPress_Inspector_Security_Utils::get_security_info();
$security_score = $security_info['security_score'];

// Group issues by category
$issues_by_category = array();
if (!empty($security_score['issues'])) {
    foreach ($security_score['issues'] as $key => $issue) {
        $category = $issue['category'];
        if (!isset($issues_by_category[$category])) {
            $issues_by_category[$category] = array();
        }
        $issues_by_category[$category][$key] = $issue;
    }
}

// Add at the top of the file after the security info
wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', array(), '3.7.0', true);
?>

<div class="wrap wordpress-inspector">
    <h1>Site Security</h1>

    <!-- Add Rescan Button -->
    <div class="page-title-actions">
        <button type="button" class="button button-primary security-rescan-button">
            <span class="spinner"></span>
            Rescan Security
        </button>
    </div>

    <div class="inspector-card security-score-card">
        <div class="security-score-wrapper">
            <div class="security-score">
                <div class="severity-donut">
                    <canvas id="severityChart"></canvas>
                    <div class="donut-center">
                        <span class="score-number <?php echo strtolower($security_score['grade']); ?>-text">
                            <?php echo $security_score['score']; ?>
                        </span>
                        <span class="score-grade <?php echo strtolower($security_score['grade']); ?>-text">
                            <?php echo $security_score['grade']; ?>
                        </span>
                    </div>
                </div>
            </div>
            
            <?php if (!empty($issues_by_category)): ?>
            <div class="security-issues">
                <h3>Security Issues Found</h3>
                <?php foreach ($issues_by_category as $category => $issues): ?>
                    <div class="security-category">
                        <h4><?php echo esc_html($category); ?></h4>
                        <?php foreach ($issues as $key => $issue): ?>
                        <div class="security-issue-card">
                            <?php if (isset($issue['autofix'])): ?>
                            <div class="issue-quick-fix">
                                <button class="quick-fix-button" 
                                        data-issue-id="<?php echo esc_attr($key); ?>"
                                        data-action="<?php echo esc_attr($issue['autofix']['action']); ?>">
                                    <span class="dashicons dashicons-admin-tools"></span>
                                    <?php echo esc_html($issue['autofix']['button_text']); ?>
                                </button>
                            </div>
                            <?php endif; ?>
                            
                            <div class="issue-content">
                                <div class="issue-header">
                                    <span class="issue-description">
                                        <?php echo esc_html($issue['description']); ?>
                                    </span>
                                    <div class="issue-severity-indicator">
                                        <div class="severity-dots">
                                            <?php for ($i = 1; $i <= 4; $i++): ?>
                                            <span class="severity-dot <?php echo $i <= $issue['severity'] ? 'active' : ''; ?>"></span>
                                            <?php endfor; ?>
                                        </div>
                                    </div>
                                </div>
                                <div class="issue-details">
                                    <div class="details-content">
                                        <h4>Impact</h4>
                                        <p><?php echo esc_html($issue['impact']); ?></p>
                                        <h4>Solution</h4>
                                        <p><?php echo esc_html($issue['solution']); ?></p>
                                    </div>
                                </div>
                            </div>
                            <div class="issue-actions">
                                <button class="issue-toggle" aria-expanded="false">
                                    <span class="dashicons dashicons-arrow-down-alt2"></span>
                                </button>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>
                <?php endforeach; ?>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
jQuery(document).ready(function($) {
    // Calculate severity counts for the donut chart
    const severityCounts = {1: 0, 2: 0, 3: 0, 4: 0};
    <?php 
    if (!empty($security_score['issues'])) {
        foreach ($security_score['issues'] as $issue) {
            echo "severityCounts[{$issue['severity']}]++;\n";
        }
    }
    ?>
    
    // Create donut chart
    const ctx = document.getElementById('severityChart').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Low', 'Medium', 'High', 'Critical'],
            datasets: [{
                data: [
                    severityCounts[1],
                    severityCounts[2],
                    severityCounts[3],
                    severityCounts[4]
                ],
                backgroundColor: [
                    '#4ade80',  // Low
                    '#fbbf24',  // Medium
                    '#f97316',  // High
                    '#dc2626'   // Critical
                ],
                borderWidth: 0
            }]
        },
        options: {
            cutout: '70%',
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    enabled: true
                }
            },
            responsive: true,
            maintainAspectRatio: true
        }
    });

    // Handle issue details toggle
    $('.issue-toggle').on('click', function() {
        const $button = $(this);
        const $card = $button.closest('.security-issue-card');
        const $details = $card.find('.issue-details');
        
        $button.toggleClass('expanded');
        $details.toggleClass('expanded');
        
        $button.attr('aria-expanded', $button.hasClass('expanded'));
    });

    // Handle quick fix buttons
    $('.quick-fix-button').on('click', function() {
        const $button = $(this);
        const issueId = $button.data('issue-id');
        const action = $button.data('action');
        const issue = <?php echo json_encode($security_score['issues']); ?>[issueId];
        
        if (confirm(issue.autofix.confirmation)) {
            $button.prop('disabled', true).addClass('fixing');
            
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: {
                    action: action,
                    nonce: '<?php echo wp_create_nonce("security_fix_nonce"); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Failed to apply fix: ' + response.data.message);
                        $button.prop('disabled', false).removeClass('fixing');
                    }
                },
                error: function() {
                    alert('Failed to apply fix. Please try again.');
                    $button.prop('disabled', false).removeClass('fixing');
                }
            });
        }
    });

    // Handle rescan button
    $('.security-rescan-button').on('click', function() {
        const $button = $(this);
        $button.addClass('scanning');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'run_security_scan',
                nonce: '<?php echo wp_create_nonce("security_scan_nonce"); ?>'
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Error running security scan: ' + (response.data?.message || 'Unknown error'));
                }
            },
            error: function() {
                alert('Failed to run security scan. Please try again.');
            },
            complete: function() {
                $button.removeClass('scanning');
            }
        });
    });
});
</script>

<style>
/* Add any additional styles needed */
.security-category {
    margin-bottom: 20px;
}

.security-category h4 {
    margin: 10px 0;
    padding: 10px;
    background: #f0f0f1;
    border-left: 4px solid #2271b1;
}

.severity-1 { color: #4ade80; }
.severity-2 { color: #fbbf24; }
.severity-3 { color: #f97316; }
.severity-4 { color: #dc2626; }

.quick-fix-button.fixing {
    opacity: 0.7;
    cursor: not-allowed;
}

/* ... existing styles ... */
</style>

