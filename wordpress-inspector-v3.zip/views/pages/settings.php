<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}
?>

<div class="wrap wordpress-inspector">
    <h1>Settings</h1>

    <div class="inspector-card">
        <h2>Display Settings</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Show System Information</th>
                <td>
                    <label class="switch">
                        <input type="checkbox" id="show_system_info" checked>
                        <span class="slider round"></span>
                    </label>
                </td>
            </tr>
            <tr>
                <th>Show Performance Metrics</th>
                <td>
                    <label class="switch">
                        <input type="checkbox" id="show_performance" checked>
                        <span class="slider round"></span>
                    </label>
                </td>
            </tr>
            <tr>
                <th>Show Security Status</th>
                <td>
                    <label class="switch">
                        <input type="checkbox" id="show_security" checked>
                        <span class="slider round"></span>
                    </label>
                </td>
            </tr>
        </table>
    </div>
</div>

<style>
/* Toggle Switch */
.switch {
    position: relative;
    display: inline-block;
    width: 50px;
    height: 24px;
}

.switch input {
    opacity: 0;
    width: 0;
    height: 0;
}

.slider {
    position: absolute;
    cursor: pointer;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: #ccc;
    transition: .4s;
}

.slider:before {
    position: absolute;
    content: "";
    height: 16px;
    width: 16px;
    left: 4px;
    bottom: 4px;
    background-color: white;
    transition: .4s;
}

input:checked + .slider {
    background-color: #2271b1;
}

input:checked + .slider:before {
    transform: translateX(26px);
}

.slider.round {
    border-radius: 24px;
}

.slider.round:before {
    border-radius: 50%;
}
</style> 