<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
wp_enqueue_style('wordpress-inspector-updates', plugins_url('assets/css/updates.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-updates', plugins_url('assets/js/updates.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery'));

// Get current auto-update settings
$core_updates = get_site_option('auto_update_core', 'enabled');
$plugin_updates = get_site_option('auto_update_plugins', array());
$theme_updates = get_site_option('auto_update_themes', array());
$translation_updates = get_site_option('auto_update_translations', true);
$email_updates = get_site_option('auto_core_update_send_email', true);

?>

<div class="wrap wordpress-inspector">
    <h1>Updates Manager</h1>
    
    <!-- Quick Actions -->
    <div class="update-section quick-actions">
        <h2>Quick Actions</h2>
        <div class="section-content">
            <div class="action-buttons">
                <button type="button" class="button button-primary disable-all-updates">
                    <span class="dashicons dashicons-dismiss"></span>
                    Disable All Updates
                </button>
                <button type="button" class="button button-primary enable-all-updates">
                    <span class="dashicons dashicons-yes"></span>
                    Enable All Updates
                </button>
                <button type="button" class="button button-secondary force-updates-check">
                    <span class="dashicons dashicons-update"></span>
                    Force Updates Check
                </button>
                <button type="button" class="button button-secondary generate-report">
                    <span class="dashicons dashicons-media-spreadsheet"></span>
                    Generate Report
                </button>
            </div>
            
            <?php
            // Check for update control overrides
            $overrides = WordPress_Inspector_Updates_Utils::check_update_overrides();
            if (!empty($overrides)): ?>
                <div class="update-warning">
                    <p><strong>Warning:</strong> The following settings may override your update controls:</p>
                    <ul>
                        <?php foreach ($overrides as $override): ?>
                            <li><?php echo esc_html($override); ?></li>
                        <?php endforeach; ?>
                    </ul>
                    <div class="override-actions">
                        <button type="button" class="button button-secondary remove-update-filter">
                            Remove Automatic Update Filter
                        </button>
                        <p class="description">
                            This will attempt to remove the automatic_updater_disabled filter. 
                            You may need to modify your wp-config.php file for constant overrides.
                        </p>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="updates-container">
        <!-- Core Updates Section -->
        <div class="update-section card">
            <h2>WordPress Core Updates</h2>
            <div class="section-content">
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="core_updates" <?php checked($core_updates !== 'disabled'); ?>>
                        Enable automatic updates for WordPress core
                    </label>
                    <p class="description">Controls whether WordPress will automatically update to new minor and security releases.</p>
                </div>
                
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="email_updates" <?php checked($email_updates); ?>>
                        Receive emails about automatic updates
                    </label>
                    <p class="description">Get notified when WordPress automatically updates.</p>
                </div>
            </div>
        </div>

        <!-- Plugin Updates Section -->
        <div class="update-section card">
            <h2>Plugin Updates</h2>
            <div class="section-content">
                <div class="bulk-actions">
                    <button type="button" class="button enable-all-plugins">Enable All</button>
                    <button type="button" class="button disable-all-plugins">Disable All</button>
                </div>
                
                <div class="plugins-list">
                    <?php
                    $all_plugins = get_plugins();
                    foreach ($all_plugins as $plugin_file => $plugin_data) {
                        $plugin_name = $plugin_data['Name'];
                        $is_active = is_plugin_active($plugin_file);
                        $auto_update = in_array($plugin_file, $plugin_updates);
                        ?>
                        <div class="plugin-item <?php echo $is_active ? 'active' : 'inactive'; ?>">
                            <label>
                                <input type="checkbox" 
                                       name="plugin_updates[]" 
                                       value="<?php echo esc_attr($plugin_file); ?>"
                                       <?php checked($auto_update); ?>>
                                <?php echo esc_html($plugin_name); ?>
                                <?php if (!$is_active) echo ' (Inactive)'; ?>
                            </label>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Theme Updates Section -->
        <div class="update-section card">
            <h2>Theme Updates</h2>
            <div class="section-content">
                <div class="bulk-actions">
                    <button type="button" class="button enable-all-themes">Enable All</button>
                    <button type="button" class="button disable-all-themes">Disable All</button>
                </div>
                
                <div class="themes-list">
                    <?php
                    $all_themes = wp_get_themes();
                    foreach ($all_themes as $theme_slug => $theme_data) {
                        $theme_name = $theme_data->get('Name');
                        $is_active = ($theme_slug === get_stylesheet());
                        $auto_update = in_array($theme_slug, $theme_updates);
                        ?>
                        <div class="theme-item <?php echo $is_active ? 'active' : 'inactive'; ?>">
                            <label>
                                <input type="checkbox" 
                                       name="theme_updates[]" 
                                       value="<?php echo esc_attr($theme_slug); ?>"
                                       <?php checked($auto_update); ?>>
                                <?php echo esc_html($theme_name); ?>
                                <?php if ($is_active) echo ' (Active)'; ?>
                            </label>
                        </div>
                        <?php
                    }
                    ?>
                </div>
            </div>
        </div>

        <!-- Translation Updates Section -->
        <div class="update-section card">
            <h2>Translation Updates</h2>
            <div class="section-content">
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="translation_updates" <?php checked($translation_updates); ?>>
                        Enable automatic translation updates
                    </label>
                    <p class="description">Automatically update translations for WordPress core, themes, and plugins.</p>
                </div>
            </div>
        </div>

        <!-- Plugin Health Section -->
        <div class="update-section card">
            <h2>Plugin Health Check</h2>
            <div class="section-content">
                <div class="plugin-health-list">
                    <?php
                    $plugin_health = WordPress_Inspector_Updates_Utils::check_plugins_health();
                    if (!empty($plugin_health['unmaintained']) || !empty($plugin_health['compatibility_issues'])): ?>
                        <div class="health-warning">
                            <?php if (!empty($plugin_health['unmaintained'])): ?>
                                <h3>Unmaintained Plugins</h3>
                                <ul>
                                    <?php foreach ($plugin_health['unmaintained'] as $plugin): ?>
                                        <li><?php echo esc_html($plugin['name']); ?> - Not found in WordPress.org repository</li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                            
                            <?php if (!empty($plugin_health['compatibility_issues'])): ?>
                                <h3>Compatibility Issues</h3>
                                <ul>
                                    <?php foreach ($plugin_health['compatibility_issues'] as $plugin): ?>
                                        <li>
                                            <?php echo esc_html($plugin['name']); ?> - 
                                            Last tested with WordPress <?php echo esc_html($plugin['tested']); ?>
                                        </li>
                                    <?php endforeach; ?>
                                </ul>
                            <?php endif; ?>
                        </div>
                    <?php else: ?>
                        <p class="health-good">All plugins appear to be well-maintained and compatible.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Advanced Settings Section -->
        <div class="update-section card">
            <h2>Advanced Settings</h2>
            <div class="section-content">
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="delay_updates">
                        Delay updates by 
                        <select name="delay_days">
                            <option value="1">1 day</option>
                            <option value="2">2 days</option>
                            <option value="7">1 week</option>
                            <option value="14">2 weeks</option>
                        </select>
                    </label>
                </div>
                
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="schedule_updates">
                        Schedule updates for 
                        <select name="schedule_time">
                            <option value="midnight">Midnight</option>
                            <option value="early_morning">Early Morning (3 AM)</option>
                            <option value="morning">Morning (6 AM)</option>
                            <option value="evening">Evening (8 PM)</option>
                        </select>
                    </label>
                </div>
                
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="email_reports">
                        Send update reports
                        <select name="report_frequency">
                            <option value="weekly">Weekly</option>
                            <option value="monthly">Monthly</option>
                        </select>
                    </label>
                </div>
                
                <div class="update-option">
                    <label>
                        <input type="checkbox" name="auto_clear_logs">
                        Automatically clear logs older than
                        <select name="log_retention">
                            <option value="30">30 days</option>
                            <option value="60">60 days</option>
                            <option value="90">90 days</option>
                        </select>
                    </label>
                </div>
            </div>
        </div>

        <!-- Update Logs Section -->
        <div class="update-section card logs-section">
            <h2>Update Logs</h2>
            <div class="section-content">
                <div class="log-controls">
                    <div class="search-filters">
                        <input type="text" id="log-search" placeholder="Search logs...">
                        <select id="log-type">
                            <option value="">All Types</option>
                            <option value="core">Core</option>
                            <option value="plugin">Plugins</option>
                            <option value="theme">Themes</option>
                        </select>
                    </div>
                    <div class="date-filters">
                        <div class="date-range">
                            <label>From:</label>
                            <input type="date" id="log-date-start">
                            <label>To:</label>
                            <input type="date" id="log-date-end">
                        </div>
                    </div>
                    <div class="log-actions">
                        <button type="button" class="button export-logs">Export Logs</button>
                    </div>
                </div>
                
                <div class="logs-table-wrapper">
                    <table class="wp-list-table widefat fixed striped">
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Item</th>
                                <th>Version</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="update-logs">
                            <!-- Logs will be loaded here via AJAX -->
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        <div class="submit-section">
            <button type="button" class="button button-primary save-updates-settings">Save Changes</button>
        </div>
    </div>
</div> 