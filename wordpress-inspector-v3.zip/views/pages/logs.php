<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
$css_file = WPI_PLUGIN_DIR . 'assets/css/logs.css';
wp_enqueue_style('wordpress-inspector-logs', plugins_url('assets/css/logs.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array(), filemtime($css_file));

// Add JS
$js_file = WPI_PLUGIN_DIR . 'assets/js/logs.js';
wp_enqueue_script('wordpress-inspector-logs', plugins_url('assets/js/logs.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'), array('jquery'), filemtime($js_file));
wp_localize_script('wordpress-inspector-logs', 'wordpress_inspector', array(
    'nonce' => wp_create_nonce('wordpress_inspector_nonce')
));

?>

<div class="wrap wordpress-inspector">
    <div class="log-quick-nav">
        <div class="quick-nav-header">Logs Quickview</div>
        <div class="quick-nav-items">
            <a href="#debug-log" class="quick-nav-item">
                <span class="log-name">Debug Log</span>
                <?php if (file_exists(WP_CONTENT_DIR . '/debug.log')): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize(WP_CONTENT_DIR . '/debug.log')); ?></span>
                <?php endif; ?>
            </a>

            <a href="#php-error-log" class="quick-nav-item">
                <span class="log-name">PHP Error Log</span>
                <?php if (file_exists(ini_get('error_log'))): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize(ini_get('error_log'))); ?></span>
                <?php endif; ?>
            </a>

            <a href="#mysql-error-log" class="quick-nav-item">
                <span class="log-name">MySQL Error Log</span>
                <?php 
                global $wpdb;
                $mysql_error_log = $wpdb->get_var("SHOW VARIABLES LIKE 'log_error'", 1);
                if ($mysql_error_log && file_exists($mysql_error_log)): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize($mysql_error_log)); ?></span>
                <?php endif; ?>
            </a>

            <a href="#slow-query-log" class="quick-nav-item">
                <span class="log-name">Slow Query Log</span>
                <?php 
                $slow_query_log = $wpdb->get_var("SHOW VARIABLES LIKE 'slow_query_log_file'", 1);
                if ($slow_query_log && file_exists($slow_query_log)): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize($slow_query_log)); ?></span>
                <?php endif; ?>
                <span class="log-quick-status">
                    <?php 
                    if (WordPress_Inspector_DB_Utils::has_super_privileges()) {
                        echo $slow_log_enabled == 'ON' ? 
                            '<span class="status-enabled">Enabled</span>' : 
                            '<span class="status-disabled">Disabled</span>';
                    } else {
                        echo '<span class="status-restricted">Requires MySQL SUPER privileges</span>';
                    }
                    ?>
                </span>
            </a>

            <a href="#access-log" class="quick-nav-item">
                <span class="log-name">Access Log</span>
                <?php 
                $access_log = '';
                if (stripos($_SERVER['SERVER_SOFTWARE'], 'apache') !== false) {
                    $access_log = shell_exec('apache2ctl -S 2>&1 | grep "access.log"');
                } elseif (stripos($_SERVER['SERVER_SOFTWARE'], 'nginx') !== false) {
                    $access_log = '/var/log/nginx/access.log';
                }
                if ($access_log && file_exists($access_log)): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize($access_log)); ?></span>
                <?php endif; ?>
            </a>

            <a href="#server-error-log" class="quick-nav-item">
                <span class="log-name">Server Error Log</span>
                <?php 
                $error_log = '';
                if (stripos($_SERVER['SERVER_SOFTWARE'], 'apache') !== false) {
                    $error_log = shell_exec('apache2ctl -S 2>&1 | grep "error.log"');
                } elseif (stripos($_SERVER['SERVER_SOFTWARE'], 'nginx') !== false) {
                    $error_log = '/var/log/nginx/error.log';
                }
                if ($error_log && file_exists($error_log)): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize($error_log)); ?></span>
                <?php endif; ?>
            </a>

            <a href="#htaccess" class="quick-nav-item">
                <span class="log-name">.htaccess</span>
                <?php if (file_exists(ABSPATH . '.htaccess')): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize(ABSPATH . '.htaccess')); ?></span>
                <?php endif; ?>
            </a>

            <a href="#cron-log" class="quick-nav-item">
                <span class="log-name">Cron Log</span>
                <?php if (file_exists(WP_CONTENT_DIR . '/cron.log')): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize(WP_CONTENT_DIR . '/cron.log')); ?></span>
                <?php endif; ?>
                <span class="log-quick-status <?php echo defined('WP_CRON_LOGGING') && WP_CRON_LOGGING ? 'status-enabled' : 'status-disabled'; ?>">
                    <?php echo defined('WP_CRON_LOGGING') && WP_CRON_LOGGING ? 'Enabled' : 'Disabled'; ?>
                </span>
            </a>

            <a href="#email-log" class="quick-nav-item">
                <span class="log-name">Email Log</span>
                <?php if (file_exists(WP_CONTENT_DIR . '/email.log')): ?>
                    <span class="log-quick-size"><?php echo size_format(filesize(WP_CONTENT_DIR . '/email.log')); ?></span>
                <?php endif; ?>
                <span class="log-quick-status <?php echo defined('WP_EMAIL_LOGGING') && WP_EMAIL_LOGGING ? 'status-enabled' : 'status-disabled'; ?>">
                    <?php echo defined('WP_EMAIL_LOGGING') && WP_EMAIL_LOGGING ? 'Enabled' : 'Disabled'; ?>
                </span>
            </a>
        </div>
    </div>

    <div class="dashboard-row">
        <div id="debug-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>WordPress Debug Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo defined('WP_DEBUG_LOG') && is_string(WP_DEBUG_LOG) ? WP_DEBUG_LOG : WP_CONTENT_DIR . '/debug.log'; ?></span>
                            </div>
                            <?php if (file_exists(WP_CONTENT_DIR . '/debug.log')): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize(WP_CONTENT_DIR . '/debug.log')); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        $debug_log = WP_CONTENT_DIR . '/debug.log';
                        if (file_exists($debug_log)) {
                            $log_content = file_get_contents($debug_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Debug log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">Debug log file not found.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="php-error-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>PHP Error Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo ini_get('error_log') ?: 'Not configured'; ?></span>
                            </div>
                            <?php if (file_exists(ini_get('error_log'))): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize(ini_get('error_log'))); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(ini_get('error_log')) ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(ini_get('error_log')) ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        $error_log = ini_get('error_log');
                        if (file_exists($error_log)) {
                            $log_content = file_get_contents($error_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Error log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">Error log file not found.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="mysql-error-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>MySQL Error Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace">
                                    <?php 
                                    global $wpdb;
                                    $mysql_error_log = $wpdb->get_var("SHOW VARIABLES LIKE 'log_error'", 1);
                                    echo $mysql_error_log ?: 'Not configured';
                                    ?>
                                </span>
                            </div>
                            <?php if ($mysql_error_log && file_exists($mysql_error_log)): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize($mysql_error_log)); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        if ($mysql_error_log && file_exists($mysql_error_log)) {
                            $log_content = file_get_contents($mysql_error_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">MySQL error log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">MySQL error log file not found or not accessible.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="slow-query-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>MySQL Slow Query Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo $slow_query_log ?: 'Not configured'; ?></span>
                            </div>
                            <?php if ($slow_query_log && file_exists($slow_query_log)): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize($slow_query_log)); ?>
                                </div>
                            <?php endif; ?>
                            <div class="log-status">
                                Status: 
                                <?php 
                                if (WordPress_Inspector_DB_Utils::has_super_privileges()) {
                                    echo $slow_log_enabled == 'ON' ? 
                                        '<span class="status-enabled">Enabled</span>' : 
                                        '<span class="status-disabled">Disabled</span>';
                                } else {
                                    echo '<span class="status-restricted">Requires MySQL SUPER privileges</span>';
                                }
                                ?>
                            </div>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !$slow_query_log || !file_exists($slow_query_log) ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !$slow_query_log || !file_exists($slow_query_log) ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        if (!WordPress_Inspector_DB_Utils::has_super_privileges()) {
                            echo '<div class="log-not-found">
                                MySQL SUPER privileges are required to configure and view the slow query log.<br><br>
                                Contact your hosting provider or database administrator to enable these privileges.
                            </div>';
                        } elseif ($slow_query_log && file_exists($slow_query_log)) {
                            $log_content = file_get_contents($slow_query_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Slow query log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">Slow query log file not found or not configured.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="access-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>Web Server Access Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace">
                                    <?php 
                                    $access_log = '';
                                    if (stripos($_SERVER['SERVER_SOFTWARE'], 'apache') !== false) {
                                        $access_log = shell_exec('apache2ctl -S 2>&1 | grep "access.log"');
                                    } elseif (stripos($_SERVER['SERVER_SOFTWARE'], 'nginx') !== false) {
                                        $access_log = '/var/log/nginx/access.log';
                                    }
                                    echo $access_log ?: 'Not accessible';
                                    ?>
                                </span>
                            </div>
                            <?php if ($access_log && file_exists($access_log)): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize($access_log)); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        if ($access_log && file_exists($access_log) && is_readable($access_log)) {
                            $log_content = shell_exec('tail -n 1000 ' . escapeshellarg($access_log));
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Access log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">Access log file not found or not accessible.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="server-error-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>Web Server Error Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace">
                                    <?php 
                                    $error_log = '';
                                    if (stripos($_SERVER['SERVER_SOFTWARE'], 'apache') !== false) {
                                        $error_log = shell_exec('apache2ctl -S 2>&1 | grep "error.log"');
                                    } elseif (stripos($_SERVER['SERVER_SOFTWARE'], 'nginx') !== false) {
                                        $error_log = '/var/log/nginx/error.log';
                                    }
                                    echo $error_log ?: 'Not accessible';
                                    ?>
                                </span>
                            </div>
                            <?php if ($error_log && file_exists($error_log)): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize($error_log)); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        if ($error_log && file_exists($error_log) && is_readable($error_log)) {
                            $log_content = shell_exec('tail -n 1000 ' . escapeshellarg($error_log));
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Error log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">Error log file not found or not accessible.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="htaccess" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>.htaccess File</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo ABSPATH . '.htaccess'; ?></span>
                            </div>
                            <?php if (file_exists(ABSPATH . '.htaccess')): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize(ABSPATH . '.htaccess')); ?>
                                </div>
                            <?php endif; ?>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button download-log" <?php echo !file_exists(ABSPATH . '.htaccess') ? 'disabled' : ''; ?>>Download File</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        $htaccess_file = ABSPATH . '.htaccess';
                        if (file_exists($htaccess_file) && is_readable($htaccess_file)) {
                            $content = file_get_contents($htaccess_file);
                            if (!empty($content)) {
                                echo '<pre class="log-output">' . esc_html($content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">.htaccess file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">.htaccess file not found or not accessible.</div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="cron-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>WordPress Cron Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo WP_CONTENT_DIR . '/cron.log'; ?></span>
                            </div>
                            <?php if (file_exists(WP_CONTENT_DIR . '/cron.log')): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize(WP_CONTENT_DIR . '/cron.log')); ?>
                                </div>
                            <?php endif; ?>
                            <div class="log-status">
                                Status: 
                                <?php 
                                // Force reload of wp-config.php
                                if (function_exists('opcache_invalidate')) {
                                    opcache_invalidate(ABSPATH . 'wp-config.php', true);
                                }
                                
                                $cron_status = defined('WP_CRON_LOGGING') && WP_CRON_LOGGING;
                                //error_log('Current Cron Status: ' . ($cron_status ? 'true' : 'false'));
                                echo !$cron_status ? 
                                    '<span class="status-disabled">Disabled</span>' : 
                                    '<span class="status-enabled">Enabled</span>';
                                ?>
                                <button type="button" class="button toggle-logging" data-type="cron" data-status="<?php echo $cron_status ? '1' : '0'; ?>">
                                    <?php echo $cron_status ? 'Disable' : 'Enable'; ?> Logging
                                </button>
                            </div>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        $cron_log = WP_CONTENT_DIR . '/cron.log';
                        if (file_exists($cron_log) && is_readable($cron_log)) {
                            $log_content = file_get_contents($cron_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Cron log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">
                                Cron log file not found. Add the following to wp-config.php to enable cron logging:<br><br>
                                <code>define("WP_CRON_LOGGING", true);</code>
                            </div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>

        <div id="email-log" class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>WordPress Email Log</h2>
                <div class="card-content">
                    <div class="log-header">
                        <div class="log-info">
                            <div class="log-path">
                                File Location: 
                                <span class="monospace"><?php echo WP_CONTENT_DIR . '/email.log'; ?></span>
                            </div>
                            <?php if (file_exists(WP_CONTENT_DIR . '/email.log')): ?>
                                <div class="log-size">
                                    File Size: <?php echo size_format(filesize(WP_CONTENT_DIR . '/email.log')); ?>
                                </div>
                            <?php endif; ?>
                            <div class="log-status">
                                Status: 
                                <?php 
                                $email_logging = defined('WP_EMAIL_LOGGING') && WP_EMAIL_LOGGING;
                                echo $email_logging ? 
                                    '<span class="status-enabled">Enabled</span>' : 
                                    '<span class="status-disabled">Disabled</span>';
                                ?>
                                <button type="button" class="button toggle-logging" data-type="email" data-status="<?php echo $email_logging ? '1' : '0'; ?>">
                                    <?php echo $email_logging ? 'Disable' : 'Enable'; ?> Logging
                                </button>
                            </div>
                        </div>
                        <div class="log-actions">
                            <button type="button" class="button clear-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Clear Log</button>
                            <button type="button" class="button download-log" <?php echo !file_exists(WP_CONTENT_DIR . '/debug.log') ? 'disabled' : ''; ?>>Download Log</button>
                        </div>
                    </div>
                    <div class="log-content">
                        <?php
                        $email_log = WP_CONTENT_DIR . '/email.log';
                        if (file_exists($email_log) && is_readable($email_log)) {
                            $log_content = file_get_contents($email_log);
                            if (!empty($log_content)) {
                                echo '<pre class="log-output">' . esc_html($log_content) . '</pre>';
                            } else {
                                echo '<div class="log-empty">Email log file is empty.</div>';
                            }
                        } else {
                            echo '<div class="log-not-found">
                                Email log file not found. Add the following to wp-config.php to enable email logging:<br><br>
                                <code>define("WP_EMAIL_LOGGING", true);</code>
                            </div>';
                        }
                        ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>