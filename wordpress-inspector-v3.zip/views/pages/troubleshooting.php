<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add CSS
wp_enqueue_style('wordpress-inspector-troubleshooting', plugins_url('assets/css/troubleshooting.css', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add JS
wp_enqueue_script('wordpress-inspector-troubleshooting', plugins_url('assets/js/troubleshooting.js', WPI_PLUGIN_DIR . 'wordpress-inspector.php'));

// Add ThickBox support
wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');

// Get debug settings
$debug_mode = defined('WP_DEBUG') && WP_DEBUG;
$debug_log = defined('WP_DEBUG_LOG') && WP_DEBUG_LOG;
$debug_display = defined('WP_DEBUG_DISPLAY') && WP_DEBUG_DISPLAY;
$script_debug = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG;
?>

<div class="wrap wordpress-inspector">
    <h1>Troubleshooting</h1>
    
    <div class="troubleshooting-container">
        <!-- Debug Section -->
        <div class="section debug-section">
            <h2>Debug Tools</h2>
            <div class="card">
                <h3>WordPress Debug Mode</h3>
                <table class="inspector-info-table">
                    <tr>
                        <th>Debug Mode</th>
                        <td>
                            <a href="#TB_inline?width=600&height=300&inlineId=tooltip-wp-debug" 
                               class="thickbox dashicons dashicons-editor-help"
                               title="WP_DEBUG"></a>
                            <div class="toggle-wrapper">
                                <label class="toggle-switch">
                                    <input type="checkbox" 
                                           class="debug-toggle" 
                                           data-setting="WP_DEBUG" 
                                           <?php echo $debug_mode ? 'checked' : ''; ?>>
                                    <span class="slider round"></span>
                                </label>
                                <span class="toggle-status">
                                    <?php echo $debug_mode ? 
                                        '<span class="status-indicator enabled">Enabled</span>' : 
                                        '<span class="status-indicator disabled">Disabled</span>'; ?>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Debug Log</th>
                        <td>
                            <a href="#TB_inline?width=600&height=300&inlineId=tooltip-debug-log" 
                               class="thickbox dashicons dashicons-editor-help"
                               title="WP_DEBUG_LOG"></a>
                            <div class="toggle-wrapper">
                                <label class="toggle-switch">
                                    <input type="checkbox" 
                                           class="debug-toggle" 
                                           data-setting="WP_DEBUG_LOG" 
                                           <?php echo $debug_log ? 'checked' : ''; ?>>
                                    <span class="slider round"></span>
                                </label>
                                <span class="toggle-status">
                                    <?php echo $debug_log ? 
                                        '<span class="status-indicator enabled">Enabled</span>' : 
                                        '<span class="status-indicator disabled">Disabled</span>'; ?>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Debug Display</th>
                        <td>
                            <a href="#TB_inline?width=600&height=300&inlineId=tooltip-debug-display" 
                               class="thickbox dashicons dashicons-editor-help"
                               title="WP_DEBUG_DISPLAY"></a>
                            <div class="toggle-wrapper">
                                <label class="toggle-switch">
                                    <input type="checkbox" 
                                           class="debug-toggle" 
                                           data-setting="WP_DEBUG_DISPLAY" 
                                           <?php echo $debug_display ? 'checked' : ''; ?>>
                                    <span class="slider round"></span>
                                </label>
                                <span class="toggle-status">
                                    <?php echo $debug_display ? 
                                        '<span class="status-indicator enabled">Enabled</span>' : 
                                        '<span class="status-indicator disabled">Disabled</span>'; ?>
                                </span>
                            </div>
                        </td>
                    </tr>
                    <tr>
                        <th>Script Debug</th>
                        <td>
                            <a href="#TB_inline?width=600&height=300&inlineId=tooltip-script-debug" 
                               class="thickbox dashicons dashicons-editor-help"
                               title="SCRIPT_DEBUG"></a>
                            <div class="toggle-wrapper">
                                <label class="toggle-switch">
                                    <input type="checkbox" 
                                           class="debug-toggle" 
                                           data-setting="SCRIPT_DEBUG" 
                                           <?php echo $script_debug ? 'checked' : ''; ?>>
                                    <span class="slider round"></span>
                                </label>
                                <span class="toggle-status">
                                    <?php echo $script_debug ? 
                                        '<span class="status-indicator enabled">Enabled</span>' : 
                                        '<span class="status-indicator disabled">Disabled</span>'; ?>
                                </span>
                            </div>
                        </td>
                    </tr>
                </table>
            </div>
            
            <div class="card">
                <h3>Error Log Viewer</h3>
                <!-- Error log content -->
            </div>
        </div>

        <!-- System Checks Section -->
        <div class="section checks-section">
            <h2>System Checks</h2>
            <!-- System diagnostics -->
        </div>
    </div>
</div>

<!-- Add tooltip divs -->
<div id="tooltip-wp-debug" style="display:none;">
    <p>WP_DEBUG is a PHP constant that enables WordPress debug mode. When enabled, it shows all errors, notices, and warnings.</p>
</div>

<div id="tooltip-debug-log" style="display:none;">
    <p>WP_DEBUG_LOG enables logging of all errors to a debug.log file in the wp-content directory.</p>
</div>

<div id="tooltip-debug-display" style="display:none;">
    <p>Controls whether debug messages are shown in the HTML of your pages. Should be disabled on production sites.</p>
</div>

<div id="tooltip-script-debug" style="display:none;">
    <p>Forces WordPress to use development versions of core CSS and JavaScript files. Useful for debugging core WordPress features.</p>
</div> 