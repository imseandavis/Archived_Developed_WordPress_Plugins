<?php
/**
 * Plugins Information view
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Add required scripts
wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');
?>

<div class="wrap wordpress-inspector">
    <h1>Plugins Information</h1>
    
    <div class="inspector-card">
        <h2>Active Plugins</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Plugin Name</th>
                <th>Version</th>
                <th>Author</th>
                <th>Auto Update</th>
                <th>Actions</th>
            </tr>
            <?php
            try {
                $active_plugins = get_option('active_plugins');
                foreach($active_plugins as $plugin) {
                    $plugin_data = get_plugin_data(WP_PLUGIN_DIR . '/' . $plugin);
                    $auto_update = in_array($plugin, (array) get_site_option('auto_update_plugins', array()));
                    ?>
                    <tr id="plugin-<?php echo esc_attr(dirname($plugin)); ?>">
                        <td>
                            <?php 
                            $details_url = add_query_arg(array(
                                'tab' => 'plugin-information',
                                'plugin' => dirname($plugin),
                                'TB_iframe' => 'true',
                                'width' => '600',
                                'height' => '550'
                            ), admin_url('plugin-install.php'));
                            ?>
                            <a href="<?php echo esc_url($details_url); ?>" 
                               class="thickbox open-plugin-details-modal" 
                               title="<?php echo esc_attr($plugin_data['Name']); ?>">
                                <?php echo esc_html($plugin_data['Name']); ?>
                            </a>
                        </td>
                        <td><?php echo esc_html($plugin_data['Version']); ?></td>
                        <td>
                            <?php 
                            if (!empty($plugin_data['AuthorURI'])) {
                                $author_name = strip_tags($plugin_data['Author']);
                                echo '<a href="' . esc_url($plugin_data['AuthorURI']) . '" target="_blank">' . esc_html($author_name) . '</a>';
                            } else {
                                echo esc_html(strip_tags($plugin_data['Author']));
                            }
                            ?>
                        </td>
                        <td>
                            <?php if (defined('WP_AUTO_UPDATE_CORE') && WP_AUTO_UPDATE_CORE === true): ?>
                                <button class="button toggle-auto-update" 
                                    data-plugin="<?php echo esc_attr($plugin); ?>"
                                    data-nonce="<?php echo wp_create_nonce('toggle_auto_update_' . $plugin); ?>"
                                    data-state="<?php echo $auto_update ? '1' : '0'; ?>">
                                    <?php echo $auto_update ? 'Disable Auto Update' : 'Enable Auto Update'; ?>
                                </button>
                            <?php else: ?>
                                <span class="auto-update-disabled">
                                    <a href="<?php echo admin_url('admin.php?page=inspector-server'); ?>" class="update-settings-link">
                                        Updates Set To <?php echo defined('WP_AUTO_UPDATE_CORE') ? 
                                            (WP_AUTO_UPDATE_CORE === 'minor' ? 'Minor Only' : 'Disabled') : 
                                            'Disabled'; ?>
                                    </a>
                                </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="plugin-actions">
                                <button class="button deactivate-plugin" 
                                    data-plugin="<?php echo esc_attr($plugin); ?>"
                                    data-nonce="<?php echo wp_create_nonce('deactivate_plugin_' . $plugin); ?>">
                                    Deactivate
                                </button>
                            </div>
                        </td>
                    </tr>
                    <?php
                }
            } catch (Exception $e) {
                ?>
                <tr>
                    <td colspan="5" class="error">
                        <?php echo esc_html($e->getMessage()); ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>

    <div class="inspector-card">
        <h2>Inactive Plugins</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Plugin Name</th>
                <th>Version</th>
                <th>Author</th>
                <th>Actions</th>
            </tr>
            <?php
            try {
                $all_plugins = get_plugins();
                foreach($all_plugins as $plugin_path => $plugin_data) {
                    if (!in_array($plugin_path, $active_plugins)) {
                        ?>
                        <tr id="plugin-<?php echo esc_attr(dirname($plugin_path)); ?>">
                            <td>
                                <?php 
                                $details_url = add_query_arg(array(
                                    'tab' => 'plugin-information',
                                    'plugin' => dirname($plugin_path),
                                    'TB_iframe' => 'true',
                                    'width' => '600',
                                    'height' => '550'
                                ), admin_url('plugin-install.php'));
                                ?>
                                <a href="<?php echo esc_url($details_url); ?>" 
                                   class="thickbox open-plugin-details-modal" 
                                   title="<?php echo esc_attr($plugin_data['Name']); ?>">
                                    <?php echo esc_html($plugin_data['Name']); ?>
                                </a>
                            </td>
                            <td><?php echo esc_html($plugin_data['Version']); ?></td>
                            <td>
                                <?php 
                                if (!empty($plugin_data['AuthorURI'])) {
                                    $author_name = strip_tags($plugin_data['Author']);
                                    echo '<a href="' . esc_url($plugin_data['AuthorURI']) . '" target="_blank">' . esc_html($author_name) . '</a>';
                                } else {
                                    echo esc_html(strip_tags($plugin_data['Author']));
                                }
                                ?>
                            </td>
                            <td>
                                <div class="plugin-actions">
                                    <button class="button activate-plugin" 
                                        data-plugin="<?php echo esc_attr($plugin_path); ?>"
                                        data-nonce="<?php echo wp_create_nonce('activate_plugin_' . $plugin_path); ?>">
                                        Activate
                                    </button>
                                    <button class="button delete-plugin" 
                                        data-plugin="<?php echo esc_attr($plugin_path); ?>"
                                        data-nonce="<?php echo wp_create_nonce('delete_plugin_' . $plugin_path); ?>">
                                        Delete
                                    </button>
                                </div>
                            </td>
                        </tr>
                        <?php
                    }
                }
            } catch (Exception $e) {
                ?>
                <tr>
                    <td colspan="4" class="error">
                        <?php echo esc_html($e->getMessage()); ?>
                    </td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
</div> 

<style>
.error {
    color: #d63638;
}
.plugin-actions {
    display: flex;
    gap: 8px;
}
.deactivate-plugin {
    background: #2271b1 !important;
    border-color: #2271b1 !important;
    color: #fff !important;
}
.deactivate-plugin:hover {
    background: #135e96 !important;
    border-color: #135e96 !important;
    color: #fff !important;
}
.delete-plugin {
    background: #d63638 !important;
    border-color: #d63638 !important;
    color: #fff !important;
}
.delete-plugin:hover {
    background: #b32d2e !important;
    border-color: #b32d2e !important;
    color: #fff !important;
}
.activate-plugin {
    background: #2271b1 !important;
    border-color: #2271b1 !important;
    color: #fff !important;
}
.activate-plugin:hover {
    background: #135e96 !important;
    border-color: #135e96 !important;
    color: #fff !important;
}
.open-plugin-details-modal {
    text-decoration: none;
    color: #2271b1;
}
.open-plugin-details-modal:hover {
    color: #135e96;
    text-decoration: underline;
}
.auto-update-disabled {
    color: #666;
    font-style: italic;
}
.update-settings-link {
    color: #666;
    text-decoration: none;
}

.update-settings-link:hover {
    color: #2271b1;
    text-decoration: underline;
}
</style>

<script>
jQuery(document).ready(function($) {
    $('.deactivate-plugin').on('click', function() {
        const button = $(this);
        const plugin = button.data('plugin');
        const nonce = button.data('nonce');
        
        if (!confirm('Are you sure you want to deactivate this plugin?')) {
            return;
        }
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'deactivate_plugin',
                plugin: plugin,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data || 'Failed to deactivate plugin.');
                    button.prop('disabled', false);
                }
            },
            error: function() {
                alert('Failed to deactivate plugin. Please try again.');
                button.prop('disabled', false);
            }
        });
    });

    $('.delete-plugin').on('click', function() {
        const button = $(this);
        const plugin = button.data('plugin');
        const nonce = button.data('nonce');
        
        if (!confirm('Are you sure you want to delete this plugin? This cannot be undone!')) {
            return;
        }
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_plugin',
                plugin: plugin,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    $('#plugin-' + plugin.replace('/', '-')).fadeOut(400, function() {
                        $(this).remove();
                    });
                } else {
                    alert(response.data || 'Failed to delete plugin.');
                    button.prop('disabled', false);
                }
            },
            error: function() {
                alert('Failed to delete plugin. Please try again.');
                button.prop('disabled', false);
            }
        });
    });

    $('.toggle-auto-update').on('click', function() {
        const button = $(this);
        const plugin = button.data('plugin');
        const nonce = button.data('nonce');
        const currentState = button.data('state') === '1';
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_plugin_auto_update',
                plugin: plugin,
                enable: !currentState,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    button.data('state', currentState ? '0' : '1');
                    button.text(currentState ? 'Enable Auto Update' : 'Disable Auto Update');
                } else {
                    alert(response.data || 'Failed to update auto-update setting.');
                }
                button.prop('disabled', false);
            },
            error: function() {
                alert('Failed to update auto-update setting. Please try again.');
                button.prop('disabled', false);
            }
        });
    });

    $('.activate-plugin').on('click', function() {
        const button = $(this);
        const plugin = button.data('plugin');
        const nonce = button.data('nonce');
        
        if (!confirm('Are you sure you want to activate this plugin?')) {
            return;
        }
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'activate_plugin',
                plugin: plugin,
                nonce: nonce
            },
            success: function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert(response.data || 'Failed to activate plugin.');
                    button.prop('disabled', false);
                }
            },
            error: function() {
                alert('Failed to activate plugin. Please try again.');
                button.prop('disabled', false);
            }
        });
    });

    $('.auto-update-toggle').on('change', function() {
        const $toggle = $(this);
        const $wrapper = $toggle.closest('.toggle-wrapper');
        const plugin = $toggle.data('plugin');
        const enabled = $toggle.prop('checked');
        const $status = $wrapper.find('.toggle-status');
        
        $wrapper.addClass('processing');
        const originalState = !enabled;
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_plugin_auto_update',
                plugin: plugin,
                enable: enabled,
                nonce: $toggle.data('nonce')
            },
            success: function(response) {
                if (response.success) {
                    $status.fadeOut(150, function() {
                        $(this).html(enabled ? 
                            '<span class="status-indicator enabled">Enabled</span>' : 
                            '<span class="status-indicator disabled">Disabled</span>'
                        ).fadeIn(150);
                    });
                } else {
                    $toggle.prop('checked', originalState);
                    alert('Failed to update auto-update setting');
                }
            },
            error: function() {
                $toggle.prop('checked', originalState);
                alert('Failed to update auto-update setting');
            },
            complete: function() {
                setTimeout(() => {
                    $wrapper.removeClass('processing');
                }, 300);
            }
        });
    });
});
</script> 