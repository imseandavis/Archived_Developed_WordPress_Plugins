<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

global $wpdb;

// Get necessary data
$system_info = WordPress_Inspector_System_Utils::get_system_info();
$cpu_info = WordPress_Inspector_System_Utils::get_cpu_info();
$memory_info = WordPress_Inspector_System_Utils::get_memory_info();

// Get hosting provider info
$hosting_provider = WordPress_Inspector_System_Utils::detect_hosting_provider();
$hosting_env = array(
    'php_handler' => php_sapi_name(),
    'max_upload_size' => ini_get('upload_max_filesize'),
    'max_post_size' => ini_get('post_max_size'),
    'max_execution_time' => ini_get('max_execution_time'),
    'max_input_vars' => ini_get('max_input_vars'),
    'allow_url_fopen' => ini_get('allow_url_fopen') ? 'Enabled' : 'Disabled',
    'display_errors' => ini_get('display_errors') ? 'Enabled' : 'Disabled'
);

// Get PHP information
$php_info = array(
    'version' => PHP_VERSION,
    'memory_limit' => ini_get('memory_limit'),
    'max_execution_time' => ini_get('max_execution_time'),
    'post_max_size' => ini_get('post_max_size'),
    'max_input_vars' => ini_get('max_input_vars'),
    'safe_mode' => ini_get('safe_mode'),
    'upload_max_filesize' => ini_get('upload_max_filesize')
);
?>

<div class="wrap wordpress-inspector">
    <h1>Hosting Information</h1>

    <div class="dashboard-row">
        <div class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>Hosting Environment</h2>
                <table class="inspector-info-table">
                    <tr>
                        <th>Hosting Provider</th>
                        <td>
                            <?php 
                            echo esc_html($hosting_provider);
                            if ($hosting_provider === 'Unknown') {
                                echo ' <span class="note">(Could not detect hosting provider)</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>PHP Handler</th>
                        <td>
                            <?php 
                            echo esc_html($hosting_env['php_handler']);
                            $handler_info = '';
                            switch($hosting_env['php_handler']) {
                                case 'apache2handler':
                                    $handler_info = '(PHP is running as an Apache module)';
                                    break;
                                case 'fpm-fcgi':
                                    $handler_info = '(PHP-FPM)';
                                    break;
                                case 'cgi-fcgi':
                                    $handler_info = '(FastCGI)';
                                    break;
                            }
                            if ($handler_info) {
                                echo ' <span class="note">' . esc_html($handler_info) . '</span>';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Document Root</th>
                        <td><?php echo esc_html($_SERVER['DOCUMENT_ROOT']); ?></td>
                    </tr>
                    <tr>
                        <th>Max Upload Size</th>
                        <td><?php echo esc_html($hosting_env['max_upload_size']); ?></td>
                    </tr>
                    <tr>
                        <th>Max POST Size</th>
                        <td><?php echo esc_html($hosting_env['max_post_size']); ?></td>
                    </tr>
                    <tr>
                        <th>Max Execution Time</th>
                        <td><?php echo esc_html($hosting_env['max_execution_time']) . ' seconds'; ?></td>
                    </tr>
                    <tr>
                        <th>Max Input Variables</th>
                        <td><?php echo esc_html($hosting_env['max_input_vars']); ?></td>
                    </tr>
                    <tr>
                        <th>Allow URL fopen</th>
                        <td>
                            <span class="status-indicator <?php echo $hosting_env['allow_url_fopen'] === 'Enabled' ? 'enabled' : 'disabled'; ?>">
                                <?php echo esc_html($hosting_env['allow_url_fopen']); ?>
                            </span>
                        </td>
                    </tr>
                    <tr>
                        <th>Display Errors</th>
                        <td>
                            <span class="status-indicator <?php echo $hosting_env['display_errors'] === 'Enabled' ? 'warning' : 'disabled'; ?>">
                                <?php echo esc_html($hosting_env['display_errors']); ?>
                            </span>
                            <?php if ($hosting_env['display_errors'] === 'Enabled'): ?>
                                <span class="warning-text">(Should be disabled in production)</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="dashboard-row">
        <div class="dashboard-col col-12">
            <?php include(WPI_PLUGIN_DIR . 'views/cards/hosting_card.php'); ?>
        </div>
    </div>

    <div class="dashboard-row mt-4">
        <div class="dashboard-col col-6">
            <div class="inspector-card">
                <h2>Server Software</h2>
                <table class="inspector-info-table">
                    <tr>
                        <th>Web Server</th>
                        <td><?php echo isset($_SERVER['SERVER_SOFTWARE']) ? esc_html($_SERVER['SERVER_SOFTWARE']) : 'N/A'; ?></td>
                    </tr>
                    <tr>
                        <th>PHP Version</th>
                        <td><?php echo esc_html(phpversion()); ?></td>
                    </tr>
                    <tr>
                        <th>MySQL Version</th>
                        <td><?php echo esc_html($wpdb->db_version()); ?></td>
                    </tr>
                </table>
            </div>
        </div>

        <div class="dashboard-col col-6">
            <div class="inspector-card">
                <h2>Server Environment</h2>
                <table class="inspector-info-table">
                    <tr>
                        <th>Operating System</th>
                        <td><?php echo esc_html(php_uname('s') . ' ' . php_uname('r')); ?></td>
                    </tr>
                    <tr>
                        <th>Server IP</th>
                        <td><?php echo esc_html($_SERVER['SERVER_ADDR'] ?? 'N/A'); ?></td>
                    </tr>
                    <tr>
                        <th>Server Hostname</th>
                        <td><?php echo esc_html(gethostname()); ?></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="dashboard-row mt-4">
        <div class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>Resource Usage</h2>
                <table class="inspector-info-table">
                    <tr>
                        <th>CPU Usage</th>
                        <td>
                            <?php 
                            if (!empty($cpu_info['load'])) {
                                echo esc_html(implode(', ', array_map(function($load) { 
                                    return number_format($load, 2); 
                                }, $cpu_info['load'])));
                                echo ' (' . esc_html(number_format(max($cpu_info['load']) / $cpu_info['cores'] * 100, 1)) . '%)';
                            } else {
                                echo 'N/A';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Memory Usage</th>
                        <td>
                            <?php 
                            if (isset($memory_info['used']) && isset($memory_info['total']) && $memory_info['total'] > 0) {
                                echo esc_html(size_format($memory_info['used'])) . ' of ' . 
                                     esc_html(size_format($memory_info['total'])) . ' (' . 
                                     esc_html(number_format($memory_info['used'] / $memory_info['total'] * 100, 1)) . '%)';
                            } else {
                                echo 'N/A (Memory information unavailable)';
                            }
                            ?>
                        </td>
                    </tr>
                    <tr>
                        <th>Disk Usage</th>
                        <td>
                            <?php
                            $disk_free = disk_free_space(ABSPATH);
                            $disk_total = disk_total_space(ABSPATH);
                            $disk_used = $disk_total - $disk_free;
                            echo esc_html(size_format($disk_used)) . ' of ' . 
                                 esc_html(size_format($disk_total)) . ' (' . 
                                 esc_html(number_format($disk_used / $disk_total * 100, 1)) . '%)';
                            ?>
                        </td>
                    </tr>
                </table>
            </div>
        </div>
    </div>

    <div class="dashboard-row mt-4">
        <div class="dashboard-col col-12">
            <div class="inspector-card">
                <h2>Performance Metrics</h2>
                <div class="coming-soon-wrapper">
                    <div class="coming-soon-content">
                        <span class="dashicons dashicons-chart-bar"></span>
                        <h3>Coming Soon</h3>
                        <p>Performance metrics and analytics will be available in a future update.</p>
                        <ul>
                            <li>Response Time Analysis</li>
                            <li>Server Response Metrics</li>
                            <li>Resource Utilization Trends</li>
                            <li>Performance Benchmarks</li>
                        </ul>
                        </br></br>
                        <?php
                            // Display basic server information
                            echo "<strong>Document Root:</strong> " . $_SERVER['DOCUMENT_ROOT'] . "<br>";
                            echo "<strong>Current Script:</strong> " . $_SERVER['SCRIPT_FILENAME'] . "<br>";

                            // Memory usage
                            echo "<h2>Memory Usage</h2>";
                            echo "<strong>Memory Usage:</strong> " . round(memory_get_usage() / 1024 / 1024, 2) . " MB<br>";
                            echo "<strong>Peak Memory Usage:</strong> " . round(memory_get_peak_usage() / 1024 / 1024, 2) . " MB<br>";

                            // CPU information (Linux systems)
                            if (is_readable('/proc/cpuinfo')) {
                                echo "<h2>CPU Information</h2>";
                                $cpuInfo = file_get_contents('/proc/cpuinfo');
                                echo "<pre>" . htmlspecialchars($cpuInfo) . "</pre>";
                            } else {
                                echo "<h2>CPU Information</h2>";
                                echo "Unable to access CPU information (restricted or not available).<br>";
                            }

                            // Memory information (Linux systems)
                            if (is_readable('/proc/meminfo')) {
                                echo "<h2>Memory Information</h2>";
                                $memInfo = file_get_contents('/proc/meminfo');
                                echo "<pre>" . htmlspecialchars($memInfo) . "</pre>";
                            } else {
                                echo "<h2>Memory Information</h2>";
                                echo "Unable to access memory information (restricted or not available).<br>";
                            }

                            // Disk usage
                            //echo "<h2>Disk Usage</h2>";
                            //echo "<strong>Total Disk Space:</strong> " . round(disk_total_space("/") / 1024 / 1024 / 1024, 2) . " GB<br>";
                            //echo "<strong>Free Disk Space:</strong> " . round(disk_free_space("/") / 1024 / 1024 / 1024, 2) . " GB<br>";
                            ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <style>
    .coming-soon-wrapper {
        padding: 40px 20px;
        text-align: center;
        background: #f8f9fa;
        border-radius: 4px;
    }
    
    .coming-soon-content {
        max-width: 600px;
        margin: 0 auto;
    }
    
    .coming-soon-content .dashicons {
        font-size: 48px;
        width: 48px;
        height: 48px;
        color: #2271b1;
        margin-bottom: 20px;
    }
    
    .coming-soon-content h3 {
        margin: 0 0 15px;
        color: #1d2327;
    }
    
    .coming-soon-content p {
        color: #50575e;
        margin-bottom: 20px;
    }
    
    .coming-soon-content ul {
        list-style: none;
        padding: 0;
        margin: 0;
        display: inline-block;
        text-align: left;
    }
    
    .coming-soon-content ul li {
        position: relative;
        padding-left: 24px;
        margin-bottom: 8px;
        color: #50575e;
    }
    
    .coming-soon-content ul li:before {
        content: "\f147";
        font-family: dashicons;
        position: absolute;
        left: 0;
        color: #2271b1;
    }
    </style>
</div> 