<?php
/**
 * Plugin License Keys view
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Initialize license patterns
$license_patterns = new WordPress_Inspector_License_Patterns();

// Add required scripts
wp_enqueue_style('thickbox');
wp_enqueue_script('thickbox');
?>

<div class="wrap wordpress-inspector">
    <h1>Plugin License Keys</h1>

    <div class="inspector-card">
        <div class="license-filters">
            <div class="filters-content">
                <label>
                    <input type="checkbox" id="show-no-license" checked>
                    Show Plugins With No License
                </label>
                <div class="action-buttons">
                    <button class="button export-keys-button">
                        Export To CSV
                    </button>
                    <button class="button button-primary scan-licenses-button">
                        <span class="spinner"></span>
                        License Key Scan
                    </button>
                </div>
            </div>
        </div>
        <div id="scan-results">
            <table class="inspector-info-table" id="licenses-table">
                <thead>
                    <tr>
                        <th>Plugin Name</th>
                        <th>Version</th>
                        <th>Author</th>
                        <th>License Key</th>
                    </tr>
                </thead>
                <tbody>
                    <!-- Results will be loaded here -->
                </tbody>
            </table>
        </div>
    </div>
</div>

<style>
.error {
    color: #d63638;
}
.license-filters {
    margin-bottom: 15px;
    padding: 10px;
    background: #f8f9fa;
    border-radius: 4px;
}

.filters-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.license-filters label {
    user-select: none;
}

.license-filters input[type="checkbox"] {
    margin-right: 5px;
}

.scan-licenses-button {
    position: relative;
    padding-left: 25px !important;
}

.scan-licenses-button .spinner {
    position: absolute;
    left: 5px;
    top: 50%;
    transform: translateY(-50%);
    float: none;
    margin: 0;
    visibility: hidden;
}

.scan-licenses-button.scanning {
    pointer-events: none;
    opacity: 0.7;
}

.scan-licenses-button.scanning .spinner {
    visibility: visible;
}

tr.no-license {
    display: table-row;
}
tr.no-license.hidden {
    display: none;
}
.open-plugin-details-modal {
    text-decoration: none;
    color: #2271b1;
}
.open-plugin-details-modal:hover {
    color: #135e96;
    text-decoration: underline;
}

.license-key-wrapper {
    display: flex;
    align-items: center;
    gap: 8px;
}

.toggle-license-key {
    padding: 2px !important;
    height: 24px !important;
    min-height: 24px !important;
    line-height: 1 !important;
}

.toggle-license-key .dashicons {
    width: 16px;
    height: 16px;
    font-size: 16px;
    margin: 0;
}

.toggle-license-key.showing .dashicons {
    color: #2271b1;
}

.action-buttons {
    display: flex;
    gap: 10px;
    align-items: center;
}

.export-keys-button {
    display: flex !important;
    align-items: center;
    gap: 4px;
}

.inspector-info-table a {
    text-decoration: none;
    color: #2271b1;
}

.inspector-info-table a:hover {
    color: #135e96;
    text-decoration: underline;
}
</style>

<script>
jQuery(document).ready(function($) {
    // Handle checkbox changes
    $('#show-no-license').on('change', function() {
        const showNoLicense = $(this).prop('checked');
        $('.no-license').toggleClass('hidden', !showNoLicense);
    });

    // Handle license scan
    $('.scan-licenses-button').on('click', function() {
        const $button = $(this);
        const $table = $('#licenses-table tbody');
        const showNoLicense = $('#show-no-license').prop('checked');
        
        // Show scanning state
        $button.addClass('scanning');
        $table.html('<tr><td colspan="4" class="loading">Scanning for license keys...</td></tr>');

        // Run scan
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'scan_license_keys',
                nonce: '<?php echo wp_create_nonce('scan_license_keys'); ?>'
            },
            success: function(response) {
                if (response.success && Array.isArray(response.data)) {
                    $table.empty();
                    
                    // Add plugins to table
                    response.data.forEach(function(plugin) {
                        if (plugin.has_license || showNoLicense) {
                            const row = `
                                <tr class="${!plugin.has_license ? 'no-license' : ''}">
                                    <td>
                                        <a href="plugin-install.php?tab=plugin-information&plugin=${plugin.plugin_slug}&TB_iframe=true&width=600&height=550" 
                                           class="thickbox open-plugin-details-modal" 
                                           title="Plugin details: ${plugin.plugin}">
                                            ${plugin.plugin}
                                        </a>
                                    </td>
                                    <td>${plugin.version}</td>
                                    <td>
                                        ${plugin.author_url ? 
                                            `<a href="${plugin.author_url}" target="_blank" rel="noopener noreferrer">${plugin.author}</a>` : 
                                            plugin.author
                                        }
                                    </td>
                                    <td>
                                        ${plugin.has_license ? `
                                            <div class="license-key-wrapper">
                                                <span class="license-key-value masked">${plugin.masked_key}</span>
                                                <span class="license-key-value unmasked" style="display: none;">${plugin.key}</span>
                                                <button class="button toggle-license-key" type="button">
                                                    <span class="dashicons dashicons-visibility"></span>
                                                </button>
                                            </div>
                                        ` : 'N/A'}
                                    </td>
                                </tr>
                            `;
                            $table.append(row);
                        }
                    });

                    // If no plugins to show
                    if ($table.children().length === 0) {
                        $table.html('<tr><td colspan="4">No plugins to display.</td></tr>');
                    }
                } else {
                    $table.html(`<tr><td colspan="4" class="error">Error scanning license keys</td></tr>`);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                $table.html(`<tr><td colspan="4" class="error">Error scanning license keys: ${textStatus}</td></tr>`);
            },
            complete: function() {
                $button.removeClass('scanning');
            }
        });
    });

    // Handle license key visibility toggle
    $(document).on('click', '.toggle-license-key', function() {
        const $button = $(this);
        const $wrapper = $button.closest('.license-key-wrapper');
        const $masked = $wrapper.find('.license-key-value.masked');
        const $unmasked = $wrapper.find('.license-key-value.unmasked');
        
        $button.toggleClass('showing');
        
        if ($masked.is(':visible')) {
            $masked.hide();
            $unmasked.show();
            $button.find('.dashicons')
                .removeClass('dashicons-visibility')
                .addClass('dashicons-hidden');
        } else {
            $masked.show();
            $unmasked.hide();
            $button.find('.dashicons')
                .removeClass('dashicons-hidden')
                .addClass('dashicons-visibility');
        }
    });

    // Handle CSV export
    $('.export-keys-button').on('click', function(e) {
        e.preventDefault();
        
        // Collect plugin data
        const plugins = [];
        $('#licenses-table tbody tr').each(function() {
            const $row = $(this);
            const plugin = {
                name: $row.find('td:first-child').text().trim(),
                version: $row.find('td:nth-child(2)').text().trim(),
                author: $row.find('td:nth-child(3)').text().trim(),
                license_key: $row.find('.license-key-value.unmasked').text().trim() || 'N/A'
            };
            plugins.push(plugin);
        });

        exportCSV(plugins);
    });

    // Export to CSV function
    function exportCSV(plugins) {
        let csv = 'Plugin Name,Version,Author,License Key\n';
        
        plugins.forEach(plugin => {
            csv += `"${plugin.name}","${plugin.version}","${plugin.author}","${plugin.license_key}"\n`;
        });

        downloadFile(csv, 'plugin-licenses.csv', 'text/csv');
    }

    // Helper function to download file
    function downloadFile(content, filename, type) {
        const blob = new Blob([content], { type: type });
        const url = window.URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.style.display = 'none';
        a.href = url;
        a.download = filename;
        document.body.appendChild(a);
        a.click();
        window.URL.revokeObjectURL(url);
        a.remove();
    }

    // Trigger initial scan on page load
    $('.scan-licenses-button').trigger('click');

    // Handle checkbox changes - update to trigger new scan
    $('#show-no-license').on('change', function() {
        $('.scan-licenses-button').trigger('click');
    });
});
</script> 