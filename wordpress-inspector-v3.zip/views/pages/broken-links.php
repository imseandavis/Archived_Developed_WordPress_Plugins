<?php
if (!defined('ABSPATH')) {
    exit;
}

if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Enqueue required scripts
wp_enqueue_script('jquery');
?>

<div class="wrap wordpress-inspector">
    <h1>Broken Link Checker</h1>
    
    <div class="notice notice-info inline">
        <p>Site scan for broken links is in progress.</p>
    </div>

    <div class="inspector-card broken-links-card">
        <div class="stats-grid">
            <div class="stat-box">
                <h3>Broken Links</h3>
                <div class="stat-number">0</div>
            </div>
            <div class="stat-box">
                <h3>Total Links</h3>
                <div class="stat-number">0 URLs</div>
            </div>
            <div class="stat-box">
                <h3>Unique URLs</h3>
                <div class="stat-number">0 URLs</div>
            </div>
        </div>

        <div class="scan-details">
            <div class="detail-row">
                <label>Start Time</label>
                <span class="value start-time">-</span>
            </div>
            <div class="detail-row">
                <label>End Time</label>
                <span class="value end-time">-</span>
            </div>
            <div class="detail-row">
                <label>Duration</label>
                <span class="value duration">0</span>
            </div>
        </div>

        <div class="scan-progress">
            <div class="progress-bar">
                <div class="progress-fill"></div>
            </div>
            <div class="progress-text">0%</div>
        </div>

        <div class="action-buttons">
            <button type="button" class="button button-primary start-scan">Start Scan</button>
            <button type="button" class="button stop-scan" disabled>Stop Scan</button>
            <div class="spinner"></div>
        </div>

        <div class="results-section" style="display: none;">
            <h3>Scan Results</h3>
            <div class="results-table-wrapper">
                <table class="wp-list-table widefat fixed striped">
                    <thead>
                        <tr>
                            <th>URL</th>
                            <th>Status</th>
                            <th>Location</th>
                        </tr>
                    </thead>
                    <tbody>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <div class="schedule-section inspector-card">
        <h2>Schedule Scan</h2>
        <p>Enable scheduled broken link checks and be notified of results.</p>
        
        <table class="form-table">
            <tr>
                <th>Notification</th>
                <th>Status</th>
                <th>Action</th>
            </tr>
            <tr>
                <td>Schedule Scan</td>
                <td><span class="status-badge disabled">Disabled</span></td>
                <td>
                    <button type="button" class="button enable-schedule">Enable</button>
                </td>
            </tr>
        </table>
    </div>
</div>

<style>
.broken-links-card {
    padding: 20px;
    background: #fff;
    margin-top: 20px;
}

.stats-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20px;
    margin-bottom: 30px;
}

.stat-box {
    text-align: center;
    padding: 20px;
    background: #f0f0f1;
    border-radius: 4px;
}

.stat-box h3 {
    margin: 0 0 10px 0;
    color: #50575e;
}

.stat-number {
    font-size: 24px;
    font-weight: bold;
    color: #2271b1;
}

.scan-details {
    margin-bottom: 30px;
}

.detail-row {
    display: flex;
    margin-bottom: 10px;
}

.detail-row label {
    width: 100px;
    font-weight: 600;
}

.scan-progress {
    margin-bottom: 20px;
}

.progress-bar {
    height: 20px;
    background: #f0f0f1;
    border-radius: 10px;
    overflow: hidden;
    margin-bottom: 5px;
}

.progress-fill {
    height: 100%;
    width: 0;
    background: #2271b1;
    transition: width 0.3s ease;
}

.progress-text {
    text-align: center;
    font-size: 12px;
    color: #50575e;
}

.action-buttons {
    display: flex;
    gap: 10px;
    align-items: center;
    margin-bottom: 30px;
}

.spinner {
    float: none;
    margin: 0;
}

.results-table-wrapper {
    margin-top: 15px;
    max-height: 400px;
    overflow-y: auto;
}

.schedule-section {
    margin-top: 20px;
    padding: 20px;
}

.status-badge {
    padding: 4px 8px;
    border-radius: 4px;
    font-size: 12px;
    font-weight: 500;
}

.status-badge.disabled {
    background: #f0f0f1;
    color: #50575e;
}

.status-badge.enabled {
    background: #edfaef;
    color: #2a7d3f;
}
</style>

<script>
jQuery(document).ready(function($) {
    let scanInProgress = false;
    let startTime = null;
    const $startButton = $('.start-scan');
    const $stopButton = $('.stop-scan');
    const $spinner = $('.spinner');
    const $progressFill = $('.progress-fill');
    const $progressText = $('.progress-text');
    const $resultsSection = $('.results-section');
    const $resultsTable = $('.results-table tbody');

    function updateProgress(percent) {
        $progressFill.css('width', percent + '%');
        $progressText.text(percent + '%');
    }

    function formatTime(date) {
        return date ? date.toLocaleTimeString() : '-';
    }

    function updateDuration() {
        if (startTime && scanInProgress) {
            const duration = Math.round((new Date() - startTime) / 1000);
            $('.duration').text(duration + 's');
            setTimeout(updateDuration, 1000);
        }
    }

    $startButton.on('click', function() {
        scanInProgress = true;
        startTime = new Date();
        $('.start-time').text(formatTime(startTime));
        $('.end-time').text('-');
        updateDuration();

        $startButton.prop('disabled', true);
        $stopButton.prop('disabled', false);
        $spinner.addClass('is-active');
        $resultsSection.hide();
        $resultsTable.empty();

        // Start the scan process
        scanLinks();
    });

    $stopButton.on('click', function() {
        scanInProgress = false;
        $startButton.prop('disabled', false);
        $stopButton.prop('disabled', true);
        $spinner.removeClass('is-active');
        $('.end-time').text(formatTime(new Date()));
    });

    function scanLinks(offset = 0) {
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'scan_links',
                nonce: '<?php echo wp_create_nonce("broken_links_nonce"); ?>',
                offset: offset
            },
            success: function(response) {
                if (response.success) {
                    // Update statistics
                    $('.stat-box:nth-child(1) .stat-number').text(response.data.broken_count);
                    $('.stat-box:nth-child(2) .stat-number').text(response.data.total_links + ' URLs');
                    $('.stat-box:nth-child(3) .stat-number').text(response.data.unique_urls + ' URLs');
                    
                    // Update progress
                    updateProgress(response.data.progress);

                    // Add results to table
                    response.data.results.forEach(function(result) {
                        $resultsTable.append(`
                            <tr>
                                <td>${result.url}</td>
                                <td>${result.status}</td>
                                <td>${result.location}</td>
                            </tr>
                        `);
                    });

                    if (response.data.results.length > 0) {
                        $resultsSection.show();
                    }

                    // Continue scanning if not completed
                    if (!response.data.completed && scanInProgress) {
                        scanLinks(response.data.next_offset);
                    } else if (scanInProgress) {
                        // Scan completed
                        scanInProgress = false;
                        $startButton.prop('disabled', false);
                        $stopButton.prop('disabled', true);
                        $spinner.removeClass('is-active');
                        $('.end-time').text(formatTime(new Date()));
                    }
                }
            },
            error: function() {
                alert('Error performing scan. Please try again.');
                scanInProgress = false;
                $startButton.prop('disabled', false);
                $stopButton.prop('disabled', true);
                $spinner.removeClass('is-active');
            }
        });
    }

    // Handle schedule enable button
    $('.enable-schedule').on('click', function() {
        const $button = $(this);
        const $status = $button.closest('tr').find('.status-badge');
        const enabling = $status.hasClass('disabled');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_schedule',
                nonce: '<?php echo wp_create_nonce("broken_links_nonce"); ?>',
                enabled: enabling
            },
            success: function(response) {
                if (response.success) {
                    if (enabling) {
                        $status.removeClass('disabled').addClass('enabled').text('Enabled');
                        $button.text('Disable');
                    } else {
                        $status.removeClass('enabled').addClass('disabled').text('Disabled');
                        $button.text('Enable');
                    }
                }
            }
        });
    });
});
</script> 