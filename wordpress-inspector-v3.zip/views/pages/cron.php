<?php
/**
 * Cron Information view
 *
 * @package WordPress_Inspector
 * @since 1.0.0
 */

if (!defined('ABSPATH')) {
    exit;
}

// Security check
if (!current_user_can('manage_options')) {
    wp_die(__('You do not have sufficient permissions to access this page.'));
}

// Get cron information
$cron_array = _get_cron_array();
$cron_times = array_keys($cron_array);
sort($cron_times);
?>

<div class="wrap wordpress-inspector">
    <h1>Cron Information</h1>

    <!-- Cron Status -->
    <div class="inspector-card">
        <h2>Cron Status</h2>
        <table class="inspector-info-table">
            <tr>
                <th>WP Cron Status</th>
                <td>
                    <?php if (defined('DISABLE_WP_CRON') && DISABLE_WP_CRON): ?>
                        <span class="status-indicator disabled">Disabled</span>
                        <span class="warning">WP Cron is disabled. Make sure you have set up an alternative cron trigger.</span>
                    <?php else: ?>
                        <span class="status-indicator enabled">Enabled</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Alternate WP Cron</th>
                <td>
                    <?php if (defined('ALTERNATE_WP_CRON') && ALTERNATE_WP_CRON): ?>
                        <span class="status-indicator enabled">Enabled</span>
                    <?php else: ?>
                        <span class="status-indicator disabled">Disabled</span>
                    <?php endif; ?>
                </td>
            </tr>
            <tr>
                <th>Next Scheduled Event</th>
                <td>
                    <?php 
                    if (!empty($cron_times)) {
                        $next_time = $cron_times[0];
                        echo esc_html(human_time_diff($next_time)) . ' (' . date('Y-m-d H:i:s', $next_time) . ')';
                    } else {
                        echo 'No events scheduled';
                    }
                    ?>
                </td>
            </tr>
        </table>
    </div>

    <!-- Scheduled Events -->
    <div class="inspector-card">
        <h2>Scheduled Events</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Hook</th>
                <th>Next Run</th>
                <th>Schedule</th>
                <th>Arguments</th>
            </tr>
            <?php
            if (!empty($cron_array)) {
                foreach ($cron_times as $timestamp) {
                    foreach ($cron_array[$timestamp] as $hook => $events) {
                        foreach ($events as $key => $event) {
                            ?>
                            <tr>
                                <td><?php echo esc_html($hook); ?></td>
                                <td>
                                    <?php 
                                    echo esc_html(human_time_diff($timestamp)) . '<br>';
                                    echo '<span class="details">' . date('Y-m-d H:i:s', $timestamp) . '</span>';
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    if (isset($event['schedule'])) {
                                        echo esc_html($event['schedule']);
                                        if (isset($event['interval'])) {
                                            echo '<br><span class="details">Every ' . 
                                                human_time_diff(0, $event['interval']) . 
                                                '</span>';
                                        }
                                    } else {
                                        echo 'One-time';
                                    }
                                    ?>
                                </td>
                                <td>
                                    <?php 
                                    if (!empty($event['args'])) {
                                        echo '<pre>' . esc_html(print_r($event['args'], true)) . '</pre>';
                                    } else {
                                        echo 'None';
                                    }
                                    ?>
                                </td>
                            </tr>
                            <?php
                        }
                    }
                }
            } else {
                ?>
                <tr>
                    <td colspan="4">No cron events scheduled</td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>

    <!-- Custom Schedules -->
    <div class="inspector-card">
        <h2>Custom Schedules</h2>
        <table class="inspector-info-table">
            <tr>
                <th>Name</th>
                <th>Interval</th>
                <th>Display</th>
            </tr>
            <?php
            $schedules = wp_get_schedules();
            if (!empty($schedules)) {
                foreach ($schedules as $name => $schedule) {
                    ?>
                    <tr>
                        <td><?php echo esc_html($name); ?></td>
                        <td><?php echo human_time_diff(0, $schedule['interval']); ?></td>
                        <td><?php echo esc_html($schedule['display']); ?></td>
                    </tr>
                    <?php
                }
            } else {
                ?>
                <tr>
                    <td colspan="3">No custom schedules defined</td>
                </tr>
                <?php
            }
            ?>
        </table>
    </div>
</div>

<style>
.status-indicator {
    display: inline-block;
    padding: 3px 8px;
    border-radius: 3px;
    font-size: 12px;
    font-weight: 500;
}
.status-indicator.enabled {
    background: #d1fae5;
    color: #065f46;
}
.status-indicator.disabled {
    background: #fee2e2;
    color: #991b1b;
}
.warning {
    color: #d97706;
    font-size: 12px;
    margin-left: 10px;
}
.details {
    color: #666;
    font-size: 12px;
}
pre {
    margin: 0;
    white-space: pre-wrap;
    word-wrap: break-word;
    font-size: 12px;
}
</style> 