<?php
$site_name = get_bloginfo('name');
$site_url = get_site_url();

// Get update statistics
$logs = WordPress_Inspector_Updates_Utils::get_update_logs(array(
    'start_date' => date('Y-m-d', strtotime('-7 days')),
    'per_page' => -1
));

$stats = array(
    'total' => count($logs['logs']),
    'success' => 0,
    'failed' => 0
);

foreach ($logs['logs'] as $log) {
    if ($log->status === 'success') {
        $stats['success']++;
    } else {
        $stats['failed']++;
    }
}

// Get available updates
$core_update = get_site_transient('update_core');
$plugin_updates = get_site_transient('update_plugins');
$theme_updates = get_site_transient('update_themes');
?>

<!DOCTYPE html>
<html>
<head>
    <style>
        body { font-family: sans-serif; line-height: 1.6; color: #444; }
        .container { max-width: 600px; margin: 0 auto; padding: 20px; }
        .header { text-align: center; margin-bottom: 30px; }
        .section { margin-bottom: 30px; }
        .stats { display: flex; justify-content: space-around; margin: 20px 0; }
        .stat-item { text-align: center; }
        .number { font-size: 24px; font-weight: bold; }
        .label { color: #666; }
        table { width: 100%; border-collapse: collapse; }
        th, td { padding: 8px; text-align: left; border-bottom: 1px solid #ddd; }
        .success { color: #46b450; }
        .warning { color: #dc3232; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h2>WordPress Update Report</h2>
            <p><?php echo esc_html($site_name); ?> (<?php echo esc_url($site_url); ?>)</p>
        </div>

        <div class="section">
            <h3>Update Statistics (Last 7 Days)</h3>
            <div class="stats">
                <div class="stat-item">
                    <div class="number"><?php echo $stats['total']; ?></div>
                    <div class="label">Total Updates</div>
                </div>
                <div class="stat-item">
                    <div class="number success"><?php echo $stats['success']; ?></div>
                    <div class="label">Successful</div>
                </div>
                <div class="stat-item">
                    <div class="number warning"><?php echo $stats['failed']; ?></div>
                    <div class="label">Failed</div>
                </div>
            </div>
        </div>

        <div class="section">
            <h3>Available Updates</h3>
            <?php if (isset($core_update->updates[0])): ?>
                <h4>WordPress Core</h4>
                <p>Version <?php echo $core_update->updates[0]->version; ?> is available</p>
            <?php endif; ?>

            <?php if (!empty($plugin_updates->response)): ?>
                <h4>Plugins (<?php echo count($plugin_updates->response); ?>)</h4>
                <table>
                    <tr>
                        <th>Plugin</th>
                        <th>New Version</th>
                    </tr>
                    <?php foreach ($plugin_updates->response as $plugin): ?>
                        <tr>
                            <td><?php echo $plugin->slug; ?></td>
                            <td><?php echo $plugin->new_version; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>

            <?php if (!empty($theme_updates->response)): ?>
                <h4>Themes (<?php echo count($theme_updates->response); ?>)</h4>
                <table>
                    <tr>
                        <th>Theme</th>
                        <th>New Version</th>
                    </tr>
                    <?php foreach ($theme_updates->response as $theme): ?>
                        <tr>
                            <td><?php echo $theme['theme']; ?></td>
                            <td><?php echo $theme['new_version']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </table>
            <?php endif; ?>
        </div>

        <div class="section">
            <h3>Recent Update History</h3>
            <table>
                <tr>
                    <th>Date</th>
                    <th>Type</th>
                    <th>Item</th>
                    <th>Status</th>
                </tr>
                <?php foreach (array_slice($logs['logs'], 0, 10) as $log): ?>
                    <tr>
                        <td><?php echo $log->update_date; ?></td>
                        <td><?php echo $log->update_type; ?></td>
                        <td><?php echo $log->item_name; ?></td>
                        <td class="<?php echo $log->status === 'success' ? 'success' : 'warning'; ?>">
                            <?php echo $log->status; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </table>
        </div>
    </div>
</body>
</html> 