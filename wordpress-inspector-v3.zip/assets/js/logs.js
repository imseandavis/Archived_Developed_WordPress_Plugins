jQuery(document).ready(function($) {
    // Clear log button handler
    $('.clear-log').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $card = $button.closest('.inspector-card');
        var logType = getLogType($card.find('h2').text());
        
        if (!confirm('Are you sure you want to clear this log file?')) {
            return;
        }
        
        $button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'clear_log',
                nonce: wordpress_inspector.nonce,
                log_type: logType
            },
            success: function(response) {
                if (response.success) {
                    $card.find('.log-output').remove();
                    $card.find('.log-content').html('<div class="log-empty">Log file is empty.</div>');
                    $card.find('.log-size').text('File Size: 0 B');
                } else {
                    alert('Failed to clear log: ' + response.data.message);
                }
            },
            error: function() {
                alert('Failed to clear log. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Download log button handler
    $('.download-log').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var $card = $button.closest('.inspector-card');
        var logType = getLogType($card.find('h2').text());
        
        $button.prop('disabled', true);
        
        // Create form and submit it
        var $form = $('<form>', {
            method: 'POST',
            action: ajaxurl
        });
        
        $form.append($('<input>', {
            type: 'hidden',
            name: 'action',
            value: 'download_log'
        }));
        
        $form.append($('<input>', {
            type: 'hidden',
            name: 'nonce',
            value: wordpress_inspector.nonce
        }));
        
        $form.append($('<input>', {
            type: 'hidden',
            name: 'log_type',
            value: logType
        }));
        
        $('body').append($form);
        $form.submit();
        $form.remove();
        
        setTimeout(function() {
            $button.prop('disabled', false);
        }, 1000);
    });

    // Toggle logging button handler
    $('.toggle-logging').on('click', function(e) {
        e.preventDefault();
        
        var $button = $(this);
        var type = $button.data('type');
        var currentStatus = $button.data('status') === 1;
        
        if (!confirm('Are you sure you want to ' + (currentStatus ? 'disable' : 'enable') + ' ' + type + ' logging?')) {
            return;
        }
        
        $button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_logging',
                nonce: wordpress_inspector.nonce,
                type: type,
                enable: currentStatus ? 0 : 1
            },
            success: function(response) {
                if (response.success) {
                    var $status = $button.siblings('.status-enabled, .status-disabled');
                    if (currentStatus) {
                        $status.removeClass('status-enabled').addClass('status-disabled').text('Disabled');
                        $button.text('Enable Logging');
                    } else {
                        $status.removeClass('status-disabled').addClass('status-enabled').text('Enabled');
                        $button.text('Disable Logging');
                    }
                    $button.data('status', currentStatus ? 0 : 1);
                    alert(response.data.message);
                    window.location.reload();
                } else {
                    alert('Failed to toggle logging: ' + response.data.message);
                }
            },
            error: function() {
                alert('Failed to toggle logging. Please try again.');
            },
            complete: function() {
                $button.prop('disabled', false);
            }
        });
    });

    // Helper function to get log type from title
    function getLogType(title) {
        title = title.toLowerCase();
        if (title.includes('debug')) return 'debug';
        if (title.includes('php error')) return 'php';
        if (title.includes('mysql error')) return 'mysql';
        if (title.includes('slow query')) return 'slow';
        if (title.includes('access')) return 'access';
        if (title.includes('server error')) return 'server';
        if (title.includes('htaccess')) return 'htaccess';
        if (title.includes('cron')) return 'cron';
        if (title.includes('email')) return 'email';
        return '';
    }
}); 