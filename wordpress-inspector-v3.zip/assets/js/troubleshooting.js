jQuery(document).ready(function($) {
    // Debug toggle handler
    $('.debug-toggle').on('change', function() {
        var $toggle = $(this);
        var setting = $toggle.data('setting');
        var enabled = $toggle.prop('checked');
        
        $toggle.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'toggle_debug_setting',
                nonce: wordpress_inspector.nonce,
                setting: setting,
                enabled: enabled
            },
            success: function(response) {
                if (response.success) {
                    var $status = $toggle.closest('.toggle-wrapper').find('.toggle-status');
                    if (enabled) {
                        $status.html('<span class="status-indicator enabled">Enabled</span>');
                    } else {
                        $status.html('<span class="status-indicator disabled">Disabled</span>');
                    }
                } else {
                    alert('Failed to update setting: ' + response.data.message);
                    $toggle.prop('checked', !enabled);
                }
            },
            error: function() {
                alert('Failed to update setting. Please try again.');
                $toggle.prop('checked', !enabled);
            },
            complete: function() {
                $toggle.prop('disabled', false);
            }
        });
    });
}); 