jQuery(document).ready(function($) {
    // Theme Management - Use event delegation
    $(document).on('click', '.make-primary-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const theme = $button.data('theme');
        
        $button.prop('disabled', true).text('Switching...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'switch_theme',
                theme: theme,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Reload page and set active tab to themes
                    window.location.href = wordpress_inspector.admin_url + '?page=wordpress-inspector#themes';
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Failed to switch theme.');
                    $button.prop('disabled', false).text('Make Primary');
                }
            },
            error: function(xhr, status, error) {
                console.error('Switch theme error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to switch theme. Please try again.');
                $button.prop('disabled', false).text('Make Primary');
            }
        });
    });

    // Delete theme - Use event delegation
    $(document).on('click', '.delete-theme-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const theme = $button.data('theme');
        
        $button.prop('disabled', true).text('Deleting...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_theme',
                theme: theme,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    // Reload page and set active tab to themes
                    window.location.href = wordpress_inspector.admin_url + '?page=wordpress-inspector#themes';
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Failed to delete theme.');
                    $button.prop('disabled', false).text('Delete');
                }
            },
            error: function(xhr, status, error) {
                console.error('Switch theme error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to delete theme. Please try again.');
                $button.prop('disabled', false).text('Delete');
            }
        });
    });
}); 