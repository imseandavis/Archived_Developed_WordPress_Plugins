jQuery(document).ready(function($) {
    const tabButtons = $('.wp-tab-button');
    const tabContents = $('.wp-tab-content');
    
    function activateTab(tabName) {
        const $targetButton = $(`.wp-tab-button[data-tab="${tabName}"]`);
        const $targetContent = $(`#${tabName}`);
        
        // Update active states
        tabButtons.removeClass('active');
        $targetButton.addClass('active');
        
        tabContents.removeClass('active');
        $targetContent.addClass('active');
        
        // Lazy load content if not already loaded
        if (!$targetContent.data('loaded')) {
            loadTabContent(tabName, $targetContent);
        }
    }
    
    // Check for hash in URL and activate corresponding tab
    if (window.location.hash) {
        const tab = window.location.hash.substring(1);
        activateTab(tab);
    }
    
    // Tab switching
    tabButtons.on('click', function() {
        const targetTab = $(this).data('tab');
        activateTab(targetTab);
    });
    
    // Load initial tab content
    if (!window.location.hash) {
        loadTabContent('overview', $('#overview'));
    }
    
    function loadTabContent(tab, $container) {
        $container.html('<div class="loading">Loading...</div>');
        
        console.log('Loading tab:', tab);
        console.log('AJAX URL:', wordpress_inspector.ajaxurl);
        console.log('Nonce:', wordpress_inspector.nonce);
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'load_wp_tab',
                tab: 'wordpress-' + tab,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                console.log('AJAX Response:', response);
                if (response.success) {
                    $container.html(response.data);
                    $container.data('loaded', true);
                } else {
                    $container.html('<div class="error">Failed to load content: ' + 
                        (response.data || 'Unknown error') + '</div>');
                    console.error('Tab load error:', response);
                }
            },
            error: function(jqXHR, textStatus, errorThrown) {
                console.log('Full error details:', {
                    status: jqXHR.status,
                    statusText: jqXHR.statusText,
                    responseText: jqXHR.responseText,
                    errorThrown: errorThrown
                });
                $container.html('<div class="error">Failed to load content: ' + textStatus + '</div>');
            }
        });
    }

    // Theme Management - Use event delegation
    $(document).on('click', '.make-primary-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const theme = $button.data('theme');
        console.log('Make Primary clicked:', {
            button: $button,
            theme: theme,
            nonce: wordpress_inspector.nonce
        });
        
        if (!confirm('Are you sure you want to switch to this theme?')) {
            return;
        }
        
        $button.prop('disabled', true).text('Switching...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'switch_theme',
                theme: theme,
                nonce: wordpress_inspector.nonce
            },
            beforeSend: function() {
                console.log('Sending switch theme request:', {
                    theme: theme,
                    action: 'switch_theme'
                });
            },
            success: function(response) {
                console.log('Switch theme response:', response);
                if (response.success) {
                    // Reload page to show updated active theme
                    location.reload();
                } else {
                    alert(response.data.message || 'Failed to switch theme.');
                    $button.prop('disabled', false).text('Make Primary');
                }
            },
            error: function(xhr, status, error) {
                console.error('Switch theme error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to switch theme. Please try again.');
                $button.prop('disabled', false).text('Make Primary');
            }
        });
    });

    // Delete theme - Use event delegation
    $(document).on('click', '.delete-theme-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const theme = $button.data('theme');
        console.log('Delete clicked:', {
            button: $button,
            theme: theme,
            nonce: wordpress_inspector.nonce
        });
        
        if (!confirm('Are you sure you want to delete this theme? This action cannot be undone.')) {
            return;
        }
        
        $button.prop('disabled', true).text('Deleting...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_theme',
                theme: theme,
                nonce: wordpress_inspector.nonce
            },
            beforeSend: function() {
                console.log('Sending delete theme request:', {
                    theme: theme,
                    action: 'delete_theme'
                });
            },
            success: function(response) {
                console.log('Delete theme response:', response);
                if (response.success) {
                    // Remove the row with animation
                    $row.fadeOut(400, function() {
                        $(this).remove();
                        // Show message
                        const message = $('<div class="notice notice-success"><p>' + response.data.message + '</p></div>')
                            .hide()
                            .insertBefore('.themes-list')
                            .fadeIn();
                        // Remove message after 3 seconds
                        setTimeout(() => message.fadeOut(() => message.remove()), 3000);
                    });
                } else {
                    alert(response.data.message || 'Failed to delete theme.');
                    $button.prop('disabled', false).text('Delete');
                }
            },
            error: function(xhr, status, error) {
                console.error('Delete theme error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to delete theme. Please try again.');
                $button.prop('disabled', false).text('Delete');
            }
        });
    });
}); 