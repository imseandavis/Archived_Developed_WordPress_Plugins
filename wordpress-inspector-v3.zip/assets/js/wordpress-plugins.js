jQuery(document).ready(function($) {
    // Plugin Management - Use event delegation
    $(document).on('click', '.activate-plugin-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const plugin = $button.data('plugin');
        
        $button.prop('disabled', true).text('Activating...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'activate_plugin',
                plugin: plugin,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = wordpress_inspector.admin_url + '?page=wordpress-inspector#plugins';
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Failed to activate plugin.');
                    $button.prop('disabled', false).text('Activate');
                }
            },
            error: function(xhr, status, error) {
                console.error('Activate plugin error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to activate plugin. Please try again.');
                $button.prop('disabled', false).text('Activate');
            }
        });
    });

    $(document).on('click', '.deactivate-plugin-button', function(e) {
        e.preventDefault();
        const $button = $(this);
        const plugin = $button.data('plugin');
        
        $button.prop('disabled', true).text('Deactivating...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'deactivate_plugin',
                plugin: plugin,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    window.location.href = wordpress_inspector.admin_url + '?page=wordpress-inspector#plugins';
                    window.location.reload();
                } else {
                    alert(response.data.message || 'Failed to deactivate plugin.');
                    $button.prop('disabled', false).text('Deactivate');
                }
            },
            error: function(xhr, status, error) {
                console.error('Deactivate plugin error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to deactivate plugin. Please try again.');
                $button.prop('disabled', false).text('Deactivate');
            }
        });
    });

    $(document).on('click', '.delete-plugin-button', function(e) {
        e.preventDefault();
        if (!confirm('Are you sure you want to delete this plugin?')) {
            return;
        }

        const $button = $(this);
        const plugin = $button.data('plugin');
        const $row = $button.closest('.plugin-card');
        
        $button.prop('disabled', true).text('Deleting...');
        
        $.ajax({
            url: wordpress_inspector.ajaxurl,
            type: 'POST',
            data: {
                action: 'delete_plugin',
                plugin: plugin,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    $row.fadeOut(400, function() {
                        $(this).remove();
                        const message = $('<div class="notice notice-success"><p>' + response.data.message + '</p></div>')
                            .hide()
                            .insertBefore('.plugins-list')
                            .fadeIn();
                        setTimeout(() => message.fadeOut(() => message.remove()), 3000);
                    });
                } else {
                    alert(response.data.message || 'Failed to delete plugin.');
                    $button.prop('disabled', false).text('Delete');
                }
            },
            error: function(xhr, status, error) {
                console.error('Delete plugin error:', {
                    xhr: xhr,
                    status: status,
                    error: error
                });
                alert('Failed to delete plugin. Please try again.');
                $button.prop('disabled', false).text('Delete');
            }
        });
    });
}); 