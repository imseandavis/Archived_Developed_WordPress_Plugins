jQuery(document).ready(function($) {
    // Calculate scrollbar width
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    document.documentElement.style.setProperty('--scrollbar-width', `${scrollbarWidth}px`);

    // Function to update totals based on visible rows
    function updateTotals() {
        let totalRows = 0;
        let totalData = 0;
        let totalIndex = 0;
        let totalSize = 0;
        let totalOverhead = 0;
        
        $('#database-tables tbody tr:visible').each(function() {
            const cells = $(this).find('td');
            totalRows += parseInt(cells.eq(2).text().replace(/,/g, '')) || 0;
            totalData += parseFileSize(cells.eq(3).text());
            totalIndex += parseFileSize(cells.eq(4).text());
            totalSize += parseFileSize(cells.eq(5).text());
            totalOverhead += parseFileSize(cells.eq(6).text());
        });
        
        // Update totals row
        const totalsRow = $('#database-tables tfoot tr');
        totalsRow.find('th').eq(2).text(totalRows.toLocaleString());
        totalsRow.find('th').eq(3).text(formatFileSize(totalData));
        totalsRow.find('th').eq(4).text(formatFileSize(totalIndex));
        totalsRow.find('th').eq(5).text(formatFileSize(totalSize));
        
        // Update overhead with warning class if needed
        const overheadCell = totalsRow.find('th').eq(6);
        if (totalOverhead > 0) {
            overheadCell.html('<span class="warning">' + formatFileSize(totalOverhead) + '</span>');
        } else {
            overheadCell.text('0 B');
        }
    }

    // Helper function to parse file sizes (converts "1.5 MB", "800 KB", etc. to bytes)
    function parseFileSize(sizeStr) {
        const units = {
            'B': 1,
            'KB': 1024,
            'MB': 1024 * 1024,
            'GB': 1024 * 1024 * 1024
        };
        
        const matches = sizeStr.trim().match(/^([\d,.]+)\s*([A-Z]+)$/i);
        if (!matches) return 0;
        
        const size = parseFloat(matches[1].replace(/,/g, ''));
        const unit = matches[2].toUpperCase();
        
        return size * (units[unit] || 0);
    }

    // Helper function to format bytes back to human-readable sizes
    function formatFileSize(bytes) {
        const units = ['B', 'KB', 'MB', 'GB'];
        let size = bytes;
        let unitIndex = 0;
        
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        
        return Math.round(size * 100) / 100 + ' ' + units[unitIndex];
    }

    // Table filtering
    $('#table-search').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#database-tables tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
        updateTotals();
    });

    // Initialize ThickBox
    $('.open-permissions-help').click(function(e) {
        e.preventDefault();
        tb_show('Fix Permissions', '#TB_inline?width=600&height=550&inlineId=permissions-help-modal');
    });

    // Adjust modal position after it opens
    $(document).on('tb_init', function() {
        setTimeout(function() {
            $('#TB_window').css({
                'overflow-y': 'auto',
                'max-height': '90vh'
            });
        }, 0);
    });

    // Function to create and show a toast
    function showToast(header, message) {
        const toast = $(`
            <div class="toast">
                <div class="toast-header">${header}</div>
                <div class="toast-message">${message}</div>
                <button class="toast-close">
                    <span class="dashicons dashicons-no-alt"></span>
                </button>
            </div>
        `);
        
        $('.toast-container').append(toast);
        
        // Handle close button
        toast.find('.toast-close').click(function() {
            toast.css('animation', 'slideOut 0.3s ease-in-out forwards')
                 .one('animationend', function() {
                     $(this).remove();
                 });
        });
        
        // Auto-close after 10 seconds
        setTimeout(function() {
            if (toast.is(':visible')) {
                toast.find('.toast-close').click();
            }
        }, 10000);
    }

    // Quick Navigation handling
    $('.quick-nav-item').click(function(e) {
        e.preventDefault();
        
        // Remove active class from all items
        $('.quick-nav-item').removeClass('active');
        
        // Add active class to clicked item
        $(this).addClass('active');
        
        // Smooth scroll to target section
        const target = $($(this).attr('href'));
        if (target.length) {
            $('html, body').animate({
                scrollTop: target.offset().top - 32 // 32px offset for admin bar
            }, 500);
        }
    });

    // Update active nav item on scroll
    $(window).scroll(function() {
        const scrollPosition = $(window).scrollTop() + 100;

        $('.quick-nav-item').each(function() {
            const target = $($(this).attr('href'));
            if (target.length && target.offset().top <= scrollPosition && 
                target.offset().top + target.height() > scrollPosition) {
                $('.quick-nav-item').removeClass('active');
                $(this).addClass('active');
            }
        });
    });

    // Update the modal handling code
    const modalTriggers = document.querySelectorAll('[data-modal]');
    modalTriggers.forEach(trigger => {
        trigger.addEventListener('click', function(e) {
            e.preventDefault();
            e.stopPropagation(); // Prevent event bubbling
            
            const modalId = this.getAttribute('data-modal');
            const modal = document.getElementById(modalId);
            if (modal) {
                // Store current scroll position
                modal.dataset.scrollPos = window.scrollY;
                
                // Add modal-open class to body
                document.body.classList.add('modal-open');
                
                // Show modal
                modal.style.display = 'block';
                
                // Prevent background scroll while maintaining position
                document.body.style.top = `-${window.scrollY}px`;
                document.body.style.position = 'fixed';
                document.body.style.width = '100%';
            }
        });
    });

    // Update close handlers
    const closeButtons = document.querySelectorAll('.modal-close');
    closeButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            closeModal(this.closest('.inspector-modal'));
        });
    });

    // Update outside click handler
    window.addEventListener('click', function(e) {
        if (e.target.classList.contains('inspector-modal')) {
            closeModal(e.target);
        }
    });

    // Update escape key handler
    document.addEventListener('keydown', function(e) {
        if (e.key === 'Escape') {
            const openModal = document.querySelector('.inspector-modal[style*="display: block"]');
            if (openModal) {
                closeModal(openModal);
            }
        }
    });

    // Helper function to close modal
    function closeModal(modal) {
        if (!modal) return;
        
        // Get the stored scroll position
        const scrollY = parseInt(modal.dataset.scrollPos || '0');
        
        // Hide modal
        modal.style.display = 'none';
        
        // Remove modal-open class
        document.body.classList.remove('modal-open');
        
        // Restore body position and scroll
        document.body.style.position = '';
        document.body.style.width = '';
        document.body.style.top = '';
        
        // Restore scroll position
        window.scrollTo(0, scrollY);
    }

    // Function to update modal table totals
    function updateModalTotals() {
        let totalRows = 0;
        let totalData = 0;
        let totalIndex = 0;
        let totalSize = 0;
        let totalOverhead = 0;
        
        $('#modal-database-tables tbody tr:visible').each(function() {
            const cells = $(this).find('td');
            totalRows += parseInt(cells.eq(2).text().replace(/,/g, '')) || 0;
            totalData += parseFileSize(cells.eq(3).text() || '0 B');
            totalIndex += parseFileSize(cells.eq(4).text() || '0 B');
            totalSize += parseFileSize(cells.eq(5).text() || '0 B');
            totalOverhead += parseFileSize(cells.eq(6).text() || '0 B');
        });
        
        // Update totals row - target the totals-table specifically
        const totalsRow = $('.totals-table .totals-row');
        totalsRow.find('th:eq(2)').text(totalRows.toLocaleString());
        totalsRow.find('th:eq(3)').text(formatFileSize(totalData));
        totalsRow.find('th:eq(4)').text(formatFileSize(totalIndex));
        totalsRow.find('th:eq(5)').text(formatFileSize(totalSize));
        
        // Update overhead with warning class if needed
        const overheadCell = totalsRow.find('th:eq(6)');
        if (totalOverhead > 0) {
            overheadCell.html('<span class="warning">' + formatFileSize(totalOverhead) + '</span>');
        } else {
            overheadCell.text('0 B');
        }
    }

    // Modal table filtering
    $('#modal-table-search').on('keyup', function() {
        var value = $(this).val().toLowerCase();
        $('#modal-database-tables tbody tr').filter(function() {
            $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
        updateModalTotals();
    });

    // Initialize modal totals when modal opens
    $('.info-modal-button[data-modal="database-tables-modal"]').click(function() {
        updateModalTotals();
    });

    // Update parseFileSize function to handle empty values better
    function parseFileSize(sizeStr) {
        if (!sizeStr) return 0;
        
        const units = {
            'B': 1,
            'KB': 1024,
            'MB': 1024 * 1024,
            'GB': 1024 * 1024 * 1024
        };
        
        const matches = sizeStr.trim().match(/^([\d,.]+)\s*([A-Z]+)$/i);
        if (!matches) return 0;
        
        const size = parseFloat(matches[1].replace(/,/g, ''));
        const unit = matches[2].toUpperCase();
        
        return size * (units[unit] || 0);
    }

    // Password toggle functionality
    $('.toggle-password').on('click', function() {
        const passwordField = $(this).closest('.password-field');
        const dots = passwordField.find('.password-dots');
        const text = passwordField.find('.password-text');
        const icon = $(this).find('.dashicons');
        
        if (dots.is(':visible')) {
            dots.hide();
            text.show();
            icon.removeClass('dashicons-visibility').addClass('dashicons-hidden');
        } else {
            dots.show();
            text.hide();
            icon.removeClass('dashicons-hidden').addClass('dashicons-visibility');
        }
    });

    // Add accordion functionality
    $('.accordion-header').on('click', function() {
        const $item = $(this).parent();
        const $content = $item.find('.accordion-content');
        
        if ($item.hasClass('active')) {
            $item.removeClass('active');
            $content.slideUp(200);
        } else {
            $('.accordion-item').removeClass('active');
            $('.accordion-content').slideUp(200);
            $item.addClass('active');
            $content.slideDown(200);
        }
    });

    // Update the collapse button click handler
    $('.collapse-button').on('click', function() {
        const container = $(this).closest('.hosting-provider-container, .webserver-container, .database-container, .application-container, .php-container');
        container.toggleClass('container-collapsed');
        
        // Toggle the icon class
        const icon = $(this).find('.dashicons');
        if (container.hasClass('container-collapsed')) {
            icon.removeClass('dashicons-arrow-up-alt2').addClass('dashicons-arrow-down-alt2');
        } else {
            icon.removeClass('dashicons-arrow-down-alt2').addClass('dashicons-arrow-up-alt2');
        }
        
        // Save state to localStorage
        const containerId = container.attr('class').split(' ')[0];
        localStorage.setItem(containerId + '-collapsed', container.hasClass('container-collapsed'));
    });

    // On page load, check saved collapse states
    $('.hosting-provider-container, .webserver-container, .database-container, .application-container, .php-container').each(function() {
        const containerId = $(this).attr('class').split(' ')[0];
        const isCollapsed = localStorage.getItem(containerId + '-collapsed') === 'true';
        
        if (isCollapsed) {
            $(this).addClass('container-collapsed');
            $(this).find('.collapse-button .dashicons')
                .removeClass('dashicons-arrow-up-alt2')
                .addClass('dashicons-arrow-down-alt2');
        }
    });

    // WordPress Constants Modal Controls
    $('#show-blank-values, #show-undefined-values').on('change', function() {
        const showBlank = $('#show-blank-values').is(':checked');
        const showUndefined = $('#show-undefined-values').is(':checked');
        
        $('.constant-row').each(function() {
            if ($(this).hasClass('blank-value')) {
                $(this).toggle(showBlank);
            }
            if ($(this).hasClass('undefined-value')) {
                $(this).toggle(showUndefined);
            }
        });
    });

    // Constants filter functionality
    $('#constants-filter').on('input', function() {
        const filterValue = $(this).val().toLowerCase();
        
        $('.constant-row').each(function() {
            const constantName = $(this).find('td:first').text().toLowerCase();
            const constantValue = $(this).find('td:last').text().toLowerCase();
            const matchesFilter = constantName.includes(filterValue) || constantValue.includes(filterValue);
            const showBlank = $('#show-blank-values').is(':checked');
            const showUndefined = $('#show-undefined-values').is(':checked');
            
            // Show/hide based on both filter and checkbox states
            $(this).toggle(
                matchesFilter && 
                ((!$(this).hasClass('blank-value') || showBlank) &&
                 (!$(this).hasClass('undefined-value') || showUndefined))
            );
        });
    });

    // Add click handler for warning messages to expand container
    $('.expand-container-trigger').on('click', function() {
        const $container = $(this).closest('.hosting-provider-container');
        if ($container.hasClass('container-collapsed')) {
            $container.removeClass('container-collapsed');
            // Update localStorage
            localStorage.setItem('hosting-provider-container_collapsed', 'false');
        }
    });
});