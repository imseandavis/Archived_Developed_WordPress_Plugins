jQuery(document).ready(function($) {
    // Tab Navigation
    function switchTab(tabId) {
        // Update tabs
        $('.nav-tab').removeClass('nav-tab-active');
        $('.nav-tab[data-tab="' + tabId + '"]').addClass('nav-tab-active');
        
        // Update content
        $('.tab-content').removeClass('active');
        $('#' + tabId).addClass('active');
    }

    // Handle tab clicks
    $('.nav-tab').on('click', function(e) {
        e.preventDefault();
        const tab = $(this).data('tab');
        window.location.hash = tab;
    });

    // Handle hash changes
    $(window).on('hashchange', function() {
        const hash = window.location.hash.substring(1) || 'information';
        switchTab(hash);
    });

    // Initial tab on page load
    const initialHash = window.location.hash.substring(1) || 'information';
    switchTab(initialHash);

    // Cleanup Buttons
    $('.cleanup-button').on('click', function() {
        const button = $(this);
        const action = button.data('action');
        
        if (!confirm('Are you sure you want to perform this cleanup action?')) {
            return;
        }
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_cleanup',
                cleanup_action: action,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Cleanup completed successfully!');
                } else {
                    alert(response.data || 'Failed to perform cleanup');
                }
            },
            error: function() {
                alert('Failed to perform cleanup');
            },
            complete: function() {
                button.prop('disabled', false);
            }
        });
    });

    // Cache Buttons
    $('.cache-button').on('click', function() {
        const button = $(this);
        const action = button.data('action');
        
        if (!confirm('Are you sure you want to clear this cache?')) {
            return;
        }
        
        button.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_clear_cache',
                cache_type: action,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    alert('Cache cleared successfully!');
                } else {
                    alert(response.data || 'Failed to clear cache');
                }
            },
            error: function() {
                alert('Failed to clear cache');
            },
            complete: function() {
                button.prop('disabled', false);
            }
        });
    });

    // Debug Setting Toggles
    $('.debug-toggle').on('change', function() {
        const checkbox = $(this);
        const setting = checkbox.data('setting');
        const value = checkbox.prop('checked');
        const statusSpan = checkbox.closest('.toggle-wrapper').find('.toggle-status');
        
        checkbox.prop('disabled', true);
        statusSpan.html('Saving...');
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_update_debug_setting',
                setting: setting,
                value: value ? '1' : '0',
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    statusSpan.html(
                        value ? 
                        '<span class="status-indicator enabled">Enabled</span>' : 
                        '<span class="status-indicator disabled">Disabled</span>'
                    );
                    
                    // Show success message
                    alert('Debug setting updated successfully! The page will now reload.');
                    location.reload();
                } else {
                    checkbox.prop('checked', !value);
                    statusSpan.html(
                        !value ? 
                        '<span class="status-indicator enabled">Enabled</span>' : 
                        '<span class="status-indicator disabled">Disabled</span>'
                    );
                    alert(response.data || 'Failed to update debug setting');
                }
            },
            error: function() {
                checkbox.prop('checked', !value);
                statusSpan.html(
                    !value ? 
                    '<span class="status-indicator enabled">Enabled</span>' : 
                    '<span class="status-indicator disabled">Disabled</span>'
                );
                alert('Failed to update debug setting');
            },
            complete: function() {
                checkbox.prop('disabled', false);
            }
        });
    });

    // PHP Info Modal
    $('#view-php-info').on('click', function() {
        $('#php-info-modal').fadeIn(200);
    });

    $('.close-modal, .inspector-modal').on('click', function(e) {
        if (e.target === this) {
            $(this).closest('.inspector-modal').fadeOut(200);
        }
    });

    // Close modal on escape key
    $(document).on('keyup', function(e) {
        if (e.key === "Escape") {
            $('.inspector-modal').fadeOut(200);
        }
    });

    // PHP Extensions Modal
    $('#view-extensions').on('click', function() {
        $('#php-extensions-modal').fadeIn(200);
    });

    $('.close-modal, .inspector-modal').on('click', function(e) {
        if (e.target === this) {
            $(this).closest('.inspector-modal').fadeOut(200);
        }
    });

    // Close modal on escape key
    $(document).on('keyup', function(e) {
        if (e.key === "Escape") {
            $('.inspector-modal').fadeOut(200);
        }
    });

    // Database Tables Modal
    $('#view-tables').on('click', function() {
        $('#database-tables-modal').fadeIn(200);
    });

    // Environment Variables Modal
    $('#view-env').on('click', function() {
        $('#env-variables-modal').fadeIn(200);
    });

    // Apache Modules Modal
    $('#view-apache').on('click', function() {
        $('#apache-modules-modal').fadeIn(200);
    });

    // Constants Modal
    $('#view-constants').on('click', function() {
        $('#constants-modal').fadeIn(200);
    });

    // Constants Filters
    function updateConstantsVisibility() {
        const showBlank = $('#show-blank').prop('checked');
        const showUndefined = $('#show-undefined').prop('checked');

        $('.constant-row').each(function() {
            const row = $(this);
            const isUndefined = row.hasClass('undefined');
            const isBlank = row.hasClass('blank');

            if ((!showBlank && isBlank) || (!showUndefined && isUndefined)) {
                row.hide();
            } else {
                row.show();
            }
        });
    }

    $('#show-blank, #show-undefined').on('change', updateConstantsVisibility);

    // Handle user registration toggle
    $('.registration-toggle').on('change', function() {
        const $toggle = $(this);
        const enabled = $toggle.prop('checked');
        const $label = $toggle.closest('.value').find('.toggle-label');
        
        $toggle.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_toggle_registration',
                enable: enabled,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    $label.text(enabled ? 'Enabled' : 'Disabled');
                } else {
                    $toggle.prop('checked', !enabled);
                    alert('Failed to update setting');
                }
            },
            error: function() {
                $toggle.prop('checked', !enabled);
                alert('Failed to update setting');
            },
            complete: function() {
                $toggle.prop('disabled', false);
            }
        });
    });

    // Handle default role change
    $('.default-role-select').on('change', function() {
        const $select = $(this);
        const role = $select.val();
        const originalRole = $select.data('current');
        
        $select.prop('disabled', true);
        
        $.ajax({
            url: ajaxurl,
            type: 'POST',
            data: {
                action: 'wordpress_inspector_update_default_role',
                role: role,
                nonce: wordpress_inspector.nonce
            },
            success: function(response) {
                if (response.success) {
                    $select.data('current', role);
                } else {
                    $select.val(originalRole);
                    alert('Failed to update default role');
                }
            },
            error: function() {
                $select.val(originalRole);
                alert('Failed to update default role');
            },
            complete: function() {
                $select.prop('disabled', false);
            }
        });
    });
});