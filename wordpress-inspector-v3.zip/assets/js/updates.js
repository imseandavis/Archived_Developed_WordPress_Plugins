jQuery(document).ready(function($) {
    // Quick Actions
    $('.disable-all-updates').on('click', function() {
        if (confirm('Are you sure you want to disable all updates?')) {
            disableAllUpdates();
        }
    });

    $('.enable-all-updates').on('click', function() {
        if (confirm('Are you sure you want to enable all updates?')) {
            enableAllUpdates();
        }
    });

    $('.force-updates-check').on('click', function() {
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('Checking...');

        $.post(ajaxurl, {
            action: 'force_updates_check'
        }, function(response) {
            if (response.success) {
                location.reload();
            } else {
                alert('Error checking for updates');
                button.prop('disabled', false).text(originalText);
            }
        });
    });

    // Plugin and Theme Controls
    $('.enable-all-plugins').on('click', function() {
        $('.plugins-list input[type="checkbox"]').prop('checked', true);
    });
    
    $('.disable-all-plugins').on('click', function() {
        $('.plugins-list input[type="checkbox"]').prop('checked', false);
    });
    
    $('.enable-all-themes').on('click', function() {
        $('.themes-list input[type="checkbox"]').prop('checked', true);
    });
    
    $('.disable-all-themes').on('click', function() {
        $('.themes-list input[type="checkbox"]').prop('checked', false);
    });

    // Update Logs
    let currentPage = 1;
    let totalPages = 1;
    loadUpdateLogs();

    $('#log-search, #log-type, #log-date-start, #log-date-end').on('change', function() {
        currentPage = 1;
        loadUpdateLogs();
    });

    // Pagination controls
    $(document).on('click', '.pagination-link', function(e) {
        e.preventDefault();
        const page = $(this).data('page');
        
        if (page === 'prev' && currentPage > 1) {
            currentPage--;
        } else if (page === 'next' && currentPage < totalPages) {
            currentPage++;
        } else if (typeof page === 'number') {
            currentPage = page;
        }
        
        loadUpdateLogs();
    });

    $('.export-logs').on('click', function() {
        const format = $(this).data('format') || 'csv';
        const startDate = $('#log-date-start').val();
        const endDate = $('#log-date-end').val();
        
        let url = `${ajaxurl}?action=export_update_logs&format=${format}`;
        if (startDate) url += `&start_date=${startDate}`;
        if (endDate) url += `&end_date=${endDate}`;
        
        window.location.href = url;
    });

    // Save all settings
    $('.save-updates-settings').on('click', function() {
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('Saving...');
        
        const data = {
            action: 'save_updates_settings',
            core_updates: $('input[name="core_updates"]').is(':checked'),
            email_updates: $('input[name="email_updates"]').is(':checked'),
            translation_updates: $('input[name="translation_updates"]').is(':checked'),
            plugin_updates: [],
            theme_updates: [],
            delay_updates: $('input[name="delay_updates"]').is(':checked'),
            delay_days: $('select[name="delay_days"]').val(),
            schedule_updates: $('input[name="schedule_updates"]').is(':checked'),
            schedule_time: $('select[name="schedule_time"]').val(),
            email_reports: $('input[name="email_reports"]').is(':checked'),
            report_frequency: $('select[name="report_frequency"]').val(),
            auto_clear_logs: $('input[name="auto_clear_logs"]').is(':checked'),
            log_retention: $('select[name="log_retention"]').val()
        };
        
        // Gather plugin updates
        $('input[name="plugin_updates[]"]:checked').each(function() {
            data.plugin_updates.push($(this).val());
        });
        
        // Gather theme updates
        $('input[name="theme_updates[]"]:checked').each(function() {
            data.theme_updates.push($(this).val());
        });
        
        $.post(ajaxurl, data, function(response) {
            if (response.success) {
                showToast('Settings saved successfully!', 'success');
            } else {
                showToast('Error saving settings', 'error');
            }
            button.prop('disabled', false).text(originalText);
        });
    });

    // Helper Functions
    function loadUpdateLogs() {
        const data = {
            action: 'get_update_logs',
            page: currentPage,
            search: $('#log-search').val(),
            type: $('#log-type').val(),
            start_date: $('#log-date-start').val(),
            end_date: $('#log-date-end').val()
        };

        $.get(ajaxurl, data, function(response) {
            if (response.success) {
                renderLogs(response.data.logs);
                updatePagination(response.data.total);
            }
        });
    }

    function renderLogs(logs) {
        const tbody = $('#update-logs');
        tbody.empty();

        logs.forEach(function(log) {
            const row = $('<tr></tr>');
            row.append(`<td>${log.update_date}</td>`);
            row.append(`<td>${log.update_type}</td>`);
            row.append(`<td>${log.item_name}</td>`);
            row.append(`<td>${log.version}</td>`);
            row.append(`<td><span class="status-${log.status}">${log.status}</span></td>`);
            tbody.append(row);
        });
    }

    function updatePagination(total) {
        const perPage = 20;
        totalPages = Math.ceil(total / perPage);
        
        if (totalPages <= 1) {
            $('.pagination').remove();
            return;
        }
        
        let html = '<div class="pagination">';
        
        // Previous button
        html += `<a href="#" class="pagination-link ${currentPage === 1 ? 'disabled' : ''}" 
            data-page="prev">&laquo; Previous</a>`;
        
        // Page numbers
        for (let i = 1; i <= totalPages; i++) {
            if (i === 1 || i === totalPages || (i >= currentPage - 2 && i <= currentPage + 2)) {
                html += `<a href="#" class="pagination-link ${i === currentPage ? 'current' : ''}" 
                    data-page="${i}">${i}</a>`;
            } else if (i === currentPage - 3 || i === currentPage + 3) {
                html += '<span class="pagination-ellipsis">&hellip;</span>';
            }
        }
        
        // Next button
        html += `<a href="#" class="pagination-link ${currentPage === totalPages ? 'disabled' : ''}" 
            data-page="next">Next &raquo;</a>`;
        
        html += '</div>';
        
        $('.logs-table-wrapper').append(html);
    }

    function disableAllUpdates() {
        $('input[name="core_updates"]').prop('checked', false);
        $('input[name="translation_updates"]').prop('checked', false);
        $('.plugins-list input[type="checkbox"]').prop('checked', false);
        $('.themes-list input[type="checkbox"]').prop('checked', false);
        $('.save-updates-settings').trigger('click');
    }

    function enableAllUpdates() {
        $('input[name="core_updates"]').prop('checked', true);
        $('input[name="translation_updates"]').prop('checked', true);
        $('.plugins-list input[type="checkbox"]').prop('checked', true);
        $('.themes-list input[type="checkbox"]').prop('checked', true);
        $('.save-updates-settings').trigger('click');
    }

    function showToast(message, type = 'info') {
        const toast = $(`<div class="toast toast-${type}">${message}</div>`);
        $('.toast-container').append(toast);
        
        toast.animate({ opacity: 1, right: '20px' }, 300);
        
        setTimeout(() => {
            toast.animate({ opacity: 0, right: '-100%' }, 300, () => {
                toast.remove();
            });
        }, 3000);
    }

    // Add compatibility check functionality
    function checkPluginCompatibility(plugin) {
        const wpVersion = $('#wp-version').data('version');
        const testedVersion = plugin.tested || '0.0';
        
        if (version_compare(wpVersion, testedVersion, '>')) {
            return `<span class="compatibility-warning" title="Not tested with your WordPress version">
                ⚠️ Tested up to ${testedVersion}</span>`;
        }
        return '<span class="compatibility-ok">✓ Compatible</span>';
    }

    // Version comparison helper
    function version_compare(v1, v2, operator) {
        const v1parts = v1.split('.');
        const v2parts = v2.split('.');
        
        for (let i = 0; i < v1parts.length; ++i) {
            if (v2parts.length === i) {
                return operator === '>' ? 1 : 0;
            }
            
            if (v1parts[i] === v2parts[i]) {
                continue;
            }
            if (v1parts[i] > v2parts[i]) {
                return operator === '>' ? 1 : 0;
            }
            return operator === '<' ? 1 : 0;
        }
        
        return operator === '<' ? 1 : 0;
    }

    $('.generate-report').on('click', function() {
        const button = $(this);
        const originalText = button.text();
        button.prop('disabled', true).text('Generating...');
        
        $.post(ajaxurl, {
            action: 'generate_update_report',
            nonce: $('#wpi_updates_nonce').val()
        }, function(response) {
            if (response.success) {
                showToast('Report generated and sent to admin email!', 'success');
            } else {
                showToast('Error generating report', 'error');
            }
            button.prop('disabled', false).text(originalText);
        });
    });

    $('.remove-update-filter').on('click', function() {
        const button = $(this);
        button.prop('disabled', true);
        
        $.post(ajaxurl, {
            action: 'remove_update_filter',
            nonce: $('#wpi_updates_nonce').val()
        }, function(response) {
            if (response.success) {
                showToast('Update filter removed successfully!', 'success');
                setTimeout(() => location.reload(), 1500);
            } else {
                showToast('Error removing filter', 'error');
                button.prop('disabled', false);
            }
        });
    });
}); 