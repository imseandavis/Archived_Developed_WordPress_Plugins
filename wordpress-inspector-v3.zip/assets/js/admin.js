/**
 * WordPress Inspector Admin JavaScript
 */
const WordPressInspector = {
    /**
     * Initialize the admin functionality
     */
    init: function() {
        this.initAjaxHandlers();
        this.initTooltips();
        this.initDialogs();
    },

    /**
     * Handle AJAX requests
     * 
     * @param {Object} options AJAX options
     * @return {Promise}
     */
    ajaxRequest: function(options) {
        const defaults = {
            url: ajaxurl,
            type: 'POST',
            dataType: 'json'
        };

        const settings = { ...defaults, ...options };

        return new Promise((resolve, reject) => {
            jQuery.ajax({
                ...settings,
                success: function(response) {
                    if (response.success) {
                        resolve(response.data);
                    } else {
                        reject(response.data?.message || 'Operation failed');
                    }
                },
                error: function(xhr, status, error) {
                    reject(error);
                }
            });
        });
    },

    /**
     * Show error message
     * 
     * @param {string} message Error message to display
     */
    showError: function(message) {
        alert(message);
    },

    /**
     * Initialize tooltips
     */
    initTooltips: function() {
        jQuery('.help-icon').tooltip();
    },

    /**
     * Initialize dialogs
     */
    initDialogs: function() {
        // Dialog initialization code
    }
};

// Initialize when document is ready
jQuery(document).ready(function($) {
    WordPressInspector.init();
}); 