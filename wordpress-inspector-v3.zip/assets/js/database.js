jQuery(document).ready(function($) {
    // Modal functionality
    $('.view-tables-button').on('click', function(e) {
        e.preventDefault();
        e.stopPropagation();
        $('#database-tables-modal').addClass('show');
    });

    $('.close-modal').on('click', function() {
        $(this).closest('.database-modal').removeClass('show');
    });

    $(document).on('click', function(e) {
        if ($(e.target).hasClass('database-modal')) {
            $('.database-modal').removeClass('show');
        }
    });

    // Close modal on escape key
    $(document).keyup(function(e) {
        if (e.key === "Escape") {
            $('.database-modal').removeClass('show');
        }
    });

    // Handle disabling autoload for options
    $('.disable-autoload').on('click', function() {
        const button = $(this);
        const option = button.data('option');
        
        if (confirm('Are you sure you want to disable autoload for this option?')) {
            button.prop('disabled', true).text('Disabling...');
            
            $.post(ajaxurl, {
                action: 'disable_option_autoload',
                option: option,
                nonce: $('#wpi_database_nonce').val()
            }, function(response) {
                if (response.success) {
                    button.closest('tr').fadeOut(300, function() {
                        $(this).remove();
                    });
                } else {
                    alert('Error disabling autoload');
                    button.prop('disabled', false).text('Disable Autoload');
                }
            });
        }
    });
}); 